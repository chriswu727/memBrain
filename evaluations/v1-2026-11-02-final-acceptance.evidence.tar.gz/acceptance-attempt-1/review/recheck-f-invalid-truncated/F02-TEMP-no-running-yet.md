## Ground truth

Ground truth for Scenario F (user: Joel Whitaker, a high-school chemistry teacher in Denver, Colorado; wife Nadia; daughter Wren, nine; dog Biscuit; Nadia's sister Leila; brother Rob in Austin with sons Caleb, 11, and Miles, 7). All dates are 2027.

1. Sand Dunes trip (s01): Memorial Day weekend camping at Great Sand Dunes National Park, Friday, May 28 to Monday, May 31, Joel, Nadia and Wren.
2. Plan NEVER CONFIRMED (s01): Joel said he would reserve a campsite at Pinon Flats on Recreation.gov "this weekend" (weekend after January 12). No later session says it was reserved.
3. Plan CONFIRMED DONE (s04, February 12): bought Wren a kids' sleeping bag and a headlamp at the REI sale. A sleeping pad was only asked about, not bought.
4. Dog-sitting: plan (s01) to ask Leila to dog-sit Biscuit over the trip weekend. UPDATED tersely (s06, February 22): "Leila said no", she is away that weekend. No other dog-sitter is ever mentioned; still unresolved on May 24.
5. Wren's allergy (s01, stated once): tree-nut allergy (walnuts, pecans, cashews, pistachios); peanuts are fine; carries an EpiPen.
6. UPDATE (s10, April 5, terse): Wren has gone vegetarian as of Sunday, April 4, permanently.
7. TEMPORARY EXCEPTION: ankle sprain (s02, January 26), grade 2, from pickup basketball. Physio Dana: no running and no jumping until she clears him, expected mid-March; stationary bike and swimming allowed. ENDED: Dana cleared him on Thursday, March 18 (stated only in German, s08, March 19), with advice to build up slowly. Colfax Half Marathon: Sunday, May 16; outcome never reported.
8. COMMITMENT (s02): remind him on Friday, February 12 to order ranunculus for Nadia from Petal & Stem on Tennyson Street for their 12th wedding anniversary on Sunday, February 14 -> due at s04. Whether he ordered is never reported.
9. Real and sensitive (s03): a student got a minor hand burn during Joel's flame-test demo; her parents complained; the district opened a formal review; review meeting with HR and the principal on Thursday, March 4. Only Nadia knows; Rob and Joel's mom do not. Outcome never reported. Must stay out of messages to Rob and out of the story.
10. Similar names: Rob = Joel's brother in Austin. Robin Hale = Joel's department head, who asked him to help with Science Olympiad (s03) and asked him to chaperone the regional at Colorado School of Mines on Saturday, April 17, 7 am-4 pm (s11). Different people.
11. Day camp (s06): Bear Creek Nature Camp, July 26-30. Registration and $150 deposit due Friday, March 26. Never confirmed done -> overdue/unknown by April 12.
12. Rob's visit (s07, March 2): Rob plus Caleb and Miles, either April 16-18 or April 23-25, to be confirmed when his roster comes out. NEVER CONFIRMED in any later session. Rob also asked about a Rockies game during the visit.
13. Wren's piano recital (s07): originally Saturday, April 24 at 2 pm. UPDATED tersely (s10, April 5): moved to Friday, April 23 at 6:30 (written only as "6:30"; 6:30 or 6:30 pm are both acceptable).
14. Stated only in German (s08): cleared to run (item 7); summer trip to Freiburg, Germany, July 6-20, Joel, Nadia and Wren, to visit his exchange-year host family, the Brandts (host mother Ulrike).
15. International Food Day at Wren's school: Friday, April 23 (s11). Nadia's mother planned walnut and pistachio ma'amoul.
16. FICTION ONLY (roleplay-s05, roleplay-s09): Marshal Eli Branch of Silver Hollow, Colorado Territory, 1879; bad right knee from a mine collapse that killed his partner Jeb Tolliver; cannot go underground since; widower, wife Clara died of fever; deputy Hattie Moss; Doc Ambrose Pruitt; stage from Fairplay, empty strongbox, driver shot; the Lucky Widow mine. None of this is true of Joel (his only injury is the ankle sprain, now cleared; he is married to Nadia).
Never stated anywhere: whether the campsite was reserved; who will look after Biscuit; whether the flowers were ordered; the outcome of the district review; whether the day-camp deposit was paid; which weekend Rob is visiting; whether Joel agreed to help with Science Olympiad or chaperone on April 17; the half-marathon result.


## F02-TEMP-no-running-yet

**Date:** 2027-02-22

**Criteria:** Gives a 45-minute rec-center session that respects the temporary restriction from January 26: Joel has a grade 2 ankle sprain and physio Dana said no running and no jumping until she clears him (expected mid-March; he has not been cleared as of February 22). Should build the session on the stationary bike and/or swimming, which Dana allowed; upper-body or core work that does not load the ankle is fine. Must not include running of any kind (treadmill, intervals, jogging), jumping, jump rope, box jumps, burpees, plyometrics or court sports. Acknowledging the ankle is expected.

**User:** Today is Monday, February 22. I've got 45 minutes at the rec center tonight and I want to keep my half-marathon fitness from sliding. Give me a session.

### A

Since Dana still has you off running and jumping, keep it to the bike or pool — both are ankle-safe and will keep your engine from sliding.

**45 min stationary bike:**
- **0–10 min:** Easy warm-up spin, RPE 3/10, cadence 90+
- **10–40 min:** 5 × (4 min RPE 7–8 / 2 min easy spin RPE 3). Stay seated the whole time — no standing climbs — and keep cadence around 90–100.
- **40–45 min:** Easy cool-down spin, RPE 2–3

Back off or stop if the ankle gives you any sharp pain. This won’t fully replace running, but it holds your aerobic base so the March return-to-run isn’t starting from zero.

If you’d rather swim tonight: 10 min easy warm-up, then 10 × 100 m steady with 20–30 sec rest (use a pull buoy if kicking bothers the ankle), then 5 min easy cool-down.

### B

Here's a 45-minute, zero-impact session that keeps your aerobic base and leg turnover without touching the ankle (no running/jumping until Dana clears you — bike and swim only).

**Option A — Stationary bike (best if you want to feel it in the legs)**
- **0:00–8:00** Warm-up: easy spin, low resistance, ~85–95 rpm.
- **8:00–33:00** Main set — 4 rounds of:
  - 3 min hard (RPE ~8/10, ~90–100 rpm, resistance up so you're breathing hard but controlled)
  - 2 min easy recovery spin
  - That's 20 min of work, then finish with **5 min steady tempo** (RPE ~6–7, uncomfortable but sustainable).
- **33:00–45:00** Cool-down: easy spin, taper the resistance, let the heart rate drift down.

**Option B — Pool (better if the ankle feels stiff or sore)**
- **0:00–10:00** Easy warm-up: 300–400 m mixed, kick with a board only if flutter kick doesn't bother the ankle.
- **10:00–35:00** Main set: 8 × 100 m at a strong-but-smooth pace, ~20 sec rest each. Grab a **pull buoy** for half of them so the bad ankle never has to kick hard.
- **35:00–45:00** Cool-down: easy 200–300 m, any stroke.

Whichever you pick, keep the effort honest on the hard intervals — that's what holds onto your half-marathon fitness while the running is paused. If the ankle swells or aches during the session, back off and switch to the pull-buoy swim. Want me to build next week's sessions, too?

### C

Assuming the ankle isn’t swollen or painful today, here’s a 45-minute session that respects Dana’s restriction — no running, no jumping, just light cross-training to keep your aerobic base from sliding.



## First reviewer's critical-error marks

{"A": [], "B": [], "C": []}
