import json, sys
from pathlib import Path
review, sealed_path, scenario = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
first = json.loads((review / f"verdicts-{scenario}.json").read_text())
resolution = json.loads((review / f"resolution-{scenario}.json").read_text())
sealed = json.loads(sealed_path.read_text())
totals = {"literal": {}, "resolved": {}}
rows = []
for case, labels in first.items():
    second = json.loads((review / f"recheck-{scenario}" / f"{case}.json").read_text())
    for label, verdict in labels.items():
        arm = sealed[case][label]
        marks = set(verdict.get("critical", []))
        rec = second.get(label, {})
        confirmed = set(rec.get("confirmed", [])) & marks
        added = set(rec.get("added", []))
        literal_standing = confirmed | added
        key = f"{case}/{label}"
        override = resolution.get(key, {})
        standing = set(override.get("standing", sorted(literal_standing)))
        literal = 0 if literal_standing else verdict["score"]
        resolved = override.get("score", 0 if standing else verdict["score"])
        totals["literal"].setdefault(arm, 0); totals["literal"][arm] += literal
        totals["resolved"].setdefault(arm, 0); totals["resolved"][arm] += resolved
        rows.append({"case": case, "label": label, "arm": arm, "first_score": verdict["score"],
                     "first_critical": sorted(marks), "second_confirmed": sorted(confirmed),
                     "second_added": sorted(added), "standing_literal": sorted(literal_standing),
                     "standing_resolved": sorted(standing), "literal": literal, "resolved": resolved,
                     "resolution_note": override.get("note")})
print(json.dumps(totals, indent=1))
for row in rows:
    if row["literal"] != row["first_score"] or row["resolved"] < 1 or row["standing_resolved"]:
        print(row["case"], row["label"], row["arm"], "first", row["first_score"], "literal", row["literal"],
              "resolved", row["resolved"], "crit", row["standing_resolved"], row["resolution_note"] or "")
(review / f"tally-{scenario}.json").write_text(json.dumps({"totals": totals, "rows": rows}, indent=1))
