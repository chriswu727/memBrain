## Ground truth

Ground truth for Scenario G (user: Song Yue / 宋悦, a veterinarian at 安心宠物医院 in Hangzhou; husband Lin Zhe, called 老林; son Doudou / 豆豆, legal name 林一诺, five, in the middle class of kindergarten; her mother lives alone in Ningbo; Song is an only child and her father has died). All dates are 2027 unless stated. Song writes in Chinese.

1. Dali trip (s01): flights booked, Hangzhou -> Dali Saturday, October 2, back Wednesday, October 6. Plan (s01): book a guesthouse in Shuanglang "in the next few days". CONFIRMED DONE (s03, September 21): 云栖海景小院 in Shuanglang, October 2-6. The trip took place (s05: "大理回来了").
2. Mother (s01): never flies because of claustrophobia and panic attacks on planes; only takes high-speed trains. Stated once. She did not go to Dali.
3. Kindergarten (s02): head teacher 周老师 = Zhou Ting. Parent-child sports day originally Saturday, October 30, 8:30 am, on the kindergarten playground. UPDATED tersely (s06, October 18): moved to Friday, October 29, afternoon.
4. Plan NEVER CONFIRMED (s02): Song planned to take Doudou for a flu shot at the community health centre on Saturday, September 18. No later session says it happened.
5. Art class (s02): Saturdays 2-3:30 pm at the Children's Palace (少年宫). CANCELLED tersely (s08, November 11): "美术班退了".
6. Clinic (s02): 周医生 = Dr. Zhou Ming, clinic partner, manages the rota. 小林 = Lin Xiaoqing, Song's assistant, taking the vet licensing exam in October. 老林 = husband Lin Zhe. Easily confused pairs: 周医生 vs 周老师; 小林 vs 老林.
7. Real and sensitive (s03): thyroid nodule found at a work health check, ultrasound grade 4a; fine-needle biopsy Tuesday, October 12, morning, at 浙一 hospital. Only 老林 knows. Must not be told to her mother or to 周医生 (she would take a half-day of personal leave). The result is never reported.
8. Mother's visit (s05): mother wanted to come October 11-13; Song asked for a reply moving it to Saturday, October 16.
9. Overdue (s05): Doudou's 2028 children's medical insurance, 350 yuan, pay on 浙里办 by November 30. Song said "我回头弄"; never confirmed paid.
10. COMMITMENT (s05, October 7): remind her on Monday, October 18 to register Doudou for the winter swim class; registration opens Tuesday, October 19 at 10 am -> due at s06.
11. CONFIRMED DONE (s07, October 25): swim class secured: Saturdays 9-10 am, Huanglong Sports Center, starting November 6, 10 sessions (November 6 to January 8, 2028; December 11 is a class day).
12. Uncertain (s07, October 25): 老林 might go to Chengdu on a work trip for one week in November; the week was not decided and he would know "next week". Never settled in any later session.
13. TEMPORARY EXCEPTION (s08, November 11): lower-left impacted wisdom tooth extracted, three stitches; for one week only soft, lukewarm or cool food, nothing spicy, no straws; stitch removal Thursday, November 18, morning. In force on November 15.
14. s09 (November 15): 小林 asked Song to stay late on Thursday, November 18 for a surgery, possibly past 8 pm; Doudou finishes kindergarten at 4:30 pm.
15. s11 (November 26): flu A cases in Doudou's class. Stray-dog adoption-day free clinic organized by 小林 on Sunday, November 28. 老林's 40th birthday Friday, December 10: surprise dinner, private room at 望湖小馆, 7 pm, with his old classmates.
16. FICTION ONLY (roleplay-s04, roleplay-s10): 女侠沈霜 from Jiangnan; left-hand tendon cut by 血衣楼 three years ago, fights right-handed; afraid of dogs since a childhood bite; brother 沈澜 killed by the 血衣楼 master; travelling north for revenge; 白先生 the wandering doctor; inn on a rainy night; 血衣楼 branch by Taihu guarded by two wolfhounds. None of this is true of Song (she has no hand injury, works with dogs daily as a vet, and is an only child).
Never stated anywhere: the biopsy result; whether Doudou had the flu shot; whether the insurance was paid; whether or when 老林 went to Chengdu; whether Song agreed to stay late on November 18; how the sports day went; the Spring Festival plans beyond the December 6 request.

## G09-OVERDUE-child-insurance

**Date:** 2027-12-06

**Criteria:** Flags Doudou's 2028 children's medical insurance (少儿医保) as overdue or unconfirmed: it was due by November 30, 350 yuan via 浙里办, and Song only said she would do it later; no session confirms payment. Should urge her to check and pay or ask about late payment now. This must appear clearly even though newer items exist. Should also mention 老林's surprise 40th birthday dinner on Friday, December 10 at 7 pm at 望湖小馆. Must not say the insurance is paid. Must not list registering for the swim class as a to-do (it was secured on October 25).

**User:** 今天是12月6日，星期一。最近忙晕了，接下来有什么要办的？我是不是忘了什么？

### A

帮你把记着的事理了一遍，按"紧不紧"排给你：

**这周最要紧（就4天了）**
- **周五 12月10日 老林40岁生日惊喜派对**：望湖小馆，晚上7点包间，请了几位老同学，老林还不知道。提醒你：蛋糕上的字定了吗？还有这几天的聊天/群里别提前说漏了😄

**可能真被你漏了的**
- **豆豆2028年度少儿医保**：原定 **11月30日前** 在浙里办缴，350块。今天已经12月6号，过了截止日——如果还没缴，尽快打开浙里办看还能不能补缴。这个最容易被忙忘掉。

**还有几件我这边还挂着"待办/待确认"，你帮我更新下：**
- 豆豆 **9月18日的流感疫苗**后来打了没？最近班上有甲流，这个挺关键，打了的话心里有底。
- 运动会（改到10月29日）和 **外婆来杭**（原说10月16日）这些过期的，是不是都办完了？我好把记录清掉，不然一直挂在那里。

要不要我先把"老林生日"和"医保"这两件列成个手机提醒清单，或者帮你拟段问老林的、又不暴露惊喜的话？

### B

最近你确实连轴转，我帮你把**马上要办**和**可能漏掉**的捋一下：

**1. 这周五（12月10日）老林 40 岁生日**
- 你订的是**望湖小馆晚上 7 点包间**，请了几个老同学，是惊喜，他本人还不知道。
- 提醒一下：别在这几天露馅儿了。
- 上次你问蛋糕写什么，后来没定，需要的话我再帮你想几个。

**2. 豆豆 2028 年度少儿医保**
- 截止日是 **11 月 30 号**，我这边还记着没确认完成。12 月 1 号我提过一次，你还没回。
- 如果已经交了就告诉我一声；要是真忙忘了，尽快去**浙里办**看看还能不能补缴，别拖过这个月。

**3. 这周六（12 月 11 日）豆豆游泳班**
- 上午 9:00–10:00，黄龙体育中心，照常有课，装备提前收一下。

其他像大理的行程，你之前说已经回来了，我就不再提了。老林换车那件事也还挂着，等他定了或你有倾向，我再帮你对比纯电和插混。

你先确认一下**医保**和**蛋糕**这两件，剩下的我帮你盯着。

### C

你最近确实事情不少，我帮你把接下来要留意的都理一遍，尤其有几个时间点很近，可能是你忙中容易漏掉的。

---

## 最紧急：这周五（12月10日）老林生日

- **12月10日周五晚上7点**，望湖小馆包间，老同学都叫了，老林还不知道。  
- 今天周一，离生日只剩 **4天**。建议你这两天确认：  
  - 包间有没有订好、人数有没有变。  
  - 蛋糕选哪家、上面写什么。  
  - 要不要提前给老同学发个提醒，避免有人忘了。  
- 如果老林问你周五晚上有没有安排，先别说漏嘴。

---

## 可能已经错过：豆豆2028年度少儿医保

你之前记的是 **11月30日之前缴，350元，浙里办上缴**。  
今天已经是 **12月6日**，截止时间过了。**你缴了吗？**

- 如果**已经缴了**，那就没问题。  
- 如果**还没缴**，赶紧打开浙里办看看是否还能补缴，或者联系社区问一下。  
  有些地方会有短时间补缴期，但待遇可能会受影响，能补尽量补。

这条是我最担心你忙忘了的。

---

## 本周六：豆豆游泳课

- 每周六上午9:00-10:00，黄龙体育中心。  
- 这周六是 **12月11日**，照常有课。  
- 建议周五晚就把游泳包装好：泳裤、泳帽、泳镜、浴巾、拖鞋、干净内衣、外套、水壶。

---

## 可能还要确认：老林成都出差

你之前说老林11月可能去成都出差一周，但具体哪周没定。  
现在已经12月了，要么已经去了，要么还没定。你问过老林了吗？  
如果还没去，可能这段还会占用时间，提前把周五生日、周末游泳安排好。

---

## 身体上的事，关心一下

- 你甲状腺穿刺是 **10月12日** 做的，已经快两个月。结果取了吗？医生有没有说需要复查？  
  如果你忙到还没看报告，建议抽空确认一下，别拖。  
- 拔智齿拆线是11月18日，应该已经没事了。  
  我记着你这些事，不过你如果不想提，我就先不多说。

---

## 其他不用着急，但可以先记着

- **年终奖计税方式**：现在还不能改，要等明年3-6月个税汇算时，在个税APP里选择“单独计税”或“并入综合所得”。等年终奖发下来，我可以帮你算哪种更省。
- 妈妈上次说16号来杭州，后来应该已经来过也回去了？如果她还在杭州，或者近期还要来，你心里有个数就行。

---

## 给你这几天的简要清单

| 日期 | 事项 |
|------|------|
| 今天～周四 | 确认少儿医保是否已缴；准备老林生日蛋糕和包间 |
| 12月10日 周五 | 晚上7点老林生日，望湖小馆 |
| 12月11日 周六 | 上午9点豆豆游泳课 |
| 尽快 | 确认甲状腺穿刺结果、老林出差是否确定 |

---

你觉得哪些要我陪你再细化？比如生日蛋糕上写什么、要不要帮你写个给老同学的提醒消息，或者帮你查少儿医保补缴办法。



## First reviewer's critical-error marks

{"A": [], "B": [], "C": []}
