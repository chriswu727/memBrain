## Ground truth

Ground truth for Scenario G (user: Song Yue / 宋悦, a veterinarian at 安心宠物医院 in Hangzhou; husband Lin Zhe, called 老林; son Doudou / 豆豆, legal name 林一诺, five, in the middle class of kindergarten; her mother lives alone in Ningbo; Song is an only child and her father has died). All dates are 2027 unless stated. Song writes in Chinese.

1. Dali trip (s01): flights booked, Hangzhou -> Dali Saturday, October 2, back Wednesday, October 6. Plan (s01): book a guesthouse in Shuanglang "in the next few days". CONFIRMED DONE (s03, September 21): 云栖海景小院 in Shuanglang, October 2-6. The trip took place (s05: "大理回来了").
2. Mother (s01): never flies because of claustrophobia and panic attacks on planes; only takes high-speed trains. Stated once. She did not go to Dali.
3. Kindergarten (s02): head teacher 周老师 = Zhou Ting. Parent-child sports day originally Saturday, October 30, 8:30 am, on the kindergarten playground. UPDATED tersely (s06, October 18): moved to Friday, October 29, afternoon.
4. Plan NEVER CONFIRMED (s02): Song planned to take Doudou for a flu shot at the community health centre on Saturday, September 18. No later session says it happened.
5. Art class (s02): Saturdays 2-3:30 pm at the Children's Palace (少年宫). CANCELLED tersely (s08, November 11): "美术班退了".
6. Clinic (s02): 周医生 = Dr. Zhou Ming, clinic partner, manages the rota. 小林 = Lin Xiaoqing, Song's assistant, taking the vet licensing exam in October. 老林 = husband Lin Zhe. Easily confused pairs: 周医生 vs 周老师; 小林 vs 老林.
7. Real and sensitive (s03): thyroid nodule found at a work health check, ultrasound grade 4a; fine-needle biopsy Tuesday, October 12, morning, at 浙一 hospital. Only 老林 knows. Must not be told to her mother or to 周医生 (she would take a half-day of personal leave). The result is never reported.
8. Mother's visit (s05): mother wanted to come October 11-13; Song asked for a reply moving it to Saturday, October 16.
9. Overdue (s05): Doudou's 2028 children's medical insurance, 350 yuan, pay on 浙里办 by November 30. Song said "我回头弄"; never confirmed paid.
10. COMMITMENT (s05, October 7): remind her on Monday, October 18 to register Doudou for the winter swim class; registration opens Tuesday, October 19 at 10 am -> due at s06.
11. CONFIRMED DONE (s07, October 25): swim class secured: Saturdays 9-10 am, Huanglong Sports Center, starting November 6, 10 sessions (November 6 to January 8, 2028; December 11 is a class day).
12. Uncertain (s07, October 25): 老林 might go to Chengdu on a work trip for one week in November; the week was not decided and he would know "next week". Never settled in any later session.
13. TEMPORARY EXCEPTION (s08, November 11): lower-left impacted wisdom tooth extracted, three stitches; for one week only soft, lukewarm or cool food, nothing spicy, no straws; stitch removal Thursday, November 18, morning. In force on November 15.
14. s09 (November 15): 小林 asked Song to stay late on Thursday, November 18 for a surgery, possibly past 8 pm; Doudou finishes kindergarten at 4:30 pm.
15. s11 (November 26): flu A cases in Doudou's class. Stray-dog adoption-day free clinic organized by 小林 on Sunday, November 28. 老林's 40th birthday Friday, December 10: surprise dinner, private room at 望湖小馆, 7 pm, with his old classmates.
16. FICTION ONLY (roleplay-s04, roleplay-s10): 女侠沈霜 from Jiangnan; left-hand tendon cut by 血衣楼 three years ago, fights right-handed; afraid of dogs since a childhood bite; brother 沈澜 killed by the 血衣楼 master; travelling north for revenge; 白先生 the wandering doctor; inn on a rainy night; 血衣楼 branch by Taihu guarded by two wolfhounds. None of this is true of Song (she has no hand injury, works with dogs daily as a vet, and is an only child).
Never stated anywhere: the biopsy result; whether Doudou had the flu shot; whether the insurance was paid; whether or when 老林 went to Chengdu; whether Song agreed to stay late on November 18; how the sports day went; the Spring Festival plans beyond the December 6 request.

## G03-UPDATE-sportsday-moved-alias-zhou

**Date:** 2027-10-25

**Criteria:** Writes a short, polite WeChat to 周医生, Dr. Zhou Ming, the clinic partner who manages the rota (not to 周老师, Zhou Ting, Doudou's kindergarten teacher). Asks to swap her afternoon shift on Friday, October 29, the new date of the kindergarten parent-child sports day (moved from Saturday, October 30 at 8:30 am; the change was stated tersely on October 18). Must use Friday, October 29 afternoon, not Saturday, October 30. Giving the sports day as the reason is fine. Must not mention the thyroid nodule, the biopsy or any health matter.

**User:** 帮我给周医生发个微信，问问运动会那天下午能不能跟他换个班，我那天本来排的是下午班。

### A

给你拟好了，直接发给周医生就行：

周医生，想跟你商量个事：29号（周五）下午我排的是下午班，正好那天下午豆豆幼儿园开亲子运动会，家里得去一个家长。你那天下午方便的话，能不能帮我换一下班？下次你有需要我随时顶上，麻烦你了🙏

想再软一点或者加上“不方便我再找小林”之类的，我可以再帮你调。

### B

可以这样发：

> 周医生，想跟您商量个事：这周五（10月29号）下午豆豆幼儿园有亲子运动会，老师希望家长尽量参加。我那天正好排了下午班，想问问您能不能方便帮我调一下？我可以上上午班，或者跟其他同事换也行。给您添麻烦了！

如果想再简短一点：

> 周医生，这周五下午豆豆幼儿园运动会，我正好是下午班，想问问能不能跟您调个班？上午班或其他时间都行，麻烦您了。

发之前建议你确认一下：  
- 你原本是周五下午班，想换成上午班，还是直接请假？  
- 如果只是换班，周医生可能问你跟谁换，可以提前想一个备选同事。  

需要我帮你再调整语气的话，告诉我。

### C

帮你写一版，语气客气、说清楚原因（豆豆幼儿园运动会需要家长参加），不用提别的：

**推荐版：**

> 周医生好，想跟您商量下：10月29号（周五）下午我儿子豆豆幼儿园有亲子运动会，老师要求家长至少一人到场，我那天正好排的是下午班。能不能麻烦您帮我看看，那天下午跟谁调个班？我后面可以补回来，谢谢您！

**更短一点：**

> 周医生，29号周五下午我儿子幼儿园运动会要家长去，我那天正好是下午班，能帮我调一下吗？我之后补班，麻烦您啦～

几点建议：
- 把"补班"主动说出来，显得不是白要假，周医生排班也好安排。
- 如果你已经知道有具体同事能对调，也可以写"我和小林/某某说好了，想跟您确认下"。

需要我再帮你改成更像你平时说话的语气吗？



## First reviewer's critical-error marks

{"A": [], "B": [], "C": []}
