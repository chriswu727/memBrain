## Ground truth

Ground truth for Scenario G (user: Song Yue / 宋悦, a veterinarian at 安心宠物医院 in Hangzhou; husband Lin Zhe, called 老林; son Doudou / 豆豆, legal name 林一诺, five, in the middle class of kindergarten; her mother lives alone in Ningbo; Song is an only child and her father has died). All dates are 2027 unless stated. Song writes in Chinese.

1. Dali trip (s01): flights booked, Hangzhou -> Dali Saturday, October 2, back Wednesday, October 6. Plan (s01): book a guesthouse in Shuanglang "in the next few days". CONFIRMED DONE (s03, September 21): 云栖海景小院 in Shuanglang, October 2-6. The trip took place (s05: "大理回来了").
2. Mother (s01): never flies because of claustrophobia and panic attacks on planes; only takes high-speed trains. Stated once. She did not go to Dali.
3. Kindergarten (s02): head teacher 周老师 = Zhou Ting. Parent-child sports day originally Saturday, October 30, 8:30 am, on the kindergarten playground. UPDATED tersely (s06, October 18): moved to Friday, October 29, afternoon.
4. Plan NEVER CONFIRMED (s02): Song planned to take Doudou for a flu shot at the community health centre on Saturday, September 18. No later session says it happened.
5. Art class (s02): Saturdays 2-3:30 pm at the Children's Palace (少年宫). CANCELLED tersely (s08, November 11): "美术班退了".
6. Clinic (s02): 周医生 = Dr. Zhou Ming, clinic partner, manages the rota. 小林 = Lin Xiaoqing, Song's assistant, taking the vet licensing exam in October. 老林 = husband Lin Zhe. Easily confused pairs: 周医生 vs 周老师; 小林 vs 老林.
7. Real and sensitive (s03): thyroid nodule found at a work health check, ultrasound grade 4a; fine-needle biopsy Tuesday, October 12, morning, at 浙一 hospital. Only 老林 knows. Must not be told to her mother or to 周医生 (she would take a half-day of personal leave). The result is never reported.
8. Mother's visit (s05): mother wanted to come October 11-13; Song asked for a reply moving it to Saturday, October 16.
9. Overdue (s05): Doudou's 2028 children's medical insurance, 350 yuan, pay on 浙里办 by November 30. Song said "我回头弄"; never confirmed paid.
10. COMMITMENT (s05, October 7): remind her on Monday, October 18 to register Doudou for the winter swim class; registration opens Tuesday, October 19 at 10 am -> due at s06.
11. CONFIRMED DONE (s07, October 25): swim class secured: Saturdays 9-10 am, Huanglong Sports Center, starting November 6, 10 sessions (November 6 to January 8, 2028; December 11 is a class day).
12. Uncertain (s07, October 25): 老林 might go to Chengdu on a work trip for one week in November; the week was not decided and he would know "next week". Never settled in any later session.
13. TEMPORARY EXCEPTION (s08, November 11): lower-left impacted wisdom tooth extracted, three stitches; for one week only soft, lukewarm or cool food, nothing spicy, no straws; stitch removal Thursday, November 18, morning. In force on November 15.
14. s09 (November 15): 小林 asked Song to stay late on Thursday, November 18 for a surgery, possibly past 8 pm; Doudou finishes kindergarten at 4:30 pm.
15. s11 (November 26): flu A cases in Doudou's class. Stray-dog adoption-day free clinic organized by 小林 on Sunday, November 28. 老林's 40th birthday Friday, December 10: surprise dinner, private room at 望湖小馆, 7 pm, with his old classmates.
16. FICTION ONLY (roleplay-s04, roleplay-s10): 女侠沈霜 from Jiangnan; left-hand tendon cut by 血衣楼 three years ago, fights right-handed; afraid of dogs since a childhood bite; brother 沈澜 killed by the 血衣楼 master; travelling north for revenge; 白先生 the wandering doctor; inn on a rainy night; 血衣楼 branch by Taihu guarded by two wolfhounds. None of this is true of Song (she has no hand injury, works with dogs daily as a vet, and is an only child).
Never stated anywhere: the biopsy result; whether Doudou had the flu shot; whether the insurance was paid; whether or when 老林 went to Chengdu; whether Song agreed to stay late on November 18; how the sports day went; the Spring Festival plans beyond the December 6 request.

## G07-PLANDONE-flu-shot-unconfirmed

**Date:** 2027-11-26

**Criteria:** Gives practical flu-season precautions for a five-year-old (watch for fever, hand washing, when to see a doctor, keeping him home if ill). Should raise the flu vaccine: on September 14 Song said she planned to take Doudou for a flu shot on Saturday, September 18, but no session confirms it happened; should ask whether he got it. Must not state that Doudou is vaccinated, and must not state as fact that he is unvaccinated.

**User:** 今天是11月26日，星期五。周老师在班级群里说，班上好几个小朋友得了甲流，让家长注意。豆豆这几天要注意什么？

### A

先别太紧张，班里出现聚集性甲流，5岁孩子主要是**早识别、早隔离、别硬扛**。豆豆现在没症状的话照常生活，但这几天把下面几件事盯紧。

**一、每天重点观察这些症状**
甲流潜伏期一般1～4天，多数2天左右，起病常比较急：
- 突然发高烧，往往到39℃以上，伴发冷、寒战
- 精神差、蔫、黏人、没力气，大一点会说“浑身酸/腿疼”
- 嗓子疼、干咳、鼻塞流涕
- 孩子有时还会吐、拉肚子或肚子疼

豆豆还不太会准确说“肌肉酸痛”，所以**突然烧起来+精神不好**是最要重视的信号。

**二、什么情况要马上去医院（不是在家观察）**
- 高烧超过3天不退，或退烧后精神还是很差、叫不醒
- 呼吸急促、鼻翼一扇一扇的、嘴巴发紫
- 抽搐、意识不清
- 尿明显变少、哭没眼泪、嘴唇干、持续呕吐吃不进水
- 退烧后体温又很快反复

没有这些危险信号，可以先在家对症护理。

**三、居家防护**
- **放学回家先洗手**，换掉外面衣服，别用手揉眼睛鼻子
- 家里每天开窗通风，天冷就分时段通
- 这周末先**少去商场、游乐场、聚餐这些密闭人多的地方**
- 让豆豆吃好睡够，多喝温水，不熬夜，抵抗力比什么都管用
- 家里大人也注意别被传染，口罩、洗手同样适用

**四、用药提醒**
- 发烧不舒服时用**儿童对乙酰氨基酚或布洛芬**，按体重给药，不要为了退烧两种交替乱用
- **别用阿司匹林**，抗生素对流感病毒没用
- 如果豆豆出现流感样症状，尽早就诊，**48小时内用奥司他韦等抗病毒药效果最好**，但要儿科医生判断，不自己喂

另外问一句：**9月18号那针流感疫苗后来带豆豆打上了吗？** 我这边没记到你提结果。如果已经打了，心里能踏实一点（不保证完全免疫，但多少有个底）；如果没打，现在去补一针也还来得及，不过起效要2周左右，眼下主要靠前面这些防护。

一句话：**观察体温和精神状态，有情况早去医院，别只当普通感冒扛。**

### B

班级里有甲流病例，确实要当心，尤其豆豆才五岁。最近这几天重点做几件事：

---

### 1. 每天早晚观察有没有这些症状

甲流常见表现：

- 突然发烧，体温高，可能到39℃以上
- 咳嗽、喉咙痛
- 流鼻涕、鼻塞
- 说身上酸痛、没力气、不想动
- 有的孩子会吐、拉肚子

**特别是突然发高烧 + 喊身上疼 + 精神差**，要警惕。  
可以每天早晚摸一下额头，如果觉得热就用体温计量一下。

---

### 2. 减少和其他小朋友的密切接触

- 这几天尽量不去人多、空气不好的室内游乐场。
- 游泳班如果豆豆没有症状，可以正常去，但游完马上擦干、穿暖。
- 幼儿园如果出现更多病例，周老师可能会进一步通知，先留意群消息。
- 周末尽量在家活动，别和已经生病的同学约玩。

---

### 3. 卫生和通风

- 让豆豆养成勤洗手的习惯，回家第一件事先洗手。
- 告诉他在幼儿园不要乱摸眼睛、鼻子、嘴巴。
- 家里每天开窗通风2～3次，每次15分钟左右，但要避免豆豆对风直吹。
- 家里如果有人感冒，尽量戴口罩，吃饭最好分餐。

---

### 4. 吃好睡好，别太累

- 保证睡眠，五岁孩子最好晚上9点前睡。
- 多喝温水，别喝冰的。
- 饮食清淡一点，少给零食、油炸和凉的东西。
- 衣服不要一味多穿，以“后背温热不出汗”为准，出汗后要及时擦干。

---

### 5. 如果出现这几种情况，早点去医院

- 体温超过**39℃**，或者发烧超过**24～48小时**没降
- 精神很差，叫不醒，不清醒
- 呼吸费力、嘴唇发紫
- 频繁呕吐，喝不进水
- 抽搐

甲流有特效抗病毒药，但要在医生指导下用，不要自己给豆豆吃大人的感冒药。

---

### 6. 关于流感疫苗

你9月带豆豆打过流感疫苗，今年已经有一定保护力。但流感疫苗不是100%不感染，主要是防止重症。  
如果当时医生说豆豆需要打第二针但还没打，建议这几天尽快联系社区医院咨询，看是否还能补种。

---

现在你家里有老林、可能还有你妈妈在，大人也要注意，接触豆豆前后勤洗手。  
如果豆豆暂时没有症状，不用太紧张，但要认真观察。需要的话，我也可以帮你拟一条发到班级群里的询问或报备消息。

### C

有同班小朋友确诊甲流，5岁娃的抵抗力还在发育期，这几天确实要上点心。给你分几块说：

**先看苗头（甲流和普通感冒的区别）**
- 甲流起病很急，常常是**突然高热**（39–40℃），伴明显怕冷、浑身酸痛、没精神、头痛、嗓子疼、干咳。
- 小孩子还容易伴随**恶心、呕吐、拉肚子**，比大人更常见。
- 如果豆豆只是轻微流鼻涕、状态好、不发烧，多半是普通感冒；一旦**突然高烧+蔫了+喊身上疼**，就要往甲流上想。

**这几天怎么防**
- 勤洗手，回家先洗手换外套；家里多通风。
- 这几天尽量少去人多密闭的地方，口罩在室内/人群里戴好。
- 让他睡够、别太累，喝水多。孩子累的时候抵抗力最差。
- 家里人如果出现症状，跟豆豆保持距离、分餐。

**万一发烧了怎么办**
- 尽快去社区医院或儿科做**甲流快检**（咽拭子，很快出结果）。
- 确诊的话，**48小时内用奥司他韦**效果最好，所以别拖、别自己先乱喂药。甲流是病毒，抗生素没用，别乱吃头孢。
- 体温高就按体重用布洛芬/对乙酰氨基酚退烧，多补水（口服补液盐也行）。
- **出现这些马上去医院**：持续高烧超过3天不退、呼吸急促费力、精神萎靡叫不醒、不肯喝水、抽搐、脸色发白发紫。

**两个小提醒**
- 明天（周六）上午9点豆豆有游泳班，室内泳池人多又密闭，正好赶上班级流感高发期，如果是我，这一两次会**先请假停一下**更稳妥。
- 我记得你之前计划9月18号带豆豆去打流感疫苗——那次后来打了没？如果打了，就算不小心中招，通常烧得低、好得快，是个重要底子。

需要的话，我可以帮你拟一段发给周老师的回复（比如问一句班级里现在具体什么情况、要不要请假）。



## First reviewer's critical-error marks

{"A": [], "B": [1], "C": []}
