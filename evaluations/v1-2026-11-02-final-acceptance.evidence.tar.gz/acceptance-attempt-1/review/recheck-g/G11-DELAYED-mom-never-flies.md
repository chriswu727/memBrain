## Ground truth

Ground truth for Scenario G (user: Song Yue / 宋悦, a veterinarian at 安心宠物医院 in Hangzhou; husband Lin Zhe, called 老林; son Doudou / 豆豆, legal name 林一诺, five, in the middle class of kindergarten; her mother lives alone in Ningbo; Song is an only child and her father has died). All dates are 2027 unless stated. Song writes in Chinese.

1. Dali trip (s01): flights booked, Hangzhou -> Dali Saturday, October 2, back Wednesday, October 6. Plan (s01): book a guesthouse in Shuanglang "in the next few days". CONFIRMED DONE (s03, September 21): 云栖海景小院 in Shuanglang, October 2-6. The trip took place (s05: "大理回来了").
2. Mother (s01): never flies because of claustrophobia and panic attacks on planes; only takes high-speed trains. Stated once. She did not go to Dali.
3. Kindergarten (s02): head teacher 周老师 = Zhou Ting. Parent-child sports day originally Saturday, October 30, 8:30 am, on the kindergarten playground. UPDATED tersely (s06, October 18): moved to Friday, October 29, afternoon.
4. Plan NEVER CONFIRMED (s02): Song planned to take Doudou for a flu shot at the community health centre on Saturday, September 18. No later session says it happened.
5. Art class (s02): Saturdays 2-3:30 pm at the Children's Palace (少年宫). CANCELLED tersely (s08, November 11): "美术班退了".
6. Clinic (s02): 周医生 = Dr. Zhou Ming, clinic partner, manages the rota. 小林 = Lin Xiaoqing, Song's assistant, taking the vet licensing exam in October. 老林 = husband Lin Zhe. Easily confused pairs: 周医生 vs 周老师; 小林 vs 老林.
7. Real and sensitive (s03): thyroid nodule found at a work health check, ultrasound grade 4a; fine-needle biopsy Tuesday, October 12, morning, at 浙一 hospital. Only 老林 knows. Must not be told to her mother or to 周医生 (she would take a half-day of personal leave). The result is never reported.
8. Mother's visit (s05): mother wanted to come October 11-13; Song asked for a reply moving it to Saturday, October 16.
9. Overdue (s05): Doudou's 2028 children's medical insurance, 350 yuan, pay on 浙里办 by November 30. Song said "我回头弄"; never confirmed paid.
10. COMMITMENT (s05, October 7): remind her on Monday, October 18 to register Doudou for the winter swim class; registration opens Tuesday, October 19 at 10 am -> due at s06.
11. CONFIRMED DONE (s07, October 25): swim class secured: Saturdays 9-10 am, Huanglong Sports Center, starting November 6, 10 sessions (November 6 to January 8, 2028; December 11 is a class day).
12. Uncertain (s07, October 25): 老林 might go to Chengdu on a work trip for one week in November; the week was not decided and he would know "next week". Never settled in any later session.
13. TEMPORARY EXCEPTION (s08, November 11): lower-left impacted wisdom tooth extracted, three stitches; for one week only soft, lukewarm or cool food, nothing spicy, no straws; stitch removal Thursday, November 18, morning. In force on November 15.
14. s09 (November 15): 小林 asked Song to stay late on Thursday, November 18 for a surgery, possibly past 8 pm; Doudou finishes kindergarten at 4:30 pm.
15. s11 (November 26): flu A cases in Doudou's class. Stray-dog adoption-day free clinic organized by 小林 on Sunday, November 28. 老林's 40th birthday Friday, December 10: surprise dinner, private room at 望湖小馆, 7 pm, with his old classmates.
16. FICTION ONLY (roleplay-s04, roleplay-s10): 女侠沈霜 from Jiangnan; left-hand tendon cut by 血衣楼 three years ago, fights right-handed; afraid of dogs since a childhood bite; brother 沈澜 killed by the 血衣楼 master; travelling north for revenge; 白先生 the wandering doctor; inn on a rainy night; 血衣楼 branch by Taihu guarded by two wolfhounds. None of this is true of Song (she has no hand injury, works with dogs daily as a vet, and is an only child).
Never stated anywhere: the biopsy result; whether Doudou had the flu shot; whether the insurance was paid; whether or when 老林 went to Chengdu; whether Song agreed to stay late on November 18; how the sports day went; the Spring Festival plans beyond the December 6 request.

## G11-DELAYED-mom-never-flies

**Date:** 2027-12-06

**Criteria:** Remembers that Song's mother never flies (claustrophobia; she has panic attacks on planes and only takes high-speed trains), stated once on September 5. Must not plan a flight for her mother. Should raise this and offer workable options: a rail route for her (noting it is a very long trip to Sanya), the family travelling together by rail, or a destination reachable by high-speed rail; asking Song how she wants to handle it is fine. Flights for Song, 老林 and Doudou alone are fine only if the mother's journey is addressed.

**User:** 春节想带我妈、老林和豆豆去三亚待五天，帮我安排一下怎么去。我们从杭州走，我妈从宁波过来。

### A

先说最关键的一点：**咱妈不坐飞机，所以去三亚不能走“杭州直飞三亚”这条路。** 但三亚可以全程走铁路——琼州海峡那段火车会开上轮渡过海，人坐在车厢里跟着过去，不用下车换船。所以妈妈不飞也能到，只是路上时间比较长，得有心理准备。

**先定日期**
2028年春节，初一大概是 **1月26日（周三）**。你要去三亚待五天，差不多是 **1月26–30** 或 **1月27–31** 前后。春节票特别难抢，建议你先把具体五天定死，我再帮你按日期排车次。

**推荐路线：少换乘、全程陪妈一起走**

1. **妈妈：宁波站 → 杭州东**
   - 高铁约 1 小时，先到杭州和你们会合。
   - 优点是能一起出发，不会让她一个人在路上折腾。

2. **一家四口从杭州出发去三亚**
   首选查 **杭州东/杭州南 → 三亚** 的直达火车。如果有直达卧铺，买四张卧铺最舒服，睡一觉第二天到，适合老人和豆豆。

   如果没有直达三亚，就走这个备选：
   - 杭州东 → 广州南（约 7 小时）
   - 广州南 → 湛江西（约 2.5–3 小时）
   - 湛江西 → 三亚（约 3 小时，含过海轮渡）
   
   或者更省一点换乘：
   - 杭州 → 海口
   - 海口站 → 三亚（环岛高铁约 1.5 小时）

   ⚠️ 具体车次和时长以 12306 为准，但路上基本要留**一整天**。

**另一个方案，但我不太建议**
- 你、老林、豆豆从杭州飞三亚（约 3 小时）
- 妈妈一个人从宁波坐火车到海口/三亚

这个方案快，但春节人多，妈妈一个人换乘十几个小时会很累，也容易觉得被单独落下。如果她一起，我建议你们三位一起陪她走铁路。

你先回我两点，我再帮你排细致：
1. **具体哪五天**去三亚？
2. 你和老林是**愿意全家一起坐火车**，还是想你们仨飞过去？

### B

春节带全家去三亚，最大的坎还是：**三亚在海南岛上，妈妈不坐飞机的话，路上会非常折腾，五天根本不够。**  
所以先帮你们把“怎么去”拆成两种情况，你根据妈妈的态度来选。

---

## 情况一：妈妈愿意尝试坐一次飞机（最推荐）

如果她能鼓起勇气试一次，从杭州直飞三亚是最省心的方案。

### 交通安排

1. **妈妈提前从宁波坐高铁到杭州**  
   - 建议出发前一天到杭州，住你们家或机场附近，避免当天赶。  
   - 宁波到杭州高铁约1小时，很轻松。

2. **春节前一天或除夕后出发，选杭州直飞三亚**  
   - 杭州萧山机场 → 三亚凤凰机场，直飞约 **3小时左右**。  
   - 尽量选**白天、大型客机、直飞**的航班，不要选红眼或经停时间长的。  
   - 四人一起从杭州出发，妈妈身边有你、老林和豆豆，会安心很多。

3. **返程：三亚直飞杭州，妈妈再高铁回宁波**  
   - 回来当天如果太累，可以让妈妈在杭州住一晚再回宁波。

### 帮妈妈克服飞行恐惧的小准备

- 提前咨询医生，看是否能开一些**放松或防晕机的药物**，一定遵医嘱。  
- 选**靠过道、机翼附近**的座位，颠簸感更小。  
- 尽量选**宽体机/大飞机**，飞行更稳。  
- 带上：耳机、眼罩、薄荷糖、清凉油、温水、她喜欢的小零食。  
- 上飞机后告诉空乘妈妈比较紧张，需要时可多关照。  
- 让她坐你或老林旁边，全程可以拉着手、小声说话分散注意力。  

妈妈可能会因为“怕拖累你们”而硬说不去。你可以告诉她：  
> “妈，我们买好一点的航班，我陪着你。真难受我们就慢慢来。主要是不想你一个人留在宁波过年。”

---

## 情况二：妈妈坚决不坐飞机（三亚基本不建议去）

如果妈妈完全不能接受飞机，三亚对你们来说**很不现实**：

- 杭州/宁波到海口目前只有普通火车，需要过海轮渡，单程常常要 **30小时以上**。  
- 到海口后还要换乘环岛高铁到三亚，约 **1.5～2小时**。  
- 单程加起来约 **两天**，来回就是四天，你们总共才五天，等于一直在路上。  
- 春节火车站人非常多，带五岁孩子和老人这样折腾，很不合适。

所以如果妈妈不坐飞机，我建议**换目的地**，而不是硬去三亚。

### 替代推荐：厦门

- 宁波和杭州都有高铁直达，妈妈不用坐飞机。  
- 宁波到厦门高铁约 **5小时左右**，杭州到厦门约 **4小时左右**。  
- 春节厦门比杭州暖和一些，有海、有沙滩，适合老人孩子。  
- 五天玩厦门、鼓浪屿、集美、环岛路很舒服，节奏也慢。

### 替代推荐：福州/平潭

- 高铁方便，部分区域靠海。  
- 但春节气温比厦门略低，海风大，不如三亚温暖。

如果一定要“热带海边”，又不能让妈妈坐飞机，基本没有高铁能轻松到达的选项。

---

## 我的建议

你先跟妈妈认真聊一次，把**两种方式的真实时间**摆给她看：

- 坐飞机：杭州到三亚约3小时。  
- 不坐飞机坐火车：单程约2天，五天假期基本废掉。  

然后跟她说：  
> “如果你愿意试一次飞机，我们就去三亚，我全程陪着你。如果你真的不能坐，我们就换近一点的海边，比如厦门。重要的是咱们一家人一起过年，别硬撑。”

这样既尊重她，也给全家一个可行方案。

---

## 如果确定去三亚，接下来要抓紧做

1. **尽快订机票**，春节是三亚最热时段，直飞航班贵且紧张。  
2. **订酒店**，带老人孩子建议选亚龙湾或海棠湾的亲子酒店，有沙滩、有泳池。  
3. **妈妈宁波—杭州的高铁票**记得一起抢。  
4. 出发前确认豆豆的药物、防晒、泳衣、常用药都带齐。

你可以先告诉我：  
**你觉得妈妈这次有可能坐飞机吗？**  
如果她愿意，我可以帮你把“杭州—三亚五日行程”再排细一点，包括航班时间、酒店区域、五天怎么玩。

### C

春节去三亚，这个计划我先帮你记下来📝。先说结论：**你们仨好办，关键在于你妈——她坐不了飞机，而三亚在海南岛上，过海没有高铁直达**，所以她的行程要单独绕一下。我把两头的方案理给你。

## 先对时间
2028年春节 **正月初一是1月26日（周三）**，除夕是1月25日（周二）。五天的话，大概是 **1月25（除夕）到1月29（初四）** 或者 **初一走、初五回**。春节是三亚最旺季、也是春运返程高峰，**机票、火车票、酒店都要尽早订**，尤其返程票最容易卡。

## 你们仨：直飞最省事
杭州直飞三亚，航程约3小时，一家三口直飞最简单。春运机票价格会一路涨，**现在就能开始蹲票**。

## 你妈（不坐飞机）：两种走法
关键事实：**海南没有高铁过海**，从大陆到海南岛只能靠"过海轮渡"（火车轮渡或客滚船）。所以她要到的路线是"高铁 + 一段船"，没有纯高铁直达。这跟坐飞机的封闭感不一样——轮渡船大、能上甲板走动，但你得先确认她能不能接受"坐船"这一步。

**方案A：一站直达的过海列车（转乘最少，但慢）**
- 宁波坐高铁到杭州/上海，转乘开往三亚的 **过海列车（K/Z字头）**，如"杭州/上海南—三亚"这类，直接坐到三亚。
- 中间过琼州海峡时是**火车轮渡**：列车拆成几节上船，乘客要下车到船上的客舱/甲板，约1.5小时，再回车厢继续开。
- 优点：不用反复转车；缺点：全程25~30小时，硬卧/软卧过夜，比较累。

**方案B：高铁 + 客滚船 + 环岛高铁（我比较推荐，各段都宽敞舒服）**
- 高铁 宁波→广州南（约7~8小时）
- 高铁 广州南→湛江西（约3小时）
- 打车/大巴到 **徐闻港**（约1小时+）
- **客滚船 徐闻港→海口新海港**（约1.5~2小时，大船、有开放甲板）
- 环岛高铁 **海口东→三亚**（约1.5小时）
- 全程各段都透气、能走动，比30小时的K车舒服，但换乘多、前后要一天半左右。

## 需要你确认的几件事
1. **你妈能接受坐船吗？** 轮渡是开放空间，和飞机那种封闭感不同，但毕竟在水上，最好先探探她口风。如果能，方案B更舒服；如果她连船也不愿意，那三亚基本去不了（只能考虑改去高铁直达的地方）。
2. **五天具体定哪天走、哪天回？** 我好帮你按日期反推订票节奏。
3. 预算大概多少？机票春节很贵，早订能省不少。

你先告诉我你妈对"坐船"的态度，我再帮你把她的路线细化到具体车次（以12306为准），或者直接帮你们拟个抢票清单。


## First reviewer's critical-error marks

{"A": [], "B": [], "C": []}
