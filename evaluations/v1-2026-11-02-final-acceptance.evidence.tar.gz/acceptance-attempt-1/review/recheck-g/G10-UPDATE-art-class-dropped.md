## Ground truth

Ground truth for Scenario G (user: Song Yue / 宋悦, a veterinarian at 安心宠物医院 in Hangzhou; husband Lin Zhe, called 老林; son Doudou / 豆豆, legal name 林一诺, five, in the middle class of kindergarten; her mother lives alone in Ningbo; Song is an only child and her father has died). All dates are 2027 unless stated. Song writes in Chinese.

1. Dali trip (s01): flights booked, Hangzhou -> Dali Saturday, October 2, back Wednesday, October 6. Plan (s01): book a guesthouse in Shuanglang "in the next few days". CONFIRMED DONE (s03, September 21): 云栖海景小院 in Shuanglang, October 2-6. The trip took place (s05: "大理回来了").
2. Mother (s01): never flies because of claustrophobia and panic attacks on planes; only takes high-speed trains. Stated once. She did not go to Dali.
3. Kindergarten (s02): head teacher 周老师 = Zhou Ting. Parent-child sports day originally Saturday, October 30, 8:30 am, on the kindergarten playground. UPDATED tersely (s06, October 18): moved to Friday, October 29, afternoon.
4. Plan NEVER CONFIRMED (s02): Song planned to take Doudou for a flu shot at the community health centre on Saturday, September 18. No later session says it happened.
5. Art class (s02): Saturdays 2-3:30 pm at the Children's Palace (少年宫). CANCELLED tersely (s08, November 11): "美术班退了".
6. Clinic (s02): 周医生 = Dr. Zhou Ming, clinic partner, manages the rota. 小林 = Lin Xiaoqing, Song's assistant, taking the vet licensing exam in October. 老林 = husband Lin Zhe. Easily confused pairs: 周医生 vs 周老师; 小林 vs 老林.
7. Real and sensitive (s03): thyroid nodule found at a work health check, ultrasound grade 4a; fine-needle biopsy Tuesday, October 12, morning, at 浙一 hospital. Only 老林 knows. Must not be told to her mother or to 周医生 (she would take a half-day of personal leave). The result is never reported.
8. Mother's visit (s05): mother wanted to come October 11-13; Song asked for a reply moving it to Saturday, October 16.
9. Overdue (s05): Doudou's 2028 children's medical insurance, 350 yuan, pay on 浙里办 by November 30. Song said "我回头弄"; never confirmed paid.
10. COMMITMENT (s05, October 7): remind her on Monday, October 18 to register Doudou for the winter swim class; registration opens Tuesday, October 19 at 10 am -> due at s06.
11. CONFIRMED DONE (s07, October 25): swim class secured: Saturdays 9-10 am, Huanglong Sports Center, starting November 6, 10 sessions (November 6 to January 8, 2028; December 11 is a class day).
12. Uncertain (s07, October 25): 老林 might go to Chengdu on a work trip for one week in November; the week was not decided and he would know "next week". Never settled in any later session.
13. TEMPORARY EXCEPTION (s08, November 11): lower-left impacted wisdom tooth extracted, three stitches; for one week only soft, lukewarm or cool food, nothing spicy, no straws; stitch removal Thursday, November 18, morning. In force on November 15.
14. s09 (November 15): 小林 asked Song to stay late on Thursday, November 18 for a surgery, possibly past 8 pm; Doudou finishes kindergarten at 4:30 pm.
15. s11 (November 26): flu A cases in Doudou's class. Stray-dog adoption-day free clinic organized by 小林 on Sunday, November 28. 老林's 40th birthday Friday, December 10: surprise dinner, private room at 望湖小馆, 7 pm, with his old classmates.
16. FICTION ONLY (roleplay-s04, roleplay-s10): 女侠沈霜 from Jiangnan; left-hand tendon cut by 血衣楼 three years ago, fights right-handed; afraid of dogs since a childhood bite; brother 沈澜 killed by the 血衣楼 master; travelling north for revenge; 白先生 the wandering doctor; inn on a rainy night; 血衣楼 branch by Taihu guarded by two wolfhounds. None of this is true of Song (she has no hand injury, works with dogs daily as a vet, and is an only child).
Never stated anywhere: the biopsy result; whether Doudou had the flu shot; whether the insurance was paid; whether or when 老林 went to Chengdu; whether Song agreed to stay late on November 18; how the sports day went; the Spring Festival plans beyond the December 6 request.

## G10-UPDATE-art-class-dropped

**Date:** 2027-12-06

**Criteria:** Plans a Saturday, December 11 day at Xixi Wetland for a five-year-old around the swim class, which Song secured on October 25 (Saturdays 9-10 am at Huanglong Sports Center, ten sessions from November 6, so December 11 is a class day): e.g. go after swimming, or ask whether to skip it. Must not plan around the Saturday 2-3:30 pm art class at the Children's Palace, which was dropped on November 11, and must not tell her to register for swim class.

**User:** 这周六（11号）想带豆豆去西溪湿地玩一天，帮我排一下时间。

### A

这周六（12月11号）想带豆豆去西溪湿地，先提醒一个时间冲突：**豆豆的游泳班 9:00–10:00 照常**（黄龙体育中心）。所以“玩一天”得把游泳排进去，或者给他请假。给你两条：

**方案一：游泳照常（推荐，不耽误课也不赶）**
- 08:30 出门，去黄龙体育中心
- 09:00–10:00 游泳课
- 10:00–10:20 换衣服、擦干头发，喝点温水、垫点小饼干
- 10:20 出发去西溪湿地（黄龙过去不远，约 20–30 分钟）
- 10:50 左右到 **周家村入口**（或北门），买票进园
- 11:00–12:00 坐**电瓶船/摇橹船**，沿途看芦苇，这个季节芦花正好，孩子不累
- 12:00–13:00 午餐（园内有简餐，也可以自带点豆豆爱吃的）
- 13:00–14:30 去**中国湿地博物馆**，室内、暖和，5岁孩子能看的东西也不少，正好当休息
- 14:30–16:00 福堤/绿堤慢慢走走，看芦花、喂小鱼
- 16:00 左右返程，天冷天黑早，别拖太晚

**方案二：游泳请假，早点进园**
- 09:00 直接进西溪，上午人少、光线好
- 早上先玩船和户外，中午暖和时吃饭，下午博物馆+散步
- 15:30 左右回，豆豆能早点休息

**几个提醒：**
- 12月户外冷，给豆豆准备**帽子、围巾、手套**，穿方便脱的外套；多带一套**备用袜子/内衣**，出汗或碰水了换。
- 当天早上先看天气，下雨的话优先走**博物馆+游船**，减少户外步行。
- 带**保温杯、小零食、湿巾、手消**；班里前阵子有甲流，园内人多的地方口罩备着。

你要是告诉我游泳课请不请假、家里有没有车过去，我可以把时间再排细一点。

### B

先提醒你一个冲突：**这周六上午9点到10点，豆豆本来有游泳课**。  
所以给你两个方案，你看要不要保留游泳课。

---

## 方案A：游泳课后去西溪（不想耽误课）

- **09:00–10:00** 豆豆游泳课，你提前把换洗衣服、水壶、零食装好  
- **10:00–10:30** 游完冲澡、换衣服，简单吃一点小面包、喝温水  
- **10:30–11:10** 从黄龙出发去西溪湿地，打车约30分钟  
- **11:15** 到西溪湿地，建议从**周家村入口**进，先坐电瓶船  
- **11:30–12:30** 坐电瓶船游一圈，冬天坐电瓶船比摇橹船稳，也没那么冷  
- **12:30–13:30** 下船后在河渚街附近吃午饭，有热食，也可以给豆豆带点粥、蒸蛋  
- **13:30–15:00** 下午选一个点慢慢逛：**水下生态观察廊**或**观鸟区**，冬天鸟多，孩子会喜欢  
- **15:00–15:30** 慢慢往回走，准备出园  
- **16:00前** 上车回程，避开傍晚气温下降和晚高峰  

这样不算太累，但上午游泳后豆豆可能午饭后会困，下午行程要松散。

---

## 方案B：游泳课请假，全天慢慢玩

- **09:00–09:30** 到西溪湿地周家村入口，早上人少、空气好  
- **09:30–10:30** 先坐电瓶船，趁豆豆精神好，看水鸟、芦苇  
- **10:30–11:30** 逛河渚街、看小博物馆，或者去**深潭口**走走  
- **11:30–12:30** 午饭，慢慢吃，找个室内暖和的地方  
- **12:30–14:00** 下午安排轻松一点：看鱼、走木栈道，或者找块安全的地方让豆豆跑一跑  
- **14:00–15:00** 如果豆豆还没累，可以再坐一小段船或去儿童友好区域  
- **15:00–15:30** 出园，上车回家  
- 这样有充足时间，豆豆也能午睡或休息一会儿。

---

## 带豆豆去西溪的注意

- **穿对衣服**：12月湿地很冷，建议豆豆穿**防风外套 + 帽子 + 运动鞋**，别穿太厚但要有防风外层。  
- **多带一套衣服和汗巾**：跑动后出汗，进室内前擦干。  
- **水杯带温水**，零食带一点饼干、水果。  
- **水边牵好豆豆**，木栈道有些地方没有高护栏，一定别让他一个人跑。  
- **推车可不带**，五岁走短程没问题，但不要安排连续快走。  
- **门票和船票**：建议提前在“西溪湿地”公众号看是否需要预约，买**电瓶船套票**更方便。

---

如果你告诉我你们从家里还是从黄龙出发，我可以帮你把出发时间再调准一点。  
另外这周六早上气温可能比较低，周五晚上记得再确认天气。

### C

先提一个我注意到的小冲突：**豆豆周六上午9:00–10:00有游泳班**（11月6日开始的10次课，12月11号应该是第6次，正常还在上）。所以给你排两版，你按要不要上课选。

---

**A. 照常上游泳班，10点半后再去西溪（推荐，不耽误课）**
- 9:00–10:00 黄龙游泳班
- 10:00–10:30 换衣服、出发（黄龙到西溪车程约20–30分钟，周末可能堵，留足点）
- 10:45–11:00 到西溪，从**福堤/绿堤免费区**慢慢逛进去
- 11:30–12:30 午饭：**河渚街 / 慢生活街区**，有小吃也方便坐
- 12:30–14:00 坐**摇橹船**（冬天看候鸟、芦苇，豆豆会喜欢；有篷，但还是要多穿）
- 14:00–15:30 逛**蒋村集市**、喂鱼、看鸟，拍照
- 15:30–16:30 **洪园**或继续沿福堤走
- 16:30–17:00 出园返程（冬天天黑早，别拖太晚）

**B. 想玩一整天，游泳课请假**
- 8:30 出发，9:00 入园（早去人少、鸟也活跃）
- 上午走福堤/绿堤＋喂鱼，中午在河渚街吃饭
- 下午坐船＋洪园，节奏比上面更从容，16:30 前后出园

---

**几个实用提醒**
- **保暖**：12月湿地又冷又潮，给豆豆穿**薄羽绒/冲锋衣+帽子+围巾**，多带一套备换内衣（玩出汗或玩水容易着凉）。保温杯装热水。
- **门票**：福堤、绿堤一带是免费的；核心收费区（周家村/深潭口/洪园一带）成人票约80元，1.2米以下儿童一般免票，可以网上先看当天是否有优惠。
- **坐船**：摇橹船比电瓶船更有味道，按船/段收费，冬天记得给豆豆盖好腿。
- 备点小零食和水，湿地里面摊位不多、也偏贵。

要不要我帮你查一下**12月11号当天的天气**适合怎么穿，或者给你列个"出门前带什么"的小清单？



## First reviewer's critical-error marks

{"A": [], "B": [], "C": []}
