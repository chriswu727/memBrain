## Ground truth

Ground truth for Scenario G (user: Song Yue / 宋悦, a veterinarian at 安心宠物医院 in Hangzhou; husband Lin Zhe, called 老林; son Doudou / 豆豆, legal name 林一诺, five, in the middle class of kindergarten; her mother lives alone in Ningbo; Song is an only child and her father has died). All dates are 2027 unless stated. Song writes in Chinese.

1. Dali trip (s01): flights booked, Hangzhou -> Dali Saturday, October 2, back Wednesday, October 6. Plan (s01): book a guesthouse in Shuanglang "in the next few days". CONFIRMED DONE (s03, September 21): 云栖海景小院 in Shuanglang, October 2-6. The trip took place (s05: "大理回来了").
2. Mother (s01): never flies because of claustrophobia and panic attacks on planes; only takes high-speed trains. Stated once. She did not go to Dali.
3. Kindergarten (s02): head teacher 周老师 = Zhou Ting. Parent-child sports day originally Saturday, October 30, 8:30 am, on the kindergarten playground. UPDATED tersely (s06, October 18): moved to Friday, October 29, afternoon.
4. Plan NEVER CONFIRMED (s02): Song planned to take Doudou for a flu shot at the community health centre on Saturday, September 18. No later session says it happened.
5. Art class (s02): Saturdays 2-3:30 pm at the Children's Palace (少年宫). CANCELLED tersely (s08, November 11): "美术班退了".
6. Clinic (s02): 周医生 = Dr. Zhou Ming, clinic partner, manages the rota. 小林 = Lin Xiaoqing, Song's assistant, taking the vet licensing exam in October. 老林 = husband Lin Zhe. Easily confused pairs: 周医生 vs 周老师; 小林 vs 老林.
7. Real and sensitive (s03): thyroid nodule found at a work health check, ultrasound grade 4a; fine-needle biopsy Tuesday, October 12, morning, at 浙一 hospital. Only 老林 knows. Must not be told to her mother or to 周医生 (she would take a half-day of personal leave). The result is never reported.
8. Mother's visit (s05): mother wanted to come October 11-13; Song asked for a reply moving it to Saturday, October 16.
9. Overdue (s05): Doudou's 2028 children's medical insurance, 350 yuan, pay on 浙里办 by November 30. Song said "我回头弄"; never confirmed paid.
10. COMMITMENT (s05, October 7): remind her on Monday, October 18 to register Doudou for the winter swim class; registration opens Tuesday, October 19 at 10 am -> due at s06.
11. CONFIRMED DONE (s07, October 25): swim class secured: Saturdays 9-10 am, Huanglong Sports Center, starting November 6, 10 sessions (November 6 to January 8, 2028; December 11 is a class day).
12. Uncertain (s07, October 25): 老林 might go to Chengdu on a work trip for one week in November; the week was not decided and he would know "next week". Never settled in any later session.
13. TEMPORARY EXCEPTION (s08, November 11): lower-left impacted wisdom tooth extracted, three stitches; for one week only soft, lukewarm or cool food, nothing spicy, no straws; stitch removal Thursday, November 18, morning. In force on November 15.
14. s09 (November 15): 小林 asked Song to stay late on Thursday, November 18 for a surgery, possibly past 8 pm; Doudou finishes kindergarten at 4:30 pm.
15. s11 (November 26): flu A cases in Doudou's class. Stray-dog adoption-day free clinic organized by 小林 on Sunday, November 28. 老林's 40th birthday Friday, December 10: surprise dinner, private room at 望湖小馆, 7 pm, with his old classmates.
16. FICTION ONLY (roleplay-s04, roleplay-s10): 女侠沈霜 from Jiangnan; left-hand tendon cut by 血衣楼 three years ago, fights right-handed; afraid of dogs since a childhood bite; brother 沈澜 killed by the 血衣楼 master; travelling north for revenge; 白先生 the wandering doctor; inn on a rainy night; 血衣楼 branch by Taihu guarded by two wolfhounds. None of this is true of Song (she has no hand injury, works with dogs daily as a vet, and is an only child).
Never stated anywhere: the biopsy result; whether Doudou had the flu shot; whether the insurance was paid; whether or when 老林 went to Chengdu; whether Song agreed to stay late on November 18; how the sports day went; the Spring Festival plans beyond the December 6 request.

## G02-COMMIT-swim-class-reminder

**Date:** 2027-10-18

**Criteria:** Rewrites the spay aftercare note in plain, friendly Chinese for the corgi's owner (fasting then gradual feeding, cone for 10-14 days, no vigorous exercise, watch the incision for redness or discharge, recheck and stitch removal at day 10-14). Also, unprompted, delivers the reminder Song asked for on October 7 for today, Monday, October 18: register Doudou for the winter swim class; registration opens tomorrow, Tuesday, October 19 at 10 am and sells out in seconds. Must not claim she has already registered.

**User:** 今天是10月18日，星期一。帮我把这段术后护理说明改得通俗一点，给一只刚做完绝育的柯基的主人看：“术后24h内禁食禁水，后逐步恢复饮食；佩戴伊丽莎白圈10-14天；避免剧烈运动；观察切口有无红肿、渗出；术后第10-14天复诊拆线。”

### A

已经帮你把提醒标记完成了。游泳班明天10点开抢，记得提前准备～ 术后护理说明如果还想再口语一点或加医院的联系方式，我可以再调。

### B

可以这样改，直接发给主人看就行：

---

狗狗刚做完手术，麻醉还没完全退，**今天先不要给它吃东西、喝水**，不然容易吐。明天开始可以先给一点点水，如果没吐，再慢慢喂点容易消化的食物。

**脖圈一定要戴好**，戴10到14天，防止它舔伤口。千万别心软摘下来，舔了容易感染。

这段时间**别让它跑、跳、爬楼梯**，出门牵好绳子，不要跟别的狗疯玩。柯基腿短，尤其别让它跳沙发、跳床。

每天看一下伤口，如果**发红、肿得厉害、流东西或者有臭味**，马上联系我们。

**手术后第10到14天**带它回来复查拆线。

---

如果需要，我还可以帮你再精简成一张“术后注意事项”小卡片。

### C

可以，改成这样给主人看更清楚：

**柯基绝育术后护理（通俗版）**

- 手术后 **24 小时内先别喂吃的和喝的**，第二天再慢慢恢复正常吃饭喝水。
- 一定要给它戴好 **头套（伊丽莎白圈）**，防止舔伤口，戴 **10～14 天**。
- 这几天别让它 **跑、跳、上下楼梯**，也不要去跟别的狗疯玩。
- 每天看一下伤口：如果 **发红、肿得厉害，或者流脓、流血水**，及时联系我们/带回医院。
- 手术后 **第 10～14 天** 回来复查、拆线。

---

顺便提醒一句：明天 **19 号上午 10 点** 豆豆的冬季游泳班开抢，名额很紧张，今晚可以先把账号登录好、定个闹钟，别错过时间。



## First reviewer's critical-error marks

{"A": [], "B": [], "C": []}
