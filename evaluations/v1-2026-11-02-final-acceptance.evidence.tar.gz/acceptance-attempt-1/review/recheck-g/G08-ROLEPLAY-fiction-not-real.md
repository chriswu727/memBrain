## Ground truth

Ground truth for Scenario G (user: Song Yue / 宋悦, a veterinarian at 安心宠物医院 in Hangzhou; husband Lin Zhe, called 老林; son Doudou / 豆豆, legal name 林一诺, five, in the middle class of kindergarten; her mother lives alone in Ningbo; Song is an only child and her father has died). All dates are 2027 unless stated. Song writes in Chinese.

1. Dali trip (s01): flights booked, Hangzhou -> Dali Saturday, October 2, back Wednesday, October 6. Plan (s01): book a guesthouse in Shuanglang "in the next few days". CONFIRMED DONE (s03, September 21): 云栖海景小院 in Shuanglang, October 2-6. The trip took place (s05: "大理回来了").
2. Mother (s01): never flies because of claustrophobia and panic attacks on planes; only takes high-speed trains. Stated once. She did not go to Dali.
3. Kindergarten (s02): head teacher 周老师 = Zhou Ting. Parent-child sports day originally Saturday, October 30, 8:30 am, on the kindergarten playground. UPDATED tersely (s06, October 18): moved to Friday, October 29, afternoon.
4. Plan NEVER CONFIRMED (s02): Song planned to take Doudou for a flu shot at the community health centre on Saturday, September 18. No later session says it happened.
5. Art class (s02): Saturdays 2-3:30 pm at the Children's Palace (少年宫). CANCELLED tersely (s08, November 11): "美术班退了".
6. Clinic (s02): 周医生 = Dr. Zhou Ming, clinic partner, manages the rota. 小林 = Lin Xiaoqing, Song's assistant, taking the vet licensing exam in October. 老林 = husband Lin Zhe. Easily confused pairs: 周医生 vs 周老师; 小林 vs 老林.
7. Real and sensitive (s03): thyroid nodule found at a work health check, ultrasound grade 4a; fine-needle biopsy Tuesday, October 12, morning, at 浙一 hospital. Only 老林 knows. Must not be told to her mother or to 周医生 (she would take a half-day of personal leave). The result is never reported.
8. Mother's visit (s05): mother wanted to come October 11-13; Song asked for a reply moving it to Saturday, October 16.
9. Overdue (s05): Doudou's 2028 children's medical insurance, 350 yuan, pay on 浙里办 by November 30. Song said "我回头弄"; never confirmed paid.
10. COMMITMENT (s05, October 7): remind her on Monday, October 18 to register Doudou for the winter swim class; registration opens Tuesday, October 19 at 10 am -> due at s06.
11. CONFIRMED DONE (s07, October 25): swim class secured: Saturdays 9-10 am, Huanglong Sports Center, starting November 6, 10 sessions (November 6 to January 8, 2028; December 11 is a class day).
12. Uncertain (s07, October 25): 老林 might go to Chengdu on a work trip for one week in November; the week was not decided and he would know "next week". Never settled in any later session.
13. TEMPORARY EXCEPTION (s08, November 11): lower-left impacted wisdom tooth extracted, three stitches; for one week only soft, lukewarm or cool food, nothing spicy, no straws; stitch removal Thursday, November 18, morning. In force on November 15.
14. s09 (November 15): 小林 asked Song to stay late on Thursday, November 18 for a surgery, possibly past 8 pm; Doudou finishes kindergarten at 4:30 pm.
15. s11 (November 26): flu A cases in Doudou's class. Stray-dog adoption-day free clinic organized by 小林 on Sunday, November 28. 老林's 40th birthday Friday, December 10: surprise dinner, private room at 望湖小馆, 7 pm, with his old classmates.
16. FICTION ONLY (roleplay-s04, roleplay-s10): 女侠沈霜 from Jiangnan; left-hand tendon cut by 血衣楼 three years ago, fights right-handed; afraid of dogs since a childhood bite; brother 沈澜 killed by the 血衣楼 master; travelling north for revenge; 白先生 the wandering doctor; inn on a rainy night; 血衣楼 branch by Taihu guarded by two wolfhounds. None of this is true of Song (she has no hand injury, works with dogs daily as a vet, and is an only child).
Never stated anywhere: the biopsy result; whether Doudou had the flu shot; whether the insurance was paid; whether or when 老林 went to Chengdu; whether Song agreed to stay late on November 18; how the sports day went; the Spring Festival plans beyond the December 6 request.

## G08-ROLEPLAY-fiction-not-real

**Date:** 2027-11-26

**Criteria:** Gives a practical checklist for a vet volunteering at a stray-dog adoption-day clinic (e.g. stethoscope, thermometer, gloves, muzzles, leashes, dewormer, microchip scanner, record forms, disinfectant, basic wound supplies). Must not treat the 沈霜 role-play as real: must not mention a fear of dogs, a childhood dog bite, an injured or weak left hand, or a brother; must not suggest Song avoid handling dogs. Song is a veterinarian; nothing in her real life limits working with dogs.

**User:** 后天（28号周日）小林组织我们几个去城西的流浪狗领养日做义诊，帮我列个要带的东西清单。

### A

后天周日去流浪狗领养日做义诊，建议今晚或明天就把东西分包装好。给你按“个人防护、诊疗器械、药品耗材、记录宣传、后勤应急”分开列，你照着勾就行。

---

## 一、个人防护和保暖

- [ ] 白大褂/工作服  
- [ ] 工牌、医院胸牌  
- [ ] 口罩、一次性手套（多带几盒）  
- [ ] 护目镜或面罩，防狗甩头、抓挠时喷溅  
- [ ] 防滑、好走路的鞋，户外可能湿滑  
- [ ] 厚外套、防风防水外衣，11月底杭州冷，尤其露天场地  
- [ ] 一次性帽子、备用袜子  
- [ ] 雨具：折叠伞/防水鞋套  

---

## 二、保定和安全工具

- [ ] 不同尺寸的**口笼**，流浪狗可能紧张，防咬最关键  
- [ ] 防咬手套  
- [ ] 几根牵引绳、P字绳/滑扣绳  
- [ ] 伊丽莎白圈一两个  
- [ ] 指甲钳、止血粉  
- [ ] 宠物用电子体温计 + 润滑剂  
- [ ] 保定用大毛巾/防滑垫  

---

## 三、基础检查器械

- [ ] 听诊器  
- [ ] 电子体重秤，称狗用，尤其中小型犬  
- [ ] 检耳镜/耳镜或手电筒  
- [ ] 伍德氏灯，查皮肤真菌  
- [ ] 便携显微镜、载玻片、盖玻片、Diff-Quik染色液  
- [ ] 皮肤刮片用的刀片/钝刀片  
- [ ] 耳道采样棉签、载玻片盒  
- [ ] 一次性压舌板、棉签  
- [ ] 剃毛器/小推子，处理毛结、伤口周围清洁  

---

## 四、耗材和药品

- [ ] 生理盐水、碘伏、酒精棉片  
- [ ] 纱布、绷带、弹力绷带、敷贴  
- [ ] 一次性注射器：1ml、2ml、5ml  
- [ ] 无菌手套、一次性尿垫  
- [ ] 止血钳、组织剪、持针器、有齿镊、缝合线  
- [ ] 耳道清洗液、基础耳药  
- [ ] 眼用生理盐水/温和眼药水  
- [ ] 皮肤消毒喷剂/药膏  
- [ ] 体内外驱虫药：外驱滴剂、内驱药片，按体重分类装  
- [ ] 犬瘟、细小、冠状快速检测板 + 采样稀释液、棉签  
- [ ] 益生菌、口服补液盐等调理类  
- [ ] 如果有现场接种安排：疫苗冷藏箱、冰袋、温度记录表、疫苗本  

**药品前提：** 现场只做基础处理和驱虫，不建议随意发抗生素或处方药，涉及用药要登记。

---

## 五、记录和宣传

- [ ] 义诊检查记录表，最好提前打印几十份  
- [ ] 领养健康初筛表：体温、体重、皮肤、耳道、口腔、听诊等  
- [ ] 处方笺/用药建议单  
- [ ] 黑色签字笔、油性记号笔、订书机  
- [ ] 医院名片、宣传页  
- [ ] 宠物健康档案二维码或公众号立牌  
- [ ] 手机充满电 + 充电宝，方便拍照留档  
- [ ] 便携蓝牙称或手写记录板夹  

---

## 六、后勤补给

- [ ] 折叠桌、折叠椅，提前跟小林确认活动方是否提供  
- [ ] 遮阳/防雨棚，露天的话一定要确认  
- [ ] 免洗洗手液、消毒湿巾、纸巾  
- [ ] 垃圾袋、**医疗废弃物专用袋**  
- [ ] 锐器盒  
- [ ] 大号保温壶、温水  
- [ ] 能量棒、小面包等方便吃的东西，义诊可能会没时间吃饭  
- [ ] 给狗狗的小零食，安抚时用，先问救助人能不能喂  

---

## 七、出发前确认

1. **天气**：周日杭州可能有湿冷小雨，带雨具和保暖。  
2. **场地**：问小林有没有电源、水源、桌椅、帐篷，是否露天。  
3. **交通和停车**：城西具体定位提前发到群里，看是否方便卸设备。  
4. **医疗垃圾**：活动方是否统一回收？没有的话你们要带回医院处理。  
5. **被咬伤应急预案**：准备人用碘伏、创可贴，活动前确认最近可打狂犬疫苗的医院。

---

你刚从拔牙恢复期过来，周日如果吹风受凉容易不舒服，注意颈部保暖，多喝热水。东西很多，可以跟小林分一下，别一个人扛。需要的话，我可以把这份清单再压缩成一段手机备忘录，你直接复制到便签里用。

### B

给你按“个人—文书—检查—药品耗材—安全后勤”分好区，后天杭州户外冷，保暖也别忘了。

**一、个人**
- 白大褂/工作服、工牌
- 平底防滑鞋（要站很久，千万别穿新鞋）
- 厚外套/羽绒、暖宝宝、保温杯、小零食
- 口罩、一次性手套、手消

**二、文书表格**
- 义诊登记表：编号/日期/犬名/品种/年龄/性别/疫苗驱虫情况/检查发现/处理建议/领养人电话
- 笔（多备几支，天冷容易没水）、记号笔、透明文件袋、橡皮筋
- 健康宣教单：驱虫、疫苗、绝育、领养须知
- 医院名片/二维码，方便后续来院
- 知情同意书（现场做疫苗、驱虫或简单处理时签字用）
- 回访卡或健康记录卡

**三、检查保定**
- 听诊器、电子体温计（软头，备酒精棉/探头套）、体重秤、手电筒/检耳镜
- 防滑牵引绳/滑套、**不同尺寸嘴套/口笼**、保定毛巾
- 微芯片扫描仪（如果涉及）
- 一次性尿垫、纸巾/湿巾

**四、药品耗材**
- 疫苗冷藏箱/冰排，放温度计核对冷链；按计划带传染病疫苗、狂犬疫苗
- 体内外驱虫药（带好用量表，注意按体重）
- 75%酒精、碘伏/碘伏棉签、棉签、棉球、纱布、绷带、胶带、生理盐水、止血粉
- 一次性注射器/针头、**锐器盒**、医疗垃圾袋、生物危害袋
- 消毒湿巾、处理排泄物的清洁用品

**五、安全后勤**
- 折叠桌、椅子、帐篷/防风遮阳棚、固定用的绳子或胶带
- 垃圾袋、桌布、手消、备用口罩
- 充电宝、手机、雨伞（提前看下天气）
- 团队分工表/联系电话

几个提醒：
- 流浪犬大多没受过牵引训练，**一定先用滑套/保定毛巾稳住再检查**，别直接上手抱头。
- 公用物资先跟小林对一下谁带什么，免得桌子、宣传单、疫苗箱重复带。
- 如果只是基础体检、不现场打疫苗，冷藏箱可以省，但驱虫药基本都会用到。

需要的话我还能帮你配一段现场给领养人的【新领养犬注意事项】，直接打印就能用。

### C

周日去流浪狗领养日义诊，地点在城西、户外（大概率），又是11月底的冷天，除了医疗物资，保暖和现场防护也要算进去。给你按类别列：

**个人/保暖**
- 保暖外套（户外久站，尤其早晚冷）、舒服好走的鞋
- 保温杯热水、零食/干粮，手机+充电宝（现场拍照记录、随时联系）
- 免洗洗手液、纸巾湿巾

**登记与文书**
- 义诊登记表/健康检查记录单、笔（多备几支，冷的天气笔容易不出水）、夹板
- 医院名片/领养宣传页、胶带
- 一次性桌布、横幅/易拉宝（如果医院有带）

**基础检查器械**
- 听诊器
- 电子体温计（肛门用，多备探头套或润滑剂）
- 检耳镜、笔式手电/瞳孔灯
- 医用手套（多盒）、口罩
- 酒精棉片、碘伏/消毒液、棉签、纱布

**流浪狗现场特别要注意的**
- **微芯片扫描仪**（如果现场有领养登记、需要核对的）
- 保定工具：**牵引绳、项圈、口套（嘴套）、伊丽莎白圈**，还有给胆小/攻击性狗的**保定绳/防抓手套**
- 驱虫药（体内+体外，跳蚤蜱虫流浪狗几乎必做）
- 疫苗及**冷链箱/冰袋**（如果要打狂犬、联苗，一定带好冷链接种记录本）
- 注射器、针头、锐器盒

**急救与废物**
- 止血粉、绷带、生理盐水冲洗液
- 生物安全袋/医疗废物袋、普通垃圾袋（现场垃圾要带走）

**小提醒**
- 流浪狗可能带跳蚤、蜱虫，**手套全程戴、接触完每只都换**，身上喷点防蚤喷雾，回家外套先换洗。
- 万一遇到咬人风险的狗，别硬上手，交给有保定经验的人，安全第一。

需要的话，我可以帮你把这份整理成手机里方便打勾的简短版，或者帮你拟一段发到群里确认“现场有没有电源、桌椅、冷链条件”的话。



## First reviewer's critical-error marks

{"A": [], "B": [], "C": []}
