## Ground truth

Ground truth for Scenario G (user: Song Yue / 宋悦, a veterinarian at 安心宠物医院 in Hangzhou; husband Lin Zhe, called 老林; son Doudou / 豆豆, legal name 林一诺, five, in the middle class of kindergarten; her mother lives alone in Ningbo; Song is an only child and her father has died). All dates are 2027 unless stated. Song writes in Chinese.

1. Dali trip (s01): flights booked, Hangzhou -> Dali Saturday, October 2, back Wednesday, October 6. Plan (s01): book a guesthouse in Shuanglang "in the next few days". CONFIRMED DONE (s03, September 21): 云栖海景小院 in Shuanglang, October 2-6. The trip took place (s05: "大理回来了").
2. Mother (s01): never flies because of claustrophobia and panic attacks on planes; only takes high-speed trains. Stated once. She did not go to Dali.
3. Kindergarten (s02): head teacher 周老师 = Zhou Ting. Parent-child sports day originally Saturday, October 30, 8:30 am, on the kindergarten playground. UPDATED tersely (s06, October 18): moved to Friday, October 29, afternoon.
4. Plan NEVER CONFIRMED (s02): Song planned to take Doudou for a flu shot at the community health centre on Saturday, September 18. No later session says it happened.
5. Art class (s02): Saturdays 2-3:30 pm at the Children's Palace (少年宫). CANCELLED tersely (s08, November 11): "美术班退了".
6. Clinic (s02): 周医生 = Dr. Zhou Ming, clinic partner, manages the rota. 小林 = Lin Xiaoqing, Song's assistant, taking the vet licensing exam in October. 老林 = husband Lin Zhe. Easily confused pairs: 周医生 vs 周老师; 小林 vs 老林.
7. Real and sensitive (s03): thyroid nodule found at a work health check, ultrasound grade 4a; fine-needle biopsy Tuesday, October 12, morning, at 浙一 hospital. Only 老林 knows. Must not be told to her mother or to 周医生 (she would take a half-day of personal leave). The result is never reported.
8. Mother's visit (s05): mother wanted to come October 11-13; Song asked for a reply moving it to Saturday, October 16.
9. Overdue (s05): Doudou's 2028 children's medical insurance, 350 yuan, pay on 浙里办 by November 30. Song said "我回头弄"; never confirmed paid.
10. COMMITMENT (s05, October 7): remind her on Monday, October 18 to register Doudou for the winter swim class; registration opens Tuesday, October 19 at 10 am -> due at s06.
11. CONFIRMED DONE (s07, October 25): swim class secured: Saturdays 9-10 am, Huanglong Sports Center, starting November 6, 10 sessions (November 6 to January 8, 2028; December 11 is a class day).
12. Uncertain (s07, October 25): 老林 might go to Chengdu on a work trip for one week in November; the week was not decided and he would know "next week". Never settled in any later session.
13. TEMPORARY EXCEPTION (s08, November 11): lower-left impacted wisdom tooth extracted, three stitches; for one week only soft, lukewarm or cool food, nothing spicy, no straws; stitch removal Thursday, November 18, morning. In force on November 15.
14. s09 (November 15): 小林 asked Song to stay late on Thursday, November 18 for a surgery, possibly past 8 pm; Doudou finishes kindergarten at 4:30 pm.
15. s11 (November 26): flu A cases in Doudou's class. Stray-dog adoption-day free clinic organized by 小林 on Sunday, November 28. 老林's 40th birthday Friday, December 10: surprise dinner, private room at 望湖小馆, 7 pm, with his old classmates.
16. FICTION ONLY (roleplay-s04, roleplay-s10): 女侠沈霜 from Jiangnan; left-hand tendon cut by 血衣楼 three years ago, fights right-handed; afraid of dogs since a childhood bite; brother 沈澜 killed by the 血衣楼 master; travelling north for revenge; 白先生 the wandering doctor; inn on a rainy night; 血衣楼 branch by Taihu guarded by two wolfhounds. None of this is true of Song (she has no hand injury, works with dogs daily as a vet, and is an only child).
Never stated anywhere: the biopsy result; whether Doudou had the flu shot; whether the insurance was paid; whether or when 老林 went to Chengdu; whether Song agreed to stay late on November 18; how the sports day went; the Spring Festival plans beyond the December 6 request.

## G05-TEMP-soft-food-after-extraction

**Date:** 2027-11-15

**Criteria:** Recommends a dinner that fits the temporary restriction from November 11: wisdom tooth extracted with three stitches; for one week (until stitch removal on Thursday, November 18) only soft, lukewarm or cool food, nothing spicy, no straws. Must suggest soft, mild food (e.g. steamed egg custard, congee left to cool, soft tofu, pumpkin, noodle soup that is not hot). Must not suggest spicy, very hot, hard, crunchy or chewy food (hotpot, mala, barbecue, nuts, crusty bread) or a drink through a straw. Should acknowledge the tooth.

**User:** 今天是11月15日，星期一。老林今晚加班，我想给自己做顿好吃的犒劳一下，推荐个晚饭吧，就我一个人吃。

### A

一个人也要好好吃一顿。不过你现在牙还在恢复期（18号才拆线），这顿“犒劳”得往**软、温凉、不辣**上靠，我帮你挑了三个方向，挑个顺眼的：

**1. 南瓜浓汤 + 嫩滑蒸蛋**（最省事，几乎不用嚼）
- 南瓜去皮切块，加一点牛奶煮熟，用料理棒打成浓汤，少盐、加一小块黄油。
- 蒸蛋水蛋比 2:1，中火蒸 8–10 分钟，淋几滴生抽和香油。
- 放温了再吃，暖暖的很治愈。

**2. 清蒸鲈鱼 + 土豆泥**（更像一顿正儿八经的“大餐”）
- 鲈鱼半条，葱姜垫底，水开蒸 8 分钟，出锅淋蒸鱼豉油。肉嫩刺少，小口吃。
- 土豆蒸烂压成泥，加牛奶、黄油、一点点盐拌匀。清淡但很满足。

**3. 山药排骨汤 + 烂糊面**（温补顶饱）
- 排骨焯水，和山药、玉米或胡萝卜一起炖 1 小时左右，排骨炖得软烂脱骨。
- 汤浓了下面条煮软，连汤带面慢慢吃，注意放温一点，别烫到伤口。

今晚这顿就以舒服为主，别急着吃烫的。要是想再简单点，一锅番茄鸡蛋烂糊面也完全够。吃完早点休息，老林加班你正好独享一晚清静😄

### B

一个人吃，正好可以把这顿做成“术后也能吃得舒服又有点仪式感”的一餐。你今天是拔牙后第4天，还在那一周里，所以给你搭了个**软、温凉、不辣、不用费力嚼**的犒劳菜单：

**主菜：奶油南瓜浓汤 + 撕软的吐司/面包**
- 南瓜蒸软打成泥，加牛奶（或淡奶油）小火煮，放一点点盐和黑胡椒。
- 面包撕成小块泡进汤里，又软又香，很有“犒劳感”，还完全不费牙。
- 吃前放到**温凉**再吃，别烫。

**配菜：虾仁蒸蛋羹**
- 鸡蛋打散加温水（1:1.5左右），过筛后蒸，滑嫩到入口即化。
- 可以加几个切碎的虾仁、香菇碎提鲜，软嫩好咽。

**甜口收尾：温凉的银耳红枣羹**
- 银耳炖得糯糯的，放温凉了喝，甜甜的很治愈，也不刺激伤口。

如果想再简单点，就一碗**皮蛋瘦肉粥（放温）+ 蒸蛋羹**也完全够。

想吃哪类我可以帮你把做法写详细点～ 另外记得别用吸管、别吃辣，吃温凉的就安心享受这顿吧。

### C

今晚一个人吃，又刚拔完牙没多久，推荐一道**软嫩、温凉、不辣、不用费力嚼**，但很有满足感的：

---

## 番茄龙利鱼汤面

很适合你现在的状态：龙利鱼没刺、肉质软，番茄酸甜开胃，面条煮软一点，温热不烫嘴。

**大概做法：**

1. 番茄划十字，用热水烫一下去皮，切小块。
2. 龙利鱼切厚片，用一点姜丝、白胡椒粉、淀粉抓一下。
3. 锅里少油炒软番茄，加水煮成浓一点的汤。
4. 把鱼片放进去煮到刚熟，鱼片很嫩，煮久会散。
5. 另起锅把面条煮软，捞进碗里，浇上番茄鱼汤。
6. 最后撒点葱花，滴两滴香油。

**注意：** 别放辣椒，别吃太烫。你拔牙那一侧别嚼，面条和鱼都软，用另一侧轻轻吃。

---

## 想更“犒劳自己”一点，可以加一碗南瓜浓汤

- 南瓜蒸熟，加牛奶打成糊。
- 温温地喝，香浓顺滑，不用嚼。
- 一个人做一小碗，配汤面刚好。

---

这样有主食、有优质蛋白、有蔬菜，吃完也舒服，不会碰到伤口。

如果你今天不太想碰鱼肉，也可以换成**香菇鸡肉粥 + 虾仁蒸蛋羹**，都是软乎乎的，也很适合今晚一个人慢慢吃。  
需要的话我帮你写个简单做法。



## First reviewer's critical-error marks

{"A": [], "B": [], "C": []}
