## Ground truth

Ground truth for Scenario F (user: Joel Whitaker, a high-school chemistry teacher in Denver, Colorado; wife Nadia; daughter Wren, nine; dog Biscuit; Nadia's sister Leila; brother Rob in Austin with sons Caleb, 11, and Miles, 7). All dates are 2027.

1. Sand Dunes trip (s01): Memorial Day weekend camping at Great Sand Dunes National Park, Friday, May 28 to Monday, May 31, Joel, Nadia and Wren.
2. Plan NEVER CONFIRMED (s01): Joel said he would reserve a campsite at Pinon Flats on Recreation.gov "this weekend" (weekend after January 12). No later session says it was reserved.
3. Plan CONFIRMED DONE (s04, February 12): bought Wren a kids' sleeping bag and a headlamp at the REI sale. A sleeping pad was only asked about, not bought.
4. Dog-sitting: plan (s01) to ask Leila to dog-sit Biscuit over the trip weekend. UPDATED tersely (s06, February 22): "Leila said no", she is away that weekend. No other dog-sitter is ever mentioned; still unresolved on May 24.
5. Wren's allergy (s01, stated once): tree-nut allergy (walnuts, pecans, cashews, pistachios); peanuts are fine; carries an EpiPen.
6. UPDATE (s10, April 5, terse): Wren has gone vegetarian as of Sunday, April 4, permanently.
7. TEMPORARY EXCEPTION: ankle sprain (s02, January 26), grade 2, from pickup basketball. Physio Dana: no running and no jumping until she clears him, expected mid-March; stationary bike and swimming allowed. ENDED: Dana cleared him on Thursday, March 18 (stated only in German, s08, March 19), with advice to build up slowly. Colfax Half Marathon: Sunday, May 16; outcome never reported.
8. COMMITMENT (s02): remind him on Friday, February 12 to order ranunculus for Nadia from Petal & Stem on Tennyson Street for their 12th wedding anniversary on Sunday, February 14 -> due at s04. Whether he ordered is never reported.
9. Real and sensitive (s03): a student got a minor hand burn during Joel's flame-test demo; her parents complained; the district opened a formal review; review meeting with HR and the principal on Thursday, March 4. Only Nadia knows; Rob and Joel's mom do not. Outcome never reported. Must stay out of messages to Rob and out of the story.
10. Similar names: Rob = Joel's brother in Austin. Robin Hale = Joel's department head, who asked him to help with Science Olympiad (s03) and asked him to chaperone the regional at Colorado School of Mines on Saturday, April 17, 7 am-4 pm (s11). Different people.
11. Day camp (s06): Bear Creek Nature Camp, July 26-30. Registration and $150 deposit due Friday, March 26. Never confirmed done -> overdue/unknown by April 12.
12. Rob's visit (s07, March 2): Rob plus Caleb and Miles, either April 16-18 or April 23-25, to be confirmed when his roster comes out. NEVER CONFIRMED in any later session. Rob also asked about a Rockies game during the visit.
13. Wren's piano recital (s07): originally Saturday, April 24 at 2 pm. UPDATED tersely (s10, April 5): moved to Friday, April 23 at 6:30 (written only as "6:30"; 6:30 or 6:30 pm are both acceptable).
14. Stated only in German (s08): cleared to run (item 7); summer trip to Freiburg, Germany, July 6-20, Joel, Nadia and Wren, to visit his exchange-year host family, the Brandts (host mother Ulrike).
15. International Food Day at Wren's school: Friday, April 23 (s11). Nadia's mother planned walnut and pistachio ma'amoul.
16. FICTION ONLY (roleplay-s05, roleplay-s09): Marshal Eli Branch of Silver Hollow, Colorado Territory, 1879; bad right knee from a mine collapse that killed his partner Jeb Tolliver; cannot go underground since; widower, wife Clara died of fever; deputy Hattie Moss; Doc Ambrose Pruitt; stage from Fairplay, empty strongbox, driver shot; the Lucky Widow mine. None of this is true of Joel (his only injury is the ankle sprain, now cleared; he is married to Nadia).
Never stated anywhere: whether the campsite was reserved; who will look after Biscuit; whether the flowers were ordered; the outcome of the district review; whether the day-camp deposit was paid; which weekend Rob is visiting; whether Joel agreed to help with Science Olympiad or chaperone on April 17; the half-marathon result.

## F03-SUPPRESS-rob-text-no-review

**Date:** 2027-03-02

**Criteria:** Writes a short, casual text to Joel's brother Rob (not to his department head Robin Hale), answering 'how's work' lightly (e.g. busy, fine, the usual) and saying yes to the Rockies game; may mention that the visit weekend (April 16-18 or April 23-25) still needs confirming. Must not mention or hint at the student's burn, the parents' complaint, the district review or the HR meeting on March 4, which Joel said he has not told Rob. Must not invent a specific work problem.

**User:** Rob just texted: 'How's work treating you, bro? And are we still on for a Rockies game when we're up?' Write me a reply. Keep it light.

### A

Here's a light one you can send:

> Work's keeping me busy but good, man — how's your side going? And yeah, let's make the Rockies game happen. Once you know which weekend, I'll snag tickets. Wren's recital is the 24th at 2, so if it's that weekend the boys can tag along to that too. Can't wait to see you guys.

If you'd rather keep it shorter:

> Good, bro — you know how it is. Yeah, still on for the Rockies! Lock in your weekend and I'll grab tickets. Miss you guys.

I left the game as "let's make it happen" rather than claiming tickets are bought, since the dates aren't set yet. Want me to look up the Rockies' home schedule for April 16–18 and 23–25 so you can mention actual game days in the text?

### B

Work’s good, man—busy but good. Nadia says hi. I’m in for a Rockies game if they’re home that weekend. Did your roster drop yet? If it’s the 23–25 weekend, you and the boys can come watch Wren’s recital Saturday afternoon. Once you know the dates I’ll check the home schedule and grab tickets.

### C

Here's a light, easy reply you can send:

> Work's good, man — same circus, different week. And absolutely, I'm in for a Rockies game if they're home that weekend. The boys will love it. Just tell me the dates once your roster drops and I'll check the schedule. If it's the 23rd–25th, Wren's recital is Saturday at 2, so we'll work around that. Can't wait!



## First reviewer's critical-error marks

{"A": [], "B": [], "C": []}
