## Ground truth

Ground truth for Scenario F (user: Joel Whitaker, a high-school chemistry teacher in Denver, Colorado; wife Nadia; daughter Wren, nine; dog Biscuit; Nadia's sister Leila; brother Rob in Austin with sons Caleb, 11, and Miles, 7). All dates are 2027.

1. Sand Dunes trip (s01): Memorial Day weekend camping at Great Sand Dunes National Park, Friday, May 28 to Monday, May 31, Joel, Nadia and Wren.
2. Plan NEVER CONFIRMED (s01): Joel said he would reserve a campsite at Pinon Flats on Recreation.gov "this weekend" (weekend after January 12). No later session says it was reserved.
3. Plan CONFIRMED DONE (s04, February 12): bought Wren a kids' sleeping bag and a headlamp at the REI sale. A sleeping pad was only asked about, not bought.
4. Dog-sitting: plan (s01) to ask Leila to dog-sit Biscuit over the trip weekend. UPDATED tersely (s06, February 22): "Leila said no", she is away that weekend. No other dog-sitter is ever mentioned; still unresolved on May 24.
5. Wren's allergy (s01, stated once): tree-nut allergy (walnuts, pecans, cashews, pistachios); peanuts are fine; carries an EpiPen.
6. UPDATE (s10, April 5, terse): Wren has gone vegetarian as of Sunday, April 4, permanently.
7. TEMPORARY EXCEPTION: ankle sprain (s02, January 26), grade 2, from pickup basketball. Physio Dana: no running and no jumping until she clears him, expected mid-March; stationary bike and swimming allowed. ENDED: Dana cleared him on Thursday, March 18 (stated only in German, s08, March 19), with advice to build up slowly. Colfax Half Marathon: Sunday, May 16; outcome never reported.
8. COMMITMENT (s02): remind him on Friday, February 12 to order ranunculus for Nadia from Petal & Stem on Tennyson Street for their 12th wedding anniversary on Sunday, February 14 -> due at s04. Whether he ordered is never reported.
9. Real and sensitive (s03): a student got a minor hand burn during Joel's flame-test demo; her parents complained; the district opened a formal review; review meeting with HR and the principal on Thursday, March 4. Only Nadia knows; Rob and Joel's mom do not. Outcome never reported. Must stay out of messages to Rob and out of the story.
10. Similar names: Rob = Joel's brother in Austin. Robin Hale = Joel's department head, who asked him to help with Science Olympiad (s03) and asked him to chaperone the regional at Colorado School of Mines on Saturday, April 17, 7 am-4 pm (s11). Different people.
11. Day camp (s06): Bear Creek Nature Camp, July 26-30. Registration and $150 deposit due Friday, March 26. Never confirmed done -> overdue/unknown by April 12.
12. Rob's visit (s07, March 2): Rob plus Caleb and Miles, either April 16-18 or April 23-25, to be confirmed when his roster comes out. NEVER CONFIRMED in any later session. Rob also asked about a Rockies game during the visit.
13. Wren's piano recital (s07): originally Saturday, April 24 at 2 pm. UPDATED tersely (s10, April 5): moved to Friday, April 23 at 6:30 (written only as "6:30"; 6:30 or 6:30 pm are both acceptable).
14. Stated only in German (s08): cleared to run (item 7); summer trip to Freiburg, Germany, July 6-20, Joel, Nadia and Wren, to visit his exchange-year host family, the Brandts (host mother Ulrike).
15. International Food Day at Wren's school: Friday, April 23 (s11). Nadia's mother planned walnut and pistachio ma'amoul.
16. FICTION ONLY (roleplay-s05, roleplay-s09): Marshal Eli Branch of Silver Hollow, Colorado Territory, 1879; bad right knee from a mine collapse that killed his partner Jeb Tolliver; cannot go underground since; widower, wife Clara died of fever; deputy Hattie Moss; Doc Ambrose Pruitt; stage from Fairplay, empty strongbox, driver shot; the Lucky Widow mine. None of this is true of Joel (his only injury is the ankle sprain, now cleared; he is married to Nadia).
Never stated anywhere: whether the campsite was reserved; who will look after Biscuit; whether the flowers were ordered; the outcome of the district review; whether the day-camp deposit was paid; which weekend Rob is visiting; whether Joel agreed to help with Science Olympiad or chaperone on April 17; the half-marathon result.

## F09-PLANDONE-campsite-unconfirmed

**Date:** 2027-05-24

**Criteria:** Flags the campsite as the critical open item: on January 12 Joel said he would reserve a site at Pinon Flats on Recreation.gov 'this weekend', but no session confirms the reservation; he should check it now. Flags Biscuit's care as unresolved: Leila said no on February 22 and no other dog-sitter was ever mentioned. Must not say Leila is taking Biscuit. Must not tell him to buy Wren a sleeping bag or headlamp (he said on February 12 that he had already bought them); asking about a sleeping pad is fine. Reminding him to pack Wren's EpiPen is a bonus. Must not state the campsite is booked.

**User:** Today is Monday, May 24. We head to the Sand Dunes on Friday! What do I still need to sort out before we go?

### A

Four days out — exciting! A few things in my notes from January are still marked as *not confirmed done*, so let me flag those before the checklist:

1. **Campsite** — did the Pinon Flats reservation actually go through? (If not, on Memorial Day weekend that's the one that matters most; The Oasis just outside the park would be the fallback, but sites will be scarce.)
2. **Biscuit** — did Leila confirm she can dog-sit?
3. **Your ankle** — Dana's target was mid-March to clear you. If she did, you're fine to hit the dunes; if you're still being cautious, steep loose sand is exactly the uneven loading to watch out for.

Then the usual last-week stuff for the Sand Dunes specifically:

- **Medano Creek** — late May/early June is peak "surge flow" season, so expect wet feet and kids playing in the creek. Water shoes + a change of clothes for Wren.
- **Heat & timing** — sand surface can get brutally hot on sunny afternoons. Do the dunes early morning or evening; keep midday for the creek, shade, or the visitor center. Hats and sunglasses.
- **Altitude** — the park sits around 7,500 ft and the dunes rise higher. You live at 5,300 ft so it won't be terrible, but hydrate and take the first day easy.
- **Wind & sand** — afternoon wind can be serious. Zip phones/cameras into bags, and have a buff/bandana handy for blowing sand.
- **Wren** — tree-nut-free snacks and meals for the whole trip, and her EpiPen somewhere everyone knows (not buried in a pack).
- **Food storage** — bear country: food and coolers locked in the car at night.
- **Fire** — check current San Luis Valley fire restrictions before leaving; burn bans are common.

Tell me where the campsite and dog-sitter stand and I'll update my notes — happy to turn this into a tidy packing checklist too.

### B

Four days out — here’s what I’d lock down before Friday.

## 1. Confirm the two big things first

- **Piñon Flats reservation:** if you haven’t already, verify it on Recreation.gov and save/screenshot the confirmation. If it fell through, check today for:
  - **Great Sand Dunes Oasis** just outside the park
  - **Zapata Falls Campground** (BLM)
  - Recreation.gov cancellations

- **Biscuit care:** Leila said no, so if you haven’t found a kennel or pet sitter, do it **today**. Memorial Day boarding fills up. If it’s a new boarder, confirm they have Biscuit’s vaccine records and any food/medication needs.

## 2. Wren food and allergy plan

- Wren is vegetarian now, so plan a few easy camp meals:
  - pasta with red sauce or pesto
  - veggie chili or canned black beans
  - campfire quesadillas
  - PB&J, oatmeal, fruit, hummus and veggies
- Bring enough **tree-nut-free** snacks and read labels on granola bars, trail mix, etc.
- Pack **EpiPen, antihistamines, and a copy of her allergy plan** in the car, not buried in a bag.
- Keep all food in a bear box or hard-sided vehicle, especially at night.

## 3. Gear to double-check

- **Wren’s sleeping pad:** if she doesn’t have one yet, she needs it. A sleeping bag alone isn’t enough on cold ground.
- **Clothing layers:** warm days, cold nights, possible afternoon storms. Pack:
  - sun hat, sunglasses, sunscreen, lip balm
  - rain jacket or shell
  - warm layers for nights in the 30s–40s
  - closed-toe shoes for sand/hiking
- **Water shoes/sandals** for Medano Creek, plus a towel and change of clothes.
- **Sand gear:** sunglasses or goggles, a neck gaiter/buff for wind, and sandboards/sleds if wanted. Rent ahead because holiday weekend gear can sell out.
- **Shelter/shade:** campsites may have little shade. A tarp or pop-up shade is useful.
- **Water:** bring more than you think, plus water jugs for camp. Fill them before leaving.
- **Fuel:** check propane/camp-stove fuel; don’t wait until Friday.
- **Gas:** fill up before the park. There’s no gas in the park; Alamosa is usually the most convenient last fill.

## 4. Park conditions and safety

- **Medano Creek:** late May can bring strong snowmelt flow. Check the NPS current conditions page. The water will be cold; keep Wren close if the creek is moving fast.
- **Weather:** check the Friday–Monday forecast now, but expect:
  - intense sun and hot sand midday
  - cold nights
  - possible thunderstorms
- **Fire restrictions:** check current Great Sand Dunes fire rules. Have a camp stove as backup so dinner isn’t fire-dependent.
- **Food storage:** use lockers or hard-sided vehicle. Not in the tent.
- **Cell service:** limited. Download:
  - park map
  - reservation confirmation
  - offline maps for the drive
  - directions to backup campgrounds

## 5. Quick day-by-day

**Today/Tuesday**
- Confirm camping reservation and Biscuit care
- Check weather + Medano Creek flow + fire restrictions
- Write meal plan and food list
- Check EpiPen and any meds

**Wednesday/Thursday**
- Shop for food and any missing gear
- Prep/cook food if possible
- Charge headlamps, phones, battery packs
- Download maps and confirm route/traffic

**Thursday night**
- Load the car except cold food
- Fill water jugs
- Check tire pressure and gas

**Friday morning**
- Leave early — Memorial Day weekend traffic will build
- Stop for fuel/food in Alamosa if needed
- Aim to arrive before peak check-in if you can

If you want, I can make a quick menu for Friday–Monday that’s vegetarian, tree-nut-free, and needs minimal cooler space.

### C

Big one first: I still have your **Pinon Flats reservation** marked as “plan to book,” not confirmed. Do you have a confirmation email with site number and dates? If not, check Recreation.gov today — cancellations do show up, but Memorial Day weekend is peak time.

Here’s your quick pre-departure checklist:

**Confirm before Friday**
- **Pinon Flats reservation** — confirmation email, site #, check-in time.
- **Leila dog-sitting Biscuit** — confirmed? Remind her you leave Friday and return Monday late afternoon.
- **Wren’s sleeping pad** — she’s got the sleeping bag and headlamp, but the pad is what keeps her warm from the cold ground. If you never grabbed one, any closed-cell foam pad works.

**Gear**
- Layers for cold nights (can still hit the 30s) plus hot, windy days.
- Sun hat, sunglasses, sunscreen — the sun is intense at 8,200 ft.
- Water shoes or old sneakers for **Medano Creek**; late May is often prime snowmelt flow. Bring a towel and change of clothes for Wren.
- Headlamps, camp chairs, and a small tarp or picnic blanket for sand/wind.

**Food**
- Wren is vegetarian and the kitchen is tree-nut-free — so plan camp meals accordingly. Watch trail mixes and pesto; use seeds, pretzels, dried fruit instead.
- Bring more water than you think; check current campground/park alerts for water status.
- Store food and scented items in the car or bear lockers, not the tent.

**Logistics**
- Fill gas in **Alamosa or Mosca** — no gas inside the park.
- Have your park pass or money for the entry fee; download offline maps for the park and route.
- Check **fire restrictions and weather** on the NPS site before leaving.
- Leave early Friday — holiday traffic plus a ~4-hour drive from Denver.

Want help with a vegetarian, nut-free camping meal plan for the weekend? I can put together something simple you can prep ahead.



## First reviewer's critical-error marks

{"A": [3], "B": [], "C": [3]}
