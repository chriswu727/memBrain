## Ground truth

Ground truth for Scenario F (user: Joel Whitaker, a high-school chemistry teacher in Denver, Colorado; wife Nadia; daughter Wren, nine; dog Biscuit; Nadia's sister Leila; brother Rob in Austin with sons Caleb, 11, and Miles, 7). All dates are 2027.

1. Sand Dunes trip (s01): Memorial Day weekend camping at Great Sand Dunes National Park, Friday, May 28 to Monday, May 31, Joel, Nadia and Wren.
2. Plan NEVER CONFIRMED (s01): Joel said he would reserve a campsite at Pinon Flats on Recreation.gov "this weekend" (weekend after January 12). No later session says it was reserved.
3. Plan CONFIRMED DONE (s04, February 12): bought Wren a kids' sleeping bag and a headlamp at the REI sale. A sleeping pad was only asked about, not bought.
4. Dog-sitting: plan (s01) to ask Leila to dog-sit Biscuit over the trip weekend. UPDATED tersely (s06, February 22): "Leila said no", she is away that weekend. No other dog-sitter is ever mentioned; still unresolved on May 24.
5. Wren's allergy (s01, stated once): tree-nut allergy (walnuts, pecans, cashews, pistachios); peanuts are fine; carries an EpiPen.
6. UPDATE (s10, April 5, terse): Wren has gone vegetarian as of Sunday, April 4, permanently.
7. TEMPORARY EXCEPTION: ankle sprain (s02, January 26), grade 2, from pickup basketball. Physio Dana: no running and no jumping until she clears him, expected mid-March; stationary bike and swimming allowed. ENDED: Dana cleared him on Thursday, March 18 (stated only in German, s08, March 19), with advice to build up slowly. Colfax Half Marathon: Sunday, May 16; outcome never reported.
8. COMMITMENT (s02): remind him on Friday, February 12 to order ranunculus for Nadia from Petal & Stem on Tennyson Street for their 12th wedding anniversary on Sunday, February 14 -> due at s04. Whether he ordered is never reported.
9. Real and sensitive (s03): a student got a minor hand burn during Joel's flame-test demo; her parents complained; the district opened a formal review; review meeting with HR and the principal on Thursday, March 4. Only Nadia knows; Rob and Joel's mom do not. Outcome never reported. Must stay out of messages to Rob and out of the story.
10. Similar names: Rob = Joel's brother in Austin. Robin Hale = Joel's department head, who asked him to help with Science Olympiad (s03) and asked him to chaperone the regional at Colorado School of Mines on Saturday, April 17, 7 am-4 pm (s11). Different people.
11. Day camp (s06): Bear Creek Nature Camp, July 26-30. Registration and $150 deposit due Friday, March 26. Never confirmed done -> overdue/unknown by April 12.
12. Rob's visit (s07, March 2): Rob plus Caleb and Miles, either April 16-18 or April 23-25, to be confirmed when his roster comes out. NEVER CONFIRMED in any later session. Rob also asked about a Rockies game during the visit.
13. Wren's piano recital (s07): originally Saturday, April 24 at 2 pm. UPDATED tersely (s10, April 5): moved to Friday, April 23 at 6:30 (written only as "6:30"; 6:30 or 6:30 pm are both acceptable).
14. Stated only in German (s08): cleared to run (item 7); summer trip to Freiburg, Germany, July 6-20, Joel, Nadia and Wren, to visit his exchange-year host family, the Brandts (host mother Ulrike).
15. International Food Day at Wren's school: Friday, April 23 (s11). Nadia's mother planned walnut and pistachio ma'amoul.
16. FICTION ONLY (roleplay-s05, roleplay-s09): Marshal Eli Branch of Silver Hollow, Colorado Territory, 1879; bad right knee from a mine collapse that killed his partner Jeb Tolliver; cannot go underground since; widower, wife Clara died of fever; deputy Hattie Moss; Doc Ambrose Pruitt; stage from Fairplay, empty strongbox, driver shot; the Lucky Widow mine. None of this is true of Joel (his only injury is the ankle sprain, now cleared; he is married to Nadia).
Never stated anywhere: whether the campsite was reserved; who will look after Biscuit; whether the flowers were ordered; the outcome of the district review; whether the day-camp deposit was paid; which weekend Rob is visiting; whether Joel agreed to help with Science Olympiad or chaperone on April 17; the half-marathon result.

## F05-TEMP-cleared-to-run

**Date:** 2027-04-05

**Criteria:** Gives a week-by-week plan from the week of April 5 to the Colfax Half Marathon on Sunday, May 16 that includes running (easy runs building to a long run, then a taper). The temporary no-running restriction has ended: physio Dana cleared Joel to run on Thursday, March 18 (stated only in German on March 19), saying to build up gradually. A cautious build-up and ankle-care tips are fine. Must not say he is still barred from running, must not tell him to wait for clearance, and must not replace running with only bike or swim work.

**User:** Today is Monday, April 5. The Colfax Half is on Sunday, May 16, about six weeks out. Can you give me a week-by-week plan to get me to the start line?

### A

Six weeks is tight but enough for a **finish, not a time**. Since you’re still early in the return-to-running after the ankle, keep everything conversational and go by time, not pace.

Assumption: you can currently do 20–30 min of easy run/walk without ankle pain. If not, we compress it.

### Week 1 — Apr 5–11: settle in
- Tue: 25 min easy run/walk
- Thu: 25 min easy run/walk
- Sat or Sun: 35 min easy
- Cross-train once: bike or swim 30 min

### Week 2 — Apr 12–18
- Tue: 25–30 min easy
- Thu: 30 min easy
- Sun: 40–45 min long run/walk
- Ankle PT 2× this week

### Week 3 — Apr 19–25
- Tue: 30 min easy
- Thu: 30 min easy
- Sun: 50–55 min long run/walk — do it Sunday since **Wren’s recital is Sat 4/24**
- If Rob’s visit lands this weekend, shift the long run to Friday or Monday

### Week 4 — Apr 26–May 2
- Tue: 30 min easy
- Thu: 35 min easy; add 5×1 min slightly quicker only if the ankle feels 100%
- Sun: 60–70 min long run/walk

### Week 5 — May 3–9: peak week
- Tue: 30 min easy
- Thu: 35 min easy
- Sat or Sun: 80–90 min long run/walk — that’s roughly 7–8 miles, which is your longest training run, **not** 13.1
- Keep total running around 3.5–4 hours for the week

### Week 6 — May 10–16: taper
- Mon: rest or 25 min easy
- Tue: 25 min easy
- Wed: 20 min easy
- Thu: 15 min easy or rest
- Fri: rest
- Sat: rest, light walk, hydrate
- Sun May 16: race day

**Race day plan:** start with **3 min run / 1 min walk** and hold that at least through the first half. If you feel great after mile 6–7, you can stretch it to 4/1 or 5/1. If anything feels off, drop to 2/1. The goal is crossing the line, not hitting a pace.

### Non-negotiables
- All weekday runs should stay easy enough to talk in full sentences.
- If you get sharp ankle pain or noticeable swelling, replace running with bike/swim for 48 hours.
- Keep doing the ankle PT 2–3× per week: calf raises, single-leg balance, banded inversion/eversion.
- The weekly long run matters most — don’t skip it.
- Nothing new on race week: no new shoes, socks, or fueling.

What’s your current longest comfortable run/walk since Dana cleared you? That tells me whether we can push the peak week closer to 90 min or keep it at 80.

### B

Assuming you’ve been cleared and can currently run about **3 miles comfortably**, here’s a six-week “get to the start line healthy” plan. The goal is finishing, not racing — especially coming off the ankle.

## Ground rules

- **No speedwork.** Keep hard days minimal; your priority is tissue tolerance.
- **Run/walk is fine** on long runs. Try 4 min run / 1 min walk from the start.
- **If the ankle hurts, swells, or makes you limp**, stop and repeat the week.
- **Cross-training still counts.** Bike or swim 2 days a week.
- **Peak long run stays at 8 miles.** You don’t need 13 before race day.

## The plan

| Week | Runs per week | Total miles | Long run |
|---|---:|---:|---:|
| Apr 5–11 | 4 | 12–15 | **4–5 mi** |
| Apr 12–18 | 4 | 15–18 | **6 mi** |
| Apr 19–25 | 4 | 18–20 | **7 mi** |
| Apr 26–May 2 | 3–4 | 12–14 | **4–5 mi** (cutback) |
| May 3–9 | 4 | 15–18 | **8 mi** |
| May 10–16 | 3 | 8–10 | **Race: 13.1 mi** |

## Weekly rhythm

- **Mon:** rest or ankle rehab only  
- **Tue:** easy 30–35 min  
- **Wed:** bike or swim, 30–40 min  
- **Thu:** easy 35–40 min  
- **Fri:** rest + ankle prehab  
- **Sat or Sun:** long run  
- **Other day:** easy cross-train or short easy run

## Ankle prehab to keep doing

Every week, 3–4 times:

- Single-leg balance, 30–45 sec per side  
- Seated calf raises, 15–20 reps  
- Heel raises off a step, slow lower  
- Ankle circles and calf stretch  
- Walk on toes/heels for 30 ft

## Race-week shape

- **Tue May 11:** 3 miles easy  
- **Thu May 13:** 2–3 miles easy  
- **Sat May 15:** rest or 10–15 min jog  
- **Sun May 16:** start slow, use run/walk if needed, don’t chase time

If you can already comfortably run 5 miles, shift the long-run numbers up one level: 5, 7, 8, 5, 8–9, race. If your current longest run is under 3 miles, use the lower end of each range and lean on run/walk intervals.

---

One housekeeping thing: **Bear Creek Nature Camp registration was due March 26** — did you get that in? If not, it’s worth checking whether spots are still open.

### C

Six weeks is enough to get you to the start line — as long as the ankle is cooperating. So the goal here should be "finish feeling okay," not a time goal, especially coming off that grade 2 sprain.

One thing I need from you to fine-tune this: **has Dana officially cleared you to run, and what are you at right now** — roughly how many runs/miles a week, and what's your longest run since January?

Assuming she's cleared you and you're back to easy running, here's a conservative build. Key point: you do **not** need to run 13.1 miles in training — topping out around 10–11 is plenty to finish.

| Week (Mon–Sun) | Runs | Long run | Notes |
|---|---|---|---|
| Apr 5–11 | 4 easy (3–4 mi each) | 6 mi | Ease back in; keep every run conversational |
| Apr 12–18 | 4 easy | 8 mi | |
| Apr 19–25 | 4 | 10 mi | |
| Apr 26–May 2 | 4–5 | 11 mi | Longest run — then taper |
| May 3–9 | 3–4 | 8 mi | Taper starts |
| May 10–16 | 2–3 short | — race Sun | ~3 mi, ~2 mi, rest, race |

Rules that matter more than the mileage numbers:

- **Every long run at a talk-easy pace.** If the ankle twinges, walk. Never push through pain.
- **Keep doing Dana's ankle strength/balance work daily** — that's the real insurance against re-injury.
- **Bike and swim are fine** on non-run days; drop them if you start feeling run-down.
- **Race week:** nothing over ~3 miles, no new shoes, no new fuel, no last-minute "testing."

On race day itself, consider run-walk intervals (like 4:1 or 5:1). Totally legitimate, and it's often the difference between finishing strong and a sore ankle at mile 10.

Tell me your current weekly mileage and longest recent run — and whether Dana's signed off — and I'll adjust the numbers to match.

One quick aside: did you ever get that **Pinon Flats campsite reserved** for Memorial Day weekend? If not, it's worth checking soon — that weekend fills up.



## First reviewer's critical-error marks

{"A": [3], "B": [], "C": []}
