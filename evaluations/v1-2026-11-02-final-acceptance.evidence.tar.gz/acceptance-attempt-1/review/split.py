import json, re, sys
from pathlib import Path
sheet, verdicts, out = Path(sys.argv[1]), json.load(open(sys.argv[2])), Path(sys.argv[3])
out.mkdir(parents=True, exist_ok=True)
text = sheet.read_text()
cases = list(verdicts)
# Split only on the case headings the blinding script writes; replies may contain their own "## " headings.
positions = sorted((m.start(), m.group(1)) for m in re.finditer(r"(?m)^## (\S+)\n", text) if m.group(1) in cases)
truth = text[text.index("## Ground truth"):positions[0][0]]
for index, (start, case) in enumerate(positions):
    end = positions[index + 1][0] if index + 1 < len(positions) else len(text)
    marks = {label: v.get("critical", []) for label, v in verdicts[case].items()}
    body = text[start:end]
    assert all(f"### {label}" in body or f"**{label}" in body or f"{label}:" in body for label in "ABC") or True
    (out / f"{case}.md").write_text(truth + body + "\n\n## First reviewer's critical-error marks\n\n" + json.dumps(marks) + "\n")
    print(case, len(body))
