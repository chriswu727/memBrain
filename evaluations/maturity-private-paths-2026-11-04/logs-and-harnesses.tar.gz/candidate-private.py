def _private(path: Path, *, directory: bool = False) -> None:
    metadata = path.lstat()
    if stat.S_ISLNK(metadata.st_mode) or not (
        stat.S_ISDIR(metadata.st_mode) if directory else stat.S_ISREG(metadata.st_mode)
    ):
        raise LocalProfileError("Profile paths must be regular files and directories.")
    if os.name == "nt":
        _restrict_windows_access(path)
    else:
        if metadata.st_uid != os.getuid() or (not directory and metadata.st_nlink != 1):
            raise LocalProfileError("Profile files must belong exclusively to the current user.")
        mode = 0o700 if directory else 0o600
        if stat.S_IMODE(metadata.st_mode) != mode:
            path.chmod(mode)
