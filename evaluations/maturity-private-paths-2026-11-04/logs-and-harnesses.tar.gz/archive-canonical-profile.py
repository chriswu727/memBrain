import hashlib
import json
import os
import shutil
import socket
import tarfile
from pathlib import Path

from membrain.local_profile import load_profile

root = Path(__file__).resolve().parent
directory = root / 'perf-53d7e32-installation'
metadata = json.loads((root / 'canonical-command.json').read_text())
assert metadata['exit_code'] == 0
profile = load_profile(directory)
assert not (directory / 'postgres/postmaster.pid').exists()
for port in (profile.api_port, profile.database_port):
    with socket.socket() as listener:
        listener.settimeout(.2)
        assert listener.connect_ex(('127.0.0.1', port)) != 0
registry = Path(profile.settings().recovery_registry_path)
assert registry.is_relative_to(root)
roots = [directory, registry]
files = {str(path.relative_to(root)): hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()
         for folder in roots for path in folder.rglob('*') if path.is_file() and not path.is_symlink()}
archive = root / 'canonical-profile-53d7e32.tar.gz'
descriptor = os.open(archive, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(descriptor, 'wb') as stream, tarfile.open(fileobj=stream, mode='w:gz', compresslevel=1) as saved:
    for folder in roots:
        saved.add(folder, arcname=str(folder.relative_to(root)))
with tarfile.open(archive) as saved:
    archived_files = {member.name for member in saved.getmembers() if member.isfile()}
    assert archived_files == set(files)
    for name, expected in files.items():
        with saved.extractfile(name) as stream:
            assert hashlib.file_digest(stream, 'sha256').hexdigest() == expected
shutil.rmtree(directory)
report = {'canonical_exit_code': 0, 'ports_closed_before_archive': True,
          'archive': str(archive), 'archive_sha256': hashlib.file_digest(archive.open('rb'), 'sha256').hexdigest(),
          'archive_bytes': archive.stat().st_size, 'regular_files_verified': len(files),
          'original_disposable_profile_removed': not directory.exists(), 'registry_preserved': registry.exists(),
          'note': 'The complete stopped synthetic profile and its registry are retained in a private local archive. '
                  'Every regular file was compared by SHA-256 before removing only the completed profile. '
                  'The archive contains disposable credentials and must not be committed.'}
(root / 'canonical-profile-archive.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
