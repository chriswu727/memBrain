import hashlib
import io
import json
import re
import tarfile
from pathlib import Path

from membrain.local_profile import load_profile

root = Path(__file__).resolve().parent
repository = Path('/Users/yichen/tmp/membrain-review-20261029')
destination = repository / 'evaluations/maturity-private-paths-2026-11-04'
destination.mkdir(exist_ok=False)
secrets = set()
for task in (root, Path('/Users/yichen/tmp/membrain-sql-recall-20261104')):
    for path in task.rglob('profile.json'):
        document = json.loads(path.read_text())
        secrets.update(value for key, value in document.items() if isinstance(value, str) and len(value) >= 8
                       and ('password' in key or key == 'api_key'))


def sanitized(data):
    value = data.decode()
    for secret in sorted(secrets, key=len, reverse=True):
        value = value.replace(secret, '[redacted-fixture-secret]')
    value = re.sub(r'postgres(?:ql)?://([^:@\s]+):[^@\s\x22\x27]+@',
                   r'postgresql://\1:[redacted-fixture-password]@', value)
    value = re.sub(r'am_[A-Za-z0-9_-]{30,}', '[redacted-fixture-api-key]', value)
    assert not any(secret in value for secret in secrets)
    return value.encode()


def read(name):
    return json.loads((root / name).read_text())


cleanup = read('cleanup-final.json')
for file in (root / 'public-practice').rglob('profile.json'):
    import socket

    profile = load_profile(file.parent)
    ports = {'api': profile.api_port, 'database': profile.database_port}
    for port in ports.values():
        with socket.socket() as listener:
            listener.settimeout(.2)
            assert listener.connect_ex(('127.0.0.1', port)) != 0
    cleanup['profiles'].append({'directory': str(file.parent), 'ports': ports, 'closed': True})
(root / 'cleanup-final.json').write_text(json.dumps(cleanup, indent=2) + '\n')
visual = read('visual-permissions-abba.json')
assert visual['completed'] and visual['passed'] and all(not p['failed_windows'] for p in visual['phases'])
comparison = read('permissions-http-abba.json')
assert comparison['completed']
assert all(p['context_sha256'] == comparison['phases'][0]['context_sha256'] for p in comparison['phases'])
practice = read('public-practice-check.log')
assert practice['ok'] and read('public-practice-validity.json')['valid']
summary = {'source_commit': visual['source_commit'], 'runtime_pin': visual['runtime_pin'],
           'all_640_context_hashes_equal': True,
           'comparison': [{k: p[k] for k in ('variant', 'n', 'median_ms', 'p95_ms', 'rss_kb')}
                          for p in comparison['phases']],
           'visual_completed': True, 'visual_passed': True, 'visual_phases': [],
           'public_practice': {'completed': read('public-practice-result.json')['completed'],
                               'checks': sum(v['passed'] for v in practice.values() if isinstance(v, dict) and 'passed' in v),
                               'validity': read('public-practice-validity.json'), 'real_model_calls': 0},
           'full_ci': {'run': 41897991336, 'source': visual['source_commit'],
                       'status_at_snapshot': 'in_progress', 'not_a_passing_result': True}}
for p in visual['phases']:
    summary['visual_phases'].append({**{k: p[k] for k in ('mode', 'seconds', 'nodes', 'edges', 'hologram_frames',
                 'page_errors', 'external_requests') if k in p},
                 'p95_ms': {n: p[n]['p95_ms'] for n in ('serial', 'one_brain_8_concurrent', 'eight_brains_8_concurrent')},
                 'windows': [{n: c[n]['p95_ms'] for n in ('serial', 'one_brain_8_concurrent', 'eight_brains_8_concurrent')}
                             for c in p['cycles']], 'failed_windows': p['failed_windows'],
                 'poll_count': len(p['browser_requests_during_measurement'])})
copies = {'summary.json': (json.dumps(summary, indent=2) + '\n').encode(),
          'install-results.json': (root / 'install-final/results.json').read_bytes()}
for name in ('canonical-53d7e32.json', 'canonical-command.json', 'permission-provenance.json',
             'installed-followup-smoke.json', 'cleanup-final.json', 'claude-review-request.json',
             'public-practice-result.json', 'public-practice-validity.json', 'canonical-profile-archive.json'):
    copies[name] = (root / name).read_bytes()
manifest = {'source_commit': visual['source_commit'], 'runtime_pin': visual['runtime_pin'],
            'files': {}, 'archive_members': {},
            'note': 'Credentials are redacted. The separate private cold profile archive is deliberately excluded. '
                    'Full CI is in progress at this evidence snapshot. No failed result is relabelled as passed.'}
for name, data in copies.items():
    data = sanitized(data)
    (destination / name).write_bytes(data)
    manifest['files'][name] = hashlib.sha256(data).hexdigest()
archive = destination / 'logs-and-harnesses.tar.gz'
paths = [p for p in root.iterdir() if p.is_file() and p.suffix in ('.py', '.json', '.txt', '.log')
         and p.name != 'continuation.json']
paths += [p for p in (root / 'public-practice').rglob('*') if p.is_file()
          and p.name in ('run.log', 'harness-events.jsonl', 'page-actions.jsonl') or
          p.is_file() and p.parent.name in ('practice-P', 'practice-E', 'practice-F') and p.suffix == '.json']
with tarfile.open(archive, 'w:gz') as saved:
    for path in sorted(set(paths)):
        name = str(path.relative_to(root))
        data = sanitized(path.read_bytes())
        entry = tarfile.TarInfo(name)
        entry.size = len(data)
        saved.addfile(entry, io.BytesIO(data))
        manifest['archive_members'][name] = hashlib.sha256(data).hexdigest()
manifest['files'][archive.name] = hashlib.sha256(archive.read_bytes()).hexdigest()
(destination / 'sha256.json').write_text(json.dumps(manifest, indent=2) + '\n')
assert all(hashlib.sha256((destination / name).read_bytes()).hexdigest() == digest
           for name, digest in manifest['files'].items())
with tarfile.open(archive) as saved:
    assert set(saved.getnames()) == set(manifest['archive_members'])
    assert all(hashlib.sha256(saved.extractfile(name).read()).hexdigest() == digest
               for name, digest in manifest['archive_members'].items())
print(json.dumps({'files': len(manifest['files']), 'archive_members': len(manifest['archive_members']),
                  'archive_bytes': archive.stat().st_size, 'hashes_verified': True,
                  'profiles_closed': len(cleanup['profiles'])}))
