import atexit
import json
import signal
import sys
import threading
import time


def start(path, *, signum):
    state = {'stacks': [], 'samples': [], 'dropped_stacks': 0, 'dropped_samples': 0,
             'sampler_thread_cpu_seconds': 0, 'interval_seconds': .1}
    identifiers = {}
    stopping = threading.Event()

    def sample():
        own = threading.get_ident()
        while not stopping.is_set():
            begin = time.thread_time()
            threads = []
            for identifier, frame in sys._current_frames().items():
                if identifier == own:
                    continue
                stack = []
                while frame is not None and len(stack) < 20:
                    stack.append((frame.f_code.co_filename, frame.f_code.co_name, frame.f_lineno))
                    frame = frame.f_back
                key = tuple(stack)
                index = identifiers.get(key)
                if index is None:
                    if len(state['stacks']) >= 4096:
                        state['dropped_stacks'] += 1
                        index = -1
                    else:
                        index = identifiers[key] = len(state['stacks'])
                        state['stacks'].append(stack)
                threads.append([identifier, index])
            if len(state['samples']) < 3000:
                state['samples'].append({'at': time.perf_counter(), 'process_cpu_seconds': time.process_time(),
                                         'threads': threads})
            else:
                state['dropped_samples'] += 1
            state['sampler_thread_cpu_seconds'] += time.thread_time() - begin
            stopping.wait(.1)

    worker = threading.Thread(target=sample, name='diagnostic-stack-sampler', daemon=True)

    def save(*args):
        stopping.set()
        worker.join(timeout=2)
        state['sampler_stopped'] = not worker.is_alive()
        path.write_text(json.dumps(state, indent=2) + '\n')

    worker.start()
    signal.signal(signum, save)
    atexit.register(save)
    return state
