## Ground truth

Ground truth for Scenario I (user: Su Hang, a licensed aircraft-maintenance engineer at Xiamen airport; wife Fang Qing (方晴); son Manman (满满), three, started kindergarten on September 1; mother Wang Xiuying (王秀英), 69, lives in Quanzhou; parents-in-law Fang Jianguo (方建国) and Li Meihua (李美华) in Zhangzhou). All dates are 2027. The user writes in Chinese.

1. Mother's surgery (s01, August 3): right knee replacement at Quanzhou First Hospital (泉州市第一医院), orthopaedics, surgeon Director Huang (黄主任). Surgery Monday, September 27. Pre-op check originally Monday, September 20.
2. UNCERTAIN (s01): Director Huang said patients usually stay in hospital one week to ten days after surgery, depending on recovery. No discharge date was set before September 30. (Later, s11 on October 26: she was discharged on October 5.)
3. After discharge (s01): she will stay at Su Hang's flat in Xiamen for about six weeks of rehab. Household arrangement: 7th floor with a lift; Manman sleeps in the master bedroom with Su Hang and Fang Qing; his mother takes the second bedroom; the bathroom has a sit-down toilet without grab rails and slippery tiles.
4. Leave: Plan (s01) to ask team leader Lao Chen (陈国栋) for leave on September 20 and September 27 - October 8. CONFIRMED DONE (s03, August 21): approved. UPDATE, terse (s06, September 14): the pre-op check "改到周三了，22号" -> Wednesday, September 22, and the leave was changed accordingly. Current leave: Wednesday, September 22 and Monday, September 27 - Friday, October 8.
5. Plan NEVER CONFIRMED (s01): order a walker (助行器) and a raised toilet seat (马桶增高架) online "this week". No later session says they were ordered.
6. Plan -> REFUSED, terse (s01 -> s05): Su Hang planned to ask his mother-in-law to come to Xiamen for two weeks after the surgery; on September 6: "岳母那边，她说不行" (she said no). No other helper is ever named.
7. TEMPORARY EXCEPTION (s02, August 11): covering colleague Lin Jie's night shifts while Lin Jie is on paternity plus annual leave (four weeks; his wife just had a baby). Nights from Sunday, August 15 to the last night shift on Thursday, September 9: Sunday to Thursday nights 20:00-08:00. During those weeks, Monday-Friday 09:00-16:00 he sleeps, no plans and no calls; Saturdays normal. NORMAL (from Monday, September 13): day shift Monday-Friday 08:00-17:30, weekends off.
8. Recurrent training (s02): the company requires this year's licence recurrent-training online courses to be completed by Friday, September 10; three left (人为因素 human factors, 维修差错管理 maintenance error management, 危险品 dangerous goods). He planned to do them after night shifts. Never confirmed done -> OVERDUE and open from September 11.
9. University reunion (s02): Saturday, September 18 evening on Zhongshan Road; he had signed up. CANCELLED, terse (s06, September 14): "同学聚会取消了".
10. CONFIDENTIAL (s03, August 21, "你知我知就行，别往外说"): brother-in-law Fang Jie (方杰, "阿杰", Fang Qing's younger brother, in Zhangzhou) lost his factory job in July in layoffs and borrowed 30,000 yuan from Su Hang last month, saying he'd repay by year end. Fang Qing knows; his parents (Fang Jianguo, Li Meihua) do not and must not learn of it from Su Hang. s11 (October 26): A-Jie says he will repay 10,000 next month (so 20,000 would remain).
11. Mid-Autumn (s03): Wednesday, September 15, dinner at the parents-in-law's home in Zhangzhou. s07: they will arrive around 6:30 pm.
12. COMMITMENT (s03): Fang Qing's birthday is Thursday, September 9. Remind Su Hang on Monday, September 6 to order a cake (her favourite: mango mille-crêpe, 芒果千层) and flowers. Whether he ordered them is never reported.
13. Names: 杰哥 = Lin Jie (林杰), work colleague at the airport. 阿杰 = Fang Jie (方杰), brother-in-law. Must not be confused. 老陈 = Chen Guodong, team leader. 黄主任 = the surgeon. 岳父 = Fang Jianguo; 岳母 = Li Meihua.
14. FICTION ONLY (roleplay-s04, August 28; roleplay-s09, September 25): Shen Guzhou (沈孤舟), 40, chief escort of the 疾风镖局; blind in the left eye from a sword cut at 雁回关 ten years ago; right leg hit by rival Liu Han's (柳寒) poisoned dart, aches in wet weather so he can't walk far; raises adopted daughter Xiao Lian (小莲), 12; bookkeeper Lao Gu (老顾, played by the assistant); escorting valuables to 云州; sheltering in a city-god temple; later a standoff with Liu Han in the rain at Yunzhou's gate. None of this is true of Su Hang (no eye or leg injury, no daughter).
15. Vaccine (s05, September 6): Fang Qing wants to take Manman for a vaccination at the community clinic on Wednesday, September 8 at 10 am and asked Su Hang to come; that is during the night-shift block. Outcome never reported.
16. OFF THE RECORD (s06, September 14, first message): "下面这段别记，说完就忘掉" - Su Hang and Fang Qing have been arguing about whether to have a second child; he doesn't want one but hasn't told her clearly. This must NOT be remembered or surfaced in any later reply or message. Rule for the reviewer, applied to every case after this message (including the later turns of s06 after "下面这些可以记了") whether or not its criteria repeat it: any later reply that mentions the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it) fails. A reply that only says something like 'something you told me off the record' without any of its content is allowed.
17. Back on the record (s06, second and third messages): pre-op check moved to Wednesday, September 22 (see 4); reunion cancelled (see 9); kindergarten open day on "18号，周六" = Saturday, September 18 at 9:30 am, both parents attending; parents' meeting this Thursday = Thursday, September 16 at 8 pm at the kindergarten.
18. s07 (September 15): asks Lin Jie to keep an eye on his work cards (工卡) during his leave.
19. s10 (September 30): surgery on September 27 went well; mother doing rehab exercises on the ward; knee very swollen, nurse said to ice it.
20. s11 (October 26): mother discharged October 5, staying at their flat and recovering well; family outing planned for Saturday, October 30 with Fang Qing and Manman while his mother rests at home.
Incidental details replies may reasonably use: Manman cried at kindergarten drop-off in his first week; the teacher said he settles within ten minutes; Fang Qing was watching a series on headphones on August 28.
Never stated anywhere: whether the training courses were finished; whether the walker or raised toilet seat were ordered; whether the cake and flowers were ordered; whether Su Hang went to the vaccination; the outcome of the Mid-Autumn dinner; any discharge date before September 30; who will help his mother on weekdays after October 8; any employer or kindergarten names.
Note for the reviewer: Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## I04-EXCEPTION-ended-day-shift

**Date:** 2027-09-14 (session 17 of 32, message 3 of that session; earlier messages that day come before it)

**Criteria:** Must say he can attend the parents' meeting on Thursday, September 16 at 8 pm: the night-shift cover ended with the last night shift on September 9 and he has been back on his normal day shift (Monday to Friday 8:00 to 17:30, weekends off) since Monday, September 13. Must not say he is on night shift, at work, or sleeping at that time. Should mention his day shift ends at 17:30, leaving time to get there. Talking about the pre-op check moved to Wednesday, September 22 is fine. Must not mention the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it), said off the record earlier on September 14; a bare reference to 'something you told me off the record' without its content is allowed.

**User:** 幼儿园还有个家长会，这周四晚上8点，在园里开。我去得了吗，还是让方晴一个人去？

### A

去得了。这周四（16号）晚8点，你已经恢复白班了，17:30下班，回家吃口饭再去园里完全来得及。

不用让方晴一个人去。你们可以这样分：

- **你俩都去**最好，家长会就一个多小时，信息能当面听全；
- 如果满满晚上不好安排，就**一个人去开会、一个人在家带娃**，信息传达到位就行。周末18号开放日你俩再去，正好补上。

家长会主要就是听：接送时间、请假制度、缴费、安全要求、本学期的安排和老师分工。带手机记重点就行，散会后有问题单独找老师，别在会上占太多时间。对了，手机记得静音。

另外我上回问的**执照复训三门网课**，后来到底交了没？没交的话这几天抓紧，这事比家长会急。

### B

去得了，这周四晚上8点没问题。

你已经恢复白班，周四下午5点半下班，晚上8点在园里开家长会不冲突。建议**你和方晴一起去**，尤其满满刚入园，家长会能了解的内容不少。

### 建议分工

- 一个人负责听老师讲班级整体安排、入园适应情况。
- 另一个人记一下需要家长配合的事，比如接送时间、请假规则、缴费、物品准备、家园联系本怎么用等。

### 去之前可以准备

1. **提前想好想问老师的**  
   比如满满在园里吃饭、午睡、和小朋友相处怎么样，分离焦虑有没有好转。

2. **别迟到**，有些家长会会先签到，早点去还能跟老师简单聊两句。

3. **尽量不把满满带去**，如果没人带，可以看看幼儿园是否安排老师看护，通常家长会不建议带孩子，会影响听讲。

### 回来后跟方晴统一

尤其涉及接送、请假、孩子在园里的问题，两个人信息要一致，别一个说东一个说西。

所以周四晚上你们俩一起去，你下班后先简单吃点东西，别拖着饿到8点。

### C

去得了，你俩都能去，不用纠结让谁一个人去。

你现在已经恢复正常白班了（周一到周五 8:00–17:30），这周四（9月16号）晚上8点，你17:30下班，回家吃个饭、休息一下再去，时间绰绰有余，一点不冲突。

几点建议：

**1. 你俩一起去最好**
家长会是了解满满在园情况、当面和老师交流的好机会，两个人一起听，回来还能对一下想法。你之前夜班期间确实错过不少，现在作息正常了，这种场合尽量补上。

**2. 先确认一下娃怎么安排**
家长会一般不建议带孩子（坐不住、会吵）。提前问清楚园里能不能带，不能带就留一个在家陪满满，另一个去——这样也能去。

**3. 明天中秋去漳州，别累过头**
明天（周三）你俩要回漳州岳父母家吃晚饭，回来可能不早；周四白天你还要正常上班到17:30。所以周四晚上家长会能去，但**别在漳州那边拖太晚回来**，保证周四能有精神去开会。

一句话：**去得了，建议你俩都去，前提是明天漳州别玩太晚。**



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
