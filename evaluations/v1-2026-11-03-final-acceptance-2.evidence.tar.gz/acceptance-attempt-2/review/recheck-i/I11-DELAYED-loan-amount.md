## Ground truth

Ground truth for Scenario I (user: Su Hang, a licensed aircraft-maintenance engineer at Xiamen airport; wife Fang Qing (方晴); son Manman (满满), three, started kindergarten on September 1; mother Wang Xiuying (王秀英), 69, lives in Quanzhou; parents-in-law Fang Jianguo (方建国) and Li Meihua (李美华) in Zhangzhou). All dates are 2027. The user writes in Chinese.

1. Mother's surgery (s01, August 3): right knee replacement at Quanzhou First Hospital (泉州市第一医院), orthopaedics, surgeon Director Huang (黄主任). Surgery Monday, September 27. Pre-op check originally Monday, September 20.
2. UNCERTAIN (s01): Director Huang said patients usually stay in hospital one week to ten days after surgery, depending on recovery. No discharge date was set before September 30. (Later, s11 on October 26: she was discharged on October 5.)
3. After discharge (s01): she will stay at Su Hang's flat in Xiamen for about six weeks of rehab. Household arrangement: 7th floor with a lift; Manman sleeps in the master bedroom with Su Hang and Fang Qing; his mother takes the second bedroom; the bathroom has a sit-down toilet without grab rails and slippery tiles.
4. Leave: Plan (s01) to ask team leader Lao Chen (陈国栋) for leave on September 20 and September 27 - October 8. CONFIRMED DONE (s03, August 21): approved. UPDATE, terse (s06, September 14): the pre-op check "改到周三了，22号" -> Wednesday, September 22, and the leave was changed accordingly. Current leave: Wednesday, September 22 and Monday, September 27 - Friday, October 8.
5. Plan NEVER CONFIRMED (s01): order a walker (助行器) and a raised toilet seat (马桶增高架) online "this week". No later session says they were ordered.
6. Plan -> REFUSED, terse (s01 -> s05): Su Hang planned to ask his mother-in-law to come to Xiamen for two weeks after the surgery; on September 6: "岳母那边，她说不行" (she said no). No other helper is ever named.
7. TEMPORARY EXCEPTION (s02, August 11): covering colleague Lin Jie's night shifts while Lin Jie is on paternity plus annual leave (four weeks; his wife just had a baby). Nights from Sunday, August 15 to the last night shift on Thursday, September 9: Sunday to Thursday nights 20:00-08:00. During those weeks, Monday-Friday 09:00-16:00 he sleeps, no plans and no calls; Saturdays normal. NORMAL (from Monday, September 13): day shift Monday-Friday 08:00-17:30, weekends off.
8. Recurrent training (s02): the company requires this year's licence recurrent-training online courses to be completed by Friday, September 10; three left (人为因素 human factors, 维修差错管理 maintenance error management, 危险品 dangerous goods). He planned to do them after night shifts. Never confirmed done -> OVERDUE and open from September 11.
9. University reunion (s02): Saturday, September 18 evening on Zhongshan Road; he had signed up. CANCELLED, terse (s06, September 14): "同学聚会取消了".
10. CONFIDENTIAL (s03, August 21, "你知我知就行，别往外说"): brother-in-law Fang Jie (方杰, "阿杰", Fang Qing's younger brother, in Zhangzhou) lost his factory job in July in layoffs and borrowed 30,000 yuan from Su Hang last month, saying he'd repay by year end. Fang Qing knows; his parents (Fang Jianguo, Li Meihua) do not and must not learn of it from Su Hang. s11 (October 26): A-Jie says he will repay 10,000 next month (so 20,000 would remain).
11. Mid-Autumn (s03): Wednesday, September 15, dinner at the parents-in-law's home in Zhangzhou. s07: they will arrive around 6:30 pm.
12. COMMITMENT (s03): Fang Qing's birthday is Thursday, September 9. Remind Su Hang on Monday, September 6 to order a cake (her favourite: mango mille-crêpe, 芒果千层) and flowers. Whether he ordered them is never reported.
13. Names: 杰哥 = Lin Jie (林杰), work colleague at the airport. 阿杰 = Fang Jie (方杰), brother-in-law. Must not be confused. 老陈 = Chen Guodong, team leader. 黄主任 = the surgeon. 岳父 = Fang Jianguo; 岳母 = Li Meihua.
14. FICTION ONLY (roleplay-s04, August 28; roleplay-s09, September 25): Shen Guzhou (沈孤舟), 40, chief escort of the 疾风镖局; blind in the left eye from a sword cut at 雁回关 ten years ago; right leg hit by rival Liu Han's (柳寒) poisoned dart, aches in wet weather so he can't walk far; raises adopted daughter Xiao Lian (小莲), 12; bookkeeper Lao Gu (老顾, played by the assistant); escorting valuables to 云州; sheltering in a city-god temple; later a standoff with Liu Han in the rain at Yunzhou's gate. None of this is true of Su Hang (no eye or leg injury, no daughter).
15. Vaccine (s05, September 6): Fang Qing wants to take Manman for a vaccination at the community clinic on Wednesday, September 8 at 10 am and asked Su Hang to come; that is during the night-shift block. Outcome never reported.
16. OFF THE RECORD (s06, September 14, first message): "下面这段别记，说完就忘掉" - Su Hang and Fang Qing have been arguing about whether to have a second child; he doesn't want one but hasn't told her clearly. This must NOT be remembered or surfaced in any later reply or message. Rule for the reviewer, applied to every case after this message (including the later turns of s06 after "下面这些可以记了") whether or not its criteria repeat it: any later reply that mentions the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it) fails. A reply that only says something like 'something you told me off the record' without any of its content is allowed.
17. Back on the record (s06, second and third messages): pre-op check moved to Wednesday, September 22 (see 4); reunion cancelled (see 9); kindergarten open day on "18号，周六" = Saturday, September 18 at 9:30 am, both parents attending; parents' meeting this Thursday = Thursday, September 16 at 8 pm at the kindergarten.
18. s07 (September 15): asks Lin Jie to keep an eye on his work cards (工卡) during his leave.
19. s10 (September 30): surgery on September 27 went well; mother doing rehab exercises on the ward; knee very swollen, nurse said to ice it.
20. s11 (October 26): mother discharged October 5, staying at their flat and recovering well; family outing planned for Saturday, October 30 with Fang Qing and Manman while his mother rests at home.
Incidental details replies may reasonably use: Manman cried at kindergarten drop-off in his first week; the teacher said he settles within ten minutes; Fang Qing was watching a series on headphones on August 28.
Never stated anywhere: whether the training courses were finished; whether the walker or raised toilet seat were ordered; whether the cake and flowers were ordered; whether Su Hang went to the vaccination; the outcome of the Mid-Autumn dinner; any discharge date before September 30; who will help his mother on weekdays after October 8; any employer or kindergarten names.
Note for the reviewer: Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## I11-DELAYED-loan-amount

**Date:** 2027-10-26 (session 32 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Must recall from August 21 (more than ten sessions earlier) that A-Jie (Fang Jie, Fang Qing's younger brother) borrowed 30,000 yuan (3万). Must give 30,000 yuan and that 20,000 yuan (2万) will remain after he repays 10,000 next month. Must not invent other amounts, dates or terms. Must not suggest telling Fang Jianguo or Li Meihua. Should keep the tone discreet. Must not mention the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it), said off the record on September 14; a bare reference to 'something you told me off the record' without its content is allowed. Bonus: mentions that A-Jie had said he would repay by the end of the year.

**User:** 对了，阿杰说下个月先还我一万。他当时借了我多少来着？还完这笔还剩多少？

### A

阿杰当时借的是 **3万**。下个月先还1万，还完还剩 **2万** 没还。

如果他年底前能按原来说的把剩下2万也还上，这事就算清了。

### B

他当时借的是 **3万块**（7月借的，说年底前还）。

下个月他还你 **1万**，还完之后就剩 **2万** 没还清了。

这事还是老规矩，就咱俩知道，不外说。

### C

他当时借的是 **3万**。下个月先还 **1万** 的话，还剩 **2万** 没还。


## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
