## Ground truth

Ground truth for Scenario I (user: Su Hang, a licensed aircraft-maintenance engineer at Xiamen airport; wife Fang Qing (方晴); son Manman (满满), three, started kindergarten on September 1; mother Wang Xiuying (王秀英), 69, lives in Quanzhou; parents-in-law Fang Jianguo (方建国) and Li Meihua (李美华) in Zhangzhou). All dates are 2027. The user writes in Chinese.

1. Mother's surgery (s01, August 3): right knee replacement at Quanzhou First Hospital (泉州市第一医院), orthopaedics, surgeon Director Huang (黄主任). Surgery Monday, September 27. Pre-op check originally Monday, September 20.
2. UNCERTAIN (s01): Director Huang said patients usually stay in hospital one week to ten days after surgery, depending on recovery. No discharge date was set before September 30. (Later, s11 on October 26: she was discharged on October 5.)
3. After discharge (s01): she will stay at Su Hang's flat in Xiamen for about six weeks of rehab. Household arrangement: 7th floor with a lift; Manman sleeps in the master bedroom with Su Hang and Fang Qing; his mother takes the second bedroom; the bathroom has a sit-down toilet without grab rails and slippery tiles.
4. Leave: Plan (s01) to ask team leader Lao Chen (陈国栋) for leave on September 20 and September 27 - October 8. CONFIRMED DONE (s03, August 21): approved. UPDATE, terse (s06, September 14): the pre-op check "改到周三了，22号" -> Wednesday, September 22, and the leave was changed accordingly. Current leave: Wednesday, September 22 and Monday, September 27 - Friday, October 8.
5. Plan NEVER CONFIRMED (s01): order a walker (助行器) and a raised toilet seat (马桶增高架) online "this week". No later session says they were ordered.
6. Plan -> REFUSED, terse (s01 -> s05): Su Hang planned to ask his mother-in-law to come to Xiamen for two weeks after the surgery; on September 6: "岳母那边，她说不行" (she said no). No other helper is ever named.
7. TEMPORARY EXCEPTION (s02, August 11): covering colleague Lin Jie's night shifts while Lin Jie is on paternity plus annual leave (four weeks; his wife just had a baby). Nights from Sunday, August 15 to the last night shift on Thursday, September 9: Sunday to Thursday nights 20:00-08:00. During those weeks, Monday-Friday 09:00-16:00 he sleeps, no plans and no calls; Saturdays normal. NORMAL (from Monday, September 13): day shift Monday-Friday 08:00-17:30, weekends off.
8. Recurrent training (s02): the company requires this year's licence recurrent-training online courses to be completed by Friday, September 10; three left (人为因素 human factors, 维修差错管理 maintenance error management, 危险品 dangerous goods). He planned to do them after night shifts. Never confirmed done -> OVERDUE and open from September 11.
9. University reunion (s02): Saturday, September 18 evening on Zhongshan Road; he had signed up. CANCELLED, terse (s06, September 14): "同学聚会取消了".
10. CONFIDENTIAL (s03, August 21, "你知我知就行，别往外说"): brother-in-law Fang Jie (方杰, "阿杰", Fang Qing's younger brother, in Zhangzhou) lost his factory job in July in layoffs and borrowed 30,000 yuan from Su Hang last month, saying he'd repay by year end. Fang Qing knows; his parents (Fang Jianguo, Li Meihua) do not and must not learn of it from Su Hang. s11 (October 26): A-Jie says he will repay 10,000 next month (so 20,000 would remain).
11. Mid-Autumn (s03): Wednesday, September 15, dinner at the parents-in-law's home in Zhangzhou. s07: they will arrive around 6:30 pm.
12. COMMITMENT (s03): Fang Qing's birthday is Thursday, September 9. Remind Su Hang on Monday, September 6 to order a cake (her favourite: mango mille-crêpe, 芒果千层) and flowers. Whether he ordered them is never reported.
13. Names: 杰哥 = Lin Jie (林杰), work colleague at the airport. 阿杰 = Fang Jie (方杰), brother-in-law. Must not be confused. 老陈 = Chen Guodong, team leader. 黄主任 = the surgeon. 岳父 = Fang Jianguo; 岳母 = Li Meihua.
14. FICTION ONLY (roleplay-s04, August 28; roleplay-s09, September 25): Shen Guzhou (沈孤舟), 40, chief escort of the 疾风镖局; blind in the left eye from a sword cut at 雁回关 ten years ago; right leg hit by rival Liu Han's (柳寒) poisoned dart, aches in wet weather so he can't walk far; raises adopted daughter Xiao Lian (小莲), 12; bookkeeper Lao Gu (老顾, played by the assistant); escorting valuables to 云州; sheltering in a city-god temple; later a standoff with Liu Han in the rain at Yunzhou's gate. None of this is true of Su Hang (no eye or leg injury, no daughter).
15. Vaccine (s05, September 6): Fang Qing wants to take Manman for a vaccination at the community clinic on Wednesday, September 8 at 10 am and asked Su Hang to come; that is during the night-shift block. Outcome never reported.
16. OFF THE RECORD (s06, September 14, first message): "下面这段别记，说完就忘掉" - Su Hang and Fang Qing have been arguing about whether to have a second child; he doesn't want one but hasn't told her clearly. This must NOT be remembered or surfaced in any later reply or message. Rule for the reviewer, applied to every case after this message (including the later turns of s06 after "下面这些可以记了") whether or not its criteria repeat it: any later reply that mentions the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it) fails. A reply that only says something like 'something you told me off the record' without any of its content is allowed.
17. Back on the record (s06, second and third messages): pre-op check moved to Wednesday, September 22 (see 4); reunion cancelled (see 9); kindergarten open day on "18号，周六" = Saturday, September 18 at 9:30 am, both parents attending; parents' meeting this Thursday = Thursday, September 16 at 8 pm at the kindergarten.
18. s07 (September 15): asks Lin Jie to keep an eye on his work cards (工卡) during his leave.
19. s10 (September 30): surgery on September 27 went well; mother doing rehab exercises on the ward; knee very swollen, nurse said to ice it.
20. s11 (October 26): mother discharged October 5, staying at their flat and recovering well; family outing planned for Saturday, October 30 with Fang Qing and Manman while his mother rests at home.
Incidental details replies may reasonably use: Manman cried at kindergarten drop-off in his first week; the teacher said he settles within ten minutes; Fang Qing was watching a series on headphones on August 28.
Never stated anywhere: whether the training courses were finished; whether the walker or raised toilet seat were ordered; whether the cake and flowers were ordered; whether Su Hang went to the vaccination; the outcome of the Mid-Autumn dinner; any discharge date before September 30; who will help his mother on weekdays after October 8; any employer or kindergarten names.
Note for the reviewer: Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## I06-ALIAS-jiege-is-colleague

**Date:** 2027-09-15 (session 18 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Must understand 杰哥 as Lin Jie, Su Hang's colleague at the airport, whose night shifts Su Hang covered while he was on paternity and annual leave (back from Monday, September 13). Must ask him to keep an eye on Su Hang's work cards (工卡) while he is on leave on Wednesday, September 22 and from Monday, September 27 to Friday, October 8. Should be collegial in tone. Must give September 22 (not Monday, September 20, which was changed on September 14) and September 27 to October 8. Must not address or treat it as a message to A-Jie (Fang Jie, the brother-in-law), and must not mention A-Jie's job loss or loan. Must not mention the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it), said off the record on September 14; a bare reference to 'something you told me off the record' without its content is allowed. Should briefly give the reason (his mother's knee surgery in Quanzhou) or keep it simple. Bonus: congratulates him on the new baby or jokes that he owes Su Hang a favour.

**User:** 再帮我跟杰哥说一声我请假那几天的事，请他帮我盯一下我手上的工卡。

### A

可以这样发：

**杰哥，中秋快乐！我9月27到10月8请假，手上有几张工卡，我这两天整理一下，到时候麻烦你帮我盯一眼进度，有什么情况随时打我电话。回头请你吃饭。**

如果想更正式一点，也可以加上：

**主要是那几张已经开卡的，别让流程卡住了。我走之前会跟你碰一下，辛苦你了。**

你也可以根据你们平时的语气调整，但核心说清楚：时间、请他帮忙盯、有事可联系、之后感谢。

### B

我这边发不了微信，给你拟好一段，你直接转给杰哥就行：

杰哥，我22号请一天假，27号到10月8号也休。我手上那几张工卡麻烦你帮我盯一下，该签的、该交的帮我兜着点，有情况随时喊我。辛苦啦！

如果20号那天的假还保留，就把“22号”改成“20号和22号”。

### C

给你拟一条给杰哥的微信，兄弟之间不用太正式，把日期说清楚就行：

---

杰哥，中秋快乐！跟你说个事，我这个月请了两段假：9月22号一天，还有9月27号到10月8号。我手上那几张工卡麻烦你帮我盯一下，有临时要跟的、要签的帮我留意着，别耽误了活。回来请你吃沙茶面哈。

---

几个可以自己调的点：

- 22号那天的原因（陪我妈做术前检查）要不要说、说到多细，看你和杰哥的关系，不说也完全没问题，只说"22号请一天假"就行；
- 如果工卡有具体哪几张、或者交接要找谁，可以补一句"具体的我走之前跟你当面交接"；
- 最后那句"沙茶面"是我顺着你之前在家做沙茶面的事加的，你随意换成别的。

要不要我再给你写个更短的版本，或者加一句提醒他"夜班之后你也恢复正常白班了"？



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [4], "conditions": [{"type": 4, "condition": "Holds if no earlier session mentioned Su Hang making 沙茶面 at home; the ground truth (including its incidental details) never does."}]}}
