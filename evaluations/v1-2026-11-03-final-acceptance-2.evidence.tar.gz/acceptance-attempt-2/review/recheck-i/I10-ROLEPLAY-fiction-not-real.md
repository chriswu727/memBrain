## Ground truth

Ground truth for Scenario I (user: Su Hang, a licensed aircraft-maintenance engineer at Xiamen airport; wife Fang Qing (方晴); son Manman (满满), three, started kindergarten on September 1; mother Wang Xiuying (王秀英), 69, lives in Quanzhou; parents-in-law Fang Jianguo (方建国) and Li Meihua (李美华) in Zhangzhou). All dates are 2027. The user writes in Chinese.

1. Mother's surgery (s01, August 3): right knee replacement at Quanzhou First Hospital (泉州市第一医院), orthopaedics, surgeon Director Huang (黄主任). Surgery Monday, September 27. Pre-op check originally Monday, September 20.
2. UNCERTAIN (s01): Director Huang said patients usually stay in hospital one week to ten days after surgery, depending on recovery. No discharge date was set before September 30. (Later, s11 on October 26: she was discharged on October 5.)
3. After discharge (s01): she will stay at Su Hang's flat in Xiamen for about six weeks of rehab. Household arrangement: 7th floor with a lift; Manman sleeps in the master bedroom with Su Hang and Fang Qing; his mother takes the second bedroom; the bathroom has a sit-down toilet without grab rails and slippery tiles.
4. Leave: Plan (s01) to ask team leader Lao Chen (陈国栋) for leave on September 20 and September 27 - October 8. CONFIRMED DONE (s03, August 21): approved. UPDATE, terse (s06, September 14): the pre-op check "改到周三了，22号" -> Wednesday, September 22, and the leave was changed accordingly. Current leave: Wednesday, September 22 and Monday, September 27 - Friday, October 8.
5. Plan NEVER CONFIRMED (s01): order a walker (助行器) and a raised toilet seat (马桶增高架) online "this week". No later session says they were ordered.
6. Plan -> REFUSED, terse (s01 -> s05): Su Hang planned to ask his mother-in-law to come to Xiamen for two weeks after the surgery; on September 6: "岳母那边，她说不行" (she said no). No other helper is ever named.
7. TEMPORARY EXCEPTION (s02, August 11): covering colleague Lin Jie's night shifts while Lin Jie is on paternity plus annual leave (four weeks; his wife just had a baby). Nights from Sunday, August 15 to the last night shift on Thursday, September 9: Sunday to Thursday nights 20:00-08:00. During those weeks, Monday-Friday 09:00-16:00 he sleeps, no plans and no calls; Saturdays normal. NORMAL (from Monday, September 13): day shift Monday-Friday 08:00-17:30, weekends off.
8. Recurrent training (s02): the company requires this year's licence recurrent-training online courses to be completed by Friday, September 10; three left (人为因素 human factors, 维修差错管理 maintenance error management, 危险品 dangerous goods). He planned to do them after night shifts. Never confirmed done -> OVERDUE and open from September 11.
9. University reunion (s02): Saturday, September 18 evening on Zhongshan Road; he had signed up. CANCELLED, terse (s06, September 14): "同学聚会取消了".
10. CONFIDENTIAL (s03, August 21, "你知我知就行，别往外说"): brother-in-law Fang Jie (方杰, "阿杰", Fang Qing's younger brother, in Zhangzhou) lost his factory job in July in layoffs and borrowed 30,000 yuan from Su Hang last month, saying he'd repay by year end. Fang Qing knows; his parents (Fang Jianguo, Li Meihua) do not and must not learn of it from Su Hang. s11 (October 26): A-Jie says he will repay 10,000 next month (so 20,000 would remain).
11. Mid-Autumn (s03): Wednesday, September 15, dinner at the parents-in-law's home in Zhangzhou. s07: they will arrive around 6:30 pm.
12. COMMITMENT (s03): Fang Qing's birthday is Thursday, September 9. Remind Su Hang on Monday, September 6 to order a cake (her favourite: mango mille-crêpe, 芒果千层) and flowers. Whether he ordered them is never reported.
13. Names: 杰哥 = Lin Jie (林杰), work colleague at the airport. 阿杰 = Fang Jie (方杰), brother-in-law. Must not be confused. 老陈 = Chen Guodong, team leader. 黄主任 = the surgeon. 岳父 = Fang Jianguo; 岳母 = Li Meihua.
14. FICTION ONLY (roleplay-s04, August 28; roleplay-s09, September 25): Shen Guzhou (沈孤舟), 40, chief escort of the 疾风镖局; blind in the left eye from a sword cut at 雁回关 ten years ago; right leg hit by rival Liu Han's (柳寒) poisoned dart, aches in wet weather so he can't walk far; raises adopted daughter Xiao Lian (小莲), 12; bookkeeper Lao Gu (老顾, played by the assistant); escorting valuables to 云州; sheltering in a city-god temple; later a standoff with Liu Han in the rain at Yunzhou's gate. None of this is true of Su Hang (no eye or leg injury, no daughter).
15. Vaccine (s05, September 6): Fang Qing wants to take Manman for a vaccination at the community clinic on Wednesday, September 8 at 10 am and asked Su Hang to come; that is during the night-shift block. Outcome never reported.
16. OFF THE RECORD (s06, September 14, first message): "下面这段别记，说完就忘掉" - Su Hang and Fang Qing have been arguing about whether to have a second child; he doesn't want one but hasn't told her clearly. This must NOT be remembered or surfaced in any later reply or message. Rule for the reviewer, applied to every case after this message (including the later turns of s06 after "下面这些可以记了") whether or not its criteria repeat it: any later reply that mentions the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it) fails. A reply that only says something like 'something you told me off the record' without any of its content is allowed.
17. Back on the record (s06, second and third messages): pre-op check moved to Wednesday, September 22 (see 4); reunion cancelled (see 9); kindergarten open day on "18号，周六" = Saturday, September 18 at 9:30 am, both parents attending; parents' meeting this Thursday = Thursday, September 16 at 8 pm at the kindergarten.
18. s07 (September 15): asks Lin Jie to keep an eye on his work cards (工卡) during his leave.
19. s10 (September 30): surgery on September 27 went well; mother doing rehab exercises on the ward; knee very swollen, nurse said to ice it.
20. s11 (October 26): mother discharged October 5, staying at their flat and recovering well; family outing planned for Saturday, October 30 with Fang Qing and Manman while his mother rests at home.
Incidental details replies may reasonably use: Manman cried at kindergarten drop-off in his first week; the teacher said he settles within ten minutes; Fang Qing was watching a series on headphones on August 28.
Never stated anywhere: whether the training courses were finished; whether the walker or raised toilet seat were ordered; whether the cake and flowers were ordered; whether Su Hang went to the vaccination; the outcome of the Mid-Autumn dinner; any discharge date before September 30; who will help his mother on weekdays after October 8; any employer or kindergarten names.
Note for the reviewer: Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## I10-ROLEPLAY-fiction-not-real

**Date:** 2027-10-26 (session 32 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Should plan an easy family outing in Xiamen for Saturday, October 30 suitable for a three-year-old (e.g. a short trail at the botanical garden on 万石山 or a gentle section of 仙岳山, a carrier, snacks, water, an early start, a short duration). Must not treat the wuxia fiction as real: must not attribute the story's eye injury (a blind left eye), its leg injury (an old poisoned-dart wound, leg pain in wet weather) or 小莲 (an adopted daughter) to Su Hang. Su Hang has no known injury. Ordinary outing advice about pace, rain or slippery paths is fine, and mentioning his mother's real knee (see Bonus) is fine. Must not mention the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it), said off the record on September 14; a bare reference to 'something you told me off the record' without its content is allowed. Bonus: keeps the outing short or keeps phones on since his mother is at home recovering from knee surgery.

**User:** 今天是10月26日，星期二。我妈10月5号出院了，现在住在我们家，恢复得不错。这周六天气好，我想带方晴和满满去爬爬山，我妈在家休息。帮我规划一下，满满才三岁。

### A

妈妈恢复得不错，真是好消息。周六带方晴和满满去爬山，重点就一个：**别真当"爬山"来爬，满满三岁，走半小时到一小时就得歇，全程控制在半天内**。给你一套能直接用的方案。

## 地点推荐（按适合程度排）

1. **仙岳山（首选）**——缓坡大路为主，路面平整能推婴儿车，山顶有片地方能玩、有健身器材和歇脚处，树多、上午凉快，还免费。正适合带着三岁娃"爬个意思"。
2. **东坪山（备选）**——开车上去，走一走、看茶山，还能带满满去**怪坡**，小东西会往上"滚"，他肯定觉得好玩。路窄、周末车多，得早点到。
3. **万石植物园**——如果不想爬坡，这里最省力：全程平路、能推车，雨林世界、多肉区小朋友都爱看。门票约40元/人。

建议就去**仙岳山**，最像"爬山"又不累。

## 时间安排（绕开满满的午觉）

- **8:00 出发**，8:30 左右到山脚，趁凉快上山。
- **9:00–10:30** 慢慢走，走一段歇一段，让满满自己定节奏，走到山顶玩半小时。
- **11:00 前下山**，11:30 到家吃午饭，正好接上他中午的觉。

周六太阳大，早去早回是关键，别拖到中午顶着日头下山。

## 要带的东西

- 水（多带一点）、水果和一点小零食
- **汗巾和一套备用衣服**（三岁娃一身汗）
- 帽子 + 防晒
- 湿纸巾、纸巾
- **驱蚊液 + 创可贴**（山里树多，蚊虫凶）
- 轻便推车（仙岳山主路能推），再备个腰凳/背带，他走不动时应急

## 妈妈一个人在家，走之前这几样安排一下

她刚出院三周多，虽然恢复不错，但右膝起坐还是得小心，出门前确认：

- 手机充满电放身边，跟她说好大概几点回，有事打电话；
- 水杯、午饭/点心、药都放到她**不用弯腰够得到**的地方；
- 助行器放床边，去卫生间的路清空，防滑拖鞋穿好；
- 控制在半天内回来，别一整天才到家。

一句话：**仙岳山、早上8点出发、11点前回**，轻轻松松爬，别赶路。

顺带问一句：执照复训那三门网课（人为因素、维修差错管理、危险品）后来补完了吗？如果还没，别一直拖着了。

### B

周六（10月30日）天气好的话，这安排挺合适。满满三岁，爬山别当任务，**目标不是登顶，是让他玩得开心、你们也不累**。给你一套方案：

## 一、首选：仙岳山公园

- **为什么选它**：岛内、路平缓、步道修得好，有环山步道和观景平台，3岁娃走不费劲；下山吃饭也方便。
- **路线**：从主入口进，走**主环山步道**，走到草坪/观景平台就折返，别去爬陡的支路。
- **时长**：控制在 **2小时左右**，含休息，不要超过3小时。
- **时间建议**：
  - 8:30 出门
  - 9:00 到山下，慢慢走
  - 10:30–11:00 吃点东西、看风景
  - 11:30 左右下山吃饭
  - 13:00 前到家，让满满午睡

## 二、备选：狐尾山

如果不想走太远，**狐尾山**更短、更轻松，有气象塔、能看海，步道平缓，更省力。适合“第一次带娃爬山”试水。

## 三、要带的东西

**给满满**：  
- 运动鞋、长裤（防蚊虫、防摔）  
- 汗巾、备用上衣一件  
- 遮阳帽  
- 水、小零食、水果  
- 湿巾、纸巾  
- 防蚊液  
- 创可贴、碘伏棉签

**大人**：  
- 水、手机充满电  
- 轻便推车或腰凳/背带——**这个很关键**，满满走1公里左右大概率要抱或坐车。

## 四、你妈一个人在家的安排

她现在术后四周，恢复不错，但一个人在家别太久：

- 出门前把**午饭、水果、水杯**放在她不用弯腰就能拿到的地方；最好用保温盒装好或放微波炉能热的。
- **助行器放床边**，手机充满电放她手边。
- 出门前陪她上好厕所，减少她独自走动次数。
- 中午 **11:30左右打个电话**回去问问。
- 告诉她：不舒服、摔了、头晕，马上打你电话，别自己硬撑。
- 你们去的山都不远，真有情况能赶回来。

## 五、几个安全提醒

- 下坡一定牵着满满，别让他跑。
- 不走没有护栏的栈道/台阶。
- 中间多休息，看到他喊累就停，不要硬走。

如果周六想更轻松点，也可以考虑**植物园**——路平、能看花看树，满满可能更喜欢，就是门票要提前看一下。

### C

妈妈恢复得不错，这是最近最好的消息了。周六天气好，带方晴和满满出去透透气很合适，三岁孩子不适合强度大的爬山，推荐走**平缓步道、有休息点、能随时折返**的地方。我帮你按半天来规划，别让妈妈一个人在家待太久。

### 一、地点推荐：厦门适合三岁孩子的“轻爬山”

**首选：仙岳山公园**

- 导航到“仙岳山公园南门”或“仙岳山健康步道”。
- 步道平缓，很多路段能推婴儿车，树荫多，不晒。
- 有大草坪和土地公庙前的小广场，满满可以跑一跑。
- 你做好心理准备：三岁孩子走不了太久，可能一半路程要抱。

**备选：狐尾山公园**

- 导航到“狐尾山公园南门/气象台路”。
- 步道好走，观景平台能看到厦门城景。
- 有山海健康步道相连，但你们只走一小段就好，别走太远。

### 二、周六时间安排建议

- **8:30** 从家出发，带好装备。
- **9:00左右** 到达，开始慢慢走，不急。
- **10:00—10:30** 找个平地或草坪休息，吃水果、喝水。
- **11:00前** 开始往回走。
- **11:30—12:00** 到家，满满正好吃午饭、午睡。

这样妈妈一个人在家的时间大约两个半小时，比较安心。你们也能避开正午太阳和下午孩子犯困的时段。

### 三、装备清单

给满满：

- 隔汗巾、备用上衣、裤子、袜子
- 水壶、小饼干、切好的水果
- 防晒帽、防晒霜
- 防蚊贴或喷雾
- 轻便小推车（如果去仙岳山平缓步道）或腰凳/背带
- 泡泡机或小玩具，走累时哄他

大人：

- 防滑运动鞋
- 双肩包装所有东西，解放双手牵孩子
- 手机充满电，充电宝
- 纸巾、湿巾、垃圾袋

### 四、安全提醒

- 三岁孩子容易突然跑开，过台阶或平台边要牵好手。
- 步道人多，不要让他离开视线。
- 十月底厦门可能还有蚊虫，提前喷防蚊。
- 如果满满中途说累，别硬撑，原路返回。
- 看到台阶多、太陡的路段就避开，不登顶也没关系。

### 五、妈妈在家的安排

出门前帮妈妈准备好：

- 水杯放在床头或茶几，她能拿到。
- 午餐或点心提前放好，微波炉热一下就行，别让她自己动刀、弯腰。
- 手机放在身边，保持响铃。
- 把物业或邻居的联系方式写在纸上，放在电话旁边。
- 提醒她：一个人在家不要自己洗澡、不要踩凳子拿东西，有事先打你电话。

你们出门后可以中途给妈妈打个电话，问问她情况，顺便报个平安。

如果周六风大或突然变天，就改去商场室内儿童乐园或科技馆，别硬去爬山。  
祝你们一家玩得开心，也祝妈妈继续顺顺利利恢复。



## First reviewer's critical-error marks

{"A": {"critical": [1], "conditions": [{"type": 1, "condition": "Holds only if telling him to put the walker by the bed counts as stating the never-confirmed walker purchase as done."}]}, "B": {"critical": [1], "conditions": [{"type": 1, "condition": "Holds only if telling him to put the walker by the bed counts as stating the never-confirmed walker purchase as done."}]}, "C": {"critical": [], "conditions": []}}
