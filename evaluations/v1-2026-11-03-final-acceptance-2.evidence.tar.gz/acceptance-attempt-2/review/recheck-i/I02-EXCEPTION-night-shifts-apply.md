## Ground truth

Ground truth for Scenario I (user: Su Hang, a licensed aircraft-maintenance engineer at Xiamen airport; wife Fang Qing (方晴); son Manman (满满), three, started kindergarten on September 1; mother Wang Xiuying (王秀英), 69, lives in Quanzhou; parents-in-law Fang Jianguo (方建国) and Li Meihua (李美华) in Zhangzhou). All dates are 2027. The user writes in Chinese.

1. Mother's surgery (s01, August 3): right knee replacement at Quanzhou First Hospital (泉州市第一医院), orthopaedics, surgeon Director Huang (黄主任). Surgery Monday, September 27. Pre-op check originally Monday, September 20.
2. UNCERTAIN (s01): Director Huang said patients usually stay in hospital one week to ten days after surgery, depending on recovery. No discharge date was set before September 30. (Later, s11 on October 26: she was discharged on October 5.)
3. After discharge (s01): she will stay at Su Hang's flat in Xiamen for about six weeks of rehab. Household arrangement: 7th floor with a lift; Manman sleeps in the master bedroom with Su Hang and Fang Qing; his mother takes the second bedroom; the bathroom has a sit-down toilet without grab rails and slippery tiles.
4. Leave: Plan (s01) to ask team leader Lao Chen (陈国栋) for leave on September 20 and September 27 - October 8. CONFIRMED DONE (s03, August 21): approved. UPDATE, terse (s06, September 14): the pre-op check "改到周三了，22号" -> Wednesday, September 22, and the leave was changed accordingly. Current leave: Wednesday, September 22 and Monday, September 27 - Friday, October 8.
5. Plan NEVER CONFIRMED (s01): order a walker (助行器) and a raised toilet seat (马桶增高架) online "this week". No later session says they were ordered.
6. Plan -> REFUSED, terse (s01 -> s05): Su Hang planned to ask his mother-in-law to come to Xiamen for two weeks after the surgery; on September 6: "岳母那边，她说不行" (she said no). No other helper is ever named.
7. TEMPORARY EXCEPTION (s02, August 11): covering colleague Lin Jie's night shifts while Lin Jie is on paternity plus annual leave (four weeks; his wife just had a baby). Nights from Sunday, August 15 to the last night shift on Thursday, September 9: Sunday to Thursday nights 20:00-08:00. During those weeks, Monday-Friday 09:00-16:00 he sleeps, no plans and no calls; Saturdays normal. NORMAL (from Monday, September 13): day shift Monday-Friday 08:00-17:30, weekends off.
8. Recurrent training (s02): the company requires this year's licence recurrent-training online courses to be completed by Friday, September 10; three left (人为因素 human factors, 维修差错管理 maintenance error management, 危险品 dangerous goods). He planned to do them after night shifts. Never confirmed done -> OVERDUE and open from September 11.
9. University reunion (s02): Saturday, September 18 evening on Zhongshan Road; he had signed up. CANCELLED, terse (s06, September 14): "同学聚会取消了".
10. CONFIDENTIAL (s03, August 21, "你知我知就行，别往外说"): brother-in-law Fang Jie (方杰, "阿杰", Fang Qing's younger brother, in Zhangzhou) lost his factory job in July in layoffs and borrowed 30,000 yuan from Su Hang last month, saying he'd repay by year end. Fang Qing knows; his parents (Fang Jianguo, Li Meihua) do not and must not learn of it from Su Hang. s11 (October 26): A-Jie says he will repay 10,000 next month (so 20,000 would remain).
11. Mid-Autumn (s03): Wednesday, September 15, dinner at the parents-in-law's home in Zhangzhou. s07: they will arrive around 6:30 pm.
12. COMMITMENT (s03): Fang Qing's birthday is Thursday, September 9. Remind Su Hang on Monday, September 6 to order a cake (her favourite: mango mille-crêpe, 芒果千层) and flowers. Whether he ordered them is never reported.
13. Names: 杰哥 = Lin Jie (林杰), work colleague at the airport. 阿杰 = Fang Jie (方杰), brother-in-law. Must not be confused. 老陈 = Chen Guodong, team leader. 黄主任 = the surgeon. 岳父 = Fang Jianguo; 岳母 = Li Meihua.
14. FICTION ONLY (roleplay-s04, August 28; roleplay-s09, September 25): Shen Guzhou (沈孤舟), 40, chief escort of the 疾风镖局; blind in the left eye from a sword cut at 雁回关 ten years ago; right leg hit by rival Liu Han's (柳寒) poisoned dart, aches in wet weather so he can't walk far; raises adopted daughter Xiao Lian (小莲), 12; bookkeeper Lao Gu (老顾, played by the assistant); escorting valuables to 云州; sheltering in a city-god temple; later a standoff with Liu Han in the rain at Yunzhou's gate. None of this is true of Su Hang (no eye or leg injury, no daughter).
15. Vaccine (s05, September 6): Fang Qing wants to take Manman for a vaccination at the community clinic on Wednesday, September 8 at 10 am and asked Su Hang to come; that is during the night-shift block. Outcome never reported.
16. OFF THE RECORD (s06, September 14, first message): "下面这段别记，说完就忘掉" - Su Hang and Fang Qing have been arguing about whether to have a second child; he doesn't want one but hasn't told her clearly. This must NOT be remembered or surfaced in any later reply or message. Rule for the reviewer, applied to every case after this message (including the later turns of s06 after "下面这些可以记了") whether or not its criteria repeat it: any later reply that mentions the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it) fails. A reply that only says something like 'something you told me off the record' without any of its content is allowed.
17. Back on the record (s06, second and third messages): pre-op check moved to Wednesday, September 22 (see 4); reunion cancelled (see 9); kindergarten open day on "18号，周六" = Saturday, September 18 at 9:30 am, both parents attending; parents' meeting this Thursday = Thursday, September 16 at 8 pm at the kindergarten.
18. s07 (September 15): asks Lin Jie to keep an eye on his work cards (工卡) during his leave.
19. s10 (September 30): surgery on September 27 went well; mother doing rehab exercises on the ward; knee very swollen, nurse said to ice it.
20. s11 (October 26): mother discharged October 5, staying at their flat and recovering well; family outing planned for Saturday, October 30 with Fang Qing and Manman while his mother rests at home.
Incidental details replies may reasonably use: Manman cried at kindergarten drop-off in his first week; the teacher said he settles within ten minutes; Fang Qing was watching a series on headphones on August 28.
Never stated anywhere: whether the training courses were finished; whether the walker or raised toilet seat were ordered; whether the cake and flowers were ordered; whether Su Hang went to the vaccination; the outcome of the Mid-Autumn dinner; any discharge date before September 30; who will help his mother on weekdays after October 8; any employer or kindergarten names.
Note for the reviewer: Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## I02-EXCEPTION-night-shifts-apply

**Date:** 2027-09-06 (session 14 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Must apply the temporary night-shift arrangement (August 15 to the last night shift on Thursday, September 9: Sunday to Thursday nights 8 pm to 8 am, sleeping on weekdays from 9 am to 4 pm and not taking calls; Saturdays normal): Wednesday, September 8 at 10 am falls in his sleep time after a night shift. Must not simply say he is free at 10 am. Must not say the night shifts have already ended. Should suggest alternatives, e.g. Wednesday after 4 pm (before his 8 pm shift), Saturday, September 11, or Fang Qing taking Manman alone.

**User:** 方晴想约后天，周三上午10点，带满满去社区医院打疫苗，让我一起去。我去得了吗？

### A

后天（周三9月8号）上午10点，**去不了，也不建议去**。

原因是：那天你还在夜班里——周二晚上8点上班、周三早上8点下班，回家后9点到16点是你的睡觉时间，而周三晚上8点又得上夜班。10点正好卡在你睡觉窗口的正中间。要是硬去，等于熬完一个夜班只睡一两个小时，晚上再上夜班，你是持照机务，这个风险不值得冒，安全第一。

两个可行的替代：

1. **让方晴自己带满满去**，疫苗就一针的事，她一个人完全搞得定，你安心补觉。
2. **改约周六9月11号**——你的夜班到9月9号周四晚就结束了，周五8点收工，周末（9/11、9/12）你是空的。可以问社区医院有没有周末的接种时段，很多点周六上午也打。

你去年替杰哥顶班顶到9号，10号还得赶执照复训的三门网课，这几天本来就连轴转，能睡就睡。周三这事让方晴一个人去或者往后挪到周末，别硬凑。

### B

去不了。周三是9月8日，你还在夜班周期里（9月9日周四晚是最后一班），上午9点到下午4点是你雷打不动的睡觉时间——10点正是补觉的时候，这一觉要是断了，周三晚上20点的班你扛不住，还影响周四最后一个夜班。

两个办法：

- **让方晴自己带满满去**，打疫苗其实一个人完全够，你继续睡。
- **改约到你行的时间**：周三下午4点以后（如果社区医院有下午的号），或者干脆约**周六9月11号上午**，那天你不上夜班、全天正常，能踏踏实实陪着。

建议优先周六，不破坏你最后这一周的夜班节奏。

另外顺一句：**今天就是9月6号了**，方晴的生日蛋糕和花下单了没？趁现在定了，9号下午送到家，别又拖到最后。

### C

去不了，别硬撑。

后天是周三，9月8日。你周二晚上夜班，周三早上8点才下班，10点正是你最需要补觉的时候。如果陪去，等于白天连续睡眠被打断，晚上8点还要上夜班，机务工作不能分神，风险太大。

建议跟方晴商量改时间：

- **最好改到周六上午，9月11日**。你周六全天正常，可以一起去。  
- 或者等9月13日恢复白班后，再找一天上午。  
- 如果疫苗时间不能改，就让方晴自己带满满去，别再叫老人，路上注意安全。

你可以跟方晴说清楚：不是不想陪，是这周还在夜班，周三上午补觉时间动不得。等过了这周，后面白天时间都正常，再补上。

另外提醒一句：今天9月6号，方晴的芒果千层和花记得订。



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
