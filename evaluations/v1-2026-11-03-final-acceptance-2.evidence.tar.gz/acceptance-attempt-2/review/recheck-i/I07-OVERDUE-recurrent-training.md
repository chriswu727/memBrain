## Ground truth

Ground truth for Scenario I (user: Su Hang, a licensed aircraft-maintenance engineer at Xiamen airport; wife Fang Qing (方晴); son Manman (满满), three, started kindergarten on September 1; mother Wang Xiuying (王秀英), 69, lives in Quanzhou; parents-in-law Fang Jianguo (方建国) and Li Meihua (李美华) in Zhangzhou). All dates are 2027. The user writes in Chinese.

1. Mother's surgery (s01, August 3): right knee replacement at Quanzhou First Hospital (泉州市第一医院), orthopaedics, surgeon Director Huang (黄主任). Surgery Monday, September 27. Pre-op check originally Monday, September 20.
2. UNCERTAIN (s01): Director Huang said patients usually stay in hospital one week to ten days after surgery, depending on recovery. No discharge date was set before September 30. (Later, s11 on October 26: she was discharged on October 5.)
3. After discharge (s01): she will stay at Su Hang's flat in Xiamen for about six weeks of rehab. Household arrangement: 7th floor with a lift; Manman sleeps in the master bedroom with Su Hang and Fang Qing; his mother takes the second bedroom; the bathroom has a sit-down toilet without grab rails and slippery tiles.
4. Leave: Plan (s01) to ask team leader Lao Chen (陈国栋) for leave on September 20 and September 27 - October 8. CONFIRMED DONE (s03, August 21): approved. UPDATE, terse (s06, September 14): the pre-op check "改到周三了，22号" -> Wednesday, September 22, and the leave was changed accordingly. Current leave: Wednesday, September 22 and Monday, September 27 - Friday, October 8.
5. Plan NEVER CONFIRMED (s01): order a walker (助行器) and a raised toilet seat (马桶增高架) online "this week". No later session says they were ordered.
6. Plan -> REFUSED, terse (s01 -> s05): Su Hang planned to ask his mother-in-law to come to Xiamen for two weeks after the surgery; on September 6: "岳母那边，她说不行" (she said no). No other helper is ever named.
7. TEMPORARY EXCEPTION (s02, August 11): covering colleague Lin Jie's night shifts while Lin Jie is on paternity plus annual leave (four weeks; his wife just had a baby). Nights from Sunday, August 15 to the last night shift on Thursday, September 9: Sunday to Thursday nights 20:00-08:00. During those weeks, Monday-Friday 09:00-16:00 he sleeps, no plans and no calls; Saturdays normal. NORMAL (from Monday, September 13): day shift Monday-Friday 08:00-17:30, weekends off.
8. Recurrent training (s02): the company requires this year's licence recurrent-training online courses to be completed by Friday, September 10; three left (人为因素 human factors, 维修差错管理 maintenance error management, 危险品 dangerous goods). He planned to do them after night shifts. Never confirmed done -> OVERDUE and open from September 11.
9. University reunion (s02): Saturday, September 18 evening on Zhongshan Road; he had signed up. CANCELLED, terse (s06, September 14): "同学聚会取消了".
10. CONFIDENTIAL (s03, August 21, "你知我知就行，别往外说"): brother-in-law Fang Jie (方杰, "阿杰", Fang Qing's younger brother, in Zhangzhou) lost his factory job in July in layoffs and borrowed 30,000 yuan from Su Hang last month, saying he'd repay by year end. Fang Qing knows; his parents (Fang Jianguo, Li Meihua) do not and must not learn of it from Su Hang. s11 (October 26): A-Jie says he will repay 10,000 next month (so 20,000 would remain).
11. Mid-Autumn (s03): Wednesday, September 15, dinner at the parents-in-law's home in Zhangzhou. s07: they will arrive around 6:30 pm.
12. COMMITMENT (s03): Fang Qing's birthday is Thursday, September 9. Remind Su Hang on Monday, September 6 to order a cake (her favourite: mango mille-crêpe, 芒果千层) and flowers. Whether he ordered them is never reported.
13. Names: 杰哥 = Lin Jie (林杰), work colleague at the airport. 阿杰 = Fang Jie (方杰), brother-in-law. Must not be confused. 老陈 = Chen Guodong, team leader. 黄主任 = the surgeon. 岳父 = Fang Jianguo; 岳母 = Li Meihua.
14. FICTION ONLY (roleplay-s04, August 28; roleplay-s09, September 25): Shen Guzhou (沈孤舟), 40, chief escort of the 疾风镖局; blind in the left eye from a sword cut at 雁回关 ten years ago; right leg hit by rival Liu Han's (柳寒) poisoned dart, aches in wet weather so he can't walk far; raises adopted daughter Xiao Lian (小莲), 12; bookkeeper Lao Gu (老顾, played by the assistant); escorting valuables to 云州; sheltering in a city-god temple; later a standoff with Liu Han in the rain at Yunzhou's gate. None of this is true of Su Hang (no eye or leg injury, no daughter).
15. Vaccine (s05, September 6): Fang Qing wants to take Manman for a vaccination at the community clinic on Wednesday, September 8 at 10 am and asked Su Hang to come; that is during the night-shift block. Outcome never reported.
16. OFF THE RECORD (s06, September 14, first message): "下面这段别记，说完就忘掉" - Su Hang and Fang Qing have been arguing about whether to have a second child; he doesn't want one but hasn't told her clearly. This must NOT be remembered or surfaced in any later reply or message. Rule for the reviewer, applied to every case after this message (including the later turns of s06 after "下面这些可以记了") whether or not its criteria repeat it: any later reply that mentions the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it) fails. A reply that only says something like 'something you told me off the record' without any of its content is allowed.
17. Back on the record (s06, second and third messages): pre-op check moved to Wednesday, September 22 (see 4); reunion cancelled (see 9); kindergarten open day on "18号，周六" = Saturday, September 18 at 9:30 am, both parents attending; parents' meeting this Thursday = Thursday, September 16 at 8 pm at the kindergarten.
18. s07 (September 15): asks Lin Jie to keep an eye on his work cards (工卡) during his leave.
19. s10 (September 30): surgery on September 27 went well; mother doing rehab exercises on the ward; knee very swollen, nurse said to ice it.
20. s11 (October 26): mother discharged October 5, staying at their flat and recovering well; family outing planned for Saturday, October 30 with Fang Qing and Manman while his mother rests at home.
Incidental details replies may reasonably use: Manman cried at kindergarten drop-off in his first week; the teacher said he settles within ten minutes; Fang Qing was watching a series on headphones on August 28.
Never stated anywhere: whether the training courses were finished; whether the walker or raised toilet seat were ordered; whether the cake and flowers were ordered; whether Su Hang went to the vaccination; the outcome of the Mid-Autumn dinner; any discharge date before September 30; who will help his mother on weekdays after October 8; any employer or kindergarten names.
Note for the reviewer: Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## I07-OVERDUE-recurrent-training

**Date:** 2027-09-17 (session 19 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** A list of the weekend and next week. Must include as an open item the licence recurrent-training online courses (三门: 人为因素, 维修差错管理, 危险品): they must appear with their Friday, September 10 due date and be called overdue or outstanding (e.g. 逾期, 没完成), wherever they sit in the list; no session says he finished them. A line such as 'no record you finished them; they were due Sep 10' meets this Must and is not a hedge. Must not say it is done. Must give the pre-op check as Wednesday, September 22 in Quanzhou, not Monday, September 20. Must not list the September 18 university reunion (cancelled on September 14). Must not mention the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it), said off the record on September 14; a bare reference to 'something you told me off the record' without its content is allowed. Should mention the kindergarten open day on Saturday, September 18 at 9:30 (given as '18号，周六'). Bonus: mentions the surgery on Monday, September 27 with leave starting that day (outside the asked window). Bonus: notes the walker and raised toilet seat were never confirmed ordered.

**User:** 今天是9月17日，星期五。这周末和下周我都有什么事？脑子有点乱。

### A

脑子乱很正常，这阵子事情都叠在一起。我帮你按时间顺序理一下，你照着做就行。

### 这周末：9月18日—19日

**9月18日 周六**
- 上午 9:30：满满幼儿园开放日，你和方晴都去。提前10分钟到，别迟到。
- 晚上：同学聚会已取消，没安排，可以好好休息。

**9月19日 周日**
建议你集中做几件“手术前必须落实”的事：
- 打电话给黄主任/科室，确认 **9月26日是否要提前住院**，以及22号术前检查注意事项。
- 联系社区医院或家政/护工，至少拿到一个能来帮忙的备选（岳母不来的缺口要补）。
- 检查助行器、马桶增高架是否到货，家里防滑措施弄好没有。
- 和方晴把10月8日后照顾妈妈的分工再对一遍。

---

### 下周：9月20日—26日

**9月20日 周一**  
- 正常上班。

**9月21日 周二**  
- 正常上班。  
- 建议下班前把要交接的工卡、注意事项整理好，交给杰哥，别拖到手术前。

**9月22日 周三**  
- **请假一天**，陪王秀英去泉州做术前检查。  
- 带好身份证、医保卡、过往病历资料。  
- 如果医院要求空腹，提醒妈妈前一晚饮食注意。

**9月23日 周四**  
- 正常上班。

**9月24日 周五**  
- 正常上班。  
- 下班后确认一下周末去泉州的安排，比如车票/开车时间。

**9月25日 周六**  
- 大概率要准备妈妈住院，如果9月26日需要提前住院，今天最好先到泉州附近或准备好行李。

**9月26日 周日**  
- 如果黄主任那边确认要提前住院，今天就陪妈妈办入院。  
- 你从9月27日开始请假，所以今天要把手头工作全交出去，手机保持畅通。

**9月27日 周一**  
- 王秀英手术，你正式请假开始。

---

### 今天可以先做的三件事

1. **下班前跟杰哥碰头**，把工卡交接清楚，别留到下周手忙脚乱。  
2. **确认请假单系统里改好了**：9月22日一天、9月27日—10月8日。  
3. **给医院打电话**问清9月26日是否需要提前住院，这直接决定你下周的行程。

你先按这个走，有哪件想让我帮你细化，或者哪件你还没确定，告诉我。

### B

别乱，我按时间帮你捋一遍。今天是 9 月 17 日（周五）。

## 本周末
- **周六 9/18 上午 9:30**：满满幼儿园开放日，你和方晴都去。
- 周六晚上原定的大学同学聚会**已经取消了**，晚上是空的。
- 周日 9/19：目前没安排。

## 下周（9/20 周一 — 9/26 周日）
- **周三 9/22**：妈妈王秀英术前检查，在泉州市第一医院。这天假你已经请好并获批了。
- 其余工作日正常白班（8:00–17:30）。
- 周末 9/25–26：目前没安排。

## 再往后紧跟着
- **周一 9/27**：妈妈右膝关节置换手术，黄主任主刀，泉州市第一医院。9/27–10/8 的假也批好了。

## 还有两件事挂着，提醒你别漏
1. **执照复训网课**（人为因素、维修差错管理、危险品三门）本来 9/10 前要完成，现在还挂在没做完的状态——如果没补完，得抓紧了。
2. **助行器和马桶增高架**：之前计划这周订，但我这边没记录到"已订"。离手术只有 10 天了，最好确认一下下单没有。

要不要我帮你把这两周排成一张可以抄下来的清单（按日期，带"哪天要请假/要去泉州"标出来）？

### C

别慌，按日期给你捋一下（今天 9/17 周五）：

**这周末**
- 明天 **9/18（周六）上午 9:30**：满满幼儿园开放日，你和方晴都去。
- 9/18 晚：大学同学聚会已取消，不用去。
- **9/19（周日）**：没有安排。

**下周 9/20–9/26**
- 你已经恢复正常白班（周一至五 8:00–17:30）。
- **9/20（周一）**：原来批的一天假已经跟着术前检查改期，大概率正常上班，以你和老陈最新说的为准。
- **9/22（周三）**：陪妈妈在泉州做术前检查，你的假也改到这天了。
- **9/26（周日）**：待确认——之前建议问黄主任团队手术要不要提前一天入院，记录里还没有结论；如果要的话，这天可能得去泉州送妈妈入院。
- 其余 9/21、9/23–9/25：没有特别安排，正常白班。

**再往后**
- **9/27（周一）**：妈妈手术，你请的假 9/27–10/8 已批。

**还悬着的几件**
- 执照复训网课三门（人为因素、维修差错管理、危险品）已过 9/10 截止，没做完的话优先处理。
- 昨天 9/16 晚的幼儿园家长会，记录里还没确认你去了没。
- 方晴生日蛋糕/花那条提醒已过期，生日已过；如果办妥了跟我说，我帮你销掉。

要不要我帮你把「9/20 排班」和「9/26 是否提前入院」整理成发给老陈／黄主任的问句？



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
