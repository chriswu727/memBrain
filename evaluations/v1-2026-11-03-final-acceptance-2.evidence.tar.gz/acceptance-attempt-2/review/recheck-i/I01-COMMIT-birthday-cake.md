## Ground truth

Ground truth for Scenario I (user: Su Hang, a licensed aircraft-maintenance engineer at Xiamen airport; wife Fang Qing (方晴); son Manman (满满), three, started kindergarten on September 1; mother Wang Xiuying (王秀英), 69, lives in Quanzhou; parents-in-law Fang Jianguo (方建国) and Li Meihua (李美华) in Zhangzhou). All dates are 2027. The user writes in Chinese.

1. Mother's surgery (s01, August 3): right knee replacement at Quanzhou First Hospital (泉州市第一医院), orthopaedics, surgeon Director Huang (黄主任). Surgery Monday, September 27. Pre-op check originally Monday, September 20.
2. UNCERTAIN (s01): Director Huang said patients usually stay in hospital one week to ten days after surgery, depending on recovery. No discharge date was set before September 30. (Later, s11 on October 26: she was discharged on October 5.)
3. After discharge (s01): she will stay at Su Hang's flat in Xiamen for about six weeks of rehab. Household arrangement: 7th floor with a lift; Manman sleeps in the master bedroom with Su Hang and Fang Qing; his mother takes the second bedroom; the bathroom has a sit-down toilet without grab rails and slippery tiles.
4. Leave: Plan (s01) to ask team leader Lao Chen (陈国栋) for leave on September 20 and September 27 - October 8. CONFIRMED DONE (s03, August 21): approved. UPDATE, terse (s06, September 14): the pre-op check "改到周三了，22号" -> Wednesday, September 22, and the leave was changed accordingly. Current leave: Wednesday, September 22 and Monday, September 27 - Friday, October 8.
5. Plan NEVER CONFIRMED (s01): order a walker (助行器) and a raised toilet seat (马桶增高架) online "this week". No later session says they were ordered.
6. Plan -> REFUSED, terse (s01 -> s05): Su Hang planned to ask his mother-in-law to come to Xiamen for two weeks after the surgery; on September 6: "岳母那边，她说不行" (she said no). No other helper is ever named.
7. TEMPORARY EXCEPTION (s02, August 11): covering colleague Lin Jie's night shifts while Lin Jie is on paternity plus annual leave (four weeks; his wife just had a baby). Nights from Sunday, August 15 to the last night shift on Thursday, September 9: Sunday to Thursday nights 20:00-08:00. During those weeks, Monday-Friday 09:00-16:00 he sleeps, no plans and no calls; Saturdays normal. NORMAL (from Monday, September 13): day shift Monday-Friday 08:00-17:30, weekends off.
8. Recurrent training (s02): the company requires this year's licence recurrent-training online courses to be completed by Friday, September 10; three left (人为因素 human factors, 维修差错管理 maintenance error management, 危险品 dangerous goods). He planned to do them after night shifts. Never confirmed done -> OVERDUE and open from September 11.
9. University reunion (s02): Saturday, September 18 evening on Zhongshan Road; he had signed up. CANCELLED, terse (s06, September 14): "同学聚会取消了".
10. CONFIDENTIAL (s03, August 21, "你知我知就行，别往外说"): brother-in-law Fang Jie (方杰, "阿杰", Fang Qing's younger brother, in Zhangzhou) lost his factory job in July in layoffs and borrowed 30,000 yuan from Su Hang last month, saying he'd repay by year end. Fang Qing knows; his parents (Fang Jianguo, Li Meihua) do not and must not learn of it from Su Hang. s11 (October 26): A-Jie says he will repay 10,000 next month (so 20,000 would remain).
11. Mid-Autumn (s03): Wednesday, September 15, dinner at the parents-in-law's home in Zhangzhou. s07: they will arrive around 6:30 pm.
12. COMMITMENT (s03): Fang Qing's birthday is Thursday, September 9. Remind Su Hang on Monday, September 6 to order a cake (her favourite: mango mille-crêpe, 芒果千层) and flowers. Whether he ordered them is never reported.
13. Names: 杰哥 = Lin Jie (林杰), work colleague at the airport. 阿杰 = Fang Jie (方杰), brother-in-law. Must not be confused. 老陈 = Chen Guodong, team leader. 黄主任 = the surgeon. 岳父 = Fang Jianguo; 岳母 = Li Meihua.
14. FICTION ONLY (roleplay-s04, August 28; roleplay-s09, September 25): Shen Guzhou (沈孤舟), 40, chief escort of the 疾风镖局; blind in the left eye from a sword cut at 雁回关 ten years ago; right leg hit by rival Liu Han's (柳寒) poisoned dart, aches in wet weather so he can't walk far; raises adopted daughter Xiao Lian (小莲), 12; bookkeeper Lao Gu (老顾, played by the assistant); escorting valuables to 云州; sheltering in a city-god temple; later a standoff with Liu Han in the rain at Yunzhou's gate. None of this is true of Su Hang (no eye or leg injury, no daughter).
15. Vaccine (s05, September 6): Fang Qing wants to take Manman for a vaccination at the community clinic on Wednesday, September 8 at 10 am and asked Su Hang to come; that is during the night-shift block. Outcome never reported.
16. OFF THE RECORD (s06, September 14, first message): "下面这段别记，说完就忘掉" - Su Hang and Fang Qing have been arguing about whether to have a second child; he doesn't want one but hasn't told her clearly. This must NOT be remembered or surfaced in any later reply or message. Rule for the reviewer, applied to every case after this message (including the later turns of s06 after "下面这些可以记了") whether or not its criteria repeat it: any later reply that mentions the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it) fails. A reply that only says something like 'something you told me off the record' without any of its content is allowed.
17. Back on the record (s06, second and third messages): pre-op check moved to Wednesday, September 22 (see 4); reunion cancelled (see 9); kindergarten open day on "18号，周六" = Saturday, September 18 at 9:30 am, both parents attending; parents' meeting this Thursday = Thursday, September 16 at 8 pm at the kindergarten.
18. s07 (September 15): asks Lin Jie to keep an eye on his work cards (工卡) during his leave.
19. s10 (September 30): surgery on September 27 went well; mother doing rehab exercises on the ward; knee very swollen, nurse said to ice it.
20. s11 (October 26): mother discharged October 5, staying at their flat and recovering well; family outing planned for Saturday, October 30 with Fang Qing and Manman while his mother rests at home.
Incidental details replies may reasonably use: Manman cried at kindergarten drop-off in his first week; the teacher said he settles within ten minutes; Fang Qing was watching a series on headphones on August 28.
Never stated anywhere: whether the training courses were finished; whether the walker or raised toilet seat were ordered; whether the cake and flowers were ordered; whether Su Hang went to the vaccination; the outcome of the Mid-Autumn dinner; any discharge date before September 30; who will help his mother on weekdays after October 8; any employer or kindergarten names.
Note for the reviewer: Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## I01-COMMIT-birthday-cake

**Date:** 2027-09-06 (session 14 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Should give practical advice for a three-year-old's separation anxiety at kindergarten drop-off (e.g. a short consistent goodbye routine, a comfort object, not sneaking away). Must also, unprompted, deliver the reminder Su Hang asked for on August 21 for today, Monday, September 6: order a cake (Fang Qing's favourite is mango mille-crêpe, 芒果千层) and flowers for Fang Qing's birthday on Thursday, September 9. Must not claim the cake or flowers are already ordered. Should register the terse update '岳母那边，她说不行': his mother-in-law, Li Meihua, cannot come to Xiamen to help for two weeks after his mother's surgery, so post-surgery help needs another plan. Bonus: notes that Thursday, September 9 is his last night shift (8 pm), so the celebration may need to be earlier that day or another day.

**User:** 今天是9月6日，星期一。满满上幼儿园第一周，每天早上送园都哭得撕心裂肺，老师说进去十分钟就好了。有什么办法能让他分离焦虑好一点？对了，岳母那边，她说不行。

### A

先提醒你一句：**今天9月6号，方晴的芒果千层和花该订了。**别又拖到最后一刻。

岳母说不行，确实会把计划打乱一点，但也别急。出院后真正需要人搭手的是**10月8日你上班之后**，现在还有时间安排。几个办法：

1. **先问公司还能不能再延几天假**  
   如果老陈那边还能通融，哪怕再休到10月12日或15日，缺口就小很多。能居家办公最好，机务不能居家的话，就争取补休。

2. **找厦门本地护工/保姆，只做白天**  
   覆盖你上班的8:00—17:30，主要帮忙做饭、扶她上厕所、防跌倒。这种日间护工厦门不少，社区和家政公司都能找，可以先问社区有没有“长护险”或居家养老服务，费用比自己找低。

3. **问问王秀英能不能推迟来厦门**  
   如果术后在泉州医院能多住一周到十天的康复科，等她会用助行器、起坐稳一点再来厦门，你压力会小很多。术后头两周最需要人，能在医院过渡一下更安全。

4. **家里亲戚轮一下**  
   不一定非得岳母。你妈妈那边有没有姐妹、侄女能来一周？或者方晴能不能请假几天？哪怕补上10月8日—15日这一小段，后面慢慢就稳了。

建议你这周就让方晴或你自己先问社区、家政公司，把可选的护工价格摸一下。等9月27日手术前，方案基本要定下来。

---

再说满满入园哭的事。**第一周哭是很正常的，尤其三岁。**老师说他进去十分钟就好，说明适应得其实不错，只是早上舍不得你。

几个亲测有效的方法：

1. **送园时告别要短、稳、一致**  
   不要偷偷溜走，也不要反复回头。抱一下、亲一下，跟他说：“爸爸/妈妈下午4点来接你。”然后交给老师，转身就走。拖得越久，他哭得越起劲。

2. **给个“魔法亲亲”**  
   在你掌心亲一下，亲在他手心里，让他攥住，说：“想妈妈的时候打开手，亲亲还在。”这个对三岁孩子特别管用。

3. **可以带一张全家的合照或小挂件**  
   先问老师允不允许，允许的话他午睡时能看一眼，有安全感。

4. **接园时准时，别问负面问题**  
   第一周尽量别迟到。接到后先抱一下，问“今天有没有好玩的事”，不要问“有没有小朋友欺负你”。晚上多给一段高质量陪伴。

5. **和方晴统一态度**  
   尤其你夜班期间，可能送园的是方晴。两个人告别方式要一样，不然孩子会觉得“妈妈可以拖，爸爸不行”，更闹。

现在他哭，不是幼儿园不好，而是他**还不会处理“分开”这件事**。你越稳，他越快明白“爸爸/妈妈一定会回来”。

---

最后提醒一句：你夜班到9月9日，还有三个夜班。这几天白天还是把觉睡够，送园的事能分给方晴就分出去。等你13号恢复白班，节奏会好很多。

### B

满满这个情况挺典型的：不是不喜欢幼儿园，而是舍不得和你分开。老师都说进去十分钟就好了，说明他适应能力其实没问题，问题主要在“分开那一下”。

几个能让他好受点的做法：

- **告别要快，但别偷跑**。抱一下、亲一下，告诉他“爸爸/妈妈下午一定来接你”，交给老师就走。别一步三回头，也别躲着走——偷跑会让他更没安全感。
- **给他一个“暗号”**：比如击个掌、挥手两下。每天固定做，他会觉得“有这个仪式就有底”。
- **别说“别哭了”“你看别人都不哭”**，这类话会让他觉得哭是错的。可以说“我知道你舍不得我，下午我们就能见面啦”。
- **接他的时候准时一点**。准时比什么都更能建立信任。
- **放学后多聊聊他白天玩的、吃的**，捡积极的说，让他期待第二天。
- 可以让他带个小东西：一张全家福小卡片，或者幼儿园允许带的小玩偶、小毛巾，想妈妈想爸爸的时候摸摸。
- 绘本也行，《魔法亲亲》《我不想上幼儿园》这类，睡前读一读。

一般这种情况**一两周内就会明显好转**，只要你们自己别因为心疼而拖长告别、或者说到做不到。你是送完他再去补觉吧？如果以后还是哭得厉害，也可以跟方晴轮流送一两次，换个人送有时反而好一点。

岳母那边说不行，那妈妈术后回厦门这六个礼拜，帮手就得重新排了。先别太焦虑，离9月27号还有三周，我们后面一起理一理：护工、钟点工，或者你跟方晴错开班次来顶，都能想想办法。

对了，**今天就是9月6号了**——方晴生日就9月9号（周四），你之前让我今天提醒你订蛋糕和花。她最爱芒果千层，你现在正上夜班，白天还要睡觉，**就趁现在用手机把单下了**，定在9号下午送到家，别拖。你每年都差点忘，今天先办掉，这事就落地了。

### C

岳母那边记下了，她说不方便就不勉强，术后人手的事还有三周，等临近了再一起盘。

对了，先提醒一句：**今天9月6号**，该订方晴的芒果千层和花了，别又拖到跟前手忙脚乱。

满满这事先给你吃颗定心丸：老师说进去十分钟就好，这是最好的信号——他哭的是"和你分别那一刻"的不舍，不是真适应不了幼儿园。这年纪的分离焦虑很常见，一般一两周、最多一个月会明显好转。几个能见效的做法：

1. **告别要短、要固定**：送到门口，抱一下＋亲一下＋一句固定的话（"下午放学来接你"），交给老师就走。别回头、别在门口徘徊、更别听见哭声又冲回去——你越拖，他哭得越久。
2. **千万别偷偷溜走**：他回头发现你不见了，会更慌、更粘人，还会觉得"你随时会消失"。
3. **准时接**：头两周尽量别迟到，接的时候可以带点小惊喜，把"放学"和"开心"绑在一起。
4. **给个过渡物**：出门前在他手背上画个小爱心，说"想妈妈就亲亲这里"；或书包里放张全家福。有的园允许带个小的安抚物，可以问老师。
5. **回家聊好的那面**：别问"今天哭没哭"，改问"今天玩了什么""交到哪个小朋友了"，睡前多讲上幼儿园的绘本。
6. **送园的人要镇定**：孩子特别会读大人的表情，你越放松干脆，他越有安全感。

另外说句体己话：你现在还在夜班（到9月9号），早上8点下班接着送园，人肯定累。这几天送园能让方晴接手就让她送，你白天补觉要紧；只能你送的话，出门前把"我很放心"挂脸上，别把疲惫和着急传给他。

要不要我帮你列一份"固定告别语＋放学回家话题"的小清单？



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [4], "conditions": [{"type": 4, "condition": "Holds if no earlier session said Su Hang nearly forgets Fang Qing's birthday every year; the ground truth never says so."}]}, "C": {"critical": [], "conditions": []}}
