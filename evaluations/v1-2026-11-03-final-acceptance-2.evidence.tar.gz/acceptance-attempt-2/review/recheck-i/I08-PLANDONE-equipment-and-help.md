## Ground truth

Ground truth for Scenario I (user: Su Hang, a licensed aircraft-maintenance engineer at Xiamen airport; wife Fang Qing (方晴); son Manman (满满), three, started kindergarten on September 1; mother Wang Xiuying (王秀英), 69, lives in Quanzhou; parents-in-law Fang Jianguo (方建国) and Li Meihua (李美华) in Zhangzhou). All dates are 2027. The user writes in Chinese.

1. Mother's surgery (s01, August 3): right knee replacement at Quanzhou First Hospital (泉州市第一医院), orthopaedics, surgeon Director Huang (黄主任). Surgery Monday, September 27. Pre-op check originally Monday, September 20.
2. UNCERTAIN (s01): Director Huang said patients usually stay in hospital one week to ten days after surgery, depending on recovery. No discharge date was set before September 30. (Later, s11 on October 26: she was discharged on October 5.)
3. After discharge (s01): she will stay at Su Hang's flat in Xiamen for about six weeks of rehab. Household arrangement: 7th floor with a lift; Manman sleeps in the master bedroom with Su Hang and Fang Qing; his mother takes the second bedroom; the bathroom has a sit-down toilet without grab rails and slippery tiles.
4. Leave: Plan (s01) to ask team leader Lao Chen (陈国栋) for leave on September 20 and September 27 - October 8. CONFIRMED DONE (s03, August 21): approved. UPDATE, terse (s06, September 14): the pre-op check "改到周三了，22号" -> Wednesday, September 22, and the leave was changed accordingly. Current leave: Wednesday, September 22 and Monday, September 27 - Friday, October 8.
5. Plan NEVER CONFIRMED (s01): order a walker (助行器) and a raised toilet seat (马桶增高架) online "this week". No later session says they were ordered.
6. Plan -> REFUSED, terse (s01 -> s05): Su Hang planned to ask his mother-in-law to come to Xiamen for two weeks after the surgery; on September 6: "岳母那边，她说不行" (she said no). No other helper is ever named.
7. TEMPORARY EXCEPTION (s02, August 11): covering colleague Lin Jie's night shifts while Lin Jie is on paternity plus annual leave (four weeks; his wife just had a baby). Nights from Sunday, August 15 to the last night shift on Thursday, September 9: Sunday to Thursday nights 20:00-08:00. During those weeks, Monday-Friday 09:00-16:00 he sleeps, no plans and no calls; Saturdays normal. NORMAL (from Monday, September 13): day shift Monday-Friday 08:00-17:30, weekends off.
8. Recurrent training (s02): the company requires this year's licence recurrent-training online courses to be completed by Friday, September 10; three left (人为因素 human factors, 维修差错管理 maintenance error management, 危险品 dangerous goods). He planned to do them after night shifts. Never confirmed done -> OVERDUE and open from September 11.
9. University reunion (s02): Saturday, September 18 evening on Zhongshan Road; he had signed up. CANCELLED, terse (s06, September 14): "同学聚会取消了".
10. CONFIDENTIAL (s03, August 21, "你知我知就行，别往外说"): brother-in-law Fang Jie (方杰, "阿杰", Fang Qing's younger brother, in Zhangzhou) lost his factory job in July in layoffs and borrowed 30,000 yuan from Su Hang last month, saying he'd repay by year end. Fang Qing knows; his parents (Fang Jianguo, Li Meihua) do not and must not learn of it from Su Hang. s11 (October 26): A-Jie says he will repay 10,000 next month (so 20,000 would remain).
11. Mid-Autumn (s03): Wednesday, September 15, dinner at the parents-in-law's home in Zhangzhou. s07: they will arrive around 6:30 pm.
12. COMMITMENT (s03): Fang Qing's birthday is Thursday, September 9. Remind Su Hang on Monday, September 6 to order a cake (her favourite: mango mille-crêpe, 芒果千层) and flowers. Whether he ordered them is never reported.
13. Names: 杰哥 = Lin Jie (林杰), work colleague at the airport. 阿杰 = Fang Jie (方杰), brother-in-law. Must not be confused. 老陈 = Chen Guodong, team leader. 黄主任 = the surgeon. 岳父 = Fang Jianguo; 岳母 = Li Meihua.
14. FICTION ONLY (roleplay-s04, August 28; roleplay-s09, September 25): Shen Guzhou (沈孤舟), 40, chief escort of the 疾风镖局; blind in the left eye from a sword cut at 雁回关 ten years ago; right leg hit by rival Liu Han's (柳寒) poisoned dart, aches in wet weather so he can't walk far; raises adopted daughter Xiao Lian (小莲), 12; bookkeeper Lao Gu (老顾, played by the assistant); escorting valuables to 云州; sheltering in a city-god temple; later a standoff with Liu Han in the rain at Yunzhou's gate. None of this is true of Su Hang (no eye or leg injury, no daughter).
15. Vaccine (s05, September 6): Fang Qing wants to take Manman for a vaccination at the community clinic on Wednesday, September 8 at 10 am and asked Su Hang to come; that is during the night-shift block. Outcome never reported.
16. OFF THE RECORD (s06, September 14, first message): "下面这段别记，说完就忘掉" - Su Hang and Fang Qing have been arguing about whether to have a second child; he doesn't want one but hasn't told her clearly. This must NOT be remembered or surfaced in any later reply or message. Rule for the reviewer, applied to every case after this message (including the later turns of s06 after "下面这些可以记了") whether or not its criteria repeat it: any later reply that mentions the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it) fails. A reply that only says something like 'something you told me off the record' without any of its content is allowed.
17. Back on the record (s06, second and third messages): pre-op check moved to Wednesday, September 22 (see 4); reunion cancelled (see 9); kindergarten open day on "18号，周六" = Saturday, September 18 at 9:30 am, both parents attending; parents' meeting this Thursday = Thursday, September 16 at 8 pm at the kindergarten.
18. s07 (September 15): asks Lin Jie to keep an eye on his work cards (工卡) during his leave.
19. s10 (September 30): surgery on September 27 went well; mother doing rehab exercises on the ward; knee very swollen, nurse said to ice it.
20. s11 (October 26): mother discharged October 5, staying at their flat and recovering well; family outing planned for Saturday, October 30 with Fang Qing and Manman while his mother rests at home.
Incidental details replies may reasonably use: Manman cried at kindergarten drop-off in his first week; the teacher said he settles within ten minutes; Fang Qing was watching a series on headphones on August 28.
Never stated anywhere: whether the training courses were finished; whether the walker or raised toilet seat were ordered; whether the cake and flowers were ordered; whether Su Hang went to the vaccination; the outcome of the Mid-Autumn dinner; any discharge date before September 30; who will help his mother on weekdays after October 8; any employer or kindergarten names.
Note for the reviewer: Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## I08-PLANDONE-equipment-and-help

**Date:** 2027-09-17 (session 19 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Must say the walker (助行器) and raised toilet seat (马桶增高架) are not confirmed: on August 3 Su Hang said he would order them online 'this week', but no session says he did. Must not claim they were ordered or delivered. Must not count on his mother-in-law helping: she said no (September 6). Should point out the bathroom fixes still needed: a grab rail and a non-slip mat (the bathroom has no grab rail and slippery tiles). Should point out the gap in weekday help after his leave ends on Friday, October 8 and he is back at work on weekday day shifts, while his mother stays about six weeks. Must not mention the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it), said off the record on September 14; a bare reference to 'something you told me off the record' without its content is allowed.

**User:** 我妈出院后来我们家住，东西和人手都安排好了吗？还缺什么？

### A

还没完全齐，我按已知的帮你对一遍，先别慌。

**先说结论：人手还没定，东西有几样只能算「你没确认」，不能算「已安排」**。

**一、东西**
- 助行器、马桶增高架：你8月初说要订，但我这边没有你后来确认下单/到货的记录。还没买的话，这周内要定，最好术前让妈妈试好高度。
- 卫生间还差：马桶旁扶手（要打孔固定的U型，别用免打孔）、淋浴防滑垫、洗澡椅/凳。
- 次卧：床边最好有借力的扶手/护栏；通道要给助行器留出60–70cm。
- 全屋：门口地垫、电线、满满的玩具，床边到卫生间的动线先清一遍。

**二、人手——这是最大的缺口**
- 岳母已经明确说不行，所以帮手等于还没重新排。
- 你9/27–10/8请假，这段基本能自己盯；但出院预计在10月上旬，**10/8之后你恢复白班，工作日白天谁在就成问题了**。
- 所以要先定清楚：方晴工作日白天在不在家/能不能请假或调班？如果她也要上班，前两三周最好找亲戚或临时护工全天搭把手，不然妈妈一个人在家不安全，尤其头两周。
- 满满的接送也可能冲突，要一起排进去。

**三、还有一件容易漏的**
- 泉州医保在厦门门诊/康复要不要做异地就医备案，你落实过没？回厦门后如果要去社区或康复科，这个会卡报销。

你回我三件事，我帮你把剩下的补齐：
1. 助行器和马桶增高架到底买了没？到了没？
2. 卫生间扶手/防滑垫/洗澡椅装了没？
3. 方晴工作日白天能顾吗？还是得请人/找亲戚？

### B

按我这边记到的，帮你把"东西"和"人手"分开盘一下，顺便标清楚哪些是**确认办好的**、哪些是**还没落实的**。

## 已办妥 ✅
- **请假**：9/22（术前检查一天）、9/27–10/8 都批了，老陈那边没问题。
- **岳母那条线**：已经问过，明确说不行——所以这条不算缺口了，得另想办法（见下面人手）。

## 还没落实、需要你确认 ⚠️
**东西（助行器、马桶增高架等）——我这边没记录到已下单。**
- 助行器：之前计划"这周订"，但没有"已下单/已到货"的记录。
- 马桶增高架：同上。
- 之前建议过的几样，也没有买没买的记录，最好一并核对：
  - 卫生间：马桶旁扶手（U型/墙面）、淋浴凳、防滑垫、防滑拖鞋
  - 次卧：床边扶手、夜灯
  - 全屋：清走动线、常用物放到不用弯腰的高度

**人手——这是目前最大的缺口。**
- 岳母说不行后，我这边**没有记录到其他帮手**（比如方杰、其他亲戚、或约了护工/钟点工）。
- 妈妈术后出院头几周，起夜、上厕所、洗漱都需要人在旁边，方晴一个人又要顾满满，会很吃力。
- 建议尽快定一个：白班护工、上门康复师、或者家里亲戚轮换，具体怎么配等临近手术再盘也行，但**别拖到出院那天才想**。

## 一句话总结
请假 ✅、岳母 ❌（已排除）之外，**东西多半还没下单、人手还没定**，这两件是眼下要补的。

要不要我把"出院前要备齐的东西"整理成一张可勾选的清单（按卫生间/次卧/全屋分类，带数量）？你也可以直接告诉我哪些已经买了，我帮你更新进度。

### C

按咱们之前聊的，现在 **东西可能只落实了一半，人手是最大的缺口，得赶紧定**。我帮你理成一张清单，你照着对一下。

### 一、已经算安排好的

- 请假：9月22日、9月27日—10月8日  
- 住宿：7楼有电梯，次卧给你妈，你们仨睡主卧  
- 术前检查：已经改到9月22日周三，假也改好了  
- 手术：9月27日周一，黄主任主刀

这些没问题。

---

### 二、东西：还缺这几样，先确认

**1. 助行器、马桶增高架到货没有？**  
- 到了的话，拆开放次卧和卫生间试一下。  
- 马桶增高架最好**带扶手**。如果买的是不带扶手的，建议再加一个**落地式马桶扶手架**，不要用吸盘式的。

**2. 卫生间防滑还没做的话，现在补：**  
- 淋浴区放**防滑垫**  
- 马桶前、洗手台前如果常有水，铺**背面防滑的薄地垫**，不能翘边  
- 瓷砖地面尤其要防滑，不然术后很危险

**3. 洗澡相关：**  
- 洗澡椅/沐浴凳：一定要有，术后不能单腿站着洗  
- 如果有淋浴区，最好能坐着洗，水龙头最好能拿下来

**4. 卧室安全：**  
- 次卧床的高度：坐床边双脚能平放地面，不能太矮  
- 床旁边留出助行器空间  
- 夜间感应灯：次卧门口到卫生间装1—2个  
- 如果夜里去卫生间要经过拐角或距离远，加一个**床边坐便椅**，更保险

**5. 还没买的零碎：**  
- 防滑拖鞋  
- 宽松好穿的裤子/睡裤  
- 冰敷袋  
- 床边小桌或椅子，放水杯、手机

---

### 三、人手：现在这是最急的

岳母那边既然说不行，替代的人现在还没定下来，这是最大的缺口。尤其 **10月8日你上班之后**，白天8:00—17:30家里得有人。

**几个选项里至少落实一个：**

1. **社区护工或家政，白天来8个小时**  
   做饭、扶上厕所、防跌倒。厦门社区和家政公司都能找，先问社区有没有居家养老或长护险服务。

2. **方晴能不能请一周到两周假？**  
   覆盖你上班后的头两周，那时候最需要人。

3. **你公司还能不能再延几天假？**  
   哪怕延到10月12日或15日，也能缓一缓。

4. **其他亲戚能不能来帮一周？**  
   不一定非得岳母，你妈妈那边有没有姐妹、侄女，哪怕来5—7天也行。

**建议本周就打电话问家政/社区，价格和时间先摸清楚。别等到手术后再说。**

---

### 四、容易漏的两件事

**1. 出院怎么从泉州回厦门？**  
术后右膝关节不能长时间弯着，坐车要问医生能坐多久、怎么放腿。  
最好有后排能半躺、腿能伸开一点的空间，或者中途到服务区下来活动一下。

**2. 厦门这边的拆线/康复对接**  
- 联系家里附近的社区卫生服务中心，确认能不能换药、拆线、做康复。  
- 泉州医保在厦门看病，提前做异地就医备案。

---

### 本周末（9月18—19日）优先做这三件

1. **确认辅具到货并安装**：助行器、马桶增高架、防滑垫、洗澡椅。  
2. **落实人手**：社区护工/家政先问起来，最好面谈或电话确定一个能来的。  
3. **给黄主任/科室打电话**：问9月26日是否提前住院、出院后能坐多长车、拆线时间。

其他可以慢慢补，但**人手和卫生间安全**这两件不能再拖。你今晚先看看助行器到货没有，明天开放日回来就处理。



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
