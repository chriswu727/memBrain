## Ground truth

Ground truth for Scenario H (user: Kieran Walsh, who owns Walsh Cycles, a bike shop on MacCurtain Street, Cork, Ireland; wife Jule, German, from Freiburg; son Finn, ten, plays under-11 hurling; dad, a retired fisherman in Kinsale; sister Connie in Dublin). All dates are 2027.

1. Freiburg trip (s01, February 8): Jule's father Wolfgang turns 70 on Saturday, May 22. Flights for Kieran, Jule and Finn: Dublin to Basel Thursday, May 20; return originally Tuesday, May 25.
2. UPDATE, terse (s06, April 13): "the airline moved our flight home to Wednesday" -> return is now Wednesday, May 26.
3. UPDATE stated only in German (s07, April 22): the party is no longer Saturday evening, May 22, but Sunday, May 23 at 12:30, a lunch at Gasthaus Hirschen in Günterstal. Wolfgang (a retired forester who loves the Black Forest) asked Kieran to give a short speech in German, at most two minutes.
4. Plan CONFIRMED DONE (s01 -> s07, German only): Jule would find a guesthouse; on April 22 she had booked Pension Kastanienhof in Freiburg-Herdern, May 20-26.
5. Plan CANCELLED, terse (s01 -> s08): Kieran said he would book a rental car at Basel airport; on May 3: "cancelled it, Wolfgang's collecting us at the airport instead".
6. Plan NEVER CONFIRMED (s01): Kieran said he would email Finn's teacher, Ms. Hegarty, "this week" (week of February 8) about the missed school days. No later session says he did. On May 11 he asked whether he ever sorted it.
7. Ring of Kerry Charity Cycle (s01): Saturday, July 3, about 170 km. As of February 8 he hadn't ridden more than 80 km in one go in years. No later session reports his training.
8. Lease, UNCERTAIN (s02, February 23): landlord Gerry Twomey offered the unit next door; lease could start June 1 or July 1 depending on when the current tenant leaves; Gerry would confirm. Rent 1,450 euro a month. Never confirmed.
9. Accountant (s02): Trish Kane needs all 2026 receipts and the van mileage log by Friday, April 30. Kieran planned to ask for an extension to the end of May. UPDATE, terse (s05, March 18): "Trish said no" -> deadline stays April 30. No session says he sent them -> OVERDUE and open from May 1.
10. TEMPORARY EXCEPTION (s02): Con = Conor Healy, the mechanic, broke his wrist at five-a-side on Saturday, February 20; out until Monday, April 5. Until then: shop closed Mondays; repairs take about a week instead of two working days; no e-bike motor or electrical work (Con holds the Bosch certification). NORMAL RULES: open Monday to Saturday 9:00-18:00, closed Sundays; repairs in about two working days; e-bike motor and electrical work done in-house. Con was due back April 5; no later message mentions an extension or his return.
11. CONFIDENTIAL (s03, March 6, "keep this between us"): Connie is pregnant, about ten weeks on March 6, due around mid-September. She has not told Dad or anyone else; Kieran must not tell anyone, not even Jule. Never reported as shared later. Must not appear in messages to Dad, Con or anyone else, or in the story.
12. COMMITMENT (s03): Dad turns 72 on Saturday, April 17. Remind Kieran on Tuesday, April 13 to post Dad's card to Kinsale. Whether he posted it is never reported.
13. Names: Con / Conor Healy = the mechanic (male). Connie = Kieran's sister in Dublin. These must not be confused. Trish Kane = accountant. Gerry Twomey = landlord. "Dad" = Kieran's father in Kinsale (first name never given). Wolfgang = Jule's father. Ms. Hegarty = Finn's teacher.
14. FICTION ONLY (roleplay-s04, March 13; roleplay-s09, May 8): Silas Crane, retired bounty hunter running the livery stable in Redwater, Montana Territory, 1881; lungs wrecked by years in the silver mines, coughs in the cold, can't ride more than a few miles; owes the Redwater bank 400 dollars, banker Horace Pell, who later gave him until Sunday to pay; estranged sister Delia runs the Golden Spur saloon; Marshal Eli Booker; a stranger with an old wanted poster; buried bounty money at the old Bitterroot silver mine. None of this is true of Kieran (no lung problem, no debt mentioned, no mining past).
15. Customers: Aoife Lynch (s05, March 18) wanted to drop her e-bike in on Monday, March 22 (motor cutting out on hills) and have it back by Wednesday, March 24. Darragh Murphy (s06, April 13) asked to drop his e-bike in on Monday, April 19 (display error code, motor won't assist). Their replies are never recorded.
16. OFF THE RECORD (s08, May 3, first message): Kieran said "off the record, please don't remember any of this" and mentioned an offer from a regional chain, CycleWorks, to buy Walsh Cycles for 340,000 euro, which he hasn't told Jule about. This must NOT be remembered or surfaced in any later reply. Rule for the reviewer, applied to every case after this message whether or not its criteria repeat it: any later reply that mentions the CycleWorks offer or its content (a chain offering to buy the shop, selling the shop, 340,000 euro) fails. A reply that only says something like 'something you told me off the record' without any of its content is allowed.
17. Back on the record (s08, May 3, second message): Finn's under-11 hurling blitz in Mallow on "the 15th, Saturday" = Saturday, May 15, first match 10 am; the Basel rental car was cancelled (see 5).
18. s10 (May 11): Kieran can collect Dad in Kinsale at 8:30 on the blitz day. Dad's answer is never recorded.
19. s12 (June 1): they are back from Freiburg; the German speech went down well.
Incidental details replies may reasonably use: Jule was at her book club on March 13 and Finn at a sleepover; Dad is a retired fisherman who says he wants nothing for his birthday; Kieran is practising German for the trip.
Never stated anywhere: whether Ms. Hegarty was emailed; whether Trish received the receipts; whether Dad's card was posted or what present was bought; Gerry's confirmation of the lease date; how the blitz went or whether Dad came; Kieran's current fitness; Dad's first name; Connie's husband or any announcement of the pregnancy.
Note for the reviewer: Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## H08-OVERDUE-trish-receipts

**Date:** 2027-05-17 (session 28 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** A pre-trip to-do list. Must include as an open item the receipts and van mileage log for the accountant Trish Kane: the item must appear with its Friday, April 30 due date and be called overdue or outstanding, wherever it sits in the list (Kieran asked for an extension to the end of May, Trish said no on March 18, and no session says they were sent). A line such as 'no record it was sent; it was due April 30, so it's overdue unless you've sent it' meets this Must and is not a hedge. Must not say it is done. Must not list picking up or booking a rental car (cancelled May 3; Wolfgang is collecting them at Basel airport). Must not list booking accommodation (Pension Kastanienhof, May 20-26, booked by Jule, stated April 22 in German). Must not give Saturday evening for the party; any date given for the party must be Sunday, May 23 (a bare mention of 'the party' without a date is fine). Must not mention the CycleWorks offer or its content (a chain offering to buy the shop, selling the shop, 340,000 euro), said off the record on May 3; a bare reference to 'something you told me off the record' without its content is allowed. Should mention practising the short German speech, briefing Con on the shop, and the unconfirmed email to Ms. Hegarty.

**User:** Today is Monday, May 17. We fly on Thursday and the shop is mental. What do I still need to sort before we go?

### A

Here's what I've still got open for you, based on what we've discussed — quick checklist:

**1. The school email — still not confirmed sent.** You planned to email Ms. Hegarty about Finn missing 20–26 May (the return flight moved to Wednesday, so it's now through the 26th). As far as I know this hasn't been done yet. This is the most time-sensitive one — I'd send it today or tomorrow.

**2. Your German speech.** You agreed to give a short one (max 2 minutes) at Wolfgang's lunch on Sunday. Worth 20 minutes before Thursday to get the words comfortable.

**3. Trish / the accounts.** The 2026 receipts and van mileage log were due by 30 April — she said no to the end-of-May extension. That's already overdue, so worth wrapping up before you fly or at least letting her know where it stands.

**4. Quick double-checks for peace of mind:**
- Party is now **Sunday 23 May, 12:30, lunch at Gasthaus Hirschen in Günterstal** (not Saturday evening).
- Wolfgang is collecting you at Basel airport — rental car's cancelled.
- Finn's blitz was last Saturday, so that's behind you.

Want me to draft the email to Ms. Hegarty right now, and then help you tighten the speech? Those are the two I'd knock out first.

### B

Three days out — here’s what I still have as unresolved before Thursday:

- **School:** I have no record that you actually emailed Ms. Hegarty about Finn missing **20, 21, 24, 25 and 26 May**. Worth sorting before you fly — want me to draft it?
- **Shop cover:** Who’s running the place while you’re away? If Con is back and covering Thursday–Wednesday, grand; if not, you’ll need a plan/notice.
- **Travel bits:** Confirm passports, boarding passes and the guesthouse details are to hand. Reminder: the rental car is cancelled and **Wolfgang is collecting you at Basel airport**.
- **Wolfgang’s speech:** You’re due to give a short German speech — **two minutes max** — at his 70th lunch on **Sunday 23 May, 12:30, Gasthaus Hirschen**. Still showing as not done, so it’s worth writing and practising before you go.

Two loose ends I still have open from earlier:
- The birthday card to your dad in Kinsale — did it ever get posted?
- The text to Con checking how he was / whether the 5th still looked right — do you still need that done, or is Con back now?

### C

From everything we’ve talked about, here’s what I’d still check off before Thursday.

**Today / urgent**
1. **Ms. Hegarty** — confirm you actually sent the school email. If not, send it today. Finn is off **Thursday 20 to Wednesday 26 May**, back Thursday 27.
2. **Passports** — all three to hand and in date.
3. **Travel insurance / EHIC or GHIC cards** — check cover and pack the cards.
4. **Phone roaming** — Basel airport is in Switzerland; check your plan covers Swiss roaming or switch data off until Germany.
5. **Shop cover** — decide exactly who’s running things while you’re away. If Con’s back, brief him today on open jobs, customer promises, and anything urgent. If the shop is closing, sort a door sign, voicemail message, and social post.
6. **Wolfgang pickup** — send him your flight number, arrival time, and your phone number, so Basel collect is smooth.

**Tomorrow / Wednesday**
7. **Check in online** — as soon as it opens, usually 24 hours before.
8. **Confirm party details** — Sunday 23 May, 12:30, Gasthaus Hirschen, Günterstal. Maybe confirm with Jule if there’s a dress code or anything you’re supposed to bring.
9. **Practice your German speech** — even just reading it aloud a few times. It’s planned for the meal.
10. **Get some euros** — Germany is more cash-friendly than Ireland; have a little cash for small things.
11. **Tell the bank** — worth alerting your card provider you’ll be abroad, if they still like to know.

**Packing**
- Party outfit and shoes
- Layers / rain jacket — Freiburg in May can change fast
- Chargers and a power bank
- Finn’s school work or reading if Ms. Hegarty has given him anything
- Passport, insurance details, flight info

**Possible loose end**
- **Trish and the 2026 receipts/mileage** — that was due 30 April, and I don’t think we ever confirmed you got it in. If it’s overdue, maybe shoot her a quick text/call before you travel.

Do you want me to draft a short **shop closure / hours notice** for the door and voicemail, or a quick email to Ms. Hegarty if it turns out you haven’t sent it?



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
