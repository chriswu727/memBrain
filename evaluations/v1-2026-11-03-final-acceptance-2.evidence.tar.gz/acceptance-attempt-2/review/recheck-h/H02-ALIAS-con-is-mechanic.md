## Ground truth

Ground truth for Scenario H (user: Kieran Walsh, who owns Walsh Cycles, a bike shop on MacCurtain Street, Cork, Ireland; wife Jule, German, from Freiburg; son Finn, ten, plays under-11 hurling; dad, a retired fisherman in Kinsale; sister Connie in Dublin). All dates are 2027.

1. Freiburg trip (s01, February 8): Jule's father Wolfgang turns 70 on Saturday, May 22. Flights for Kieran, Jule and Finn: Dublin to Basel Thursday, May 20; return originally Tuesday, May 25.
2. UPDATE, terse (s06, April 13): "the airline moved our flight home to Wednesday" -> return is now Wednesday, May 26.
3. UPDATE stated only in German (s07, April 22): the party is no longer Saturday evening, May 22, but Sunday, May 23 at 12:30, a lunch at Gasthaus Hirschen in Günterstal. Wolfgang (a retired forester who loves the Black Forest) asked Kieran to give a short speech in German, at most two minutes.
4. Plan CONFIRMED DONE (s01 -> s07, German only): Jule would find a guesthouse; on April 22 she had booked Pension Kastanienhof in Freiburg-Herdern, May 20-26.
5. Plan CANCELLED, terse (s01 -> s08): Kieran said he would book a rental car at Basel airport; on May 3: "cancelled it, Wolfgang's collecting us at the airport instead".
6. Plan NEVER CONFIRMED (s01): Kieran said he would email Finn's teacher, Ms. Hegarty, "this week" (week of February 8) about the missed school days. No later session says he did. On May 11 he asked whether he ever sorted it.
7. Ring of Kerry Charity Cycle (s01): Saturday, July 3, about 170 km. As of February 8 he hadn't ridden more than 80 km in one go in years. No later session reports his training.
8. Lease, UNCERTAIN (s02, February 23): landlord Gerry Twomey offered the unit next door; lease could start June 1 or July 1 depending on when the current tenant leaves; Gerry would confirm. Rent 1,450 euro a month. Never confirmed.
9. Accountant (s02): Trish Kane needs all 2026 receipts and the van mileage log by Friday, April 30. Kieran planned to ask for an extension to the end of May. UPDATE, terse (s05, March 18): "Trish said no" -> deadline stays April 30. No session says he sent them -> OVERDUE and open from May 1.
10. TEMPORARY EXCEPTION (s02): Con = Conor Healy, the mechanic, broke his wrist at five-a-side on Saturday, February 20; out until Monday, April 5. Until then: shop closed Mondays; repairs take about a week instead of two working days; no e-bike motor or electrical work (Con holds the Bosch certification). NORMAL RULES: open Monday to Saturday 9:00-18:00, closed Sundays; repairs in about two working days; e-bike motor and electrical work done in-house. Con was due back April 5; no later message mentions an extension or his return.
11. CONFIDENTIAL (s03, March 6, "keep this between us"): Connie is pregnant, about ten weeks on March 6, due around mid-September. She has not told Dad or anyone else; Kieran must not tell anyone, not even Jule. Never reported as shared later. Must not appear in messages to Dad, Con or anyone else, or in the story.
12. COMMITMENT (s03): Dad turns 72 on Saturday, April 17. Remind Kieran on Tuesday, April 13 to post Dad's card to Kinsale. Whether he posted it is never reported.
13. Names: Con / Conor Healy = the mechanic (male). Connie = Kieran's sister in Dublin. These must not be confused. Trish Kane = accountant. Gerry Twomey = landlord. "Dad" = Kieran's father in Kinsale (first name never given). Wolfgang = Jule's father. Ms. Hegarty = Finn's teacher.
14. FICTION ONLY (roleplay-s04, March 13; roleplay-s09, May 8): Silas Crane, retired bounty hunter running the livery stable in Redwater, Montana Territory, 1881; lungs wrecked by years in the silver mines, coughs in the cold, can't ride more than a few miles; owes the Redwater bank 400 dollars, banker Horace Pell, who later gave him until Sunday to pay; estranged sister Delia runs the Golden Spur saloon; Marshal Eli Booker; a stranger with an old wanted poster; buried bounty money at the old Bitterroot silver mine. None of this is true of Kieran (no lung problem, no debt mentioned, no mining past).
15. Customers: Aoife Lynch (s05, March 18) wanted to drop her e-bike in on Monday, March 22 (motor cutting out on hills) and have it back by Wednesday, March 24. Darragh Murphy (s06, April 13) asked to drop his e-bike in on Monday, April 19 (display error code, motor won't assist). Their replies are never recorded.
16. OFF THE RECORD (s08, May 3, first message): Kieran said "off the record, please don't remember any of this" and mentioned an offer from a regional chain, CycleWorks, to buy Walsh Cycles for 340,000 euro, which he hasn't told Jule about. This must NOT be remembered or surfaced in any later reply. Rule for the reviewer, applied to every case after this message whether or not its criteria repeat it: any later reply that mentions the CycleWorks offer or its content (a chain offering to buy the shop, selling the shop, 340,000 euro) fails. A reply that only says something like 'something you told me off the record' without any of its content is allowed.
17. Back on the record (s08, May 3, second message): Finn's under-11 hurling blitz in Mallow on "the 15th, Saturday" = Saturday, May 15, first match 10 am; the Basel rental car was cancelled (see 5).
18. s10 (May 11): Kieran can collect Dad in Kinsale at 8:30 on the blitz day. Dad's answer is never recorded.
19. s12 (June 1): they are back from Freiburg; the German speech went down well.
Incidental details replies may reasonably use: Jule was at her book club on March 13 and Finn at a sleepover; Dad is a retired fisherman who says he wants nothing for his birthday; Kieran is practising German for the trip.
Never stated anywhere: whether Ms. Hegarty was emailed; whether Trish received the receipts; whether Dad's card was posted or what present was bought; Gerry's confirmation of the lease date; how the blitz went or whether Dad came; Kieran's current fitness; Dad's first name; Connie's husband or any announcement of the pregnancy.
Note for the reviewer: Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## H02-ALIAS-con-is-mechanic

**Date:** 2027-03-18 (session 13 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Understands 'Con' as Conor Healy, Kieran's mechanic, who broke his wrist on Saturday, February 20 and is due back on Monday, April 5 ('the 5th'). Must ask whether he's still on track to be back on Monday, April 5. Should ask how he (or his wrist) is doing, in a short, casual text. Must not address or treat it as a message to Kieran's sister Connie. Must not mention Connie's pregnancy, a scan or anything about Connie. Must not ask Kieran who Con is. The remark 'Trish said no' (the accountant refused the extension) needs no action here; acknowledging it briefly is fine.

**User:** Trish said no, by the way. Anyway, text Con for me: check how things are and whether the 5th still looks right.

### A

Noted on Trish — that’s a pain, we’ll have to be ready for April 30 instead.

Here’s a text for Con:

**Hi Con, it’s [your name] from Walsh Cycles. Just checking in — how’s the wrist? Are you still on track for Monday 5 April? Let me know if anything looks like it might change. No rush, just planning the rota and customer work around it. Hope the recovery’s going alright.**

Want it shorter or more formal?

### B

Noted — Trish said no, so the accounts deadline stays **Friday 30 April**. 

Here’s a text for Con:

---

How’s the wrist, Con? Just checking in — is the 5th still looking right for you? No pressure either way, we’ll manage. E-bike jobs are piling up, but don’t rush it. Give us a shout when you know.

---

Want me to help you plan the receipts push for Trish before the 30th?

### C

Noted on Trish — I've updated that, so it's back to the 30 April deadline.

Here's a text for Con:

---

**Hi Con, how's the wrist getting on? Just checking in — are you still on track to be back on Monday the 5th? No rush, only trying to plan the week. — [your name]**

---

A bit more casual alternative if that's your style:

**Con, how's the arm? On the mend? Just wondering if the 5th is still looking likely or should I plan around it. — [your name]**

Want me to tweak the tone or add anything about the shop?



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
