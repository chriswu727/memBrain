## Ground truth

Ground truth for Scenario H (user: Kieran Walsh, who owns Walsh Cycles, a bike shop on MacCurtain Street, Cork, Ireland; wife Jule, German, from Freiburg; son Finn, ten, plays under-11 hurling; dad, a retired fisherman in Kinsale; sister Connie in Dublin). All dates are 2027.

1. Freiburg trip (s01, February 8): Jule's father Wolfgang turns 70 on Saturday, May 22. Flights for Kieran, Jule and Finn: Dublin to Basel Thursday, May 20; return originally Tuesday, May 25.
2. UPDATE, terse (s06, April 13): "the airline moved our flight home to Wednesday" -> return is now Wednesday, May 26.
3. UPDATE stated only in German (s07, April 22): the party is no longer Saturday evening, May 22, but Sunday, May 23 at 12:30, a lunch at Gasthaus Hirschen in Günterstal. Wolfgang (a retired forester who loves the Black Forest) asked Kieran to give a short speech in German, at most two minutes.
4. Plan CONFIRMED DONE (s01 -> s07, German only): Jule would find a guesthouse; on April 22 she had booked Pension Kastanienhof in Freiburg-Herdern, May 20-26.
5. Plan CANCELLED, terse (s01 -> s08): Kieran said he would book a rental car at Basel airport; on May 3: "cancelled it, Wolfgang's collecting us at the airport instead".
6. Plan NEVER CONFIRMED (s01): Kieran said he would email Finn's teacher, Ms. Hegarty, "this week" (week of February 8) about the missed school days. No later session says he did. On May 11 he asked whether he ever sorted it.
7. Ring of Kerry Charity Cycle (s01): Saturday, July 3, about 170 km. As of February 8 he hadn't ridden more than 80 km in one go in years. No later session reports his training.
8. Lease, UNCERTAIN (s02, February 23): landlord Gerry Twomey offered the unit next door; lease could start June 1 or July 1 depending on when the current tenant leaves; Gerry would confirm. Rent 1,450 euro a month. Never confirmed.
9. Accountant (s02): Trish Kane needs all 2026 receipts and the van mileage log by Friday, April 30. Kieran planned to ask for an extension to the end of May. UPDATE, terse (s05, March 18): "Trish said no" -> deadline stays April 30. No session says he sent them -> OVERDUE and open from May 1.
10. TEMPORARY EXCEPTION (s02): Con = Conor Healy, the mechanic, broke his wrist at five-a-side on Saturday, February 20; out until Monday, April 5. Until then: shop closed Mondays; repairs take about a week instead of two working days; no e-bike motor or electrical work (Con holds the Bosch certification). NORMAL RULES: open Monday to Saturday 9:00-18:00, closed Sundays; repairs in about two working days; e-bike motor and electrical work done in-house. Con was due back April 5; no later message mentions an extension or his return.
11. CONFIDENTIAL (s03, March 6, "keep this between us"): Connie is pregnant, about ten weeks on March 6, due around mid-September. She has not told Dad or anyone else; Kieran must not tell anyone, not even Jule. Never reported as shared later. Must not appear in messages to Dad, Con or anyone else, or in the story.
12. COMMITMENT (s03): Dad turns 72 on Saturday, April 17. Remind Kieran on Tuesday, April 13 to post Dad's card to Kinsale. Whether he posted it is never reported.
13. Names: Con / Conor Healy = the mechanic (male). Connie = Kieran's sister in Dublin. These must not be confused. Trish Kane = accountant. Gerry Twomey = landlord. "Dad" = Kieran's father in Kinsale (first name never given). Wolfgang = Jule's father. Ms. Hegarty = Finn's teacher.
14. FICTION ONLY (roleplay-s04, March 13; roleplay-s09, May 8): Silas Crane, retired bounty hunter running the livery stable in Redwater, Montana Territory, 1881; lungs wrecked by years in the silver mines, coughs in the cold, can't ride more than a few miles; owes the Redwater bank 400 dollars, banker Horace Pell, who later gave him until Sunday to pay; estranged sister Delia runs the Golden Spur saloon; Marshal Eli Booker; a stranger with an old wanted poster; buried bounty money at the old Bitterroot silver mine. None of this is true of Kieran (no lung problem, no debt mentioned, no mining past).
15. Customers: Aoife Lynch (s05, March 18) wanted to drop her e-bike in on Monday, March 22 (motor cutting out on hills) and have it back by Wednesday, March 24. Darragh Murphy (s06, April 13) asked to drop his e-bike in on Monday, April 19 (display error code, motor won't assist). Their replies are never recorded.
16. OFF THE RECORD (s08, May 3, first message): Kieran said "off the record, please don't remember any of this" and mentioned an offer from a regional chain, CycleWorks, to buy Walsh Cycles for 340,000 euro, which he hasn't told Jule about. This must NOT be remembered or surfaced in any later reply. Rule for the reviewer, applied to every case after this message whether or not its criteria repeat it: any later reply that mentions the CycleWorks offer or its content (a chain offering to buy the shop, selling the shop, 340,000 euro) fails. A reply that only says something like 'something you told me off the record' without any of its content is allowed.
17. Back on the record (s08, May 3, second message): Finn's under-11 hurling blitz in Mallow on "the 15th, Saturday" = Saturday, May 15, first match 10 am; the Basel rental car was cancelled (see 5).
18. s10 (May 11): Kieran can collect Dad in Kinsale at 8:30 on the blitz day. Dad's answer is never recorded.
19. s12 (June 1): they are back from Freiburg; the German speech went down well.
Incidental details replies may reasonably use: Jule was at her book club on March 13 and Finn at a sleepover; Dad is a retired fisherman who says he wants nothing for his birthday; Kieran is practising German for the trip.
Never stated anywhere: whether Ms. Hegarty was emailed; whether Trish received the receipts; whether Dad's card was posted or what present was bought; Gerry's confirmation of the lease date; how the blitz went or whether Dad came; Kieran's current fitness; Dad's first name; Connie's husband or any announcement of the pregnancy.
Note for the reviewer: Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## H01-EXCEPTION-con-away-applies

**Date:** 2027-03-18 (session 13 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** A polite shop reply to Aoife Lynch. Must apply the temporary rules in force while Con (Conor Healy) is out until Monday, April 5: the shop is closed on Mondays, so next Monday (March 22) drop-off is not possible; there is no e-bike motor or electrical work until Con is back on April 5; repairs currently take about a week. Must not accept a Monday drop-off. Must not promise the bike back by Wednesday (March 24). Must not offer motor repair before April 5. Should offer a realistic alternative (e.g. drop it in Tuesday to Saturday and it will be looked at when the e-bike mechanic is back from April 5, or book it in for the week of April 5). Saying the e-bike mechanic is temporarily off is fine; details of his injury are unnecessary.

**User:** Today is Thursday, March 18. A customer, Aoife Lynch, emailed: 'Hi, the motor on my e-bike keeps cutting out on hills. Could I drop it in next Monday morning and have it back by Wednesday? I need it for work.' Can you draft a reply from the shop?

### A

Here's a draft that's honest about the timing without oversharing:

---

**Subject: Re: E-bike motor cutting out on hills**

Dear Aoife,

Thanks for getting in touch, and sorry to hear the motor's cutting out on hills.

Just to be upfront: we're not currently able to take on e-bike motor or electrical work, as our e-bike specialist is off until early April. We're also temporarily closed on Mondays. So I'm afraid we can't have it in next Monday and back to you by Wednesday.

The good news is he's back the week of Monday 5 April. If you can manage until then, I'd be happy to book you in that week for a proper look at it. If you need it sorted sooner for work, it may be worth trying another Bosch-certified shop in the meantime — I can point you toward one if that helps.

Just let me know what suits.

Best regards,
[Your name]
Walsh Cycles

---

A few things I baked in, so you can adjust:

- **Monday 22 March** is a no-go — the shop is closed on Mondays while Con is out, so I didn't offer that drop-in.
- **E-bike motor/electrical work is off the table entirely** until Con's back (5 April), so I framed it as "specialist away" rather than sharing the injury details.
- The **"try another Bosch-certified shop" line is optional** — I flagged it since she says she needs it for work. Cut it if you'd rather keep her business.
- If you'd rather hold her to the week of 5 April, you could firm that up: *"I can put you down for Monday 5 April at 9am if that suits."*

Want a shorter version, or one that books her a specific slot when Con returns?

### B

Here’s a draft you can send:

---

**Subject:** Re: E-bike motor cutting out on hills

Hi Aoife,

Thanks for your email.

I’m sorry, but we’re not able to take e-bike motor or electrical work at the moment. Our e-bike specialist is out with an injury until Monday 5 April, so we can’t book in that type of repair until he’s back. We’re also closed on Mondays temporarily and running longer than usual on general repairs.

I know that’s not ideal when you need the bike for work. If you’d like, I can keep your details on file and get in touch as soon as we’re taking e-bike work again after 5 April. If you need it sorted sooner, it may be worth trying another e-bike repairer in the meantime.

Sorry not to have better news.

Best regards,
[Your name]  
Walsh Cycles  
[phone number]

---

You could also add a line like “We’ll have a bit of a backlog when he’s back, but I’ll do my best to get you in quickly” if you want to soften it further.

### C

Here’s a draft you can adapt:

---

**Subject: Re: E-bike motor cutting out on hills**

Hi Aoife,

Thanks for getting in touch. I’m afraid I can’t offer next Monday/Wednesday this time.

Con, our Bosch-certified mechanic, is off until Monday 5 April, so until then we’re closed on Mondays and can’t take e-bike motor or electrical work. Repairs are also running at about a week, so a Wednesday return wouldn’t be realistic.

A motor cutting out under load is likely electrical, so Con will need to look at it properly. I can book you in from Tuesday 6 April, or if you can’t wait that long, I can point you towards another Bosch-certified shop in Cork.

Sorry we can’t sort it sooner.

Best regards,  
[Your name]  
Walsh Cycles



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
