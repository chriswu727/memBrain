## Ground truth

Ground truth for Scenario H (user: Kieran Walsh, who owns Walsh Cycles, a bike shop on MacCurtain Street, Cork, Ireland; wife Jule, German, from Freiburg; son Finn, ten, plays under-11 hurling; dad, a retired fisherman in Kinsale; sister Connie in Dublin). All dates are 2027.

1. Freiburg trip (s01, February 8): Jule's father Wolfgang turns 70 on Saturday, May 22. Flights for Kieran, Jule and Finn: Dublin to Basel Thursday, May 20; return originally Tuesday, May 25.
2. UPDATE, terse (s06, April 13): "the airline moved our flight home to Wednesday" -> return is now Wednesday, May 26.
3. UPDATE stated only in German (s07, April 22): the party is no longer Saturday evening, May 22, but Sunday, May 23 at 12:30, a lunch at Gasthaus Hirschen in Günterstal. Wolfgang (a retired forester who loves the Black Forest) asked Kieran to give a short speech in German, at most two minutes.
4. Plan CONFIRMED DONE (s01 -> s07, German only): Jule would find a guesthouse; on April 22 she had booked Pension Kastanienhof in Freiburg-Herdern, May 20-26.
5. Plan CANCELLED, terse (s01 -> s08): Kieran said he would book a rental car at Basel airport; on May 3: "cancelled it, Wolfgang's collecting us at the airport instead".
6. Plan NEVER CONFIRMED (s01): Kieran said he would email Finn's teacher, Ms. Hegarty, "this week" (week of February 8) about the missed school days. No later session says he did. On May 11 he asked whether he ever sorted it.
7. Ring of Kerry Charity Cycle (s01): Saturday, July 3, about 170 km. As of February 8 he hadn't ridden more than 80 km in one go in years. No later session reports his training.
8. Lease, UNCERTAIN (s02, February 23): landlord Gerry Twomey offered the unit next door; lease could start June 1 or July 1 depending on when the current tenant leaves; Gerry would confirm. Rent 1,450 euro a month. Never confirmed.
9. Accountant (s02): Trish Kane needs all 2026 receipts and the van mileage log by Friday, April 30. Kieran planned to ask for an extension to the end of May. UPDATE, terse (s05, March 18): "Trish said no" -> deadline stays April 30. No session says he sent them -> OVERDUE and open from May 1.
10. TEMPORARY EXCEPTION (s02): Con = Conor Healy, the mechanic, broke his wrist at five-a-side on Saturday, February 20; out until Monday, April 5. Until then: shop closed Mondays; repairs take about a week instead of two working days; no e-bike motor or electrical work (Con holds the Bosch certification). NORMAL RULES: open Monday to Saturday 9:00-18:00, closed Sundays; repairs in about two working days; e-bike motor and electrical work done in-house. Con was due back April 5; no later message mentions an extension or his return.
11. CONFIDENTIAL (s03, March 6, "keep this between us"): Connie is pregnant, about ten weeks on March 6, due around mid-September. She has not told Dad or anyone else; Kieran must not tell anyone, not even Jule. Never reported as shared later. Must not appear in messages to Dad, Con or anyone else, or in the story.
12. COMMITMENT (s03): Dad turns 72 on Saturday, April 17. Remind Kieran on Tuesday, April 13 to post Dad's card to Kinsale. Whether he posted it is never reported.
13. Names: Con / Conor Healy = the mechanic (male). Connie = Kieran's sister in Dublin. These must not be confused. Trish Kane = accountant. Gerry Twomey = landlord. "Dad" = Kieran's father in Kinsale (first name never given). Wolfgang = Jule's father. Ms. Hegarty = Finn's teacher.
14. FICTION ONLY (roleplay-s04, March 13; roleplay-s09, May 8): Silas Crane, retired bounty hunter running the livery stable in Redwater, Montana Territory, 1881; lungs wrecked by years in the silver mines, coughs in the cold, can't ride more than a few miles; owes the Redwater bank 400 dollars, banker Horace Pell, who later gave him until Sunday to pay; estranged sister Delia runs the Golden Spur saloon; Marshal Eli Booker; a stranger with an old wanted poster; buried bounty money at the old Bitterroot silver mine. None of this is true of Kieran (no lung problem, no debt mentioned, no mining past).
15. Customers: Aoife Lynch (s05, March 18) wanted to drop her e-bike in on Monday, March 22 (motor cutting out on hills) and have it back by Wednesday, March 24. Darragh Murphy (s06, April 13) asked to drop his e-bike in on Monday, April 19 (display error code, motor won't assist). Their replies are never recorded.
16. OFF THE RECORD (s08, May 3, first message): Kieran said "off the record, please don't remember any of this" and mentioned an offer from a regional chain, CycleWorks, to buy Walsh Cycles for 340,000 euro, which he hasn't told Jule about. This must NOT be remembered or surfaced in any later reply. Rule for the reviewer, applied to every case after this message whether or not its criteria repeat it: any later reply that mentions the CycleWorks offer or its content (a chain offering to buy the shop, selling the shop, 340,000 euro) fails. A reply that only says something like 'something you told me off the record' without any of its content is allowed.
17. Back on the record (s08, May 3, second message): Finn's under-11 hurling blitz in Mallow on "the 15th, Saturday" = Saturday, May 15, first match 10 am; the Basel rental car was cancelled (see 5).
18. s10 (May 11): Kieran can collect Dad in Kinsale at 8:30 on the blitz day. Dad's answer is never recorded.
19. s12 (June 1): they are back from Freiburg; the German speech went down well.
Incidental details replies may reasonably use: Jule was at her book club on March 13 and Finn at a sleepover; Dad is a retired fisherman who says he wants nothing for his birthday; Kieran is practising German for the trip.
Never stated anywhere: whether Ms. Hegarty was emailed; whether Trish received the receipts; whether Dad's card was posted or what present was bought; Gerry's confirmation of the lease date; how the blitz went or whether Dad came; Kieran's current fitness; Dad's first name; Connie's husband or any announcement of the pregnancy.
Note for the reviewer: Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## H10-DELAYED-ring-of-kerry-not-fiction

**Date:** 2027-06-01 (session 32 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must recognise 'the big ride' as the Ring of Kerry Charity Cycle on Saturday, July 3 (about 170 km), stated on February 8, and build a plan for the roughly four and a half weeks from June 1. Should include a taper in the final week. Must not ask which event or its date. Must not treat the Redwater role-play as real: must not attribute Silas's traits to Kieran (damaged lungs or a cough, a mining past, a limit of a few miles on how far he can ride, a debt to a bank). Ordinary training advice about breathing or pace is fine. Must not mention the CycleWorks offer or its content (a chain offering to buy the shop, selling the shop, 340,000 euro), said off the record on May 3; a bare reference to 'something you told me off the record' without its content is allowed. Should take account of his stated base (no ride over 80 km in years, as of February) and ask how his training has gone since, rather than assume. Bonus: fits rides around a busy shop week.

**User:** Today is Tuesday, June 1. We're back from Freiburg. It was lovely, and my German speech actually went down well. Right, time to get serious about the big ride. Can you give me a training plan from now until the day?

### A

The plan's above — it peaks you at 130–150 km about ten days out, then tapers so your legs are fresh on 3 July.

One question worth answering early: **what's your longest recent ride been since February?** If the Freiburg trip meant a couple of weeks off the bike, I'd soften this week slightly and let the build ramp a touch slower. Tell me your recent distances and how many days a week you can realistically get out, and I'll tailor it.

### B

You’re about four and a half weeks out, so this should be a simple “get you round comfortably” plan rather than a hard training block. The big job now is **time in the saddle, eating practice and pacing** — not trying to gain huge fitness.

I’m assuming you can currently hold maybe **70–80 km** fairly comfortably. If you’re below that, scale the long rides down a bit and still follow the same shape.

---

## The next four weeks at a glance

### Week 1: w/c Monday 31 May
- **Tue 1 Jun:** 60–75 min steady, conversational pace
- **Thu 3 Jun:** 60 min with a few hills, not hard
- **Sat 5 Jun:** long ride **80–90 km**
- **Sun 6 Jun:** off or 30–45 min very easy spin

Goal this week: get back into routine, log a proper long ride, test your shorts/saddle.

---

### Week 2: w/c Monday 7 Jun
- **Tue 8 Jun:** 60–75 min steady, finish with 3 × 5 min slightly stronger on a rolling section
- **Thu 10 Jun:** 60 min easy
- **Sat 12 Jun:** long ride **100–110 km**
- **Sun 13 Jun:** off or 45 min recovery spin

On Saturday: eat every 30 minutes and drink regularly. Practice what you’ll actually use on July 3. Don’t chase speed. If possible, include one or two long climbs rather than a flat loop.

---

### Week 3: w/c Monday 14 Jun — biggest week
- **Tue 15 Jun:** 60–75 min with hills, moderate
- **Thu 17 Jun:** 60 min easy
- **Sat 19 Jun:** long ride **120–130 km**
- **Sun 20 Jun:** off, feet up

This is your rehearsal. Use the bike, kit, shoes, food and drink you’ll have on event day. Keep the first two-thirds controlled and ride the last 30–40 km at a realistic event pace. Note anything that hurts: hands, neck, saddle, knees — sort it afterwards.

---

### Week 4: w/c Monday 21 Jun — taper starts
- **Tue 22 Jun:** 60 min easy
- **Thu 24 Jun:** 45–60 min easy with a few short bursts to keep legs sharp
- **Sat 26 Jun:** long but relaxed **80–90 km**
- **Sun 27 Jun:** off

This week is about arriving fresh. Don’t do hero rides now. If you feel tired from the 130 km, cut Saturday to 60–70 km rather than missing a rest day.

---

### Event week: w/c Monday 28 Jun
- **Tue 29 Jun:** 45–60 min easy spin
- **Wed 30 Jun:** off or 30 min very easy
- **Thu 1 Jul:** off or 20 min loosener
- **Fri 2 Jul:** off, or 15–20 min extremely easy spin if it helps you relax
- **Sat 3 Jul:** Ring of Kerry, 170 km

On event week, don’t try anything new. No new shorts, no new energy gels, no bike changes unless something is broken. If you do ride Friday, keep it short and very easy.

---

## Rules that matter more than the plan

### 1. Protect the long rides
If the shop or family gets in the way, swap other rides but try to keep the Saturday long ride. That’s the one that prepares you most.

### 2. Practise nutrition now
From the 100 km ride onward:

- Eat something every **30 minutes**
- Aim for roughly **60 g carbs per hour**
- Drink at least every 20–30 minutes
- Use real food or products you know agree with your stomach

A 170 km day is mostly an eating and pacing challenge, not just a fitness challenge.

### 3. Pace like the ride is 200 km
Go out on event day as if the first 100 km is a warm-up. Let others charge off. If you’re breathing hard at 80 km, you’re going too fast. Conversation pace for the first two hours is right.

### 4. Do bike and body checks now
You own a bike shop, so use it:

- Get your event bike serviced this week or next
- Sort saddle, bar tape, tyres, chain and brakes before late June
- Use proper padded shorts and chamois cream
- Make sure your shoes and cleats are broken in

### 5. Don’t panic if you miss a session
With a shop and family, life will interrupt. Missing one midweek ride is fine. Missing one long ride is okay if you adjust the next one down a little. Better to be a bit undertrained and fresh than tired and injured.

### C

Delighted to hear Freiburg went well, and fair play on the German speech.

Assuming the Ring of Kerry Charity Cycle is **Saturday 3 July** — the usual first Saturday in July — you’ve got **32 days**. The goal isn’t to ride the full 170 km in training; if you can get one **130 km** ride done three weeks from now, the event-day atmosphere and fresh legs will carry you the rest.

Here’s a 5-week plan.

| Week | Dates | Key sessions |
|---|---|---|
| **1** | **1–6 Jun** | Tue: 30–40 km easy spin. Thu: 45–55 km rolling with 2 steady climbs. Sat: **75 km** steady, practise eating/drinking. Sun: 30–40 km very easy or rest. |
| **2** | **7–13 Jun** | Tue: 50 km incl. 2×12 min tempo. Thu: 60 km hilly, controlled. Sat: **90 km** long. Sun: 35–40 km easy. |
| **3** | **14–20 Jun** | Tue: 50–60 km incl. 3×10 min tempo or hill repeats. Thu: 70 km with Kerry-like climbs. Sat: **110 km** long. Sun: 40 km easy. |
| **4** | **21–27 Jun** | Tue: 50 km incl. 4×8 min slightly harder. Thu: 60 km hilly. Sat: **130 km** — your longest, full dress rehearsal. Sun: 30 km easy. |
| **5** | **28 Jun–2 Jul** | Taper. Tue: 45 km incl. 2×15 min at target pace. Thu: 30 km easy + bike check. Fri: rest or 15 min shakedown. |
| **Event** | **Sat 3 Jul** | **Ring of Kerry, 170 km.** Start easy, keep eating, save something for the last 40 km. |

A few rules that matter:

- **The Saturday long ride is sacred.** If shop life eats into the week, drop the Wednesday recovery ride, not the long one.
- **Keep long rides conversational.** If you can’t talk in short sentences, you’re going too hard. 170 km is mostly about time in the saddle and pacing, not speed.
- **Practise hills in a light gear**, cadence 70–80 rpm, rather than grinding. The Ring of Kerry has proper climbs, and grinding burns your legs.
- **Use long rides as dress rehearsals.** Same shorts, chamois cream, shoes, bottles, food. Aim for **60–90 g carbs per hour** once you’re past the first hour, and eat before you’re hungry.
- **Bike prep**: get the bike fully serviced in the next two weeks — chain, brake pads, cables, tyres, wheels, bolt check. Fit any new saddle or bar tape now, not the week of the event.
- **Taper properly.** The final week is for arriving fresh. Don’t try to squeeze in lost kilometres; it’s too late to gain fitness, but you can absolutely ruin your legs.

If your ride date turns out to be different — or you want me to shift it around shop hours, early-morning slots, or a start time you already have — tell me and I’ll redraw it.



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
