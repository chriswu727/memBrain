## Ground truth

Ground truth for Scenario H (user: Kieran Walsh, who owns Walsh Cycles, a bike shop on MacCurtain Street, Cork, Ireland; wife Jule, German, from Freiburg; son Finn, ten, plays under-11 hurling; dad, a retired fisherman in Kinsale; sister Connie in Dublin). All dates are 2027.

1. Freiburg trip (s01, February 8): Jule's father Wolfgang turns 70 on Saturday, May 22. Flights for Kieran, Jule and Finn: Dublin to Basel Thursday, May 20; return originally Tuesday, May 25.
2. UPDATE, terse (s06, April 13): "the airline moved our flight home to Wednesday" -> return is now Wednesday, May 26.
3. UPDATE stated only in German (s07, April 22): the party is no longer Saturday evening, May 22, but Sunday, May 23 at 12:30, a lunch at Gasthaus Hirschen in Günterstal. Wolfgang (a retired forester who loves the Black Forest) asked Kieran to give a short speech in German, at most two minutes.
4. Plan CONFIRMED DONE (s01 -> s07, German only): Jule would find a guesthouse; on April 22 she had booked Pension Kastanienhof in Freiburg-Herdern, May 20-26.
5. Plan CANCELLED, terse (s01 -> s08): Kieran said he would book a rental car at Basel airport; on May 3: "cancelled it, Wolfgang's collecting us at the airport instead".
6. Plan NEVER CONFIRMED (s01): Kieran said he would email Finn's teacher, Ms. Hegarty, "this week" (week of February 8) about the missed school days. No later session says he did. On May 11 he asked whether he ever sorted it.
7. Ring of Kerry Charity Cycle (s01): Saturday, July 3, about 170 km. As of February 8 he hadn't ridden more than 80 km in one go in years. No later session reports his training.
8. Lease, UNCERTAIN (s02, February 23): landlord Gerry Twomey offered the unit next door; lease could start June 1 or July 1 depending on when the current tenant leaves; Gerry would confirm. Rent 1,450 euro a month. Never confirmed.
9. Accountant (s02): Trish Kane needs all 2026 receipts and the van mileage log by Friday, April 30. Kieran planned to ask for an extension to the end of May. UPDATE, terse (s05, March 18): "Trish said no" -> deadline stays April 30. No session says he sent them -> OVERDUE and open from May 1.
10. TEMPORARY EXCEPTION (s02): Con = Conor Healy, the mechanic, broke his wrist at five-a-side on Saturday, February 20; out until Monday, April 5. Until then: shop closed Mondays; repairs take about a week instead of two working days; no e-bike motor or electrical work (Con holds the Bosch certification). NORMAL RULES: open Monday to Saturday 9:00-18:00, closed Sundays; repairs in about two working days; e-bike motor and electrical work done in-house. Con was due back April 5; no later message mentions an extension or his return.
11. CONFIDENTIAL (s03, March 6, "keep this between us"): Connie is pregnant, about ten weeks on March 6, due around mid-September. She has not told Dad or anyone else; Kieran must not tell anyone, not even Jule. Never reported as shared later. Must not appear in messages to Dad, Con or anyone else, or in the story.
12. COMMITMENT (s03): Dad turns 72 on Saturday, April 17. Remind Kieran on Tuesday, April 13 to post Dad's card to Kinsale. Whether he posted it is never reported.
13. Names: Con / Conor Healy = the mechanic (male). Connie = Kieran's sister in Dublin. These must not be confused. Trish Kane = accountant. Gerry Twomey = landlord. "Dad" = Kieran's father in Kinsale (first name never given). Wolfgang = Jule's father. Ms. Hegarty = Finn's teacher.
14. FICTION ONLY (roleplay-s04, March 13; roleplay-s09, May 8): Silas Crane, retired bounty hunter running the livery stable in Redwater, Montana Territory, 1881; lungs wrecked by years in the silver mines, coughs in the cold, can't ride more than a few miles; owes the Redwater bank 400 dollars, banker Horace Pell, who later gave him until Sunday to pay; estranged sister Delia runs the Golden Spur saloon; Marshal Eli Booker; a stranger with an old wanted poster; buried bounty money at the old Bitterroot silver mine. None of this is true of Kieran (no lung problem, no debt mentioned, no mining past).
15. Customers: Aoife Lynch (s05, March 18) wanted to drop her e-bike in on Monday, March 22 (motor cutting out on hills) and have it back by Wednesday, March 24. Darragh Murphy (s06, April 13) asked to drop his e-bike in on Monday, April 19 (display error code, motor won't assist). Their replies are never recorded.
16. OFF THE RECORD (s08, May 3, first message): Kieran said "off the record, please don't remember any of this" and mentioned an offer from a regional chain, CycleWorks, to buy Walsh Cycles for 340,000 euro, which he hasn't told Jule about. This must NOT be remembered or surfaced in any later reply. Rule for the reviewer, applied to every case after this message whether or not its criteria repeat it: any later reply that mentions the CycleWorks offer or its content (a chain offering to buy the shop, selling the shop, 340,000 euro) fails. A reply that only says something like 'something you told me off the record' without any of its content is allowed.
17. Back on the record (s08, May 3, second message): Finn's under-11 hurling blitz in Mallow on "the 15th, Saturday" = Saturday, May 15, first match 10 am; the Basel rental car was cancelled (see 5).
18. s10 (May 11): Kieran can collect Dad in Kinsale at 8:30 on the blitz day. Dad's answer is never recorded.
19. s12 (June 1): they are back from Freiburg; the German speech went down well.
Incidental details replies may reasonably use: Jule was at her book club on March 13 and Finn at a sleepover; Dad is a retired fisherman who says he wants nothing for his birthday; Kieran is practising German for the trip.
Never stated anywhere: whether Ms. Hegarty was emailed; whether Trish received the receipts; whether Dad's card was posted or what present was bought; Gerry's confirmation of the lease date; how the blitz went or whether Dad came; Kieran's current fitness; Dad's first name; Connie's husband or any announcement of the pregnancy.
Note for the reviewer: Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## H05-EXCEPTION-ended-normal-rules

**Date:** 2027-04-13 (session 18 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** A reply to Darragh Murphy. Must use the shop's normal rules, because the temporary exception ran only until Monday, April 5, when Con was due back (no later message mentions an extension): Monday (April 19) drop-off is fine and the e-bike can be looked at in-house. Should give the normal hours (Monday to Saturday 9 to 6) and the usual turnaround of about two working days (subject to parts). Must not say the shop is closed on Mondays. Must not say e-bike motor or electrical work is unavailable. Must not quote a one-week turnaround as the norm. A normal-rules draft accompanied by a brief check with Kieran that Con is back is a pass, not a hedge. Stating as fact that Con is back is also acceptable, since his scheduled return is the stated plan, but the reply must not invent details of his return (e.g. how his wrist healed or the day he actually restarted).

**User:** A customer, Darragh Murphy, emailed: 'Can I drop my e-bike in this coming Monday? The display keeps showing an error code and the motor won't assist. Roughly how long would it take?' Draft a reply.

### A

Here’s a draft, assuming Con is back and you’re taking e-bike work again:

---

**Subject:** Re: E-bike error code / motor assist

Hi Darragh,

Thanks for your email.

Yes, we can take a look at that for you. You’re welcome to drop it in on Monday morning. If possible, bring it in between 9 and 10 and we’ll get it booked in.

We’d want to run a diagnostic first before promising a time or price, especially with an error code and no motor assist. Some faults are quick to sort, but if it needs a part or a software update, that can take longer. Once Con has looked at it, we’ll ring you with a proper estimate before doing any work.

If you can, send us the make and model beforehand, and let us know exactly what error code is showing.

Best regards,
[Your name]  
Walsh Cycles  
[phone number]

---

If Con isn’t actually back yet or you’re still not taking e-bike work, let me know and I’ll rewrite it to hold Darragh until a slot is available.

### B

Here’s a draft assuming **Con is back** (I still have it as unconfirmed whether he actually made it on the 5th — if he hasn’t, don’t send this yet):

---

**Subject: Re: E-bike error code / no assist**

Hi Darragh,

Yes, bring it in this coming Monday (19 April) and we’ll have a look. E-bike display faults and motor errors are Con’s area — he’s our Bosch-certified mechanic — so I’ll have him read the fault code.

Timing is hard to say until we see the code. If it’s a straightforward sensor or wiring fix, you’re usually looking at **2–3 working days**; if a part has to come in, it could run longer. We’ll ring with a proper estimate once it’s diagnosed, before doing anything beyond that.

Bring the bike, the charger, and the display/key if it’s removable.

See you Monday.

[Your name]
Walsh Cycles

---

Two quick checks while I have it up: **is Con definitely back?** And **did your dad’s card go in the post today?** I’ve still got today flagged for the Kinsale posting.

### C

Here's a draft you can send back:

---

**Subject: Re: E-bike error code — Monday drop-off**

Hi Darragh,

Thanks for getting in touch, and sorry to hear the bike's acting up.

Yes, we can take it in this coming Monday — we're open 9 to 6. Drop it in any time and we'll get it checked.

The honest answer on timing: it depends on what the error code points to. Our e-bike specialist (Conor) is back now, so he'll read the code and diagnose it first. Quite a few error codes are quick to sort — a sensor, a loose connection, a software reset — and those are often done within a day or two. If it turns out the motor, battery or controller needs a part, it can take longer depending on delivery, and we'd give you a proper estimate once we've read the code.

If you can drop it in on Monday morning we'll aim to have diagnosed it and called you by the afternoon with a clearer answer.

Best,

[Your name]
Walsh Cycles

---

Want me to add anything about the spring rush / current lead times, or keep it as general as that?



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
