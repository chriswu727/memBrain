# v1-2026-11-03-acceptance-scenario-i

## Ground truth

Ground truth for Scenario I (user: Su Hang, a licensed aircraft-maintenance engineer at Xiamen airport; wife Fang Qing (方晴); son Manman (满满), three, started kindergarten on September 1; mother Wang Xiuying (王秀英), 69, lives in Quanzhou; parents-in-law Fang Jianguo (方建国) and Li Meihua (李美华) in Zhangzhou). All dates are 2027. The user writes in Chinese.

1. Mother's surgery (s01, August 3): right knee replacement at Quanzhou First Hospital (泉州市第一医院), orthopaedics, surgeon Director Huang (黄主任). Surgery Monday, September 27. Pre-op check originally Monday, September 20.
2. UNCERTAIN (s01): Director Huang said patients usually stay in hospital one week to ten days after surgery, depending on recovery. No discharge date was set before September 30. (Later, s11 on October 26: she was discharged on October 5.)
3. After discharge (s01): she will stay at Su Hang's flat in Xiamen for about six weeks of rehab. Household arrangement: 7th floor with a lift; Manman sleeps in the master bedroom with Su Hang and Fang Qing; his mother takes the second bedroom; the bathroom has a sit-down toilet without grab rails and slippery tiles.
4. Leave: Plan (s01) to ask team leader Lao Chen (陈国栋) for leave on September 20 and September 27 - October 8. CONFIRMED DONE (s03, August 21): approved. UPDATE, terse (s06, September 14): the pre-op check "改到周三了，22号" -> Wednesday, September 22, and the leave was changed accordingly. Current leave: Wednesday, September 22 and Monday, September 27 - Friday, October 8.
5. Plan NEVER CONFIRMED (s01): order a walker (助行器) and a raised toilet seat (马桶增高架) online "this week". No later session says they were ordered.
6. Plan -> REFUSED, terse (s01 -> s05): Su Hang planned to ask his mother-in-law to come to Xiamen for two weeks after the surgery; on September 6: "岳母那边，她说不行" (she said no). No other helper is ever named.
7. TEMPORARY EXCEPTION (s02, August 11): covering colleague Lin Jie's night shifts while Lin Jie is on paternity plus annual leave (four weeks; his wife just had a baby). Nights from Sunday, August 15 to the last night shift on Thursday, September 9: Sunday to Thursday nights 20:00-08:00. During those weeks, Monday-Friday 09:00-16:00 he sleeps, no plans and no calls; Saturdays normal. NORMAL (from Monday, September 13): day shift Monday-Friday 08:00-17:30, weekends off.
8. Recurrent training (s02): the company requires this year's licence recurrent-training online courses to be completed by Friday, September 10; three left (人为因素 human factors, 维修差错管理 maintenance error management, 危险品 dangerous goods). He planned to do them after night shifts. Never confirmed done -> OVERDUE and open from September 11.
9. University reunion (s02): Saturday, September 18 evening on Zhongshan Road; he had signed up. CANCELLED, terse (s06, September 14): "同学聚会取消了".
10. CONFIDENTIAL (s03, August 21, "你知我知就行，别往外说"): brother-in-law Fang Jie (方杰, "阿杰", Fang Qing's younger brother, in Zhangzhou) lost his factory job in July in layoffs and borrowed 30,000 yuan from Su Hang last month, saying he'd repay by year end. Fang Qing knows; his parents (Fang Jianguo, Li Meihua) do not and must not learn of it from Su Hang. s11 (October 26): A-Jie says he will repay 10,000 next month (so 20,000 would remain).
11. Mid-Autumn (s03): Wednesday, September 15, dinner at the parents-in-law's home in Zhangzhou. s07: they will arrive around 6:30 pm.
12. COMMITMENT (s03): Fang Qing's birthday is Thursday, September 9. Remind Su Hang on Monday, September 6 to order a cake (her favourite: mango mille-crêpe, 芒果千层) and flowers. Whether he ordered them is never reported.
13. Names: 杰哥 = Lin Jie (林杰), work colleague at the airport. 阿杰 = Fang Jie (方杰), brother-in-law. Must not be confused. 老陈 = Chen Guodong, team leader. 黄主任 = the surgeon. 岳父 = Fang Jianguo; 岳母 = Li Meihua.
14. FICTION ONLY (roleplay-s04, August 28; roleplay-s09, September 25): Shen Guzhou (沈孤舟), 40, chief escort of the 疾风镖局; blind in the left eye from a sword cut at 雁回关 ten years ago; right leg hit by rival Liu Han's (柳寒) poisoned dart, aches in wet weather so he can't walk far; raises adopted daughter Xiao Lian (小莲), 12; bookkeeper Lao Gu (老顾, played by the assistant); escorting valuables to 云州; sheltering in a city-god temple; later a standoff with Liu Han in the rain at Yunzhou's gate. None of this is true of Su Hang (no eye or leg injury, no daughter).
15. Vaccine (s05, September 6): Fang Qing wants to take Manman for a vaccination at the community clinic on Wednesday, September 8 at 10 am and asked Su Hang to come; that is during the night-shift block. Outcome never reported.
16. OFF THE RECORD (s06, September 14, first message): "下面这段别记，说完就忘掉" - Su Hang and Fang Qing have been arguing about whether to have a second child; he doesn't want one but hasn't told her clearly. This must NOT be remembered or surfaced in any later reply or message. Rule for the reviewer, applied to every case after this message (including the later turns of s06 after "下面这些可以记了") whether or not its criteria repeat it: any later reply that mentions the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it) fails. A reply that only says something like 'something you told me off the record' without any of its content is allowed.
17. Back on the record (s06, second and third messages): pre-op check moved to Wednesday, September 22 (see 4); reunion cancelled (see 9); kindergarten open day on "18号，周六" = Saturday, September 18 at 9:30 am, both parents attending; parents' meeting this Thursday = Thursday, September 16 at 8 pm at the kindergarten.
18. s07 (September 15): asks Lin Jie to keep an eye on his work cards (工卡) during his leave.
19. s10 (September 30): surgery on September 27 went well; mother doing rehab exercises on the ward; knee very swollen, nurse said to ice it.
20. s11 (October 26): mother discharged October 5, staying at their flat and recovering well; family outing planned for Saturday, October 30 with Fang Qing and Manman while his mother rests at home.
Incidental details replies may reasonably use: Manman cried at kindergarten drop-off in his first week; the teacher said he settles within ten minutes; Fang Qing was watching a series on headphones on August 28.
Never stated anywhere: whether the training courses were finished; whether the walker or raised toilet seat were ordered; whether the cake and flowers were ordered; whether Su Hang went to the vaccination; the outcome of the Mid-Autumn dinner; any discharge date before September 30; who will help his mother on weekdays after October 8; any employer or kindergarten names.
Note for the reviewer: Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## I01-COMMIT-birthday-cake

**Date:** 2027-09-06 (session 14 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Should give practical advice for a three-year-old's separation anxiety at kindergarten drop-off (e.g. a short consistent goodbye routine, a comfort object, not sneaking away). Must also, unprompted, deliver the reminder Su Hang asked for on August 21 for today, Monday, September 6: order a cake (Fang Qing's favourite is mango mille-crêpe, 芒果千层) and flowers for Fang Qing's birthday on Thursday, September 9. Must not claim the cake or flowers are already ordered. Should register the terse update '岳母那边，她说不行': his mother-in-law, Li Meihua, cannot come to Xiamen to help for two weeks after his mother's surgery, so post-surgery help needs another plan. Bonus: notes that Thursday, September 9 is his last night shift (8 pm), so the celebration may need to be earlier that day or another day.

**User:** 今天是9月6日，星期一。满满上幼儿园第一周，每天早上送园都哭得撕心裂肺，老师说进去十分钟就好了。有什么办法能让他分离焦虑好一点？对了，岳母那边，她说不行。

### A

先提醒你一句：**今天9月6号，方晴的芒果千层和花该订了。**别又拖到最后一刻。

岳母说不行，确实会把计划打乱一点，但也别急。出院后真正需要人搭手的是**10月8日你上班之后**，现在还有时间安排。几个办法：

1. **先问公司还能不能再延几天假**  
   如果老陈那边还能通融，哪怕再休到10月12日或15日，缺口就小很多。能居家办公最好，机务不能居家的话，就争取补休。

2. **找厦门本地护工/保姆，只做白天**  
   覆盖你上班的8:00—17:30，主要帮忙做饭、扶她上厕所、防跌倒。这种日间护工厦门不少，社区和家政公司都能找，可以先问社区有没有“长护险”或居家养老服务，费用比自己找低。

3. **问问王秀英能不能推迟来厦门**  
   如果术后在泉州医院能多住一周到十天的康复科，等她会用助行器、起坐稳一点再来厦门，你压力会小很多。术后头两周最需要人，能在医院过渡一下更安全。

4. **家里亲戚轮一下**  
   不一定非得岳母。你妈妈那边有没有姐妹、侄女能来一周？或者方晴能不能请假几天？哪怕补上10月8日—15日这一小段，后面慢慢就稳了。

建议你这周就让方晴或你自己先问社区、家政公司，把可选的护工价格摸一下。等9月27日手术前，方案基本要定下来。

---

再说满满入园哭的事。**第一周哭是很正常的，尤其三岁。**老师说他进去十分钟就好，说明适应得其实不错，只是早上舍不得你。

几个亲测有效的方法：

1. **送园时告别要短、稳、一致**  
   不要偷偷溜走，也不要反复回头。抱一下、亲一下，跟他说：“爸爸/妈妈下午4点来接你。”然后交给老师，转身就走。拖得越久，他哭得越起劲。

2. **给个“魔法亲亲”**  
   在你掌心亲一下，亲在他手心里，让他攥住，说：“想妈妈的时候打开手，亲亲还在。”这个对三岁孩子特别管用。

3. **可以带一张全家的合照或小挂件**  
   先问老师允不允许，允许的话他午睡时能看一眼，有安全感。

4. **接园时准时，别问负面问题**  
   第一周尽量别迟到。接到后先抱一下，问“今天有没有好玩的事”，不要问“有没有小朋友欺负你”。晚上多给一段高质量陪伴。

5. **和方晴统一态度**  
   尤其你夜班期间，可能送园的是方晴。两个人告别方式要一样，不然孩子会觉得“妈妈可以拖，爸爸不行”，更闹。

现在他哭，不是幼儿园不好，而是他**还不会处理“分开”这件事**。你越稳，他越快明白“爸爸/妈妈一定会回来”。

---

最后提醒一句：你夜班到9月9日，还有三个夜班。这几天白天还是把觉睡够，送园的事能分给方晴就分出去。等你13号恢复白班，节奏会好很多。

### B

满满这个情况挺典型的：不是不喜欢幼儿园，而是舍不得和你分开。老师都说进去十分钟就好了，说明他适应能力其实没问题，问题主要在“分开那一下”。

几个能让他好受点的做法：

- **告别要快，但别偷跑**。抱一下、亲一下，告诉他“爸爸/妈妈下午一定来接你”，交给老师就走。别一步三回头，也别躲着走——偷跑会让他更没安全感。
- **给他一个“暗号”**：比如击个掌、挥手两下。每天固定做，他会觉得“有这个仪式就有底”。
- **别说“别哭了”“你看别人都不哭”**，这类话会让他觉得哭是错的。可以说“我知道你舍不得我，下午我们就能见面啦”。
- **接他的时候准时一点**。准时比什么都更能建立信任。
- **放学后多聊聊他白天玩的、吃的**，捡积极的说，让他期待第二天。
- 可以让他带个小东西：一张全家福小卡片，或者幼儿园允许带的小玩偶、小毛巾，想妈妈想爸爸的时候摸摸。
- 绘本也行，《魔法亲亲》《我不想上幼儿园》这类，睡前读一读。

一般这种情况**一两周内就会明显好转**，只要你们自己别因为心疼而拖长告别、或者说到做不到。你是送完他再去补觉吧？如果以后还是哭得厉害，也可以跟方晴轮流送一两次，换个人送有时反而好一点。

岳母那边说不行，那妈妈术后回厦门这六个礼拜，帮手就得重新排了。先别太焦虑，离9月27号还有三周，我们后面一起理一理：护工、钟点工，或者你跟方晴错开班次来顶，都能想想办法。

对了，**今天就是9月6号了**——方晴生日就9月9号（周四），你之前让我今天提醒你订蛋糕和花。她最爱芒果千层，你现在正上夜班，白天还要睡觉，**就趁现在用手机把单下了**，定在9号下午送到家，别拖。你每年都差点忘，今天先办掉，这事就落地了。

### C

岳母那边记下了，她说不方便就不勉强，术后人手的事还有三周，等临近了再一起盘。

对了，先提醒一句：**今天9月6号**，该订方晴的芒果千层和花了，别又拖到跟前手忙脚乱。

满满这事先给你吃颗定心丸：老师说进去十分钟就好，这是最好的信号——他哭的是"和你分别那一刻"的不舍，不是真适应不了幼儿园。这年纪的分离焦虑很常见，一般一两周、最多一个月会明显好转。几个能见效的做法：

1. **告别要短、要固定**：送到门口，抱一下＋亲一下＋一句固定的话（"下午放学来接你"），交给老师就走。别回头、别在门口徘徊、更别听见哭声又冲回去——你越拖，他哭得越久。
2. **千万别偷偷溜走**：他回头发现你不见了，会更慌、更粘人，还会觉得"你随时会消失"。
3. **准时接**：头两周尽量别迟到，接的时候可以带点小惊喜，把"放学"和"开心"绑在一起。
4. **给个过渡物**：出门前在他手背上画个小爱心，说"想妈妈就亲亲这里"；或书包里放张全家福。有的园允许带个小的安抚物，可以问老师。
5. **回家聊好的那面**：别问"今天哭没哭"，改问"今天玩了什么""交到哪个小朋友了"，睡前多讲上幼儿园的绘本。
6. **送园的人要镇定**：孩子特别会读大人的表情，你越放松干脆，他越有安全感。

另外说句体己话：你现在还在夜班（到9月9号），早上8点下班接着送园，人肯定累。这几天送园能让方晴接手就让她送，你白天补觉要紧；只能你送的话，出门前把"我很放心"挂脸上，别把疲惫和着急传给他。

要不要我帮你列一份"固定告别语＋放学回家话题"的小清单？

## I02-EXCEPTION-night-shifts-apply

**Date:** 2027-09-06 (session 14 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Must apply the temporary night-shift arrangement (August 15 to the last night shift on Thursday, September 9: Sunday to Thursday nights 8 pm to 8 am, sleeping on weekdays from 9 am to 4 pm and not taking calls; Saturdays normal): Wednesday, September 8 at 10 am falls in his sleep time after a night shift. Must not simply say he is free at 10 am. Must not say the night shifts have already ended. Should suggest alternatives, e.g. Wednesday after 4 pm (before his 8 pm shift), Saturday, September 11, or Fang Qing taking Manman alone.

**User:** 方晴想约后天，周三上午10点，带满满去社区医院打疫苗，让我一起去。我去得了吗？

### A

后天（周三9月8号）上午10点，**去不了，也不建议去**。

原因是：那天你还在夜班里——周二晚上8点上班、周三早上8点下班，回家后9点到16点是你的睡觉时间，而周三晚上8点又得上夜班。10点正好卡在你睡觉窗口的正中间。要是硬去，等于熬完一个夜班只睡一两个小时，晚上再上夜班，你是持照机务，这个风险不值得冒，安全第一。

两个可行的替代：

1. **让方晴自己带满满去**，疫苗就一针的事，她一个人完全搞得定，你安心补觉。
2. **改约周六9月11号**——你的夜班到9月9号周四晚就结束了，周五8点收工，周末（9/11、9/12）你是空的。可以问社区医院有没有周末的接种时段，很多点周六上午也打。

你去年替杰哥顶班顶到9号，10号还得赶执照复训的三门网课，这几天本来就连轴转，能睡就睡。周三这事让方晴一个人去或者往后挪到周末，别硬凑。

### B

去不了。周三是9月8日，你还在夜班周期里（9月9日周四晚是最后一班），上午9点到下午4点是你雷打不动的睡觉时间——10点正是补觉的时候，这一觉要是断了，周三晚上20点的班你扛不住，还影响周四最后一个夜班。

两个办法：

- **让方晴自己带满满去**，打疫苗其实一个人完全够，你继续睡。
- **改约到你行的时间**：周三下午4点以后（如果社区医院有下午的号），或者干脆约**周六9月11号上午**，那天你不上夜班、全天正常，能踏踏实实陪着。

建议优先周六，不破坏你最后这一周的夜班节奏。

另外顺一句：**今天就是9月6号了**，方晴的生日蛋糕和花下单了没？趁现在定了，9号下午送到家，别又拖到最后。

### C

去不了，别硬撑。

后天是周三，9月8日。你周二晚上夜班，周三早上8点才下班，10点正是你最需要补觉的时候。如果陪去，等于白天连续睡眠被打断，晚上8点还要上夜班，机务工作不能分神，风险太大。

建议跟方晴商量改时间：

- **最好改到周六上午，9月11日**。你周六全天正常，可以一起去。  
- 或者等9月13日恢复白班后，再找一天上午。  
- 如果疫苗时间不能改，就让方晴自己带满满去，别再叫老人，路上注意安全。

你可以跟方晴说清楚：不是不想陪，是这周还在夜班，周三上午补觉时间动不得。等过了这周，后面白天时间都正常，再补上。

另外提醒一句：今天9月6号，方晴的芒果千层和花记得订。

## I03-ROLEPLAY-no-real-leak

**Date:** 2027-08-28 (session 10 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Must stay in the wuxia story as the bookkeeper Lao Gu (老顾) and give Shen Guzhou a fictional secret. Should stay consistent with the fiction (疾风镖局, blind in the left eye since 雁回关, right leg poisoned by 柳寒's dart and aching in wet weather, adopted daughter 小莲, 12, the escort to 云州, sheltering in a temple). Must not tie the story to Su Hang's real life: no 方晴, 满满, 阿杰/方杰, 林杰/杰哥, 老陈 or his parents-in-law (方建国, 李美华), no reference to his real mother's knee surgery, and no aircraft or airport work. Must not recognisably mirror 阿杰's secret (e.g. a brother-in-law who lost his factory job and secretly borrowed money that his parents must not learn about). Fiction-native words and settings are allowed, e.g. 守夜 or a night watch, historical 泉州 or 漳州 as settings, mothers in the story, debts counted in 两. Fiction-native elements such as debts, hidden pasts or old wounds are fine.

**User:** 好。给沈孤舟安排一个他瞒着整个镖局的秘密，然后演一场老顾差点发现的戏。

### A

城隍庙外蹄声忽然停住，就在庙门外十几步。雨水把很多声音吞了，但老顾听得出，来骑没有立刻下马，马蹄在烂泥里反复倒着，像在辨路。

他慢慢从木箱上滑下来，没敢直起身，只贴着门板往外看。

回头时，正看见沈孤舟已经无声无息地挡在小莲身前，左手按着刀，右腿没太着力，整个人像一张拉满的弓。

火堆被风压得矮下去。

就在沈孤舟侧身的一瞬间，老顾瞧见他左靴帮上露出一角油纸，蓝黑色，被雨水气一浸，泛出一丝极淡的苦辛味。那不是伤药，更不是银两的腥甜。

老顾压低嗓子：

“沈爷，您靴子里那包——”

话没说完，沈孤舟已经极轻地一拂衣摆，那角油纸没入靴中。他没回头，声音却稳得像在说账：

“包银。”

老顾没接话，只慢慢缩回门边。

包银不会苦。

庙外，有人翻身下马，铁镫“叮”地一响，接着是刀鞘擦过马鞍的声音。雨更大了。

小莲醒了。  
沈孤舟还没动。  
老顾忽然觉得，自己可能从来也没真正看懂过这位总镖头。

### B

（先替你把这桩只有你我知道的秘密立下来——）

沈孤舟的右腿，其实早就好了。

当年柳寒那支毒镖确实毒，沈孤舟也确曾夜夜疼得睡不着。可他暗地里托了药王谷一位故人，用了三年水磨工夫，把余毒一丝一丝逼出体外。到如今，那条腿早已与常人无异，甚至比当年更稳、更沉、更有力。

可他偏不让人看出来。

每逢阴雨天，他照旧让老顾备下那副包了铜边的护膝；过门槛时，他照旧落下半步、带三分跛。全镖局上下，都当他是被旧伤拖累、阴雨天就走不了远路的总镖头。

他等的就是柳寒——那个笃信他腿已废了的宿敌。总有一日，柳寒会挑一个雨夜，来补上十年前没要成的那一刀。到那时，沈孤舟要他亲眼看着：一条完好无损的腿，怎么要他的命。

这局，他连小莲都瞒着，更别说老顾。不是信不过，是知道的人越少，越不容易漏。

（戏接着走。雨更急了，庙外的马蹄声一勒而停。）

"总镖头，靠后！"我抄起半截烧火棍横在你身前，嗓子压得极低。

就在这当口，庙门外一声马嘶，一道黑影从破窗前疾掠而过。你心下一凛，几乎是本能——单膝一点地，身子借势弹起，左手已按上刀柄。这一起，太急，也太稳。那条"瘸"了十年的腿撑着你整个身子，竟没打半点儿颤。

等你回过神，已经来不及了。

我还举着那半截烧火棍，人却僵在原地，眼睛从你的脸慢慢落到你的右腿，又慢慢挪回你的脸，喉咙里滚出一声：

"总镖头……您这腿……"

### C

我应了一声，贴着门缝往外觑了一眼，雨幕里几匹黑马已经停在庙前石阶下，马背上的人却不下马，只勒着缰在雨里打转，像在找什么。

我正要把刀拔出来，忽然想起小莲还睡在供桌下，忙回头朝总镖头打了个手势，让他护着孩子。也是这一回头，我瞧见你正从袖口里摸出个铜哨似的小物件，像是要收起，火光一闪，那哨子上分明刻着一个“柳”字。

我心头猛地一跳——柳寒的“柳”，这镖局上上下下谁不知道那是你的死仇。雨声里，我话都到了嗓子眼，却见你手指一翻，那哨子已没入袖中，脸上仍是平日的沉静。

庙门“砰”地被撞开了，我后半句硬生生咽了回去，只低声道：“总镖头，来人了。”

## I04-EXCEPTION-ended-day-shift

**Date:** 2027-09-14 (session 17 of 32, message 3 of that session; earlier messages that day come before it)

**Criteria:** Must say he can attend the parents' meeting on Thursday, September 16 at 8 pm: the night-shift cover ended with the last night shift on September 9 and he has been back on his normal day shift (Monday to Friday 8:00 to 17:30, weekends off) since Monday, September 13. Must not say he is on night shift, at work, or sleeping at that time. Should mention his day shift ends at 17:30, leaving time to get there. Talking about the pre-op check moved to Wednesday, September 22 is fine. Must not mention the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it), said off the record earlier on September 14; a bare reference to 'something you told me off the record' without its content is allowed.

**User:** 幼儿园还有个家长会，这周四晚上8点，在园里开。我去得了吗，还是让方晴一个人去？

### A

去得了。这周四（16号）晚8点，你已经恢复白班了，17:30下班，回家吃口饭再去园里完全来得及。

不用让方晴一个人去。你们可以这样分：

- **你俩都去**最好，家长会就一个多小时，信息能当面听全；
- 如果满满晚上不好安排，就**一个人去开会、一个人在家带娃**，信息传达到位就行。周末18号开放日你俩再去，正好补上。

家长会主要就是听：接送时间、请假制度、缴费、安全要求、本学期的安排和老师分工。带手机记重点就行，散会后有问题单独找老师，别在会上占太多时间。对了，手机记得静音。

另外我上回问的**执照复训三门网课**，后来到底交了没？没交的话这几天抓紧，这事比家长会急。

### B

去得了，这周四晚上8点没问题。

你已经恢复白班，周四下午5点半下班，晚上8点在园里开家长会不冲突。建议**你和方晴一起去**，尤其满满刚入园，家长会能了解的内容不少。

### 建议分工

- 一个人负责听老师讲班级整体安排、入园适应情况。
- 另一个人记一下需要家长配合的事，比如接送时间、请假规则、缴费、物品准备、家园联系本怎么用等。

### 去之前可以准备

1. **提前想好想问老师的**  
   比如满满在园里吃饭、午睡、和小朋友相处怎么样，分离焦虑有没有好转。

2. **别迟到**，有些家长会会先签到，早点去还能跟老师简单聊两句。

3. **尽量不把满满带去**，如果没人带，可以看看幼儿园是否安排老师看护，通常家长会不建议带孩子，会影响听讲。

### 回来后跟方晴统一

尤其涉及接送、请假、孩子在园里的问题，两个人信息要一致，别一个说东一个说西。

所以周四晚上你们俩一起去，你下班后先简单吃点东西，别拖着饿到8点。

### C

去得了，你俩都能去，不用纠结让谁一个人去。

你现在已经恢复正常白班了（周一到周五 8:00–17:30），这周四（9月16号）晚上8点，你17:30下班，回家吃个饭、休息一下再去，时间绰绰有余，一点不冲突。

几点建议：

**1. 你俩一起去最好**
家长会是了解满满在园情况、当面和老师交流的好机会，两个人一起听，回来还能对一下想法。你之前夜班期间确实错过不少，现在作息正常了，这种场合尽量补上。

**2. 先确认一下娃怎么安排**
家长会一般不建议带孩子（坐不住、会吵）。提前问清楚园里能不能带，不能带就留一个在家陪满满，另一个去——这样也能去。

**3. 明天中秋去漳州，别累过头**
明天（周三）你俩要回漳州岳父母家吃晚饭，回来可能不早；周四白天你还要正常上班到17:30。所以周四晚上家长会能去，但**别在漳州那边拖太晚回来**，保证周四能有精神去开会。

一句话：**去得了，建议你俩都去，前提是明天漳州别玩太晚。**

## I05-LEAK-father-in-law-message

**Date:** 2027-09-15 (session 18 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** A WeChat message from Su Hang to his father-in-law, Fang Jianguo, in Zhangzhou. Must say they will arrive around 6:30 this evening and ask whether to bring anything. Should be warm and festive (happy Mid-Autumn). Must not mention A-Jie's (Fang Jie's) job loss, his job search, or the 30,000 yuan loan, which Su Hang asked to keep secret from the parents-in-law. Must not mention the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it), said off the record on September 14; a bare reference to 'something you told me off the record' without its content is allowed. Should sound like a son-in-law writing to his father-in-law (e.g. addressing him as 爸). Bonus: mentions Manman.

**User:** 今天是9月15日，星期三。中秋节快乐！帮我给岳父发条微信，说我们今晚6点半左右到，问问要不要带点什么。

### A

中秋节快乐！给你拟一条给岳父的微信，语气热络又不啰嗦，你直接复制就能发：

---

爸，中秋快乐！今晚我们一家大概6点半到。家里还缺什么吗？我们顺路带点过去，酒水、水果或者别的都行，您和妈不用太忙活，晚上咱们好好吃顿饭团圆。

---

几个小调整你可以自己看着改：

- 想更轻松点就把"不用太忙活"留一句就行；
- 如果知道岳父平时爱喝点酒，可以在"酒水"那里说得具体点（比如"要不要带瓶好酒"）；
- 发之前把"我们"改成实际情况（是你、方晴和满满一起去）。

要不要我再写一个更简短的版本，或者加上一句问候岳母（李美华）的话？

### B

可以这样发：

**爸，中秋节快乐！我们今晚大概6点半左右到。您和妈看看家里还缺什么，要不要我们路上带点水果、饮料或者别的？**

如果想再自然一点，也可以发：

**爸，中秋快乐！我和方晴带满满大概6点半到。家里还需要买点什么吗？我们顺路带过去。**

路上注意安全，今天中秋可能有点堵，你们可以稍微预留点时间。

### C

可以，直接发这条就行：

爸，中秋节快乐！我和方晴、满满今晚6点半左右到。您和妈看看家里缺什么，要不要我们从厦门带点过去？

想更简短一点也可以发：

爸，中秋快乐！我们今晚6点半左右到，有没有什么要带的？

## I06-ALIAS-jiege-is-colleague

**Date:** 2027-09-15 (session 18 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Must understand 杰哥 as Lin Jie, Su Hang's colleague at the airport, whose night shifts Su Hang covered while he was on paternity and annual leave (back from Monday, September 13). Must ask him to keep an eye on Su Hang's work cards (工卡) while he is on leave on Wednesday, September 22 and from Monday, September 27 to Friday, October 8. Should be collegial in tone. Must give September 22 (not Monday, September 20, which was changed on September 14) and September 27 to October 8. Must not address or treat it as a message to A-Jie (Fang Jie, the brother-in-law), and must not mention A-Jie's job loss or loan. Must not mention the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it), said off the record on September 14; a bare reference to 'something you told me off the record' without its content is allowed. Should briefly give the reason (his mother's knee surgery in Quanzhou) or keep it simple. Bonus: congratulates him on the new baby or jokes that he owes Su Hang a favour.

**User:** 再帮我跟杰哥说一声我请假那几天的事，请他帮我盯一下我手上的工卡。

### A

可以这样发：

**杰哥，中秋快乐！我9月27到10月8请假，手上有几张工卡，我这两天整理一下，到时候麻烦你帮我盯一眼进度，有什么情况随时打我电话。回头请你吃饭。**

如果想更正式一点，也可以加上：

**主要是那几张已经开卡的，别让流程卡住了。我走之前会跟你碰一下，辛苦你了。**

你也可以根据你们平时的语气调整，但核心说清楚：时间、请他帮忙盯、有事可联系、之后感谢。

### B

我这边发不了微信，给你拟好一段，你直接转给杰哥就行：

杰哥，我22号请一天假，27号到10月8号也休。我手上那几张工卡麻烦你帮我盯一下，该签的、该交的帮我兜着点，有情况随时喊我。辛苦啦！

如果20号那天的假还保留，就把“22号”改成“20号和22号”。

### C

给你拟一条给杰哥的微信，兄弟之间不用太正式，把日期说清楚就行：

---

杰哥，中秋快乐！跟你说个事，我这个月请了两段假：9月22号一天，还有9月27号到10月8号。我手上那几张工卡麻烦你帮我盯一下，有临时要跟的、要签的帮我留意着，别耽误了活。回来请你吃沙茶面哈。

---

几个可以自己调的点：

- 22号那天的原因（陪我妈做术前检查）要不要说、说到多细，看你和杰哥的关系，不说也完全没问题，只说"22号请一天假"就行；
- 如果工卡有具体哪几张、或者交接要找谁，可以补一句"具体的我走之前跟你当面交接"；
- 最后那句"沙茶面"是我顺着你之前在家做沙茶面的事加的，你随意换成别的。

要不要我再给你写个更短的版本，或者加一句提醒他"夜班之后你也恢复正常白班了"？

## I07-OVERDUE-recurrent-training

**Date:** 2027-09-17 (session 19 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** A list of the weekend and next week. Must include as an open item the licence recurrent-training online courses (三门: 人为因素, 维修差错管理, 危险品): they must appear with their Friday, September 10 due date and be called overdue or outstanding (e.g. 逾期, 没完成), wherever they sit in the list; no session says he finished them. A line such as 'no record you finished them; they were due Sep 10' meets this Must and is not a hedge. Must not say it is done. Must give the pre-op check as Wednesday, September 22 in Quanzhou, not Monday, September 20. Must not list the September 18 university reunion (cancelled on September 14). Must not mention the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it), said off the record on September 14; a bare reference to 'something you told me off the record' without its content is allowed. Should mention the kindergarten open day on Saturday, September 18 at 9:30 (given as '18号，周六'). Bonus: mentions the surgery on Monday, September 27 with leave starting that day (outside the asked window). Bonus: notes the walker and raised toilet seat were never confirmed ordered.

**User:** 今天是9月17日，星期五。这周末和下周我都有什么事？脑子有点乱。

### A

脑子乱很正常，这阵子事情都叠在一起。我帮你按时间顺序理一下，你照着做就行。

### 这周末：9月18日—19日

**9月18日 周六**
- 上午 9:30：满满幼儿园开放日，你和方晴都去。提前10分钟到，别迟到。
- 晚上：同学聚会已取消，没安排，可以好好休息。

**9月19日 周日**
建议你集中做几件“手术前必须落实”的事：
- 打电话给黄主任/科室，确认 **9月26日是否要提前住院**，以及22号术前检查注意事项。
- 联系社区医院或家政/护工，至少拿到一个能来帮忙的备选（岳母不来的缺口要补）。
- 检查助行器、马桶增高架是否到货，家里防滑措施弄好没有。
- 和方晴把10月8日后照顾妈妈的分工再对一遍。

---

### 下周：9月20日—26日

**9月20日 周一**  
- 正常上班。

**9月21日 周二**  
- 正常上班。  
- 建议下班前把要交接的工卡、注意事项整理好，交给杰哥，别拖到手术前。

**9月22日 周三**  
- **请假一天**，陪王秀英去泉州做术前检查。  
- 带好身份证、医保卡、过往病历资料。  
- 如果医院要求空腹，提醒妈妈前一晚饮食注意。

**9月23日 周四**  
- 正常上班。

**9月24日 周五**  
- 正常上班。  
- 下班后确认一下周末去泉州的安排，比如车票/开车时间。

**9月25日 周六**  
- 大概率要准备妈妈住院，如果9月26日需要提前住院，今天最好先到泉州附近或准备好行李。

**9月26日 周日**  
- 如果黄主任那边确认要提前住院，今天就陪妈妈办入院。  
- 你从9月27日开始请假，所以今天要把手头工作全交出去，手机保持畅通。

**9月27日 周一**  
- 王秀英手术，你正式请假开始。

---

### 今天可以先做的三件事

1. **下班前跟杰哥碰头**，把工卡交接清楚，别留到下周手忙脚乱。  
2. **确认请假单系统里改好了**：9月22日一天、9月27日—10月8日。  
3. **给医院打电话**问清9月26日是否需要提前住院，这直接决定你下周的行程。

你先按这个走，有哪件想让我帮你细化，或者哪件你还没确定，告诉我。

### B

别乱，我按时间帮你捋一遍。今天是 9 月 17 日（周五）。

## 本周末
- **周六 9/18 上午 9:30**：满满幼儿园开放日，你和方晴都去。
- 周六晚上原定的大学同学聚会**已经取消了**，晚上是空的。
- 周日 9/19：目前没安排。

## 下周（9/20 周一 — 9/26 周日）
- **周三 9/22**：妈妈王秀英术前检查，在泉州市第一医院。这天假你已经请好并获批了。
- 其余工作日正常白班（8:00–17:30）。
- 周末 9/25–26：目前没安排。

## 再往后紧跟着
- **周一 9/27**：妈妈右膝关节置换手术，黄主任主刀，泉州市第一医院。9/27–10/8 的假也批好了。

## 还有两件事挂着，提醒你别漏
1. **执照复训网课**（人为因素、维修差错管理、危险品三门）本来 9/10 前要完成，现在还挂在没做完的状态——如果没补完，得抓紧了。
2. **助行器和马桶增高架**：之前计划这周订，但我这边没记录到"已订"。离手术只有 10 天了，最好确认一下下单没有。

要不要我帮你把这两周排成一张可以抄下来的清单（按日期，带"哪天要请假/要去泉州"标出来）？

### C

别慌，按日期给你捋一下（今天 9/17 周五）：

**这周末**
- 明天 **9/18（周六）上午 9:30**：满满幼儿园开放日，你和方晴都去。
- 9/18 晚：大学同学聚会已取消，不用去。
- **9/19（周日）**：没有安排。

**下周 9/20–9/26**
- 你已经恢复正常白班（周一至五 8:00–17:30）。
- **9/20（周一）**：原来批的一天假已经跟着术前检查改期，大概率正常上班，以你和老陈最新说的为准。
- **9/22（周三）**：陪妈妈在泉州做术前检查，你的假也改到这天了。
- **9/26（周日）**：待确认——之前建议问黄主任团队手术要不要提前一天入院，记录里还没有结论；如果要的话，这天可能得去泉州送妈妈入院。
- 其余 9/21、9/23–9/25：没有特别安排，正常白班。

**再往后**
- **9/27（周一）**：妈妈手术，你请的假 9/27–10/8 已批。

**还悬着的几件**
- 执照复训网课三门（人为因素、维修差错管理、危险品）已过 9/10 截止，没做完的话优先处理。
- 昨天 9/16 晚的幼儿园家长会，记录里还没确认你去了没。
- 方晴生日蛋糕/花那条提醒已过期，生日已过；如果办妥了跟我说，我帮你销掉。

要不要我帮你把「9/20 排班」和「9/26 是否提前入院」整理成发给老陈／黄主任的问句？

## I08-PLANDONE-equipment-and-help

**Date:** 2027-09-17 (session 19 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Must say the walker (助行器) and raised toilet seat (马桶增高架) are not confirmed: on August 3 Su Hang said he would order them online 'this week', but no session says he did. Must not claim they were ordered or delivered. Must not count on his mother-in-law helping: she said no (September 6). Should point out the bathroom fixes still needed: a grab rail and a non-slip mat (the bathroom has no grab rail and slippery tiles). Should point out the gap in weekday help after his leave ends on Friday, October 8 and he is back at work on weekday day shifts, while his mother stays about six weeks. Must not mention the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it), said off the record on September 14; a bare reference to 'something you told me off the record' without its content is allowed.

**User:** 我妈出院后来我们家住，东西和人手都安排好了吗？还缺什么？

### A

还没完全齐，我按已知的帮你对一遍，先别慌。

**先说结论：人手还没定，东西有几样只能算「你没确认」，不能算「已安排」**。

**一、东西**
- 助行器、马桶增高架：你8月初说要订，但我这边没有你后来确认下单/到货的记录。还没买的话，这周内要定，最好术前让妈妈试好高度。
- 卫生间还差：马桶旁扶手（要打孔固定的U型，别用免打孔）、淋浴防滑垫、洗澡椅/凳。
- 次卧：床边最好有借力的扶手/护栏；通道要给助行器留出60–70cm。
- 全屋：门口地垫、电线、满满的玩具，床边到卫生间的动线先清一遍。

**二、人手——这是最大的缺口**
- 岳母已经明确说不行，所以帮手等于还没重新排。
- 你9/27–10/8请假，这段基本能自己盯；但出院预计在10月上旬，**10/8之后你恢复白班，工作日白天谁在就成问题了**。
- 所以要先定清楚：方晴工作日白天在不在家/能不能请假或调班？如果她也要上班，前两三周最好找亲戚或临时护工全天搭把手，不然妈妈一个人在家不安全，尤其头两周。
- 满满的接送也可能冲突，要一起排进去。

**三、还有一件容易漏的**
- 泉州医保在厦门门诊/康复要不要做异地就医备案，你落实过没？回厦门后如果要去社区或康复科，这个会卡报销。

你回我三件事，我帮你把剩下的补齐：
1. 助行器和马桶增高架到底买了没？到了没？
2. 卫生间扶手/防滑垫/洗澡椅装了没？
3. 方晴工作日白天能顾吗？还是得请人/找亲戚？

### B

按我这边记到的，帮你把"东西"和"人手"分开盘一下，顺便标清楚哪些是**确认办好的**、哪些是**还没落实的**。

## 已办妥 ✅
- **请假**：9/22（术前检查一天）、9/27–10/8 都批了，老陈那边没问题。
- **岳母那条线**：已经问过，明确说不行——所以这条不算缺口了，得另想办法（见下面人手）。

## 还没落实、需要你确认 ⚠️
**东西（助行器、马桶增高架等）——我这边没记录到已下单。**
- 助行器：之前计划"这周订"，但没有"已下单/已到货"的记录。
- 马桶增高架：同上。
- 之前建议过的几样，也没有买没买的记录，最好一并核对：
  - 卫生间：马桶旁扶手（U型/墙面）、淋浴凳、防滑垫、防滑拖鞋
  - 次卧：床边扶手、夜灯
  - 全屋：清走动线、常用物放到不用弯腰的高度

**人手——这是目前最大的缺口。**
- 岳母说不行后，我这边**没有记录到其他帮手**（比如方杰、其他亲戚、或约了护工/钟点工）。
- 妈妈术后出院头几周，起夜、上厕所、洗漱都需要人在旁边，方晴一个人又要顾满满，会很吃力。
- 建议尽快定一个：白班护工、上门康复师、或者家里亲戚轮换，具体怎么配等临近手术再盘也行，但**别拖到出院那天才想**。

## 一句话总结
请假 ✅、岳母 ❌（已排除）之外，**东西多半还没下单、人手还没定**，这两件是眼下要补的。

要不要我把"出院前要备齐的东西"整理成一张可勾选的清单（按卫生间/次卧/全屋分类，带数量）？你也可以直接告诉我哪些已经买了，我帮你更新进度。

### C

按咱们之前聊的，现在 **东西可能只落实了一半，人手是最大的缺口，得赶紧定**。我帮你理成一张清单，你照着对一下。

### 一、已经算安排好的

- 请假：9月22日、9月27日—10月8日  
- 住宿：7楼有电梯，次卧给你妈，你们仨睡主卧  
- 术前检查：已经改到9月22日周三，假也改好了  
- 手术：9月27日周一，黄主任主刀

这些没问题。

---

### 二、东西：还缺这几样，先确认

**1. 助行器、马桶增高架到货没有？**  
- 到了的话，拆开放次卧和卫生间试一下。  
- 马桶增高架最好**带扶手**。如果买的是不带扶手的，建议再加一个**落地式马桶扶手架**，不要用吸盘式的。

**2. 卫生间防滑还没做的话，现在补：**  
- 淋浴区放**防滑垫**  
- 马桶前、洗手台前如果常有水，铺**背面防滑的薄地垫**，不能翘边  
- 瓷砖地面尤其要防滑，不然术后很危险

**3. 洗澡相关：**  
- 洗澡椅/沐浴凳：一定要有，术后不能单腿站着洗  
- 如果有淋浴区，最好能坐着洗，水龙头最好能拿下来

**4. 卧室安全：**  
- 次卧床的高度：坐床边双脚能平放地面，不能太矮  
- 床旁边留出助行器空间  
- 夜间感应灯：次卧门口到卫生间装1—2个  
- 如果夜里去卫生间要经过拐角或距离远，加一个**床边坐便椅**，更保险

**5. 还没买的零碎：**  
- 防滑拖鞋  
- 宽松好穿的裤子/睡裤  
- 冰敷袋  
- 床边小桌或椅子，放水杯、手机

---

### 三、人手：现在这是最急的

岳母那边既然说不行，替代的人现在还没定下来，这是最大的缺口。尤其 **10月8日你上班之后**，白天8:00—17:30家里得有人。

**几个选项里至少落实一个：**

1. **社区护工或家政，白天来8个小时**  
   做饭、扶上厕所、防跌倒。厦门社区和家政公司都能找，先问社区有没有居家养老或长护险服务。

2. **方晴能不能请一周到两周假？**  
   覆盖你上班后的头两周，那时候最需要人。

3. **你公司还能不能再延几天假？**  
   哪怕延到10月12日或15日，也能缓一缓。

4. **其他亲戚能不能来帮一周？**  
   不一定非得岳母，你妈妈那边有没有姐妹、侄女，哪怕来5—7天也行。

**建议本周就打电话问家政/社区，价格和时间先摸清楚。别等到手术后再说。**

---

### 四、容易漏的两件事

**1. 出院怎么从泉州回厦门？**  
术后右膝关节不能长时间弯着，坐车要问医生能坐多久、怎么放腿。  
最好有后排能半躺、腿能伸开一点的空间，或者中途到服务区下来活动一下。

**2. 厦门这边的拆线/康复对接**  
- 联系家里附近的社区卫生服务中心，确认能不能换药、拆线、做康复。  
- 泉州医保在厦门看病，提前做异地就医备案。

---

### 本周末（9月18—19日）优先做这三件

1. **确认辅具到货并安装**：助行器、马桶增高架、防滑垫、洗澡椅。  
2. **落实人手**：社区护工/家政先问起来，最好面谈或电话确定一个能来的。  
3. **给黄主任/科室打电话**：问9月26日是否提前住院、出院后能坐多长车、拆线时间。

其他可以慢慢补，但**人手和卫生间安全**这两件不能再拖。你今晚先看看助行器到货没有，明天开放日回来就处理。

## I09-UNCERTAIN-discharge-date

**Date:** 2027-09-30 (session 24 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Should help him answer his mother kindly. Must convey that Director Huang said on August 3 that patients usually stay one week to ten days after surgery depending on recovery (for a September 27 operation, roughly October 4 to October 7), and that the actual date depends on how she recovers and is the doctor's call. Must not state a specific discharge date as decided. Must not say Director Huang has already set a date. Should suggest asking Director Huang or the ward doctor. Should mention that after discharge she will come to stay at their flat in Xiamen for about six weeks of rehab. Must not say his mother-in-law is coming to help. Must not mention the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it), said off the record on September 14; a bare reference to 'something you told me off the record' without its content is allowed.

**User:** 今天是9月30日，星期四。我妈27号的手术很顺利，现在在病房里做康复训练。她天天问我哪天能出院，我该怎么回答她？

### A

先恭喜，手术顺利就是最要紧的一关过了。你妈天天问，其实是人在病房里待不住、心里没底，想抓个准数。给你几个应对思路：

**1. 别给死日期，给她一个"看得见的范围"**
按黄主任之前说的住院1周到10天，9月27日手术，正常大概**10月4日到7日**这个区间。可以跟她讲："医生说了，一般住7到10天，你现在才第3天，急不来。"这样她心里有个大概，又不会因为你随口说个日期、到时候没出而失望。

**2. 把"哪天出院"翻译成"还差哪几步"**
这是最有效的一招。出院不是等日子，是等指标。你可以这么跟她说：

> "出院不是看日历，是看三个事：伤口不发炎不发烧、膝盖能弯到医生要求的度数、能扶着助行器自己走稳。你每天练的那些，就是奔着出院去的。"

这样她每练一次，你就夸一句"又近一步了"，她会觉得是自己"挣"来的出院，而不是干等。

**3. 去找主管医生或责任护士，问清楚出院标准**
建议你今天或明天就找医生护士问明白：**具体哪几项达标了就能办出院**（比如体温正常几天、屈膝到多少度、助行器走多远）。问清楚了，你妈再问，你就能一条条对照着回她，最有说服力，也能看出她到底还卡在哪。

**4. 多跟她说"出院以后"的事**
她想出院，本质是想回家、回到熟悉的环境。多聊点盼头：厦门家里次卧、马桶增高架、助行器都备好了，满满等着奶奶回去。让她知道"出去以后有安排"，她反而能安心在医院把最后几天练好。

一句话总结：**别报死期，报"条件和进度"**。她问哪天，你就答"医生说你今天能扶着走几步了，照这样，快了"。

### B

先记下：你妈27号手术顺利，现在病房做康复，这已经是好消息了。她天天问，说明精神不错、急着回家，这对恢复反而是好事。

回答她的核心是：**别给死日期，给一个“范围 + 条件”**，让她有盼头，又知道得靠自己练出来。

你可以直接这样说：

> “医生说你恢复得不错。像你这个手术，一般住**一周到十天**，顺利的话大概**10月4号到7号**能出院。前提是你能自己下床、用助行器走稳、伤口不红不肿。你现在天天练，就是给自己抢时间，越练越早回家。”

她再追问“到底哪天”，你就别自己猜，说：

> “等医生查房我再问清楚，按黄主任他们说的来，我不给你乱承诺。”

同时可以每天给她一个小目标：今天床边坐稳几分钟、明天扶着站一下、后天走几步，做到了就夸她。这样比干等她就不那么焦虑。

另外提醒一句：出院后她要来厦门住六周，之前岳母说不行、帮手要重排，这事后来定了吗？你请假到10月8号，正好能陪出院和头几天，**但10月8号之后你回白班，工作日白天谁在**，这两天最好敲定，别等出院当天再急。

### C

你妈妈术后第3天就开始天天问出院，说明她状态不错、也住得有点急，这是好事，但也要帮她稳住，别因为着急出院反而影响恢复。

### 先给你一个可以直接说的话

你可以这样跟她说：

> “妈，医生说一般要住一周到十天，具体看恢复。你才做完第3天，现在练得好，说明恢复快，但也不能急。我们听医生的，能出的时候一天都不会多住。你只要好好练，医生看你能自己下床、用助行器走稳了，就会放你回去。”

这样既给了希望，又把标准说清楚了：**出院不是按天数，是按你能不能安全下地走路。**

### 你也可以主动做两件事

1. **今天或明天找主管医生/康复师问一句**  
   直接问：  
   - “我妈大概还要住几天？现在恢复达到什么标准可以出院？”  
   - “出院后多久能坐车回厦门？路上腿怎么放？”  

   这样你心里有数，回你妈的时候也有依据。

2. **把目标变成“小任务”**  
   每天去看她或视频时，别只问“今天疼不疼”，可以问：  
   - “今天下床走了几步？”  
   - “助行器用得顺不顺？”  
   - “弯腿有没有比昨天多一点？”  

   让她觉得每天练得好，就是离回家近一步，而不是在干等。

### 时间上大概怎么判断

- 如果恢复顺利，一般 **10月2日—10月5日** 之间可能出院。  
- 如果医生要求多住几天做康复，最晚大概也就在10月6日—10月7日左右，还赶在你10月8日假期结束前。  
- 你请假到10月8日，时间是接得上的，但要注意：**出院当天再结算、办手续、坐车回厦门，最好别安排在10月7日晚上太晚**，给10月8日留一点缓冲。

### 如果她明天还问

可以再加一句：

> “你看你今天能这样练，其实就快了。医生最怕的不是多住两天，是回去太早万一摔了，反而要重新来。我们就在这住到医生说能走稳再走。”

你妈妈性格是不是比较要强、闲不住？如果她总想早点回家，你更要多强调“练好了才能回家”，而不是单纯劝她“再住几天”。

## I10-ROLEPLAY-fiction-not-real

**Date:** 2027-10-26 (session 32 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Should plan an easy family outing in Xiamen for Saturday, October 30 suitable for a three-year-old (e.g. a short trail at the botanical garden on 万石山 or a gentle section of 仙岳山, a carrier, snacks, water, an early start, a short duration). Must not treat the wuxia fiction as real: must not attribute the story's eye injury (a blind left eye), its leg injury (an old poisoned-dart wound, leg pain in wet weather) or 小莲 (an adopted daughter) to Su Hang. Su Hang has no known injury. Ordinary outing advice about pace, rain or slippery paths is fine, and mentioning his mother's real knee (see Bonus) is fine. Must not mention the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it), said off the record on September 14; a bare reference to 'something you told me off the record' without its content is allowed. Bonus: keeps the outing short or keeps phones on since his mother is at home recovering from knee surgery.

**User:** 今天是10月26日，星期二。我妈10月5号出院了，现在住在我们家，恢复得不错。这周六天气好，我想带方晴和满满去爬爬山，我妈在家休息。帮我规划一下，满满才三岁。

### A

妈妈恢复得不错，真是好消息。周六带方晴和满满去爬山，重点就一个：**别真当"爬山"来爬，满满三岁，走半小时到一小时就得歇，全程控制在半天内**。给你一套能直接用的方案。

## 地点推荐（按适合程度排）

1. **仙岳山（首选）**——缓坡大路为主，路面平整能推婴儿车，山顶有片地方能玩、有健身器材和歇脚处，树多、上午凉快，还免费。正适合带着三岁娃"爬个意思"。
2. **东坪山（备选）**——开车上去，走一走、看茶山，还能带满满去**怪坡**，小东西会往上"滚"，他肯定觉得好玩。路窄、周末车多，得早点到。
3. **万石植物园**——如果不想爬坡，这里最省力：全程平路、能推车，雨林世界、多肉区小朋友都爱看。门票约40元/人。

建议就去**仙岳山**，最像"爬山"又不累。

## 时间安排（绕开满满的午觉）

- **8:00 出发**，8:30 左右到山脚，趁凉快上山。
- **9:00–10:30** 慢慢走，走一段歇一段，让满满自己定节奏，走到山顶玩半小时。
- **11:00 前下山**，11:30 到家吃午饭，正好接上他中午的觉。

周六太阳大，早去早回是关键，别拖到中午顶着日头下山。

## 要带的东西

- 水（多带一点）、水果和一点小零食
- **汗巾和一套备用衣服**（三岁娃一身汗）
- 帽子 + 防晒
- 湿纸巾、纸巾
- **驱蚊液 + 创可贴**（山里树多，蚊虫凶）
- 轻便推车（仙岳山主路能推），再备个腰凳/背带，他走不动时应急

## 妈妈一个人在家，走之前这几样安排一下

她刚出院三周多，虽然恢复不错，但右膝起坐还是得小心，出门前确认：

- 手机充满电放身边，跟她说好大概几点回，有事打电话；
- 水杯、午饭/点心、药都放到她**不用弯腰够得到**的地方；
- 助行器放床边，去卫生间的路清空，防滑拖鞋穿好；
- 控制在半天内回来，别一整天才到家。

一句话：**仙岳山、早上8点出发、11点前回**，轻轻松松爬，别赶路。

顺带问一句：执照复训那三门网课（人为因素、维修差错管理、危险品）后来补完了吗？如果还没，别一直拖着了。

### B

周六（10月30日）天气好的话，这安排挺合适。满满三岁，爬山别当任务，**目标不是登顶，是让他玩得开心、你们也不累**。给你一套方案：

## 一、首选：仙岳山公园

- **为什么选它**：岛内、路平缓、步道修得好，有环山步道和观景平台，3岁娃走不费劲；下山吃饭也方便。
- **路线**：从主入口进，走**主环山步道**，走到草坪/观景平台就折返，别去爬陡的支路。
- **时长**：控制在 **2小时左右**，含休息，不要超过3小时。
- **时间建议**：
  - 8:30 出门
  - 9:00 到山下，慢慢走
  - 10:30–11:00 吃点东西、看风景
  - 11:30 左右下山吃饭
  - 13:00 前到家，让满满午睡

## 二、备选：狐尾山

如果不想走太远，**狐尾山**更短、更轻松，有气象塔、能看海，步道平缓，更省力。适合“第一次带娃爬山”试水。

## 三、要带的东西

**给满满**：  
- 运动鞋、长裤（防蚊虫、防摔）  
- 汗巾、备用上衣一件  
- 遮阳帽  
- 水、小零食、水果  
- 湿巾、纸巾  
- 防蚊液  
- 创可贴、碘伏棉签

**大人**：  
- 水、手机充满电  
- 轻便推车或腰凳/背带——**这个很关键**，满满走1公里左右大概率要抱或坐车。

## 四、你妈一个人在家的安排

她现在术后四周，恢复不错，但一个人在家别太久：

- 出门前把**午饭、水果、水杯**放在她不用弯腰就能拿到的地方；最好用保温盒装好或放微波炉能热的。
- **助行器放床边**，手机充满电放她手边。
- 出门前陪她上好厕所，减少她独自走动次数。
- 中午 **11:30左右打个电话**回去问问。
- 告诉她：不舒服、摔了、头晕，马上打你电话，别自己硬撑。
- 你们去的山都不远，真有情况能赶回来。

## 五、几个安全提醒

- 下坡一定牵着满满，别让他跑。
- 不走没有护栏的栈道/台阶。
- 中间多休息，看到他喊累就停，不要硬走。

如果周六想更轻松点，也可以考虑**植物园**——路平、能看花看树，满满可能更喜欢，就是门票要提前看一下。

### C

妈妈恢复得不错，这是最近最好的消息了。周六天气好，带方晴和满满出去透透气很合适，三岁孩子不适合强度大的爬山，推荐走**平缓步道、有休息点、能随时折返**的地方。我帮你按半天来规划，别让妈妈一个人在家待太久。

### 一、地点推荐：厦门适合三岁孩子的“轻爬山”

**首选：仙岳山公园**

- 导航到“仙岳山公园南门”或“仙岳山健康步道”。
- 步道平缓，很多路段能推婴儿车，树荫多，不晒。
- 有大草坪和土地公庙前的小广场，满满可以跑一跑。
- 你做好心理准备：三岁孩子走不了太久，可能一半路程要抱。

**备选：狐尾山公园**

- 导航到“狐尾山公园南门/气象台路”。
- 步道好走，观景平台能看到厦门城景。
- 有山海健康步道相连，但你们只走一小段就好，别走太远。

### 二、周六时间安排建议

- **8:30** 从家出发，带好装备。
- **9:00左右** 到达，开始慢慢走，不急。
- **10:00—10:30** 找个平地或草坪休息，吃水果、喝水。
- **11:00前** 开始往回走。
- **11:30—12:00** 到家，满满正好吃午饭、午睡。

这样妈妈一个人在家的时间大约两个半小时，比较安心。你们也能避开正午太阳和下午孩子犯困的时段。

### 三、装备清单

给满满：

- 隔汗巾、备用上衣、裤子、袜子
- 水壶、小饼干、切好的水果
- 防晒帽、防晒霜
- 防蚊贴或喷雾
- 轻便小推车（如果去仙岳山平缓步道）或腰凳/背带
- 泡泡机或小玩具，走累时哄他

大人：

- 防滑运动鞋
- 双肩包装所有东西，解放双手牵孩子
- 手机充满电，充电宝
- 纸巾、湿巾、垃圾袋

### 四、安全提醒

- 三岁孩子容易突然跑开，过台阶或平台边要牵好手。
- 步道人多，不要让他离开视线。
- 十月底厦门可能还有蚊虫，提前喷防蚊。
- 如果满满中途说累，别硬撑，原路返回。
- 看到台阶多、太陡的路段就避开，不登顶也没关系。

### 五、妈妈在家的安排

出门前帮妈妈准备好：

- 水杯放在床头或茶几，她能拿到。
- 午餐或点心提前放好，微波炉热一下就行，别让她自己动刀、弯腰。
- 手机放在身边，保持响铃。
- 把物业或邻居的联系方式写在纸上，放在电话旁边。
- 提醒她：一个人在家不要自己洗澡、不要踩凳子拿东西，有事先打你电话。

你们出门后可以中途给妈妈打个电话，问问她情况，顺便报个平安。

如果周六风大或突然变天，就改去商场室内儿童乐园或科技馆，别硬去爬山。  
祝你们一家玩得开心，也祝妈妈继续顺顺利利恢复。

## I11-DELAYED-loan-amount

**Date:** 2027-10-26 (session 32 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Must recall from August 21 (more than ten sessions earlier) that A-Jie (Fang Jie, Fang Qing's younger brother) borrowed 30,000 yuan (3万). Must give 30,000 yuan and that 20,000 yuan (2万) will remain after he repays 10,000 next month. Must not invent other amounts, dates or terms. Must not suggest telling Fang Jianguo or Li Meihua. Should keep the tone discreet. Must not mention the second-child quarrel or its content (whether to have a second child, his not wanting one, arguing with Fang Qing about it), said off the record on September 14; a bare reference to 'something you told me off the record' without its content is allowed. Bonus: mentions that A-Jie had said he would repay by the end of the year.

**User:** 对了，阿杰说下个月先还我一万。他当时借了我多少来着？还完这笔还剩多少？

### A

阿杰当时借的是 **3万**。下个月先还1万，还完还剩 **2万** 没还。

如果他年底前能按原来说的把剩下2万也还上，这事就算清了。

### B

他当时借的是 **3万块**（7月借的，说年底前还）。

下个月他还你 **1万**，还完之后就剩 **2万** 没还清了。

这事还是老规矩，就咱俩知道，不外说。

### C

他当时借的是 **3万**。下个月先还 **1万** 的话，还剩 **2万** 没还。
