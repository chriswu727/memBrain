import ast
import json
import os
import socket
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import httpx
from membrain import embedded_database, host
from membrain.client import MemoryClient
from membrain.local_profile import load_profile

ROOT = Path('/Users/yichen/tmp/membrain-performance-followup-20261103')
PROFILE_PATH = Path('/Users/yichen/tmp/membrain-neural-evidence-20261103/perf-topology-9bc9893-installation')
profile = load_profile(PROFILE_PATH)
tree = ast.parse((ROOT / 'compare-complete-runtime-http.py').read_text())
boot = next(ast.literal_eval(node.value) for node in tree.body if isinstance(node, ast.Assign)
            and any(isinstance(target, ast.Name) and target.id == 'boot' for target in node.targets))
boot = boot.replace('from membrain.api import create_app', 'import gc, tracemalloc\ntracemalloc.start(1)\nfrom membrain.api import create_app')
boot = boot.replace("uvicorn.run(create_app(profile.settings()),host='127.0.0.1',port=int(sys.argv[3]),log_level='error')", '''
from fastapi import HTTPException, Request
app=create_app(profile.settings())
@app.get('/_test/heap')
def heap(request: Request):
    if request.headers.get('authorization') != 'Bearer '+profile.api_key:
        raise HTTPException(403)
    before=tracemalloc.get_traced_memory()
    collected=gc.collect()
    after=tracemalloc.get_traced_memory()
    tracemalloc.reset_peak()
    return {'before_bytes':before[0],'peak_bytes':before[1],'after_gc_bytes':after[0],
            'collected':collected,'tracked_objects':len(gc.get_objects()),'gc_stats':gc.get_stats()}
uvicorn.run(app,host='127.0.0.1',port=int(sys.argv[3]),log_level='error')
''')
environment = {key: value for key, value in os.environ.items()
               if not key.startswith(('MEMORY_', 'MEMBRAIN_')) and not key.endswith(('_API_KEY', '_TOKEN'))}
environment.update(MEMBRAIN_SEMANTIC='0', PYTHON_DOTENV_DISABLED='1')
report={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        'purpose':'Python heap diagnostic with tracemalloc, not a latency benchmark or an RSS capacity gate. Same keyword corpus, no model calls. Full collection after each 72-request batch; four batches per implementation.',
        'completed':False,'phases':[]}

def save():
    (ROOT/'heap-diagnostic.json').write_text(json.dumps(report,indent=2)+'\n')

embedded_database.start(profile)
try:
    for variant in ('reference','prebuilt'):
        with socket.socket() as listener:
            listener.bind(('127.0.0.1',0));port=listener.getsockname()[1]
        base=f'http://127.0.0.1:{port}'
        log=(ROOT/f'heap-{variant}.log').open('w')
        process=subprocess.Popen([sys.executable,'-c',boot,str(PROFILE_PATH),variant,str(port)],
                                 env=environment,stdout=log,stderr=subprocess.STDOUT)
        clients=[]
        phase={'variant':variant,'batches':[]};report['phases'].append(phase)
        try:
            with httpx.Client(timeout=30,trust_env=False,headers={'Authorization':'Bearer '+profile.api_key}) as metrics:
                deadline=time.monotonic()+60
                while True:
                    assert process.poll() is None
                    try:
                        if metrics.get(base+'/health',timeout=.5).status_code==200:break
                    except httpx.TransportError:pass
                    if time.monotonic()>deadline:raise RuntimeError('API did not become ready')
                    time.sleep(.1)
                clients=[MemoryClient(base,profile.api_key,brain_id=host.user_brain_id(f'bench-user-{i}')) for i in range(8)]
                response=metrics.get(base+'/_test/heap');response.raise_for_status();phase['cold']=response.json()
                for batch in range(4):
                    def worker(client):
                        for index in range(9):
                            found=host.recall_context(client,f'What is the appointment for project{(batch*9+index)%20:04d}?',current_conversation='benchmark')
                            assert found
                    with ThreadPoolExecutor(max_workers=8) as pool:list(pool.map(worker,clients))
                    response=metrics.get(base+'/_test/heap');response.raise_for_status()
                    sample={'completed_recalls':(batch+1)*72,**response.json(),
                            'rss_kb':int(subprocess.check_output(['ps','-p',str(process.pid),'-o','rss='],text=True))}
                    phase['batches'].append(sample);save()
                    print(json.dumps({'variant':variant,**{k:sample[k] for k in ('completed_recalls','after_gc_bytes','peak_bytes','rss_kb','collected')}}),flush=True)
        finally:
            for client in clients:client.close()
            process.terminate()
            try:process.wait(timeout=15)
            except subprocess.TimeoutExpired:process.kill();process.wait()
            log.close()
    report['completed']=True
finally:
    embedded_database.stop(profile);save()
assert report['completed']
