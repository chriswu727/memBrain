import re
from jsonschema import Draft202012Validator
from membrain import contracts


def string_check(schema):
    if set(schema) - {'type', 'minLength', 'maxLength', 'pattern', 'format', 'enum', 'const', 'description', 'title', 'default'}:
        return None
    types = schema.get('type')
    if types != 'string' and not (isinstance(types, list) and 'string' in types):
        return None
    if 'enum' in schema and not all(type(value) is str for value in schema['enum']):
        return None
    if 'const' in schema and type(schema['const']) is not str:
        return None
    try:
        pattern = re.compile(schema['pattern']) if 'pattern' in schema else None
    except re.error:
        return None
    minimum, maximum = schema.get('minLength', 0), schema.get('maxLength')
    choices = frozenset(schema['enum']) if 'enum' in schema else None
    constant, has_constant, format_name = schema.get('const'), 'const' in schema, schema.get('format')

    def check(value, checker):
        if type(value) is not str:
            return False
        length = len(value)
        return (length >= minimum and (maximum is None or length <= maximum)
                and (choices is None or value in choices) and (not has_constant or value == constant)
                and (pattern is None or pattern.search(value) is not None)
                and (format_name is None or checker is None or checker.conforms(value, format_name)))
    return check


def install():
    original_extend = contracts.extend

    def extended(parent, validators):
        plans = {id(node): check for node in contracts._subschemas({'$defs': contracts._linked_definitions()})
                 if (check := string_check(node)) is not None}
        original_properties = validators['properties']

        def properties(current, properties, instance, schema):
            if not current.is_type(instance, 'object'):
                return
            for name, subschema in properties.items():
                if name not in instance:
                    continue
                check = plans.get(id(subschema))
                if (check is not None and current.TYPE_CHECKER is Draft202012Validator.TYPE_CHECKER
                        and check(instance[name], current.format_checker)):
                    continue
                yield from original_properties(current, {name: subschema}, instance, schema)
        return original_extend(parent, {**validators, 'properties': properties})
    contracts.extend = extended
    contracts.validator.cache_clear()
    contracts._prepared_root.cache_clear()
