import json,statistics,sys,time
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'tests'))
from test_contract_linking import documents,mutations,error_details
from membrain import contracts
from scalar_probe import install
cases=documents()
reference={name:contracts.validator(name) for name in cases}
install()
report=[]
for name,doc in cases.items():
    candidate=contracts.validator(name)
    for broken in mutations(doc,1000,'scalar-'+name):
        assert [error_details(x) for x in candidate.iter_errors(broken)]==[error_details(x) for x in reference[name].iter_errors(broken)], name
    for label,validator in [('current',reference[name]),('scalar',candidate)]:
        samples=[]
        for i in range(100):
            start=time.perf_counter();validator.validate(doc);samples.append(1000*(time.perf_counter()-start))
        report.append({'definition':name,'variant':label,'median_ms':statistics.median(samples),'p95_ms':sorted(samples)[94]})
print(json.dumps(report,indent=2))
