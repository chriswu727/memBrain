from functools import lru_cache

from jsonschema import Draft202012Validator, FormatChecker
from jsonschema.validators import extend
from membrain import contracts


@lru_cache(maxsize=1)
def root_validator():
    linked = contracts._linked_definitions()
    assert linked is not None
    nodes = contracts._subschemas({"$defs": linked})
    if any('$ref' in node and not str(node['$ref']).startswith('#/$defs/') for node in nodes):
        return None
    children = {}

    def child_errors(validator, value, subschema, path, schema_path=None):
        child = children.get(id(subschema))
        if child is None or child.format_checker is not validator.format_checker:
            yield from validator.descend(value, subschema, path=path, schema_path=schema_path)
            return
        for error in child.iter_errors(value):
            error.path.appendleft(path)
            if schema_path is not None:
                error.schema_path.appendleft(schema_path)
            yield error

    def properties(validator, properties, instance, schema):
        if not validator.is_type(instance, 'object'):
            return
        for name, subschema in properties.items():
            if name in instance:
                yield from child_errors(validator, instance[name], subschema, name, name)

    def items(validator, subschema, instance, schema):
        if not isinstance(subschema, dict):
            yield from Draft202012Validator.VALIDATORS['items'](validator, subschema, instance, schema)
            return
        if not validator.is_type(instance, 'array'):
            return
        for index in range(len(schema.get('prefixItems', [])), len(instance)):
            yield from child_errors(validator, instance[index], subschema, index)

    cls = extend(Draft202012Validator, {'properties': properties, 'items': items})
    result = cls({'$schema': contracts.schema()['$schema'], '$defs': linked, 'description': 'Prepared contract validators'},
                 format_checker=FormatChecker())
    children.update((id(node), result.evolve(schema=node)) for node in nodes)
    return result


def build(definition):
    root = root_validator()
    assert root is not None and definition is not None
    return root.evolve(schema=contracts._linked_definitions().get(definition, {'$ref': '#/$defs/' + definition}))
