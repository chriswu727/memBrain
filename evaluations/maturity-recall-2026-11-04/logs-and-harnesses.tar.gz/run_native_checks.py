import json,os,subprocess,sys
from pathlib import Path
from membrain import embedded_database
from membrain.local_profile import load_profile

root=Path('/Users/yichen/tmp/membrain-performance-followup-20261103')
profile=load_profile(Path('/Users/yichen/tmp/membrain-neural-evidence-20261103/map-1b2ef2a/installation'))
environment={key:value for key,value in os.environ.items() if not key.startswith(('MEMORY_','MEMBRAIN_')) and not key.endswith(('_API_KEY','_API_TOKEN'))}
environment.update(MEMORY_DATABASE_URL=profile.database_url,MEMORY_MIGRATION_DATABASE_URL=profile.migration_database_url,
                   MEMORY_DATABASE_APP_PASSWORD=profile.app_password,MEMBRAIN_SEMANTIC='0',PYTHON_DOTENV_DISABLED='1',
                   MEMBRAIN_REQUIRE_BROWSER='1')
if sys.argv[1] == 'full':
    environment.update(MEMBRAIN_TEST_EMBEDDING_MODEL='/Users/yichen/tmp/membrain-neural-evidence-20261103/model-activation-mac/home/Library/Application Support/memBrain',
                       MEMORY_CHAT_E2E_PYTHON=str(Path.cwd()/'.venv/bin/python'))
embedded_database.start(profile)
try:
    from membrain.cli import bootstrap
    bootstrap(profile.settings(), app_password=[fixture-secret-redacted]
    result=subprocess.run([sys.executable,'-m','pytest','-q','-rs',*sys.argv[2:]],env=environment)
finally:
    embedded_database.stop(profile)
raise SystemExit(result.returncode)
