import hashlib
import io
import json
import re
import tarfile
from pathlib import Path
from urllib.parse import quote

root = Path('/Users/yichen/tmp/membrain-goal-polish-20261104')
output = Path('/Users/yichen/tmp/membrain-review-20261029/evaluations/maturity-owned-recall-2026-11-04')
output.mkdir(exist_ok=True)
secrets = set()
profiles = list(root.rglob('profile.json'))
profiles.append(Path('/Users/yichen/tmp/membrain-neural-evidence-20261103/map-1b2ef2a/installation/profile.json'))
for path in profiles:
    data = json.loads(path.read_text())
    for key in ('api_key', 'app_password', 'postgres_password', 'admin_password'):
        value = data.get(key)
        if isinstance(value, str) and len(value) >= 8:
            secrets.update((value, quote(value, safe='')))


def redact(data):
    text = data.decode()
    for value in sorted(secrets, key=len, reverse=True):
        text = text.replace(value, '[fixture credential removed]')
    text = re.sub(r'(postgres(?:ql)?://[^:/\s\x22\x27]+:)[^@/\s\x22\x27]+(@)', r'\1[fixture credential removed]\2', text)
    assert not any(value in text for value in secrets)
    return text.encode()


sources = {
    'recall-canonical.json': root / 'canonical-37fab44.json',
    'runtime-abba.json': root / 'owned-document-http-abba.json',
    'visual-poll-first-failed.json': root / 'visual-poll-recall-abba-first-failed.json',
    'install.json': root / 'install-final/results.json',
    'installed-package.json': root / 'installed-followup-smoke.json',
    'provenance.json': root / 'provenance.json',
    'stop-check.json': root / 'stop-check.json',
    'ci-status.json': root / 'ci-status.json',
    'recall-command.json': root / 'canonical-command.json',
}
for name, path in sources.items():
    (output / name).write_bytes(redact(path.read_bytes()))

logs = {path.name: path for path in root.iterdir() if path.suffix in {'.py', '.log', '.txt'}}
with tarfile.open(output / 'logs-and-harnesses.tar.gz', 'w:gz') as archive:
    for name, path in sorted(logs.items()):
        data = redact(path.read_bytes())
        entry = tarfile.TarInfo(name)
        entry.size, entry.mode = len(data), 0o644
        archive.addfile(entry, io.BytesIO(data))

proof = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(output.iterdir())
         if path.is_file() and path.name != 'sha256.json'}
(output / 'sha256.json').write_text(json.dumps(proof, indent=2) + '\n')
assert all(hashlib.sha256((output / name).read_bytes()).hexdigest() == digest for name, digest in proof.items())
print(json.dumps({'artifacts': len(proof), 'archived_logs_and_harnesses': len(logs), 'hashes_verified': True}))
