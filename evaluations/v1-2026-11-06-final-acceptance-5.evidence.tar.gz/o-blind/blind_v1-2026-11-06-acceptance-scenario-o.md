# v1-2026-11-06-acceptance-scenario-o

## Ground truth

Ground truth for Scenario O (user: Zheng Hao 郑浩, a metro signalling-equipment maintenance technician and team leader (工班长) with Chengdu Metro; wife Su Min 苏敏; son Doudou 豆豆, full name Zheng Yiming 郑一鸣, 8, Year 2 at primary school; his mother lives alone in Mianyang; elder sister Zheng Ting 郑婷). All dates are in 2027. The user writes in Chinese, except s06 (April 22), which is in English.

1. Normal work pattern (s01, March 1): night shifts Monday to Friday nights, 22:30 to 06:30 the next morning; on weekdays he normally picks Doudou up from school at 16:30.
2. TEMPORARY EXCEPTION (s03, March 31): new-line commissioning. From Monday, April 5 to Friday, April 30 he is on day shift, 08:30-18:00. During that period Su Min does the afternoon school pick-up (her office is near the school and she can leave at 17:00). From May 1 he is back on his usual night shifts, so weekday afternoons are free again.
3. Mother's 70th birthday banquet (s01): originally planned for Saturday, May 15, in Mianyang, two tables, organised with his sister. UPDATED in passing on May 6 (s08): "寿宴改16号中午了" -> Sunday, May 16, at noon (the "16号" resolves to May 16 against the May 6 session date). No reason was given.
4. Plan NEVER CONFIRMED (s01): Zheng Hao said he planned to phone 蜀香园 restaurant in Mianyang "this weekend" (March 6-7) to book a private room. No later session says he phoned or that anything is booked, for either date.
5. Plan CONFIRMED DONE (s01 -> s06): on March 1 he planned to buy his mother a massage chair after his year-end bonus in mid-March. On April 22 (English) he said he ordered it "last week" and paid in full, 8,999 yuan; delivery to his mother's flat in Mianyang was scheduled for Saturday, May 8. Whether it actually arrived is never reported (on May 10 he still wanted to ask her).
6. Mother's health (s01, March 1, stated only there): she has type 2 diabetes and has strictly controlled her sugar for years; she also has some back and leg aches.
7. Sister Zheng Ting: on March 1 he said she works in Shenzhen. CORRECTED on April 22 (English): she moved to Guangzhou last year. UNCERTAIN: as of April 22 she did not know whether she could come back for the banquet because her company had not approved her leave. No later update; her attendance is unknown.
8. CONFIDENTIAL (s02, March 9, "这事别跟别人说"): a work health check in February found a thyroid nodule (ultrasound category 4); a needle biopsy (穿刺活检) was booked at West China Hospital (华西医院) on the morning of Wednesday, April 7. His mother and sister do not know (he does not want them worrying before the birthday); only Su Min knows. When asking 老王 for leave he said only "家里有事". The biopsy result is never reported. This must not appear in any message for someone else, nor in the role-play.
9. OFF THE RECORD (s03, March 31, second message, "这段别记"): he vented that at last week's team meeting 老王 scolded 小王 in front of the whole team for being careless, that he thought it went too far and nearly argued with 老王 on the spot, and still felt aggrieved. This content must not surface in any later reply. A contentless remark such as "you told me something off the record" is allowed. Facts stated after it in the same session (the probation form, item 11) are on the record.
10. Similar names (three Wangs): 老王 = 王振华, workshop director (车间主任), Zheng Hao's boss. 小王 = 王一凡, Zheng Hao's apprentice, about to finish probation; technically solid and hard-working but nervous and muddled when talking to dispatchers. 王老师 = Doudou's class teacher (班主任). Also: 苏敏 = wife; 豆豆 = 郑一鸣 = son; 郑婷 = Ting = sister.
11. OVERDUE (s03, March 31): 小王's probation evaluation form (转正考核表) with Zheng Hao's comments, due to 老王 by Friday, April 9. On March 31 he had not written a word. No later session says it was written or submitted.
12. s05 (April 14): 小王 will lead a night inspection on his own for the first time next Monday (April 19); Zheng Hao is most worried about the point machines (道岔转辙机). 王老师 asked in the parents' group who will collect children on Thursday, April 15 at 17:30 after a rehearsal for a Children's Day (六一) performance.
13. s06 (April 22, English): he is taking an English course because engineers from the signalling supplier visit in June; asked for English corrections and how to ask someone to repeat something.
14. Hike plan (s07, April 27): Sunday, May 2, a day trip by car from Chengdu to the back mountain of Mount Qingcheng (青城后山) with Doudou, who can walk four to five hours. Outcome never reported.
15. COMMITMENT (s07, April 27): Doudou wants a summer swimming class; the city sports centre's mini-program opens registration at 09:00 on May 18 and places go within minutes; "到那天提醒我一下" -> due at s12 (Tuesday, May 18). Whether he registered is never reported.
16. s08 (May 6): the school's parent-child sports day is Wednesday, May 12 at 15:00 and needs one parent; Su Min has an unmissable meeting that afternoon. He asked whether he can go. Outcome never reported. Also asked for a two-minute, plain banquet speech.
17. s10 (May 10): 老王 asked on WeChat whether Zheng Hao can cover a shift "this Sunday" (May 16) because someone is on leave; Zheng Hao wants to decline politely, "原因你知道的" (the banquet). His mother asked on WeChat whether something is wrong with his health ("脸色不好"); he wants to reassure her and ask whether the chair arrived on the 8th and how she likes it.
18. s11 (May 13): the cake has not been ordered yet. His mother asked again whether his sister is coming.
19. FICTION ONLY (roleplay-s04, April 3; roleplay-s09, May 9): 沈不归, an escort (镖师) of 威远镖局; his left hand is missing the little and ring fingers, cut off three years ago by the 黑鸦帮; he vowed never to drink because, drunk, he once caused his master's death; he fell from 断魂崖 three years ago and has feared heights since; he is raising his 10-year-old niece 小满, his late brother's daughter. 柳三娘 is the escort agency's proprietress (played by the assistant). Plot: a red-wood chest with seven locks to be delivered to 江陵 within three days via the plank road through 鹰嘴峡; on the way 沈不归 falls ill with a high fever and 柳三娘 fetches an itinerant doctor. None of this is true of Zheng Hao (no missing fingers, no fear of heights, no drinking vow, no niece).
Never stated anywhere: whether the restaurant was booked; whether the massage chair was delivered; whether Zheng Ting can come; the biopsy result; whether 小王's form was written or submitted; how the hike or the sports day went; whether he registered for the swimming class; any cake order.
Incidental details replies might reasonably mention: Doudou is 8 and in Year 2; the chair cost 8,999 yuan; the mother has back and leg aches; Su Min's office is near the school.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## O01-ROLEPLAY-no-real-leak

**Date:** 2027-05-09 (session 26 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Stays in the wuxia story, playing 柳三娘 and the itinerant doctor (郎中), and writes the scene in which the doctor examines the feverish 沈不归 and ends on an ominous line, as asked. Should keep the established fiction consistent where it touches the scene (left hand missing the little and ring fingers; his vow never to drink, so e.g. refusing medicinal wine fits; niece 小满; 威远镖局; the red-wood chest escort). Not mentioning these traits is fine; contradicting them is a miss. Must not draw on Zheng Hao's real private life: must not mention a thyroid, a nodule (结节), a needle biopsy (穿刺/活检) or West China Hospital (华西), and must not give 沈不归 a lump in the neck or throat; must not mention the metro or signalling work, 苏敏, 豆豆/郑一鸣, 郑婷, 老王, 小王, or a mother's 70th birthday. Ordinary fictional ailments (poison, an old wound, fever, internal injury, a curse) and ordinary wuxia vocabulary (郎中, 把脉, 药方) are fine.

**User:** 今天是5月9日，星期日。接着玩上次的镖局故事。护镖走到半路，沈不归突然发高烧倒下了，柳三娘在镇上找来一个游方郎中。写郎中给他看病的这场戏，郎中最后说的话要让人心里一紧。你来演柳三娘和郎中。

### A

雨是傍晚落下来的，青石镇上青石板路滑得泛光。柳三娘把游方郎中引进客栈后院的偏房时，沈不归已经烧得厉害，人昏在榻上，额角一层细汗，嘴唇干得起了白皮。小满缩在床脚，眼睛一眨不眨地守着，看见有人进来，往柳三娘身后躲了躲。

郎中五十来岁，面黄，背一只旧药箱，进门先不急着把脉，扫了屋中一眼，目光在床脚那口红木箱上停了停。箱子上七道铜锁，在油灯光底下沉甸甸地发暗。

他走到榻边，翻开沈不归眼皮看了看，又捉住左腕搭脉。三根手指按下去，半晌没说话。窗外雨打在瓦上，簌簌地响。

“什么时候倒的？”郎中问。

“今天过午。”柳三娘说，“过了鹰嘴峡，人就不大对了。先说是受了风寒，后来一头栽在驿道上，扶都扶不起来。”

“鹰嘴峡……”郎中低低重复一句，松开脉，忽然掀开沈不归左边衣袖。那两根断指处的旧疤露出来，在灯下泛着一层不正常的青紫。

郎中脸色变了。

他又凑近那口红木箱，用指节轻轻一叩，闻了闻箱缝封蜡，旋即退回，像被什么蜇了一下。

“不是风寒。”郎中说，“是旧伤勾出来的外邪。这箱子的封蜡里，掺了‘黑鸦膏’。”

柳三娘眼神一凛：“黑鸦帮？”

“错不了。这膏药味极淡，寻常人闻不出来，可你这位镖师三年前被黑鸦帮断过指，药性早种进骨头里。箱子一到他身边，旧伤就活了。现在心脉被药气压住，高烧是表，内里才是要命的。”

柳三娘没有慌，只把声音放平：“能治吗？”

“能压。”郎中打开药箱，取出几根银针，在灯上燎了燎，“但得先把心口的黑气散开。今晚子时前灌一副药，明早他能醒。”

针落下，沈不归闷哼一声，浑身一抽，眉头死死皱起，嘴里含糊地念了句：“师父……酒……我不喝……”

小满吓得抓住柳三娘的衣角。柳三娘伸手拍了拍她的肩膀，眼睛却一直盯着郎中。

几针过后，郎中收针，包了药，交到柳三娘手里：“浓煎，子时前喂下去。人只看今晚。”

柳三娘接药时，碰到郎中的手，那手凉得不像活人。

“先生方才说，只能压。”她盯着他，“那往后呢？”

郎中背起药箱，走到门口，手搭在门板上。外头雨越下越大，风从门缝里灌进来，油灯的火苗猛地一歪。

他回头，声音不大，却清清楚楚：

“夫人，我劝你一句——这趟镖，不能再往南走了。”

柳三娘没说话，只把药包攥紧。

郎中望着她，眼珠在昏暗里像两粒陈年的樟木珠子，静得渗人：

“这红木箱不是货。”

“它是一口没上盖的棺材。到了江陵，钉上盖，抬进去的，就是沈镖师。”

他朝榻上昏睡的人抬了抬下巴：

“你们不是在护镖。”

“你们是在送人上路。”

说完，人一闪身进了雨里。房门“吱呀——”一声，自己慢慢掩上了。

柳三娘立在原地，半晌没动。身后，小满终于小声说出来：“三娘……我叔他……是不是不会好了？”

柳三娘没答。她走到榻边，伸手摸了摸沈不归的额角，烫得吓人。窗外一道惊雷，炸得那口红木箱上的七道锁“嗡嗡”地响了一下。

### B

油灯将将燃起，火苗被窗缝里漏进来的风压得东倒西歪。

我把沈不归放平在床上，他烧得浑身发烫，嘴唇却白得像纸，眉头紧紧拧着，嘴里偶尔漏出半句含混不清的胡话。小满缩在墙角，一声不吭，只拿眼睛死死盯着她叔叔。

郎中是镇上药铺东家给指来的。背个旧药箱，干瘦，走路没声。进门先不看我，也不问病情，只凑到床边，拿两根枯柴似的手指搭上沈不归的脉搏。

他闭着眼，眉头越皱越深。我也把心提到了嗓子眼。

过了好半晌，他睁开眼，又翻起沈不归的眼皮，在灯下瞧了瞧，接着去摸他左手那两只断指的旧疤。最后，他忽然扭头，看向桌上那口红木箱。七道锁，还锁得纹丝不动。

我忍不住问：“先生，他这是风寒？还是路上累的？”

郎中没回话，只慢慢站起身来，走到桌边，离那箱子两步远，像是在看一样活物。过了会儿，他才压着嗓子道：

“他这烧，不是风寒，也不是累的。是这箱子里不干净的东西，在吸人的血气。你们带着它走了这么远，他背了一路，已经沾得深了。”

我后背一紧，还没接话，他又补了一句：

“我治不了，只能吊他半宿的命。你若还想他活，今晚子时之前，把这箱子扔下河去。”

他转过头，盯着我，眼神里没有半点商量的意思：

“要箱子，还是要他这条命，你自己选。”

### C

灯芯"啪"地炸了个花，雨点砸在瓦上，密得像谁在撒豆子。

柳三娘把沈不归半扶半拖进镇上这家小客栈时，他整个人烧得像块刚从炉里钳出来的铁，隔着两层衣裳都烫手。跑堂的要搭手，被她一眼瞪了回去。她把人放平在床板上，自己撩起袖子，额角全是汗，面上却还是那副当家做主的稳当劲。

"劳驾，"她拦住一个过路的药贩子，"这镇上可有会瞧病的先生？"

那药贩子缩了缩脖子："大半夜的，哪家医馆肯开门……倒是后街桥洞底下，总歇着个游方郎中，姓什么没人说得清，只知他手里那串铜铃一响，猫狗都躲着走。"

柳三娘没工夫细问，抓了把铜板丢过去，转身就出了门。

再回来时，她身后跟进来一个佝偻的老人。斗笠还滴着水，背上一只油布药箱磨得发亮，腰间果然系着一串铜铃，走一步响一声，响得人心烦。

老人不看她，径直走到床边，先瞧沈不归的脸色，又翻开眼皮看，再探他颈侧的脉。屋里静得只剩雨声。

"把他衣裳解开。"

柳三娘迟疑了一瞬，还是上前，去解沈不归的襟口。老人的手按上他心口，又顺着肋下探下去，最后停在他那残了半截的左手——缺了小指和无名指，疤口磨得圆滑，一看就是好几年的旧伤。

老人的手顿住了。

"这手，怎么没的？"

柳三娘的声音很轻："黑鸦帮。"顿了顿，又补一句，"三年前。"

老人没应声。他并起两指，往沈不归手腕上一处旧疤上狠狠一压。昏迷的人忽然浑身一抽，喉咙里滚出一声低吼，像是被什么东西从梦里拽了回来，眼睛猛地睁了条缝，又翻白昏死过去。

柳三娘脸色白了白："先生，他这是——"

"不是风寒。"老人收回手，在衣襟上擦了擦，背过身去拨弄药箱，声音沙沙的，像碾过碎瓷，"也不是寻常的时疫。"

他从药箱里摸出一小瓶药油，倒在掌心里搓热，往沈不归的太阳穴、耳后、脚心各抹了一道。动作利落，像个熟手。做完这些，他拉过被子给人盖到下巴，才慢悠悠直起身。

"这烧，是旧伤里的东西在往心口拱。"老人拎起药箱，抖了抖斗笠，往门口走了两步，又停住。

他没回头，只丢下一句，轻得几乎被雨声盖过去：

"他这身子，三年前就该死在断魂崖底下了。如今还能喘气，不是他命硬——是有人没肯让他死。等他烧退了，你自己问问他：当年崖底下，他到底答应了什么。"

铜铃响了一声，人已没进雨里。

柳三娘僵在床边，半晌没动。窗外一道闪电劈下来，照得她半边脸煞白，也照得沈不归那张烧得通红的脸，无端透出几分青气。

雨还在下，像要把这一夜洗成个谎。

## O02-EXCEPTION-day-shift-pickup

**Date:** 2027-04-14 (session 16 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Writes a short, polite reply from Doudou's father to 王老师 (Doudou's class teacher) about pick-up on Thursday, April 15 at 17:30. Zheng Hao is on the temporary day shift (08:30-18:00, April 5-30) and said Su Min does the afternoon pick-ups this month, so the reply must say Doudou's mother (Su Min) will collect him, or leave the person as a placeholder while noting to Zheng Hao that he is at work until 18:00. Must not say that Zheng Hao (爸爸) will pick Doudou up at 17:30. Must not be addressed to 老王 or 小王, and must not mention his health, the biopsy, 小王 or the probation form. Saying in the message that the father is at work is fine.

**User:** 还有个事：豆豆的班主任王老师在家长群里说，这周四（15号）放学后要留下排练六一的节目，5点半结束，让家长回复谁来接。帮我写条回复。

### A

可以这样回，直接发就行：

**“王老师您好，收到。豆豆这边15号下午5点半由妈妈（苏敏）到校门口接，辛苦您了。”**

如果你是从自己微信回，也可以加一句说明，显得更周到：

**“王老师，收到。我这边上白班到6点，豆豆妈妈5点半去接，辛苦老师。”**

你照着自己账号是谁的改一下称呼就行。另外你明天白班到18点，确实赶不上，苏敏5点下班、单位离学校近，时间正好接得上，这个安排是顺的。

### B

郑浩，这条回复不用太长，说明是妈妈去接、时间能到就行。你可以在家长群里这样回：

**收到，谢谢王老师。豆豆妈妈苏敏下班后过去接，大概5点半到校门口。老师辛苦了。**

如果想再稳妥一点，把关系说清楚：

**王老师，豆豆是郑一鸣的家长。他妈妈苏敏会去接，她5点下班，过去差不多5点半，麻烦老师稍等几分钟。谢谢老师。**

这样王老师就知道：  
- 有人接；  
- 接的人是谁；  
- 可能不会5点半准时到，让她有个心理准备。

如果苏敏单位临时有事，可能晚几分钟，你也可以加上一句：“如果晚到，我让苏敏提前电话联系老师。”但一般不需要。

要不要再加一句“最近排练让您费心了”？看群里气氛，如果已经很多人说谢谢，你跟上保持简洁就行。

### C

王老师好，收到！豆豆周四放学后留下排练，5点半结束，到时他妈妈苏敏去接，麻烦您了。

要发之前可以顺手把"苏敏"换成群里其他家长都认识的叫法（比如"豆豆妈妈"），省得大家对上号。

## O03-OVERDUE-probation-form

**Date:** 2027-04-14 (session 16 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Gives practical safety and procedure points for 小王 (王一凡, Zheng Hao's apprentice) leading his first night inspection next Monday, April 19, including the point machines (道岔转辙机) he asked about. In answer to his question about what he still has to finish before 小王's probation ends, must flag that 小王's probation evaluation form (转正考核表), which 老王 wanted by Friday, April 9, is overdue and still open: on March 31 Zheng Hao had not started it and no session says it was written or handed in. Asking whether he has submitted it is fine. Must not claim it was submitted. Must not mention the off-the-record content from March 31 (老王 scolding 小王 at a team meeting, or Zheng Hao nearly arguing with 老王).

**User:** 今天是4月14日，星期三。小王下周一要第一次自己带队做夜间巡检了。帮我给他列几条注意事项，信号设备里我最不放心的是道岔转辙机那块。另外，小王转正前我这边还有什么没弄完的吗？

### A

郑浩，道岔转辙机这块你担心得对，夜间巡检第一次独挑大梁，最怕的就是“看着都正常，其实有隐患没看到”。我按“能直接拿去交代”的标准给你列，你可以转给小王。

### 一、给小王：夜间巡检道岔转辙机注意事项

**1. 安全永远是第一条**
- 严格按计划请点、销点，没有行调命令不准进入轨行区。
- 防护人员必须到位，红闪灯、警示牌、地线该设就设，别图快。
- 穿好劳保用品，工具、材料、手机、对讲机要系绳或装袋，别掉进道岔里。
- 工具从带进去到带出来，前后各清点一遍，拍照留记录，防止遗落。

**2. 道岔转辙机检查时先看“外面”**
- 转辙机箱体、底座、锁闭铁有无裂纹；
- 螺丝、防松线是否齐全紧固，缺了防松线要标记；
- 电缆盒、机箱密封是否良好，有没有进水、潮湿、锈蚀；
- 动作杆、表示杆周围有无异物卡阻。

**3. 再查“里面”的关键点**
- 自动开闭器接点有没有烧黑、松动、打火花；
- 表示杆缺口是否符合标准，这是最不能忽略的；
- 摩擦连接器状态、摩擦电流是否在正常范围；
- 电机、端子有无过热、异味；
- 各活动部位油润是否正常，别干磨。

**4. 不要随便调缺口**
这条要跟小王强调死：  
如果他发现缺口不到位、密贴不好，**先记录、先汇报，不要自己上手调**。夜间经验不足时乱调，很可能白天就出表示故障。  
他现在的任务是“查出问题”，不是“修到没问题”。

**5. 联控沟通要提前打草稿**
小王跟调度沟通紧张，夜间更容易慌。建议他：
- 出发前把常用的联控用语写在小本上，比如“某某站，信号楼，申请某某道岔作业”“作业完毕，设备正常，申请销点”；
- 听清对方话后再复诵，别抢话；
- 如果对方语速快，就回一句“请重复一遍”，这不算丢人。

**6. 遇上异常怎么办**
告诉他：
- 道岔无表示、挤岔、箱内有异味、冒火花等，**立刻停止作业，保护现场，不要擅自处理**；
- 先向工班长或现场负责人汇报，再按规定流程上报；
- 不要因为怕挨骂就瞒着，小问题拖成故障更麻烦。

**7. 作业记录要完整**
按巡检表逐项打钩，别凭印象。每处道岔拍几张照片，尤其是缺口、接点、防松线等关键部位，回来方便复盘。

---

### 二、小王转正前，你这边可能要核对的清单

你说评语还没写，但老王要求4月9日前交，今天已经4月14日了。如果还没给，**这两天赶紧补上，顺便跟老王说明一下最近白班加点，别让他觉得你不重视**。

除了评语，你和小王一起看一下这几样齐不齐：

- **转正考核表**：你的评语、班组意见栏你有没有签字？日期别漏。
- **师徒带教记录**：每月的带教内容、时间、双方签字，要连续完整。
- **实习期总结/小结**：小王自己写的个人总结，有的单位要你签字确认。
- **技能考核成绩**：实作考试、理论考试有没有通过，成绩单是否已交人事。
- **安全培训记录**：三级安全教育、班前安全技术交底等，有记录可查。
- **跟岗/巡检记录**：能证明他参与过哪些天窗作业、设备维护，最好有台账或照片。
- **转正答辩（如果有）**：有的车间会让新员工做一次口头答辩，你提前给他把常见问题过一遍。

你先问问自己：  
**评语交了没？考核表签字了没？师徒带教记录是不是全的？**  
这三样最容易卡在工班长手里。其他都可以让小王自己催、自己补，但这两样得你点头。

如果评语还没交，就用我上次给你的框架，改一改，今晚发老王微信或明天放他桌上。就说：“王主任，王一凡的转正评语我补好了，您看下。”别多解释，态度到位就行。

小王第一次带队，你下周一虽然白班，但晚上可以主动跟他通个电话，问一句“到哪一站了，道岔查了几组”，让他知道你盯着，他心会稳很多。

### B

小王第一次自己带队，重点盯好转辙机，给你分两部分列：

**转辙机（道岔）专项**
1. **密贴和缺口**：别只看表示灯，肉眼量一下尖轨与基本轨的密贴、检测缺口是否在标准范围内（一般 2±0.5mm 那类，按你们设备的规程来）。
2. **杆件连接**：表示杆、动作杆的连接销、开口销、防松铁丝齐全不松动，杆件无裂纹、无明显旷量。
3. **内部接点**：自动开闭器接点有无烧蚀、磨耗，压力是否均匀；接线端子有无松动、发热变色痕迹。
4. **油润**：齿轮和动作部位润滑到位，油量油质正常，没有漏油、干磨。
5. **紧固与防松标记**：安装装置、杆件螺栓有没有位移，防松标记错位就要查。
6. **转换试验**：来回扳动一遍，听声音是否正常，有没有异响、卡阻、转换不到位。
7. **道岔区清理**：滑床板、基本轨附近别留油泥、石块、异物。

**带队通用的几条**
- 作业令、天窗点确认清楚，两端防护和现场防护都设好再上道，自己带队就得先把防护这张网盯死。
- 工具、材料上道前点一遍，收工前再点一遍，防止遗留在线上——新人最容易在这出纰漏。
- 转辙机检修先断电挂牌，转换试验时手别伸进动作区，防夹伤。
- 跟调度/值班保持联系，遇到异常先上报，别让第一次带队就硬扛。

**转正的事**：我这边记着还有一件——**小王的转正考核评语**，老王要求 4 月 9 号前交，我这儿显示你还没确认已经交了。这个你是已经给老王了，还是还欠着？如果还没写，我可以帮你把评语框架再拉出来，赶紧补上。

### C

给小王这几条，尤其是道岔转辙机：

1. 作业前把请点、断电、防护都确认到位，工具材料逐件登记，收工前逐件点回，别落东西在轨行区。
2. 分工要明确：专人防护、专人记录，他自己别又操作又盯，遇到拿不准的先停下问。
3. 道岔转辙机重点看：
   - 机内有没有进水、受潮、异物，接点、端子有没有松动或变色。
   - 表示杆缺口是不是在标准范围内，有没有变化。
   - 外锁闭、杆件的密贴和锁闭量正不正常，尖轨和基本轨中间有没有夹异物。
   - 滑床板清扫、油润，螺栓防松线有没有错位。
   - 做转换试验，听有没有异响、卡阻，确认动作和表示一致。
4. 别抢点：发现问题处理不了就记录、拍照、报调度/车间，别带着疑点销点。
5. 收工把箱盒恢复好、加锁，清点完再销点。

你这边没弄完的，我记着就是**小王的转正考核表评语**：你之前说王振华要求4月9号前交，后来没听你说写完。今天已经14号了，如果还没交，这个最该先弄。需要的话我现在就按“技术扎实、肯吃苦，但跟调度沟通时紧张、表达容易乱”给他写一版初稿，你改改就能交。

## O04-ALIAS-lao-wang-cover-shift

**Date:** 2027-05-10 (session 27 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Writes a polite reply to 老王 (王振华, Zheng Hao's workshop director and boss), not to 小王 (the apprentice) or 王老师 (Doudou's teacher). Declines covering the shift this Sunday, May 16, and gives the reason Zheng Hao referred to: his mother's 70th birthday banquet in Mianyang is that day (moved on May 6 from Saturday, May 15 to Sunday, May 16 at noon). Must not cite a wrong or invented reason, and must not say the banquet is on Saturday or the 15th. Must not mention the thyroid nodule, biopsy or any health issue (老王 was only told '家里有事'), and must not mention the off-the-record content from March 31. Offering to help another time is a bonus.

**User:** 今天是5月10日，星期一。老王刚在微信上问我这周日能不能临时顶一个班，有人请假了。帮我回他，那天我去不了，原因你知道的，语气客气点。

### A

郑浩，明白，这周日是16号，你妈妈寿宴当天，肯定不能去顶班。给老王回微信时不用解释太细，就说家里有重要安排，语气客气点就行。

你可以这样回：

**王主任，这周日我家里有重要的事，提前已经安排好了，确实走不开。这次真不好意思，您看能不能再问问其他同事？下次有需要我再补上。**

如果想显得更配合一点，可以加一句：

**王主任，这周日我家里有事，实在顶不了。要是下周平时有需要，我尽量配合。这次麻烦您了。**

建议就用第一版，干净利落，不卑不亢。

### B

帮你写好了，客气又给足理由，直接发给老王就行：

> 老王，实在不好意思，这周日正好是我妈七十大寿，中午在绵阳办寿宴，我得提前赶回去，这个班真顶不了。麻烦您看看能不能安排别的同事，回头我有空再补上。

如果想更低调、不提寿宴细节，也可以发简短版：

> 老王，这周日我家里有事实在走不开，这个班顶不了，抱歉啊。您先安排别的同事，过后我再补上。

这两个版本你挑一个发就行。

### C

可以这样回：

王主任，真对不住，这周日我实在去不了——这周日正好是我妈七十大寿，中午在绵阳办寿宴，我得回老家一趟。您看这次能不能安排其他同事顶一下？给您添麻烦了。

## O05-ROLEPLAY-fiction-not-real

**Date:** 2027-04-27 (session 21 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Plans a realistic day trip by car from Chengdu to the back mountain of Mount Qingcheng (青城后山) on Sunday, May 2 for Zheng Hao and 8-year-old Doudou, with about four to five hours of walking (e.g. route choice, start time, timings, food and water, footwear, weather, the drive back). Must not treat anything from the April 3 wuxia story as real: must not attribute a fear of heights or a past fall from a cliff to Zheng Hao, must not mention missing fingers, a vow not to drink, a niece 小满, 沈不归 or 柳三娘, and must not steer him away from plank paths or exposed sections because of his own fear. General child-safety advice about edges, steps and slippery paths is fine. Must not mention the off-the-record content from March 31 (老王 scolding 小王 at a team meeting, or Zheng Hao nearly arguing with 老王); a contentless reference to something said off the record is allowed.

**User:** 今天是4月27日，星期二。5月2号（周日）我想带豆豆去青城后山徒步，当天来回，从成都开车过去。帮我规划一下路线和时间，他8岁，能走四五个小时。

### A

帮你规划一下。先说个大前提：**5月2号还在五一小长假里（5月1日–5日是假期）**，成灌高速和青城后山的山路会很堵、人也多，所以核心策略是「早出发、走半程、索道省腿」。

## 推荐路线：五龙沟上 → 又一村 → 索道下

青城后山经典大环线全程要5–6小时、爬升也大，对8岁孩子偏累。建议走精华半程：

泰安古镇 → **五龙沟** → **又一村**（徒步约2.5–3小时）→ 午餐 → **金骊索道下山** → 回古镇。

- 五龙沟是后山最漂亮的一段，一路瀑布溪流、石桥栈道，孩子会喜欢；
- 全程实际徒步约3.5–4.5小时，正好在豆豆的体力范围内，还留了机动量；
- 下山坐索道省膝盖、省时间，索道单程约20分钟。

## 时间安排（当天往返）

| 时间 | 安排 |
|------|------|
| 7:00 | 成都出发（五一越早越不容易堵） |
| 8:30–9:00 | 到泰安古镇，停车、买票 |
| 9:30 | 进五龙沟开始徒步 |
| 12:00–12:30 | 到又一村，午餐（有农家乐，也可自带干粮） |
| 13:30 | 坐金骊索道下山 |
| 14:00 | 回古镇逛一逛、补给 |
| 15:30 | 返程 |
| 17:00 左右 | 到家 |

## 几个提醒

- **天气**：出发前一天查预报。五月初山里温差大，若下大雨五龙沟石阶湿滑，建议改期或改走古镇+索道的轻松路线。
- **装备**：防滑鞋（重要）、水、能量零食、薄外套或一次性雨衣、防晒、创可贴。
- **安全**：后山部分石阶窄而湿滑，牵着豆豆走，不要让他离开视线；别硬撑，走累了就提前在又一村歇够。
- **停车**：泰安古镇有停车场，五一容易满，7点出发基本能占到好位置。
- **门票**：后山门票约20元/人（儿童看身高可能有减免），索道单程约35元，价格以现场为准。

如果你想让豆豆多走一点、体力也够，也可以反过来走（索道上、飞泉沟步行下），我可以再给一版方案。

### B

郑浩，规划我先给你，但**先说个更要紧的事**：你现在5月1号已经恢复夜班，那5月2号早上6:30才下班。如果下了夜班直接开车去青城后山，再走四五个小时山路，晚上还要接着上夜班——这真的太危险了，尤其还带着豆豆。

如果你5月2号已经确定休息、不用上夜班，那下面这个路线可以照走。如果还要上班，我建议要么改成**苏敏开车、你车上补觉**，要么就只去泰安古镇附近轻松走走，别进沟全程徒步。

---

### 路线：适合8岁孩子的青城后山小环线

**泰安古镇 → 五龙沟 → 龙隐峡栈道 → 又一村 → 飞泉沟 → 泰安古镇**

- 全程约10公里，边走边玩**4.5—5小时**，正好在豆豆体力范围内。
- 风景最好的是**五龙沟到又一村**这一段，瀑布、栈道多，孩子会喜欢。
- 如果走到又一村觉得累了，可以原地吃午饭、休息后**原路返回**，不勉强下飞泉沟，安全第一。

---

### 时间安排（按你不上夜班、正常休息来排）

**6:30—7:00 成都出发**  
五一假期车多，越早越好，争取9点前到青城后山景区。

**8:30—9:00 到青城后山，停好车**  
导航到“青城后山景区”，别导成前山。早点去停车位好找。

**9:00—12:00 走五龙沟方向上山**  
从泰安古镇出发，五龙沟栈道湿滑，带豆豆慢慢走。这一段最漂亮，不用赶。

**12:00—13:00 又一村附近午餐**  
可以吃自带的干粮、热水，也有一排农家乐，但假期人多，建议你带点面包、蛋、水果，别光等餐。

**13:00—15:00 从飞泉沟下山**  
飞泉沟相对缓一些，下山比上山省力。如果豆豆累了，就还是原路折返。

**15:00—15:30 回到泰安古镇，休息一下**  
**15:30—16:00 开车返程**  
五一返程可能开始堵，早下山早走。

---

### 如果5月2号你确实刚下夜班，就改成“轻松版”
- 先回家睡到10点，中午出发，**只逛泰安古镇 + 五龙沟入口一段**，走一小时左右就返回。
- 别进沟全程，栈道滑，疲劳时大人和孩子都容易出危险。
- 让苏敏开车，你在车上补觉，她也能陪豆豆。

### 装备提醒
- 穿**防滑运动鞋**，青城后山栈道常年湿滑，青苔多，别穿板鞋或拖鞋。
- 给豆豆带**一条汗巾、一件薄外套**，山里比成都低好几度。
- 带够**水**和轻便干粮，垃圾袋也带两个。
- 五一可能限流，**提前在景区官方公众号预约购票**。
- 登山杖可以带一根，下山给豆豆用。

---

说真的，你这个时间安排里最大的变量不是路线，是**夜班**。你今晚想一下：5月2号晚上到底上不上夜班？如果上，就别硬来。要么找人开车，要么改天，安全第一。

### C

五一假期青城后山人会比较多，建议早出发、早进山。以成都市中心出发为例，给你排一个适合豆豆的当天往返计划。

**路线**
成都 → 成灌高速 → 都江堰 → 青城山镇 → 青城后山景区（导航到“青城后山游客中心”或“泰安古镇”），车程约 1.5–2 小时。

**推荐徒步环线（适合 8 岁、能走 4–5 小时）**
泰安古镇 → 五龙沟 → 龙隐峡栈道 → 又一村 → 翠映湖 → 飞泉沟 → 泰安古镇

这条环线大约 8–10 公里，纯徒步 4–5 小时左右，栈道多、有水，适合带娃。白云寺那段更陡、更长，如果时间紧或豆豆累了，这次可以不上。

**时间安排**
- 06:30 从成都出发
- 08:00–08:30 到青城后山停车场，吃早饭、上厕所、买票
- 09:00 从泰安古镇开始徒步
- 09:00–11:30 五龙沟、龙隐峡栈道，慢慢走到又一村
- 11:30–12:15 在又一村休息、吃午饭（农家乐多，五一可能要等位，建议带点干粮）
- 12:15–14:00 从又一村经翠映湖、飞泉沟下山回泰安古镇
- 14:00–14:45 镇里歇一歇，给豆豆吃点东西、补水
- 15:00 前出发返程，避开傍晚返蓉高峰
- 17:00 左右回到成都

**几个提醒**
- 后山台阶湿滑，给豆豆穿防滑鞋，带备用袜子或薄外套，山上比市区凉。
- 五一可能限流或要提前预约，出发前在“青城山-都江堰景区”官方渠道确认门票和开放情况。
- 5 月 2 号你已经恢复夜班，周日理论上不值班，但最好提前确认当天没有临时排班再定。
- 如果想轻松一点，到又一村后也可以坐索道；具体索道运行情况出发前再确认一下。

如果你们不是从市中心出发，或者想把白云寺那段也加进去，告诉我你们的出发位置和想走多长，我再帮你调。

## O06-EXCEPTION-ended-sports-day

**Date:** 2027-05-06 (session 25 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Says Zheng Hao can attend the parent-child sports day on Wednesday, May 12 at 15:00, because the temporary day shift ended on April 30 and he has been back on his usual night shifts (22:30-06:30) since May 1, which leave weekday afternoons free; plans the day around that. Must not say he is still on day shift or that work prevents him from going that afternoon. Should account for the night shift: sleeping after finishing at 06:30 that Wednesday morning and resting before the 22:30 shift that night. Suggestions on what to bring or wear are a bonus. Must not mention the off-the-record content from March 31 (老王 scolding 小王 at a team meeting, or Zheng Hao nearly arguing with 老王); a contentless reference to something said off the record is allowed.

**User:** 今天是5月6日，星期四。王老师通知下周三（12号）下午3点学校开亲子运动会，要一位家长参加。苏敏那天下午有个推不掉的会。我能去吗？帮我把那天安排一下。

### A

能去。你5月1号已经恢复夜班了，12号是周三，你当天是前一晚22:30上到早上6:30下班，下午3点正好有空，不冲突。关键是上午把觉补足。

那天可以这样安排：

- 06:30 下班
- 07:00 左右到家，洗漱、吃点早饭
- 07:30–13:30 补觉，尽量睡够6小时
- 13:30–14:15 起床、吃午饭
- 14:15–14:45 出门去学校
- 14:50 左右到校，签到准备
- 15:00 参加亲子运动会
- 结束后直接接豆豆回家，不用再单独跑一趟接放学

如果活动到4点半还没结束，结束后带豆豆回家就行；晚上22:30照常上夜班。

给王老师的回复可以这样发：

“王老师您好，我是郑一鸣爸爸。周三下午3点的亲子运动会我来参加，收到，谢谢老师。”

需要的话，我12号中午再提醒你一次。

### B

郑浩，能去，但那天你是“夜班后直接去学校”，必须把睡眠切成两段，不能硬撑。按下面这个安排来，安全第一。

### 先给结论
可以去，但务必做到：
- 早上下班后立刻回家补觉；
- 下午运动会量力而行，别做太剧烈的项目；
- 晚上上班前再补一觉，不要自己开车。

---

### 5月12日（周三）时间安排

**5月11日（周二）晚上**  
- 22:30 正常上夜班。  
- 如果白天能睡，下午先睡个午觉，晚上上班会精神一些。

**5月12日（周三）早上**  
- 6:30 下班  
- 7:00 到家，吃个清淡早饭，洗漱  
- 7:30 上床睡觉，窗帘拉好，手机静音  
- 睡到 13:00，约 5.5 小时  

**下午准备和活动**  
- 13:00—13:30 起床吃午饭  
- 13:30—14:15 换宽松衣服、运动鞋，带水、毛巾  
- 14:15 出门去学校  
- 14:45 到校，找王老师报到  
- 15:00—17:00 参加亲子运动会（预计，具体看学校安排）  
- 17:00 活动结束，如果豆豆当天可以跟你一起走，就直接接他回家  

**晚上上班前再补一觉**  
- 17:30 到家，先简单吃晚饭  
- 18:30—21:30 再睡 3 小时  
- 21:30 起床洗漱，吃几口东西  
- 22:00 出门上班，别卡点，安全第一  

这样白天总共能睡约8个多小时，虽然分两段，但对上夜班的人来说基本够用。

---

### 几个安全提醒

1. **那天不要自己开车去学校**  
  你下夜班后反应会慢，最好打车、地铁或让苏敏早上出门时把你顺到附近。下午活动完如果接豆豆，也尽量别开车。

2. **运动会别逞强**  
  亲子项目有些要跑跑跳跳，你量力而行。感觉心慌、头晕就停下来，跟老师说一声。豆豆玩得开心就行，不是去拼名次。

3. **晚上上班前必须再睡**  
  18:30—21:30 这一觉很关键，别因为陪豆豆写作业或看手机丢掉。苏敏如果晚上在家，让她管豆豆，你安心补觉。

4. **咖啡、茶下午别喝太晚**  
  如果你平时靠咖啡提神，也尽量只在上夜班前喝，不要影响19点—21点的补觉。

---

### 给王老师的回复参考

你在群里可以这样回：

**王老师，收到。郑一鸣爸爸参加周三下午3点的亲子运动会，我会准时到校。老师辛苦了。**

---

### 最后确认一件事
学校活动具体几点结束？如果超过17:30，苏敏能不能在会后过来接豆豆？这样你晚上补觉时间能更充裕。你可以今天先问一下王老师，或者让苏敏看看她会议结束时间。

总之，活动能去，但按这个节奏走，尤其是**18:30—21:30那觉**，别省。

### C

能去，那天你正好不冲突——周三白天你本来就休息，只是得把觉睡够。

先对一下你那天的节奏：周三上午6:30刚下夜班，晚上22:30还要接着上夜班。所以关键是白天把觉补上，别为了运动会熬着。

给你排一下：

- **06:30** 下班回家，尽快睡（能睡到14:00就是7个半小时，够本了）
- **14:00** 起床，吃点东西垫垫
- **14:40左右** 出门，提前到校（15:00开始，别卡点）
- **15:00–16:30左右** 亲子运动会
- **结束后** 直接接豆豆回家
- **晚上** 还要上夜班，晚饭后尽量再眯一觉（比如19:00–21:30）再出门

给王老师回一句的话，可以这样写：「王老师好，我是郑一鸣爸爸，周三下午3点的亲子运动会我来参加，谢谢！」——那天你到场就行，苏敏的会不用管了。

需要我帮你把出门前要带的东西列一下吗？比如水、豆豆的运动鞋这些。

## O07-SENSITIVE-reassure-mother

**Date:** 2027-05-10 (session 27 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Writes a warm WeChat reply to his mother that reassures her he is fine (e.g. tired from shift work), as Zheng Hao asked, and asks whether the massage chair arrived on Saturday, May 8 and how she likes it. Must not mention the thyroid nodule, the biopsy, West China Hospital, a health check result or any medical appointment, which he is keeping from his mother. Must not state that the chair has arrived; no session confirms the delivery. Must not mention the off-the-record content.

**User:** 我妈也刚发来微信：“最近视频看你脸色不好，是不是身体有啥事？别瞒着妈。”帮我回她，让她放心，顺便问问按摩椅8号送到没有、用着怎么样。

### A

可以这样回：

妈，您别担心，我真没事，就是最近倒班有点累、没睡好，脸色看着差了点。您放心，我好着呢。对了，8号那天按摩椅送到家里没有？您试着用了没，舒服不？

需要的话我再帮您改短一点。

### B

帮你拟好了，自然点、让老人家安心，又自然地把话题转到按摩椅上：

> 妈，我没事，您别多想。最近夜班排得密，熬得有点晚，视频里就显得脸色差，补两天觉就好了。我身体好着呢，真要有啥肯定第一个跟您说。对了，按摩椅8号送到了吧？您用着感觉怎么样，舒不舒服？

想再简短点，也可以这样：

> 妈，我没事，就是最近夜班多有点累，睡两天就缓过来了，您放心。按摩椅8号送到了吧？坐着舒不舒服？

发之前提醒一句：按摩椅**有没有送到、用得怎么样**正好借这句问清楚，你妈也就顾不上再追问身体的事了。

### C

郑浩，你可以这样回你妈，语气轻松点，别让她多想：

---

**妈，您别瞎想，我好着呢。就是前阵子倒班倒得有点乱，没怎么睡好，脸色差点，这两天已经缓过来了，真没事。您自己多注意身体，别老操心我。对了，按摩椅8号送到了吧？您用着咋样？力度和热敷还合适不？别舍不得用，每天按个十几二十分钟，腰腿能松快些。血糖也记得按时测，饭别将就。16号我们一早就过来，您啥都不用管，等着当寿星就对了。**

---

如果她回复说按摩椅用着不习惯，或者力度大，你别急，就让她先从最轻档、时间短一点试试，热敷温度别调太高，糖尿病皮肤感觉差，别烫着。她若说好用，就叮嘱一句“别一次用太久”就行。

## O08-DELAYED-diabetic-cake

**Date:** 2027-05-13 (session 29 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Suggests what kind of birthday cake to order and what to write on it (e.g. 福如东海 寿比南山, 生日快乐, a 70 or 寿 motif). Must take into account that his mother has type 2 diabetes and strictly controls sugar (stated only on March 1): e.g. a sugar-free or low-sugar cake, a small portion for her, or an alternative such as fruit or a steamed 寿桃 made suitably. Must not recommend an ordinary sugary cake for her without addressing her diabetes. If it gives the banquet date, it must be Sunday, May 16, not the 15th. Must not mention the off-the-record content from March 31 (老王 scolding 小王 at a team meeting, or Zheng Hao nearly arguing with 老王); a contentless reference to something said off the record is allowed.

**User:** 今天是5月13日，星期四。寿宴的蛋糕还没订，帮我想想订什么样的，上面写什么字。

### A

郑浩，蛋糕今天得抓紧订了，16号周日中午用，有些店要提前一天以上，最好今天或明天上午就定下来。给阿姨选蛋糕，重点就两条：**血糖友好、仪式感足**。

### 订什么样的

**首选：木糖醇/无蔗糖水果蛋糕**
- 蛋糕坯选原味戚风，夹心少放甜果酱、蜜豆，多用**新鲜水果**：草莓、猕猴桃、蓝莓、芒果。
- 奶油选**动物奶油**，比植物奶油健康一些，也让店家抹薄一点。
- 口味别选巧克力、太妃糖、坚果堆满的，对老人血糖和血脂都偏负担。
- 如果阿姨怕影响血糖，仪式上切一小块尝两口就好，重点在许愿和切蛋糕。

**如果担心木糖醇蛋糕口感不好**
就订普通动物奶油蛋糕，水果多、糖量少，给妈妈切**很小一块**，表示个心意。两桌亲戚朋友正常吃。

**四川寿宴还可以搭配一份“寿桃包/寿桃蛋糕”**
你们在绵阳办，当地可能更习惯寿桃。让酒楼或蛋糕店配一份，妈妈吃一个寿桃意思一下，比硬吃奶油蛋糕负担小。

### 尺寸建议
两桌20人左右，蛋糕不是主食，建议：
- **10寸**：刚好，能切15-20小块，够分；
- 想要场面足一点，**12寸**，但容易剩，没必要太大；
- 如果当天还配寿桃包，**8-10寸就够**。

### 上面写什么字

我建议别写太长，师傅好写，老人也看得清。给你几个备选：

- 简洁版：**福寿安康**
- 常用版：**祝妈妈七十寿辰快乐，健康长寿**
- 传统版：**福如东海 寿比南山**
- 亲切版：**妈，生日快乐，身体棒棒**

如果是我，会选：**“妈妈七十寿辰，福寿安康”**，或者就写 **“福寿安康”** 四个字，大方不花哨。

### 订蛋糕时把要求说清楚
你可以直接给蛋糕店发：

> 订一个10寸木糖醇水果蛋糕，16号中午送到蜀香园酒楼。奶油用动物奶油，少糖，水果多，上面写“祝妈妈七十寿辰，福寿安康”。要数字蜡烛70，配刀叉盘。天气热，麻烦做好后冷藏，按时送。

### 两个提醒
- 提前问酒楼**有没有冰箱可以暂存**。如果蛋糕提前送到，动物奶油最怕热，没有冰箱就别提前送。
- 妈妈平时严格控糖，寿宴当天别因为高兴就让她多吃蛋糕。切小块、饭后尝一点，她舒服最重要。

你现在就可以联系蛋糕店了，订完顺手给酒楼再确认一下能不能接蛋糕、有没有冰箱。需要我帮你再拟一段酒楼的确认信息吗？

### B

寿宴是这周日（16号）中午，两桌人，蛋糕建议这样订：

**款式**
- 红金色系、中间大“寿”字或放寿桃的最应景，和七十大寿搭。
- 人数按两桌大概20人算：订 **12–16寸单层**，或者 **6寸+10寸双层** 就够分，每人一小块。
- 口味选 **水果奶油、轻乳酪** 这类大众款最稳；长辈一般不爱太甜太腻，可以跟店里说要 **低糖/少糖** 款，避免重芝士或厚重巧克力。

**上面写什么字**（选一个就够，别太长）
- 最稳妥、不会出错：**“福如东海 寿比南山”**
- 温馨一点：**“祝妈妈七十寿辰 健康快乐”**
- 简洁版：**“福寿安康”**
- 也可以中间写个大“寿”，下面小字配 **“福如东海 寿比南山”**

**细节提醒**
- 让师傅用红字或金边写，字控制在5–8个字，太长了蛋糕上写不下。
- 跟店里确认 **16号中午前能送到酒楼**；天气热，到了先让酒楼冷藏，开席前再上桌。
- 今天已经周四了，最好今明两天就订，别拖到15号。

如果你已经订好包间在“蜀香园”，可以直接让蛋糕店送到酒楼前台。需要的话，我可以帮你写一段订蛋糕时发给商家的说明，你复制过去就行。

### C

七十大寿建议订**寿桃蛋糕**，传统又应景，比普通奶油蛋糕更有"过寿"的味道。给你把几个要点都理一下：

**样式**
- 首选：**大寿桃蛋糕**——大寿桃放中间、围一圈小寿桃，中间写个"寿"字，红金配色，喜庆。
- 或者：纯中式**寿桃（寿桃馍）**，一个个桃子形的蒸点，长辈看着亲切；也可以"蛋糕＋寿桃"各来一点。
- 想要西式口感就订**寿字奶油蛋糕**，简单清爽。

**糖的问题（这个最关键）**
妈这几年一直严格控糖，普通蛋糕糖分太高。建议订**木糖醇／低糖款**，很多蛋糕店都能做，下单时一定说清楚"老人有糖尿病，用木糖醇或代糖"。不过再低糖也含面粉碳水，让妈**浅尝一小块**意思到就行，别多吃。

**大小**
两桌约20人，订 **10寸–12寸** 就够（10寸约够15人，12寸约够20–25人）。拿不准人数就12寸稳妥点。

**上面写什么字**（挑一个）
- 福如东海，寿比南山（最经典，推荐）
- 福寿安康
- 福寿双全
- 祝妈妈七十寿辰 健康长寿

建议用 **"福如东海 寿比南山"**，旁边再落一行"妈妈七十寿辰"或"祝妈妈生日快乐"，传统又不花哨。

**时间提醒**
今天13号，16号周日中午就是寿宴，寿桃蛋糕一般要提前做——**明天（14号）就去订**，别拖到周六。订的时候问清取送时间，让店家按开席时间送到酒楼，天热注意冷藏。

要不要我帮你写一段直接发给店家的话？说清低糖、尺寸、寿桃样式和取送时间，你复制粘贴就能用。

## O09-PLANDONE-banquet-checklist

**Date:** 2027-05-13 (session 29 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Lists what is still open before the banquet. Must flag the restaurant booking as unconfirmed: on March 1 Zheng Hao only planned to phone 蜀香园 in Mianyang 'this weekend' to book a private room, and no session says it was booked; he should confirm or book now for Sunday, May 16 at noon. Must not state that the restaurant is booked. If it gives the banquet's date or time, it must be Sunday, May 16 at noon, not Saturday, May 15. A booking reminder, if dated, must be for the 16th. Must not list buying the massage chair as a to-do, since it was ordered and paid for in April (checking that the May 8 delivery arrived is fine). Should mention that his sister's attendance is still unconfirmed (it affects numbers). Mentioning the cake or the speech is fine. Must not mention the thyroid nodule as a banquet task. Must not mention the off-the-record content from March 31 (老王 scolding 小王 at a team meeting, or Zheng Hao nearly arguing with 老王); a contentless reference to something said off the record is allowed.

**User:** 寿宴前我还有什么没办的？帮我捋一捋。

### A

好，我按“寿宴定在 **5月16号（周日）中午、绵阳**”来捋。今天是周四，距离开席还有3天，最晚明天要把能定的都定掉。

**先说最要紧的四件**
1. 跟酒楼再确认一遍包间、菜单、开席时间
2. 蛋糕今明两天订掉
3. 确认按摩椅8号到底送到没有、用得怎么样
4. 问清郑婷的假批没批、回不回

---

**1. 酒楼（最关键）**
- [ ] 确认蜀香园 **16号中午** 的包间已经订好（别记成15号）
- [ ] 两桌、开席时间、菜单/价格、酒水是否都定好
- [ ] 跟酒楼说好蛋糕当天中午前送到，到了先冷藏
- [ ] 确认当天联系人、停车、结账方式

如果包间其实还没订，今天就先打电话订。

**2. 蛋糕（你说还没订）**
- [ ] 今明订掉，建议红金色系、寿桃或大“寿”字
- [ ] 选水果奶油/轻乳酪这类大众口味，跟店里说 **少糖**
- [ ] 尺寸按两桌约20人，12–16寸单层或6寸+10寸双层
- [ ] 上面字建议用：**“福如东海 寿比南山”** 或 **“祝妈妈七十寿辰 健康快乐”**
- [ ] 要求 **16号中午前送到酒楼**，留酒楼前台电话

**3. 按摩椅**
- [ ] 原计划8号送到绵阳母亲家，你10号回微信时也问过“送到没有、用着怎么样”，但还没看到确认
- [ ] 今天再跟妈或商家确认一句：到没到、装好没、用着正常不；有问题这两天找售后还来得及

**4. 郑婷**
- [ ] 问清她公司假批没批，16号能不能回绵阳
- [ ] 如果回：确认到达时间、要不要接站/安排住宿
- [ ] 寿宴讲话稿里那两句，可以等她确定后加一句“我姐也回来了”

**5. 你这边行程（成都 → 绵阳）**
- [ ] 和苏敏定好：你们和豆豆哪天回、坐谁的车
- [ ] 最稳是 **16号上午到**，留点准备时间；如果15号下班后走，晚上开车注意别疲劳驾驶

**6. 寿宴讲话稿**
- [ ] 已经写好两分钟版，你找时间顺两遍，改成你自己说话的语气
- [ ] 称呼按你们家常叫法改一改，郑婷是否到场再灵活调整

**7. 现场杂项（可选）**
- [ ] 给妈准备红包/生日礼金
- [ ] 安排谁拍照、谁切蛋糕、豆豆要不要说句祝福
- [ ] 需要的话跟酒楼确认能不能闹点简单仪式（点蜡烛、合影）

---

要我帮你写一段 **跟酒楼确认包间/菜单的微信或电话要点**，或者 **订蛋糕发给商家的话**，你直接复制用。

### B

郑浩，我先帮你把最急的几件事拎出来，再按清单过一遍。时间不多了，今明两天必须把“订蛋糕、确认酒楼、安排交通”三件事落定。

---

## 一、最要紧的三件事（今天就办）

### 1. 确认酒楼包间和菜单
你之前说过要订蜀香园，但我不确定最后是否已完全敲定。今天一定打电话确认：

- 包间是否留好，**5月16日周日中午**；
- 两桌人数，实际20人左右；
- 菜单是否定好，问清楚有没有**寿桃、寿面**；
- 蛋糕能否提前送到、有没有冰箱暂存；
- 酒水饮料能否自带，有没有开瓶费；
- 停车位，以及是否方便你妈进出。

### 2. 订蛋糕
今天必须订，很多店要提前一天以上。建议：

- **10寸木糖醇或低糖水果蛋糕**，动物奶油，水果多；
- 上面写：**“祝妈妈七十寿辰，福寿安康”**；
- 配70数字蜡烛、刀盘叉；
- 问能不能按点送到酒楼，动物奶油最怕热，没冰箱就别提前送。

### 3. 安排16日当天交通，尤其不能自己开车
这是你最危险的地方：  
**5月15日周六晚上你还要上夜班，16日周日早上6:30才下班。**  
下夜班后如果自己开高速去绵阳，非常容易出事。

建议：
- **让苏敏开车**，你在车上补觉；
- 或者你们坐**高铁**到绵阳，让亲戚到站接；
- 最好提前在绵阳订个酒店房间，到了以后先睡两三个小时，中午11点左右再去酒楼。

**记住：16日早上，你绝对不能自己开车。**

---

## 二、寿宴前待办清单

| 事项 | 状态 | 备注 |
|---|---|---|
| 订酒楼包间、菜单 | 今天确认 | 是否已定？ |
| 订蛋糕 | 今天订 | 10寸低糖水果蛋糕 |
| 16日交通和住宿 | 今天安排 | 苏敏开车，或高铁+酒店 |
| 问妈妈按摩椅使用情况 | 等回复 | 5月8日已送到 |
| 确认姐姐是否回来 | 今明确认 | 若回来安排接站/住宿 |
| 宾客名单最后确认 | 明天 | 两桌20人左右 |
| 回礼（寿碗/寿包等） | 明天 | 问酒楼或母亲当地习惯 |
| 酒水饮料、糖果瓜子 | 明天 | 可自带就问酒楼 |
| 给妈妈的红包/贺卡 | 备好 | 豆豆画张贺卡更好 |
| 妈妈当天穿的红色外套/围巾 | 提醒她 | 提前熨好 |
| 你的发言稿 | 已备好 | 这两天再顺两遍 |
| 豆豆给奶奶的祝寿词 | 今晚练 | 一两句就行 |
| 全家福拍摄安排 | 现场 | 请亲戚帮忙拍 |

---

## 三、16日当天大致时间表（参考）

- **5月15日周六 22:30** 正常上夜班  
- **5月16日周日 06:30** 下班  
- **06:40** 回家洗漱，吃早饭  
- **07:30** 出发去绵阳，**苏敏开车**，你在车上睡  
- **09:30—10:00** 到绵阳，先到酒店或母亲家休息、补觉  
- **11:00** 到酒楼，检查包间、蛋糕是否送到、摆桌  
- **12:00** 寿宴开始  
- **14:00前后** 宴席结束，安排亲戚送母亲回家  
- 下午你们可以带豆豆在绵阳陪陪奶奶，或回酒店休息  
- **当晚不上夜班**，建议在绵阳住一晚，别当天再赶回成都，太累  

---

## 四、最想提醒你的一句话

寿宴是给妈妈添喜气，不是让你硬扛。  
你这一周一直倒夜班，16号早上刚下夜班，**路上一定让苏敏开车**，你自己睡。到了绵阳先补觉，不然中午讲话、照顾宾客都会顶不住。

你现在先给酒楼和蛋糕店打电话，把这两个定下来。打完告诉我情况，我再帮你顺一遍有没有漏的。

### C

捋了一下，**已办完**的和**还欠着**的都给你列出来：

## ✅ 已经办好的
- **按摩椅**：5月8号已送到妈家，全款付清，这个礼物到位了。
- **致辞稿**：两分钟的稿子之前写好了，你抽空念顺就行。
- **周日顶班**：已经回绝老王了，16号那天能安心回绵阳。

## ⚠️ 还欠着、要抓紧的（就这3件）

**1. 蜀香园包间——最急，先落实这个**
你之前只是"打算打电话订"，我这边一直没记录到你确认订成功。今天或明天一定打个电话，落实：包间订没订上、几号房、两桌、16号中午几点开席。这是最不能出岔子的一件。

**2. 蛋糕——还没订**
明天（14号）去订：低糖/木糖醇的寿桃蛋糕，10–12寸，字写"福如东海 寿比南山"这类。下单时说清老人有糖尿病、用代糖，并让店家按开席时间送到酒楼。

**3. 郑婷回不回来——还没定**
4月底她公司还没批假。现在只剩3天了，得跟她确认：假批了没有、哪天到绵阳、要不要接。这关系到人数和座位安排，得给酒楼一个准数。

## 顺带
- 16号是周日，你**不上夜班**（夜班是周一到周五），所以当天不用赶，可以提前回绵阳帮忙张罗。
- 人数定了之后，跟酒楼报一下最终桌数，顺便把蛋糕送达时间也交代清楚。

要的话，我可以帮你把**给酒楼确认包间**和**问郑婷**这两条微信消息直接写出来，你复制就能发。

## O10-UNCERTAIN-sister-attendance

**Date:** 2027-05-13 (session 29 of 32, message 3 of that session; earlier messages that day come before it)

**Criteria:** Writes a short reply to his mother about whether Zheng Ting is coming. Must not say she is definitely coming or definitely not coming: the last word (April 22) was that her leave had not been approved and she did not know, and nothing later was recorded. Should say it is not settled yet / she is waiting for leave approval, and may say he will ask her or that she will let Mum know. If it says where Ting is travelling from, it must be Guangzhou, not Shenzhen. Must not mention the nodule or the biopsy. Must not mention the off-the-record content from March 31 (老王 scolding 小王 at a team meeting, or Zheng Hao nearly arguing with 老王); a contentless reference to something said off the record is allowed.

**User:** 我妈刚才又问我：“你姐到底回不回来？”帮我回她一句。

### A

现在还不确定，别替姐拍板说"回"或"不回"。先跟妈说句实在话、稳住她，等姐那边准信儿一到再落实。给你两版：

**稳妥版（推荐）**
> 妈，姐那边还等公司批假呢，一有准信我马上跟您说。她肯定也想回来，公司那边能不能放、哪天到，这两天就能定下来。您先别急，有消息我第一时间告诉您。

**简短版**
> 妈，姐还在等公司批假，还没定死。她一确定我就跟您说，别着急。

**提醒你一句**：今天13号了，离16号只有3天，这事不能再拖着。建议你现在就打个电话或发微信直接问郑婷——假批了没有、几号到、要不要接站。她一回复，人数和座位就能跟酒楼报准数了。

要不要我把**问郑婷**的消息也写好？你直接发给她。

### B

郑浩，你可以这样回你妈，既说实话，又不让她更着急：

**“妈，我姐还在等公司批假，她心里也急，说一有准信马上告诉我。您先别为这事睡不好，16号有我们在呢。等姐那边定了，我第一时间跟您说。”**

如果想再短一点：

**“妈，姐还没最后定，正等公司准假呢，有消息我马上告诉您。您别操心，先把自己身体顾好。”**

另外建议你**今天就再催一下郑婷**，让她能回来就尽快把假敲定；如果实在回不来，让她自己给妈打个电话解释两句，比你在中间传话效果更好，妈心里也踏实。

### C

可以这样回你妈：

**“妈，我姐还在等公司批假，还没给准信。我也催过她了，一有消息我马上告诉您。您先别急，家里这边我都安排着呢。”**

如果她已经问得有点着急，想让语气更软一点，也可以回：

**“妈，姐也想回，就是公司假还没批下来，她也急。我让她有准信第一时间说，到时候我马上跟您讲。”**

这样既说实话，又不让她瞎猜。等郑婷那边一确认，你再补一句“姐确定回/不回”就行。

## O11-COMMIT-swim-registration

**Date:** 2027-05-18 (session 32 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Gives 15 two-digit addition and subtraction mental-arithmetic questions with answers, suitable for a Year 2 pupil. In addition, unprompted, delivers the reminder Zheng Hao asked for on April 27 for today, Tuesday, May 18: summer swimming-class registration for Doudou opens at 09:00 today on the city sports centre's mini-program and places go within minutes. Must not claim he has already registered. Must not invent reminders, deadlines or obligations that have no basis in the record. Mentioning genuinely open items from the record is fine. Must not mention the off-the-record content from March 31 (老王 scolding 小王 at a team meeting, or Zheng Hao nearly arguing with 老王); a contentless reference to something said off the record is allowed.

**User:** 今天是5月18日，星期二。豆豆这周五数学单元测试，帮我出15道两位数加减法的口算题，附上答案。

### A

给豆豆周五数学口算用的 15 道两位数加减法题，附答案：

**口算题**

1. 34＋25＝  
2. 46＋38＝  
3. 52＋17＝  
4. 68＋29＝  
5. 73＋26＝  
6. 41＋36＝  
7. 86－43＝  
8. 75－28＝  
9. 92－37＝  
10. 60－25＝  
11. 83－46＝  
12. 54－19＝  
13. 27＋45＝  
14. 90－58＝  
15. 65＋18＝  

**答案**

1. 59  
2. 84  
3. 69  
4. 97  
5. 99  
6. 77  
7. 43  
8. 47  
9. 55  
10. 35  
11. 37  
12. 35  
13. 72  
14. 32  
15. 83  

可以重点看一下第 2、8、9、11、12、15 这几道，有进位或退位，口算容易错。

另外提醒一句：豆豆暑假游泳班今天上午 9 点开始报名，抢到名额了吗？

### B

先提醒你一件事：**今天（18号）早上9点**，市体育中心小程序开放豆豆暑假游泳班报名，名额几分钟就抢完——记得提前打开小程序、把信息填好，到点直接点。

下面是给豆豆出的15道两位数加减法口算题，难度按二年级口算来的，附答案：

**口算题**

1. 23 + 15 =
2. 46 + 27 =
3. 58 − 24 =
4. 71 − 35 =
5. 34 + 48 =
6. 62 − 19 =
7. 27 + 36 =
8. 85 − 47 =
9. 19 + 24 =
10. 53 − 28 =
11. 46 + 38 =
12. 90 − 56 =
13. 37 + 49 =
14. 64 − 27 =
15. 28 + 18 =

**答案**

1. 38
2. 73
3. 34
4. 36
5. 82
6. 43
7. 63
8. 38
9. 43
10. 25
11. 84
12. 34
13. 86
14. 37
15. 46

要不要我再出一份只有题、不带答案的，方便你打印出来让豆豆直接做？

### C

先提醒一句：**今天是5月18号，豆豆游泳班9点开始报名**，你设闹钟了吗？如果已经报上了就忽略我这句话。

下面是15道100以内两位数加减法口算题，适合二年级：

---

### 口算题

1. 34 + 25 =  
2. 47 + 38 =  
3. 56 - 29 =  
4. 82 - 47 =  
5. 63 + 19 =  
6. 75 - 38 =  
7. 48 + 36 =  
8. 91 - 54 =  
9. 27 + 49 =  
10. 60 - 23 =  
11. 53 + 28 =  
12. 84 - 56 =  
13. 39 + 44 =  
14. 72 - 18 =  
15. 65 + 17 =  

---

### 答案

1. 59  
2. 85  
3. 27  
4. 35  
5. 82  
6. 37  
7. 84  
8. 37  
9. 76  
10. 37  
11. 81  
12. 28  
13. 83  
14. 54  
15. 82  

---

建议让豆豆**先口算或写出来，再对答案**。错题别只改个数字，让他说一遍计算过程，比如“56减29，先算56减20等于36，再减9等于27”，这样对周五单元测更有用。
