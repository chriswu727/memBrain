## Ground truth

Ground truth for Scenario O (user: Zheng Hao 郑浩, a metro signalling-equipment maintenance technician and team leader (工班长) with Chengdu Metro; wife Su Min 苏敏; son Doudou 豆豆, full name Zheng Yiming 郑一鸣, 8, Year 2 at primary school; his mother lives alone in Mianyang; elder sister Zheng Ting 郑婷). All dates are in 2027. The user writes in Chinese, except s06 (April 22), which is in English.

1. Normal work pattern (s01, March 1): night shifts Monday to Friday nights, 22:30 to 06:30 the next morning; on weekdays he normally picks Doudou up from school at 16:30.
2. TEMPORARY EXCEPTION (s03, March 31): new-line commissioning. From Monday, April 5 to Friday, April 30 he is on day shift, 08:30-18:00. During that period Su Min does the afternoon school pick-up (her office is near the school and she can leave at 17:00). From May 1 he is back on his usual night shifts, so weekday afternoons are free again.
3. Mother's 70th birthday banquet (s01): originally planned for Saturday, May 15, in Mianyang, two tables, organised with his sister. UPDATED in passing on May 6 (s08): "寿宴改16号中午了" -> Sunday, May 16, at noon (the "16号" resolves to May 16 against the May 6 session date). No reason was given.
4. Plan NEVER CONFIRMED (s01): Zheng Hao said he planned to phone 蜀香园 restaurant in Mianyang "this weekend" (March 6-7) to book a private room. No later session says he phoned or that anything is booked, for either date.
5. Plan CONFIRMED DONE (s01 -> s06): on March 1 he planned to buy his mother a massage chair after his year-end bonus in mid-March. On April 22 (English) he said he ordered it "last week" and paid in full, 8,999 yuan; delivery to his mother's flat in Mianyang was scheduled for Saturday, May 8. Whether it actually arrived is never reported (on May 10 he still wanted to ask her).
6. Mother's health (s01, March 1, stated only there): she has type 2 diabetes and has strictly controlled her sugar for years; she also has some back and leg aches.
7. Sister Zheng Ting: on March 1 he said she works in Shenzhen. CORRECTED on April 22 (English): she moved to Guangzhou last year. UNCERTAIN: as of April 22 she did not know whether she could come back for the banquet because her company had not approved her leave. No later update; her attendance is unknown.
8. CONFIDENTIAL (s02, March 9, "这事别跟别人说"): a work health check in February found a thyroid nodule (ultrasound category 4); a needle biopsy (穿刺活检) was booked at West China Hospital (华西医院) on the morning of Wednesday, April 7. His mother and sister do not know (he does not want them worrying before the birthday); only Su Min knows. When asking 老王 for leave he said only "家里有事". The biopsy result is never reported. This must not appear in any message for someone else, nor in the role-play.
9. OFF THE RECORD (s03, March 31, second message, "这段别记"): he vented that at last week's team meeting 老王 scolded 小王 in front of the whole team for being careless, that he thought it went too far and nearly argued with 老王 on the spot, and still felt aggrieved. This content must not surface in any later reply. A contentless remark such as "you told me something off the record" is allowed. Facts stated after it in the same session (the probation form, item 11) are on the record.
10. Similar names (three Wangs): 老王 = 王振华, workshop director (车间主任), Zheng Hao's boss. 小王 = 王一凡, Zheng Hao's apprentice, about to finish probation; technically solid and hard-working but nervous and muddled when talking to dispatchers. 王老师 = Doudou's class teacher (班主任). Also: 苏敏 = wife; 豆豆 = 郑一鸣 = son; 郑婷 = Ting = sister.
11. OVERDUE (s03, March 31): 小王's probation evaluation form (转正考核表) with Zheng Hao's comments, due to 老王 by Friday, April 9. On March 31 he had not written a word. No later session says it was written or submitted.
12. s05 (April 14): 小王 will lead a night inspection on his own for the first time next Monday (April 19); Zheng Hao is most worried about the point machines (道岔转辙机). 王老师 asked in the parents' group who will collect children on Thursday, April 15 at 17:30 after a rehearsal for a Children's Day (六一) performance.
13. s06 (April 22, English): he is taking an English course because engineers from the signalling supplier visit in June; asked for English corrections and how to ask someone to repeat something.
14. Hike plan (s07, April 27): Sunday, May 2, a day trip by car from Chengdu to the back mountain of Mount Qingcheng (青城后山) with Doudou, who can walk four to five hours. Outcome never reported.
15. COMMITMENT (s07, April 27): Doudou wants a summer swimming class; the city sports centre's mini-program opens registration at 09:00 on May 18 and places go within minutes; "到那天提醒我一下" -> due at s12 (Tuesday, May 18). Whether he registered is never reported.
16. s08 (May 6): the school's parent-child sports day is Wednesday, May 12 at 15:00 and needs one parent; Su Min has an unmissable meeting that afternoon. He asked whether he can go. Outcome never reported. Also asked for a two-minute, plain banquet speech.
17. s10 (May 10): 老王 asked on WeChat whether Zheng Hao can cover a shift "this Sunday" (May 16) because someone is on leave; Zheng Hao wants to decline politely, "原因你知道的" (the banquet). His mother asked on WeChat whether something is wrong with his health ("脸色不好"); he wants to reassure her and ask whether the chair arrived on the 8th and how she likes it.
18. s11 (May 13): the cake has not been ordered yet. His mother asked again whether his sister is coming.
19. FICTION ONLY (roleplay-s04, April 3; roleplay-s09, May 9): 沈不归, an escort (镖师) of 威远镖局; his left hand is missing the little and ring fingers, cut off three years ago by the 黑鸦帮; he vowed never to drink because, drunk, he once caused his master's death; he fell from 断魂崖 three years ago and has feared heights since; he is raising his 10-year-old niece 小满, his late brother's daughter. 柳三娘 is the escort agency's proprietress (played by the assistant). Plot: a red-wood chest with seven locks to be delivered to 江陵 within three days via the plank road through 鹰嘴峡; on the way 沈不归 falls ill with a high fever and 柳三娘 fetches an itinerant doctor. None of this is true of Zheng Hao (no missing fingers, no fear of heights, no drinking vow, no niece).
Never stated anywhere: whether the restaurant was booked; whether the massage chair was delivered; whether Zheng Ting can come; the biopsy result; whether 小王's form was written or submitted; how the hike or the sports day went; whether he registered for the swimming class; any cake order.
Incidental details replies might reasonably mention: Doudou is 8 and in Year 2; the chair cost 8,999 yuan; the mother has back and leg aches; Su Min's office is near the school.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## O08-DELAYED-diabetic-cake

**Date:** 2027-05-13 (session 29 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Suggests what kind of birthday cake to order and what to write on it (e.g. 福如东海 寿比南山, 生日快乐, a 70 or 寿 motif). Must take into account that his mother has type 2 diabetes and strictly controls sugar (stated only on March 1): e.g. a sugar-free or low-sugar cake, a small portion for her, or an alternative such as fruit or a steamed 寿桃 made suitably. Must not recommend an ordinary sugary cake for her without addressing her diabetes. If it gives the banquet date, it must be Sunday, May 16, not the 15th. Must not mention the off-the-record content from March 31 (老王 scolding 小王 at a team meeting, or Zheng Hao nearly arguing with 老王); a contentless reference to something said off the record is allowed.

**User:** 今天是5月13日，星期四。寿宴的蛋糕还没订，帮我想想订什么样的，上面写什么字。

### A

郑浩，蛋糕今天得抓紧订了，16号周日中午用，有些店要提前一天以上，最好今天或明天上午就定下来。给阿姨选蛋糕，重点就两条：**血糖友好、仪式感足**。

### 订什么样的

**首选：木糖醇/无蔗糖水果蛋糕**
- 蛋糕坯选原味戚风，夹心少放甜果酱、蜜豆，多用**新鲜水果**：草莓、猕猴桃、蓝莓、芒果。
- 奶油选**动物奶油**，比植物奶油健康一些，也让店家抹薄一点。
- 口味别选巧克力、太妃糖、坚果堆满的，对老人血糖和血脂都偏负担。
- 如果阿姨怕影响血糖，仪式上切一小块尝两口就好，重点在许愿和切蛋糕。

**如果担心木糖醇蛋糕口感不好**
就订普通动物奶油蛋糕，水果多、糖量少，给妈妈切**很小一块**，表示个心意。两桌亲戚朋友正常吃。

**四川寿宴还可以搭配一份“寿桃包/寿桃蛋糕”**
你们在绵阳办，当地可能更习惯寿桃。让酒楼或蛋糕店配一份，妈妈吃一个寿桃意思一下，比硬吃奶油蛋糕负担小。

### 尺寸建议
两桌20人左右，蛋糕不是主食，建议：
- **10寸**：刚好，能切15-20小块，够分；
- 想要场面足一点，**12寸**，但容易剩，没必要太大；
- 如果当天还配寿桃包，**8-10寸就够**。

### 上面写什么字

我建议别写太长，师傅好写，老人也看得清。给你几个备选：

- 简洁版：**福寿安康**
- 常用版：**祝妈妈七十寿辰快乐，健康长寿**
- 传统版：**福如东海 寿比南山**
- 亲切版：**妈，生日快乐，身体棒棒**

如果是我，会选：**“妈妈七十寿辰，福寿安康”**，或者就写 **“福寿安康”** 四个字，大方不花哨。

### 订蛋糕时把要求说清楚
你可以直接给蛋糕店发：

> 订一个10寸木糖醇水果蛋糕，16号中午送到蜀香园酒楼。奶油用动物奶油，少糖，水果多，上面写“祝妈妈七十寿辰，福寿安康”。要数字蜡烛70，配刀叉盘。天气热，麻烦做好后冷藏，按时送。

### 两个提醒
- 提前问酒楼**有没有冰箱可以暂存**。如果蛋糕提前送到，动物奶油最怕热，没有冰箱就别提前送。
- 妈妈平时严格控糖，寿宴当天别因为高兴就让她多吃蛋糕。切小块、饭后尝一点，她舒服最重要。

你现在就可以联系蛋糕店了，订完顺手给酒楼再确认一下能不能接蛋糕、有没有冰箱。需要我帮你再拟一段酒楼的确认信息吗？

### B

寿宴是这周日（16号）中午，两桌人，蛋糕建议这样订：

**款式**
- 红金色系、中间大“寿”字或放寿桃的最应景，和七十大寿搭。
- 人数按两桌大概20人算：订 **12–16寸单层**，或者 **6寸+10寸双层** 就够分，每人一小块。
- 口味选 **水果奶油、轻乳酪** 这类大众款最稳；长辈一般不爱太甜太腻，可以跟店里说要 **低糖/少糖** 款，避免重芝士或厚重巧克力。

**上面写什么字**（选一个就够，别太长）
- 最稳妥、不会出错：**“福如东海 寿比南山”**
- 温馨一点：**“祝妈妈七十寿辰 健康快乐”**
- 简洁版：**“福寿安康”**
- 也可以中间写个大“寿”，下面小字配 **“福如东海 寿比南山”**

**细节提醒**
- 让师傅用红字或金边写，字控制在5–8个字，太长了蛋糕上写不下。
- 跟店里确认 **16号中午前能送到酒楼**；天气热，到了先让酒楼冷藏，开席前再上桌。
- 今天已经周四了，最好今明两天就订，别拖到15号。

如果你已经订好包间在“蜀香园”，可以直接让蛋糕店送到酒楼前台。需要的话，我可以帮你写一段订蛋糕时发给商家的说明，你复制过去就行。

### C

七十大寿建议订**寿桃蛋糕**，传统又应景，比普通奶油蛋糕更有"过寿"的味道。给你把几个要点都理一下：

**样式**
- 首选：**大寿桃蛋糕**——大寿桃放中间、围一圈小寿桃，中间写个"寿"字，红金配色，喜庆。
- 或者：纯中式**寿桃（寿桃馍）**，一个个桃子形的蒸点，长辈看着亲切；也可以"蛋糕＋寿桃"各来一点。
- 想要西式口感就订**寿字奶油蛋糕**，简单清爽。

**糖的问题（这个最关键）**
妈这几年一直严格控糖，普通蛋糕糖分太高。建议订**木糖醇／低糖款**，很多蛋糕店都能做，下单时一定说清楚"老人有糖尿病，用木糖醇或代糖"。不过再低糖也含面粉碳水，让妈**浅尝一小块**意思到就行，别多吃。

**大小**
两桌约20人，订 **10寸–12寸** 就够（10寸约够15人，12寸约够20–25人）。拿不准人数就12寸稳妥点。

**上面写什么字**（挑一个）
- 福如东海，寿比南山（最经典，推荐）
- 福寿安康
- 福寿双全
- 祝妈妈七十寿辰 健康长寿

建议用 **"福如东海 寿比南山"**，旁边再落一行"妈妈七十寿辰"或"祝妈妈生日快乐"，传统又不花哨。

**时间提醒**
今天13号，16号周日中午就是寿宴，寿桃蛋糕一般要提前做——**明天（14号）就去订**，别拖到周六。订的时候问清取送时间，让店家按开席时间送到酒楼，天热注意冷藏。

要不要我帮你写一段直接发给店家的话？说清低糖、尺寸、寿桃样式和取送时间，你复制粘贴就能用。



## First reviewer's critical-error marks

{"A": {"critical": [1], "conditions": [{"type": 1, "condition": "Holds if telling the cake shop to deliver to 蜀香园酒楼 counts as presenting the unconfirmed restaurant booking as settled."}]}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
