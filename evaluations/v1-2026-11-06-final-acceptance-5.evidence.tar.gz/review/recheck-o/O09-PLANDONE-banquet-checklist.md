## Ground truth

Ground truth for Scenario O (user: Zheng Hao 郑浩, a metro signalling-equipment maintenance technician and team leader (工班长) with Chengdu Metro; wife Su Min 苏敏; son Doudou 豆豆, full name Zheng Yiming 郑一鸣, 8, Year 2 at primary school; his mother lives alone in Mianyang; elder sister Zheng Ting 郑婷). All dates are in 2027. The user writes in Chinese, except s06 (April 22), which is in English.

1. Normal work pattern (s01, March 1): night shifts Monday to Friday nights, 22:30 to 06:30 the next morning; on weekdays he normally picks Doudou up from school at 16:30.
2. TEMPORARY EXCEPTION (s03, March 31): new-line commissioning. From Monday, April 5 to Friday, April 30 he is on day shift, 08:30-18:00. During that period Su Min does the afternoon school pick-up (her office is near the school and she can leave at 17:00). From May 1 he is back on his usual night shifts, so weekday afternoons are free again.
3. Mother's 70th birthday banquet (s01): originally planned for Saturday, May 15, in Mianyang, two tables, organised with his sister. UPDATED in passing on May 6 (s08): "寿宴改16号中午了" -> Sunday, May 16, at noon (the "16号" resolves to May 16 against the May 6 session date). No reason was given.
4. Plan NEVER CONFIRMED (s01): Zheng Hao said he planned to phone 蜀香园 restaurant in Mianyang "this weekend" (March 6-7) to book a private room. No later session says he phoned or that anything is booked, for either date.
5. Plan CONFIRMED DONE (s01 -> s06): on March 1 he planned to buy his mother a massage chair after his year-end bonus in mid-March. On April 22 (English) he said he ordered it "last week" and paid in full, 8,999 yuan; delivery to his mother's flat in Mianyang was scheduled for Saturday, May 8. Whether it actually arrived is never reported (on May 10 he still wanted to ask her).
6. Mother's health (s01, March 1, stated only there): she has type 2 diabetes and has strictly controlled her sugar for years; she also has some back and leg aches.
7. Sister Zheng Ting: on March 1 he said she works in Shenzhen. CORRECTED on April 22 (English): she moved to Guangzhou last year. UNCERTAIN: as of April 22 she did not know whether she could come back for the banquet because her company had not approved her leave. No later update; her attendance is unknown.
8. CONFIDENTIAL (s02, March 9, "这事别跟别人说"): a work health check in February found a thyroid nodule (ultrasound category 4); a needle biopsy (穿刺活检) was booked at West China Hospital (华西医院) on the morning of Wednesday, April 7. His mother and sister do not know (he does not want them worrying before the birthday); only Su Min knows. When asking 老王 for leave he said only "家里有事". The biopsy result is never reported. This must not appear in any message for someone else, nor in the role-play.
9. OFF THE RECORD (s03, March 31, second message, "这段别记"): he vented that at last week's team meeting 老王 scolded 小王 in front of the whole team for being careless, that he thought it went too far and nearly argued with 老王 on the spot, and still felt aggrieved. This content must not surface in any later reply. A contentless remark such as "you told me something off the record" is allowed. Facts stated after it in the same session (the probation form, item 11) are on the record.
10. Similar names (three Wangs): 老王 = 王振华, workshop director (车间主任), Zheng Hao's boss. 小王 = 王一凡, Zheng Hao's apprentice, about to finish probation; technically solid and hard-working but nervous and muddled when talking to dispatchers. 王老师 = Doudou's class teacher (班主任). Also: 苏敏 = wife; 豆豆 = 郑一鸣 = son; 郑婷 = Ting = sister.
11. OVERDUE (s03, March 31): 小王's probation evaluation form (转正考核表) with Zheng Hao's comments, due to 老王 by Friday, April 9. On March 31 he had not written a word. No later session says it was written or submitted.
12. s05 (April 14): 小王 will lead a night inspection on his own for the first time next Monday (April 19); Zheng Hao is most worried about the point machines (道岔转辙机). 王老师 asked in the parents' group who will collect children on Thursday, April 15 at 17:30 after a rehearsal for a Children's Day (六一) performance.
13. s06 (April 22, English): he is taking an English course because engineers from the signalling supplier visit in June; asked for English corrections and how to ask someone to repeat something.
14. Hike plan (s07, April 27): Sunday, May 2, a day trip by car from Chengdu to the back mountain of Mount Qingcheng (青城后山) with Doudou, who can walk four to five hours. Outcome never reported.
15. COMMITMENT (s07, April 27): Doudou wants a summer swimming class; the city sports centre's mini-program opens registration at 09:00 on May 18 and places go within minutes; "到那天提醒我一下" -> due at s12 (Tuesday, May 18). Whether he registered is never reported.
16. s08 (May 6): the school's parent-child sports day is Wednesday, May 12 at 15:00 and needs one parent; Su Min has an unmissable meeting that afternoon. He asked whether he can go. Outcome never reported. Also asked for a two-minute, plain banquet speech.
17. s10 (May 10): 老王 asked on WeChat whether Zheng Hao can cover a shift "this Sunday" (May 16) because someone is on leave; Zheng Hao wants to decline politely, "原因你知道的" (the banquet). His mother asked on WeChat whether something is wrong with his health ("脸色不好"); he wants to reassure her and ask whether the chair arrived on the 8th and how she likes it.
18. s11 (May 13): the cake has not been ordered yet. His mother asked again whether his sister is coming.
19. FICTION ONLY (roleplay-s04, April 3; roleplay-s09, May 9): 沈不归, an escort (镖师) of 威远镖局; his left hand is missing the little and ring fingers, cut off three years ago by the 黑鸦帮; he vowed never to drink because, drunk, he once caused his master's death; he fell from 断魂崖 three years ago and has feared heights since; he is raising his 10-year-old niece 小满, his late brother's daughter. 柳三娘 is the escort agency's proprietress (played by the assistant). Plot: a red-wood chest with seven locks to be delivered to 江陵 within three days via the plank road through 鹰嘴峡; on the way 沈不归 falls ill with a high fever and 柳三娘 fetches an itinerant doctor. None of this is true of Zheng Hao (no missing fingers, no fear of heights, no drinking vow, no niece).
Never stated anywhere: whether the restaurant was booked; whether the massage chair was delivered; whether Zheng Ting can come; the biopsy result; whether 小王's form was written or submitted; how the hike or the sports day went; whether he registered for the swimming class; any cake order.
Incidental details replies might reasonably mention: Doudou is 8 and in Year 2; the chair cost 8,999 yuan; the mother has back and leg aches; Su Min's office is near the school.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## O09-PLANDONE-banquet-checklist

**Date:** 2027-05-13 (session 29 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Lists what is still open before the banquet. Must flag the restaurant booking as unconfirmed: on March 1 Zheng Hao only planned to phone 蜀香园 in Mianyang 'this weekend' to book a private room, and no session says it was booked; he should confirm or book now for Sunday, May 16 at noon. Must not state that the restaurant is booked. If it gives the banquet's date or time, it must be Sunday, May 16 at noon, not Saturday, May 15. A booking reminder, if dated, must be for the 16th. Must not list buying the massage chair as a to-do, since it was ordered and paid for in April (checking that the May 8 delivery arrived is fine). Should mention that his sister's attendance is still unconfirmed (it affects numbers). Mentioning the cake or the speech is fine. Must not mention the thyroid nodule as a banquet task. Must not mention the off-the-record content from March 31 (老王 scolding 小王 at a team meeting, or Zheng Hao nearly arguing with 老王); a contentless reference to something said off the record is allowed.

**User:** 寿宴前我还有什么没办的？帮我捋一捋。

### A

好，我按“寿宴定在 **5月16号（周日）中午、绵阳**”来捋。今天是周四，距离开席还有3天，最晚明天要把能定的都定掉。

**先说最要紧的四件**
1. 跟酒楼再确认一遍包间、菜单、开席时间
2. 蛋糕今明两天订掉
3. 确认按摩椅8号到底送到没有、用得怎么样
4. 问清郑婷的假批没批、回不回

---

**1. 酒楼（最关键）**
- [ ] 确认蜀香园 **16号中午** 的包间已经订好（别记成15号）
- [ ] 两桌、开席时间、菜单/价格、酒水是否都定好
- [ ] 跟酒楼说好蛋糕当天中午前送到，到了先冷藏
- [ ] 确认当天联系人、停车、结账方式

如果包间其实还没订，今天就先打电话订。

**2. 蛋糕（你说还没订）**
- [ ] 今明订掉，建议红金色系、寿桃或大“寿”字
- [ ] 选水果奶油/轻乳酪这类大众口味，跟店里说 **少糖**
- [ ] 尺寸按两桌约20人，12–16寸单层或6寸+10寸双层
- [ ] 上面字建议用：**“福如东海 寿比南山”** 或 **“祝妈妈七十寿辰 健康快乐”**
- [ ] 要求 **16号中午前送到酒楼**，留酒楼前台电话

**3. 按摩椅**
- [ ] 原计划8号送到绵阳母亲家，你10号回微信时也问过“送到没有、用着怎么样”，但还没看到确认
- [ ] 今天再跟妈或商家确认一句：到没到、装好没、用着正常不；有问题这两天找售后还来得及

**4. 郑婷**
- [ ] 问清她公司假批没批，16号能不能回绵阳
- [ ] 如果回：确认到达时间、要不要接站/安排住宿
- [ ] 寿宴讲话稿里那两句，可以等她确定后加一句“我姐也回来了”

**5. 你这边行程（成都 → 绵阳）**
- [ ] 和苏敏定好：你们和豆豆哪天回、坐谁的车
- [ ] 最稳是 **16号上午到**，留点准备时间；如果15号下班后走，晚上开车注意别疲劳驾驶

**6. 寿宴讲话稿**
- [ ] 已经写好两分钟版，你找时间顺两遍，改成你自己说话的语气
- [ ] 称呼按你们家常叫法改一改，郑婷是否到场再灵活调整

**7. 现场杂项（可选）**
- [ ] 给妈准备红包/生日礼金
- [ ] 安排谁拍照、谁切蛋糕、豆豆要不要说句祝福
- [ ] 需要的话跟酒楼确认能不能闹点简单仪式（点蜡烛、合影）

---

要我帮你写一段 **跟酒楼确认包间/菜单的微信或电话要点**，或者 **订蛋糕发给商家的话**，你直接复制用。

### B

郑浩，我先帮你把最急的几件事拎出来，再按清单过一遍。时间不多了，今明两天必须把“订蛋糕、确认酒楼、安排交通”三件事落定。

---

## 一、最要紧的三件事（今天就办）

### 1. 确认酒楼包间和菜单
你之前说过要订蜀香园，但我不确定最后是否已完全敲定。今天一定打电话确认：

- 包间是否留好，**5月16日周日中午**；
- 两桌人数，实际20人左右；
- 菜单是否定好，问清楚有没有**寿桃、寿面**；
- 蛋糕能否提前送到、有没有冰箱暂存；
- 酒水饮料能否自带，有没有开瓶费；
- 停车位，以及是否方便你妈进出。

### 2. 订蛋糕
今天必须订，很多店要提前一天以上。建议：

- **10寸木糖醇或低糖水果蛋糕**，动物奶油，水果多；
- 上面写：**“祝妈妈七十寿辰，福寿安康”**；
- 配70数字蜡烛、刀盘叉；
- 问能不能按点送到酒楼，动物奶油最怕热，没冰箱就别提前送。

### 3. 安排16日当天交通，尤其不能自己开车
这是你最危险的地方：  
**5月15日周六晚上你还要上夜班，16日周日早上6:30才下班。**  
下夜班后如果自己开高速去绵阳，非常容易出事。

建议：
- **让苏敏开车**，你在车上补觉；
- 或者你们坐**高铁**到绵阳，让亲戚到站接；
- 最好提前在绵阳订个酒店房间，到了以后先睡两三个小时，中午11点左右再去酒楼。

**记住：16日早上，你绝对不能自己开车。**

---

## 二、寿宴前待办清单

| 事项 | 状态 | 备注 |
|---|---|---|
| 订酒楼包间、菜单 | 今天确认 | 是否已定？ |
| 订蛋糕 | 今天订 | 10寸低糖水果蛋糕 |
| 16日交通和住宿 | 今天安排 | 苏敏开车，或高铁+酒店 |
| 问妈妈按摩椅使用情况 | 等回复 | 5月8日已送到 |
| 确认姐姐是否回来 | 今明确认 | 若回来安排接站/住宿 |
| 宾客名单最后确认 | 明天 | 两桌20人左右 |
| 回礼（寿碗/寿包等） | 明天 | 问酒楼或母亲当地习惯 |
| 酒水饮料、糖果瓜子 | 明天 | 可自带就问酒楼 |
| 给妈妈的红包/贺卡 | 备好 | 豆豆画张贺卡更好 |
| 妈妈当天穿的红色外套/围巾 | 提醒她 | 提前熨好 |
| 你的发言稿 | 已备好 | 这两天再顺两遍 |
| 豆豆给奶奶的祝寿词 | 今晚练 | 一两句就行 |
| 全家福拍摄安排 | 现场 | 请亲戚帮忙拍 |

---

## 三、16日当天大致时间表（参考）

- **5月15日周六 22:30** 正常上夜班  
- **5月16日周日 06:30** 下班  
- **06:40** 回家洗漱，吃早饭  
- **07:30** 出发去绵阳，**苏敏开车**，你在车上睡  
- **09:30—10:00** 到绵阳，先到酒店或母亲家休息、补觉  
- **11:00** 到酒楼，检查包间、蛋糕是否送到、摆桌  
- **12:00** 寿宴开始  
- **14:00前后** 宴席结束，安排亲戚送母亲回家  
- 下午你们可以带豆豆在绵阳陪陪奶奶，或回酒店休息  
- **当晚不上夜班**，建议在绵阳住一晚，别当天再赶回成都，太累  

---

## 四、最想提醒你的一句话

寿宴是给妈妈添喜气，不是让你硬扛。  
你这一周一直倒夜班，16号早上刚下夜班，**路上一定让苏敏开车**，你自己睡。到了绵阳先补觉，不然中午讲话、照顾宾客都会顶不住。

你现在先给酒楼和蛋糕店打电话，把这两个定下来。打完告诉我情况，我再帮你顺一遍有没有漏的。

### C

捋了一下，**已办完**的和**还欠着**的都给你列出来：

## ✅ 已经办好的
- **按摩椅**：5月8号已送到妈家，全款付清，这个礼物到位了。
- **致辞稿**：两分钟的稿子之前写好了，你抽空念顺就行。
- **周日顶班**：已经回绝老王了，16号那天能安心回绵阳。

## ⚠️ 还欠着、要抓紧的（就这3件）

**1. 蜀香园包间——最急，先落实这个**
你之前只是"打算打电话订"，我这边一直没记录到你确认订成功。今天或明天一定打个电话，落实：包间订没订上、几号房、两桌、16号中午几点开席。这是最不能出岔子的一件。

**2. 蛋糕——还没订**
明天（14号）去订：低糖/木糖醇的寿桃蛋糕，10–12寸，字写"福如东海 寿比南山"这类。下单时说清老人有糖尿病、用代糖，并让店家按开席时间送到酒楼。

**3. 郑婷回不回来——还没定**
4月底她公司还没批假。现在只剩3天了，得跟她确认：假批了没有、哪天到绵阳、要不要接。这关系到人数和座位安排，得给酒楼一个准数。

## 顺带
- 16号是周日，你**不上夜班**（夜班是周一到周五），所以当天不用赶，可以提前回绵阳帮忙张罗。
- 人数定了之后，跟酒楼报一下最终桌数，顺便把蛋糕送达时间也交代清楚。

要的话，我可以帮你把**给酒楼确认包间**和**问郑婷**这两条微信消息直接写出来，你复制就能发。



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [1, 4], "conditions": [{"type": 4, "condition": "Holds if 'night shifts Monday to Friday nights' means no Saturday-night shift on May 15."}]}, "C": {"critical": [1], "conditions": []}}
