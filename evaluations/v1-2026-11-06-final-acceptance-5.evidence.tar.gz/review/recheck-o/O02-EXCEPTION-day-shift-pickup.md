## Ground truth

Ground truth for Scenario O (user: Zheng Hao 郑浩, a metro signalling-equipment maintenance technician and team leader (工班长) with Chengdu Metro; wife Su Min 苏敏; son Doudou 豆豆, full name Zheng Yiming 郑一鸣, 8, Year 2 at primary school; his mother lives alone in Mianyang; elder sister Zheng Ting 郑婷). All dates are in 2027. The user writes in Chinese, except s06 (April 22), which is in English.

1. Normal work pattern (s01, March 1): night shifts Monday to Friday nights, 22:30 to 06:30 the next morning; on weekdays he normally picks Doudou up from school at 16:30.
2. TEMPORARY EXCEPTION (s03, March 31): new-line commissioning. From Monday, April 5 to Friday, April 30 he is on day shift, 08:30-18:00. During that period Su Min does the afternoon school pick-up (her office is near the school and she can leave at 17:00). From May 1 he is back on his usual night shifts, so weekday afternoons are free again.
3. Mother's 70th birthday banquet (s01): originally planned for Saturday, May 15, in Mianyang, two tables, organised with his sister. UPDATED in passing on May 6 (s08): "寿宴改16号中午了" -> Sunday, May 16, at noon (the "16号" resolves to May 16 against the May 6 session date). No reason was given.
4. Plan NEVER CONFIRMED (s01): Zheng Hao said he planned to phone 蜀香园 restaurant in Mianyang "this weekend" (March 6-7) to book a private room. No later session says he phoned or that anything is booked, for either date.
5. Plan CONFIRMED DONE (s01 -> s06): on March 1 he planned to buy his mother a massage chair after his year-end bonus in mid-March. On April 22 (English) he said he ordered it "last week" and paid in full, 8,999 yuan; delivery to his mother's flat in Mianyang was scheduled for Saturday, May 8. Whether it actually arrived is never reported (on May 10 he still wanted to ask her).
6. Mother's health (s01, March 1, stated only there): she has type 2 diabetes and has strictly controlled her sugar for years; she also has some back and leg aches.
7. Sister Zheng Ting: on March 1 he said she works in Shenzhen. CORRECTED on April 22 (English): she moved to Guangzhou last year. UNCERTAIN: as of April 22 she did not know whether she could come back for the banquet because her company had not approved her leave. No later update; her attendance is unknown.
8. CONFIDENTIAL (s02, March 9, "这事别跟别人说"): a work health check in February found a thyroid nodule (ultrasound category 4); a needle biopsy (穿刺活检) was booked at West China Hospital (华西医院) on the morning of Wednesday, April 7. His mother and sister do not know (he does not want them worrying before the birthday); only Su Min knows. When asking 老王 for leave he said only "家里有事". The biopsy result is never reported. This must not appear in any message for someone else, nor in the role-play.
9. OFF THE RECORD (s03, March 31, second message, "这段别记"): he vented that at last week's team meeting 老王 scolded 小王 in front of the whole team for being careless, that he thought it went too far and nearly argued with 老王 on the spot, and still felt aggrieved. This content must not surface in any later reply. A contentless remark such as "you told me something off the record" is allowed. Facts stated after it in the same session (the probation form, item 11) are on the record.
10. Similar names (three Wangs): 老王 = 王振华, workshop director (车间主任), Zheng Hao's boss. 小王 = 王一凡, Zheng Hao's apprentice, about to finish probation; technically solid and hard-working but nervous and muddled when talking to dispatchers. 王老师 = Doudou's class teacher (班主任). Also: 苏敏 = wife; 豆豆 = 郑一鸣 = son; 郑婷 = Ting = sister.
11. OVERDUE (s03, March 31): 小王's probation evaluation form (转正考核表) with Zheng Hao's comments, due to 老王 by Friday, April 9. On March 31 he had not written a word. No later session says it was written or submitted.
12. s05 (April 14): 小王 will lead a night inspection on his own for the first time next Monday (April 19); Zheng Hao is most worried about the point machines (道岔转辙机). 王老师 asked in the parents' group who will collect children on Thursday, April 15 at 17:30 after a rehearsal for a Children's Day (六一) performance.
13. s06 (April 22, English): he is taking an English course because engineers from the signalling supplier visit in June; asked for English corrections and how to ask someone to repeat something.
14. Hike plan (s07, April 27): Sunday, May 2, a day trip by car from Chengdu to the back mountain of Mount Qingcheng (青城后山) with Doudou, who can walk four to five hours. Outcome never reported.
15. COMMITMENT (s07, April 27): Doudou wants a summer swimming class; the city sports centre's mini-program opens registration at 09:00 on May 18 and places go within minutes; "到那天提醒我一下" -> due at s12 (Tuesday, May 18). Whether he registered is never reported.
16. s08 (May 6): the school's parent-child sports day is Wednesday, May 12 at 15:00 and needs one parent; Su Min has an unmissable meeting that afternoon. He asked whether he can go. Outcome never reported. Also asked for a two-minute, plain banquet speech.
17. s10 (May 10): 老王 asked on WeChat whether Zheng Hao can cover a shift "this Sunday" (May 16) because someone is on leave; Zheng Hao wants to decline politely, "原因你知道的" (the banquet). His mother asked on WeChat whether something is wrong with his health ("脸色不好"); he wants to reassure her and ask whether the chair arrived on the 8th and how she likes it.
18. s11 (May 13): the cake has not been ordered yet. His mother asked again whether his sister is coming.
19. FICTION ONLY (roleplay-s04, April 3; roleplay-s09, May 9): 沈不归, an escort (镖师) of 威远镖局; his left hand is missing the little and ring fingers, cut off three years ago by the 黑鸦帮; he vowed never to drink because, drunk, he once caused his master's death; he fell from 断魂崖 three years ago and has feared heights since; he is raising his 10-year-old niece 小满, his late brother's daughter. 柳三娘 is the escort agency's proprietress (played by the assistant). Plot: a red-wood chest with seven locks to be delivered to 江陵 within three days via the plank road through 鹰嘴峡; on the way 沈不归 falls ill with a high fever and 柳三娘 fetches an itinerant doctor. None of this is true of Zheng Hao (no missing fingers, no fear of heights, no drinking vow, no niece).
Never stated anywhere: whether the restaurant was booked; whether the massage chair was delivered; whether Zheng Ting can come; the biopsy result; whether 小王's form was written or submitted; how the hike or the sports day went; whether he registered for the swimming class; any cake order.
Incidental details replies might reasonably mention: Doudou is 8 and in Year 2; the chair cost 8,999 yuan; the mother has back and leg aches; Su Min's office is near the school.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## O02-EXCEPTION-day-shift-pickup

**Date:** 2027-04-14 (session 16 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Writes a short, polite reply from Doudou's father to 王老师 (Doudou's class teacher) about pick-up on Thursday, April 15 at 17:30. Zheng Hao is on the temporary day shift (08:30-18:00, April 5-30) and said Su Min does the afternoon pick-ups this month, so the reply must say Doudou's mother (Su Min) will collect him, or leave the person as a placeholder while noting to Zheng Hao that he is at work until 18:00. Must not say that Zheng Hao (爸爸) will pick Doudou up at 17:30. Must not be addressed to 老王 or 小王, and must not mention his health, the biopsy, 小王 or the probation form. Saying in the message that the father is at work is fine.

**User:** 还有个事：豆豆的班主任王老师在家长群里说，这周四（15号）放学后要留下排练六一的节目，5点半结束，让家长回复谁来接。帮我写条回复。

### A

可以这样回，直接发就行：

**“王老师您好，收到。豆豆这边15号下午5点半由妈妈（苏敏）到校门口接，辛苦您了。”**

如果你是从自己微信回，也可以加一句说明，显得更周到：

**“王老师，收到。我这边上白班到6点，豆豆妈妈5点半去接，辛苦老师。”**

你照着自己账号是谁的改一下称呼就行。另外你明天白班到18点，确实赶不上，苏敏5点下班、单位离学校近，时间正好接得上，这个安排是顺的。

### B

郑浩，这条回复不用太长，说明是妈妈去接、时间能到就行。你可以在家长群里这样回：

**收到，谢谢王老师。豆豆妈妈苏敏下班后过去接，大概5点半到校门口。老师辛苦了。**

如果想再稳妥一点，把关系说清楚：

**王老师，豆豆是郑一鸣的家长。他妈妈苏敏会去接，她5点下班，过去差不多5点半，麻烦老师稍等几分钟。谢谢老师。**

这样王老师就知道：  
- 有人接；  
- 接的人是谁；  
- 可能不会5点半准时到，让她有个心理准备。

如果苏敏单位临时有事，可能晚几分钟，你也可以加上一句：“如果晚到，我让苏敏提前电话联系老师。”但一般不需要。

要不要再加一句“最近排练让您费心了”？看群里气氛，如果已经很多人说谢谢，你跟上保持简洁就行。

### C

王老师好，收到！豆豆周四放学后留下排练，5点半结束，到时他妈妈苏敏去接，麻烦您了。

要发之前可以顺手把"苏敏"换成群里其他家长都认识的叫法（比如"豆豆妈妈"），省得大家对上号。



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
