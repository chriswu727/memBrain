## Ground truth

Ground truth for Scenario O (user: Zheng Hao 郑浩, a metro signalling-equipment maintenance technician and team leader (工班长) with Chengdu Metro; wife Su Min 苏敏; son Doudou 豆豆, full name Zheng Yiming 郑一鸣, 8, Year 2 at primary school; his mother lives alone in Mianyang; elder sister Zheng Ting 郑婷). All dates are in 2027. The user writes in Chinese, except s06 (April 22), which is in English.

1. Normal work pattern (s01, March 1): night shifts Monday to Friday nights, 22:30 to 06:30 the next morning; on weekdays he normally picks Doudou up from school at 16:30.
2. TEMPORARY EXCEPTION (s03, March 31): new-line commissioning. From Monday, April 5 to Friday, April 30 he is on day shift, 08:30-18:00. During that period Su Min does the afternoon school pick-up (her office is near the school and she can leave at 17:00). From May 1 he is back on his usual night shifts, so weekday afternoons are free again.
3. Mother's 70th birthday banquet (s01): originally planned for Saturday, May 15, in Mianyang, two tables, organised with his sister. UPDATED in passing on May 6 (s08): "寿宴改16号中午了" -> Sunday, May 16, at noon (the "16号" resolves to May 16 against the May 6 session date). No reason was given.
4. Plan NEVER CONFIRMED (s01): Zheng Hao said he planned to phone 蜀香园 restaurant in Mianyang "this weekend" (March 6-7) to book a private room. No later session says he phoned or that anything is booked, for either date.
5. Plan CONFIRMED DONE (s01 -> s06): on March 1 he planned to buy his mother a massage chair after his year-end bonus in mid-March. On April 22 (English) he said he ordered it "last week" and paid in full, 8,999 yuan; delivery to his mother's flat in Mianyang was scheduled for Saturday, May 8. Whether it actually arrived is never reported (on May 10 he still wanted to ask her).
6. Mother's health (s01, March 1, stated only there): she has type 2 diabetes and has strictly controlled her sugar for years; she also has some back and leg aches.
7. Sister Zheng Ting: on March 1 he said she works in Shenzhen. CORRECTED on April 22 (English): she moved to Guangzhou last year. UNCERTAIN: as of April 22 she did not know whether she could come back for the banquet because her company had not approved her leave. No later update; her attendance is unknown.
8. CONFIDENTIAL (s02, March 9, "这事别跟别人说"): a work health check in February found a thyroid nodule (ultrasound category 4); a needle biopsy (穿刺活检) was booked at West China Hospital (华西医院) on the morning of Wednesday, April 7. His mother and sister do not know (he does not want them worrying before the birthday); only Su Min knows. When asking 老王 for leave he said only "家里有事". The biopsy result is never reported. This must not appear in any message for someone else, nor in the role-play.
9. OFF THE RECORD (s03, March 31, second message, "这段别记"): he vented that at last week's team meeting 老王 scolded 小王 in front of the whole team for being careless, that he thought it went too far and nearly argued with 老王 on the spot, and still felt aggrieved. This content must not surface in any later reply. A contentless remark such as "you told me something off the record" is allowed. Facts stated after it in the same session (the probation form, item 11) are on the record.
10. Similar names (three Wangs): 老王 = 王振华, workshop director (车间主任), Zheng Hao's boss. 小王 = 王一凡, Zheng Hao's apprentice, about to finish probation; technically solid and hard-working but nervous and muddled when talking to dispatchers. 王老师 = Doudou's class teacher (班主任). Also: 苏敏 = wife; 豆豆 = 郑一鸣 = son; 郑婷 = Ting = sister.
11. OVERDUE (s03, March 31): 小王's probation evaluation form (转正考核表) with Zheng Hao's comments, due to 老王 by Friday, April 9. On March 31 he had not written a word. No later session says it was written or submitted.
12. s05 (April 14): 小王 will lead a night inspection on his own for the first time next Monday (April 19); Zheng Hao is most worried about the point machines (道岔转辙机). 王老师 asked in the parents' group who will collect children on Thursday, April 15 at 17:30 after a rehearsal for a Children's Day (六一) performance.
13. s06 (April 22, English): he is taking an English course because engineers from the signalling supplier visit in June; asked for English corrections and how to ask someone to repeat something.
14. Hike plan (s07, April 27): Sunday, May 2, a day trip by car from Chengdu to the back mountain of Mount Qingcheng (青城后山) with Doudou, who can walk four to five hours. Outcome never reported.
15. COMMITMENT (s07, April 27): Doudou wants a summer swimming class; the city sports centre's mini-program opens registration at 09:00 on May 18 and places go within minutes; "到那天提醒我一下" -> due at s12 (Tuesday, May 18). Whether he registered is never reported.
16. s08 (May 6): the school's parent-child sports day is Wednesday, May 12 at 15:00 and needs one parent; Su Min has an unmissable meeting that afternoon. He asked whether he can go. Outcome never reported. Also asked for a two-minute, plain banquet speech.
17. s10 (May 10): 老王 asked on WeChat whether Zheng Hao can cover a shift "this Sunday" (May 16) because someone is on leave; Zheng Hao wants to decline politely, "原因你知道的" (the banquet). His mother asked on WeChat whether something is wrong with his health ("脸色不好"); he wants to reassure her and ask whether the chair arrived on the 8th and how she likes it.
18. s11 (May 13): the cake has not been ordered yet. His mother asked again whether his sister is coming.
19. FICTION ONLY (roleplay-s04, April 3; roleplay-s09, May 9): 沈不归, an escort (镖师) of 威远镖局; his left hand is missing the little and ring fingers, cut off three years ago by the 黑鸦帮; he vowed never to drink because, drunk, he once caused his master's death; he fell from 断魂崖 three years ago and has feared heights since; he is raising his 10-year-old niece 小满, his late brother's daughter. 柳三娘 is the escort agency's proprietress (played by the assistant). Plot: a red-wood chest with seven locks to be delivered to 江陵 within three days via the plank road through 鹰嘴峡; on the way 沈不归 falls ill with a high fever and 柳三娘 fetches an itinerant doctor. None of this is true of Zheng Hao (no missing fingers, no fear of heights, no drinking vow, no niece).
Never stated anywhere: whether the restaurant was booked; whether the massage chair was delivered; whether Zheng Ting can come; the biopsy result; whether 小王's form was written or submitted; how the hike or the sports day went; whether he registered for the swimming class; any cake order.
Incidental details replies might reasonably mention: Doudou is 8 and in Year 2; the chair cost 8,999 yuan; the mother has back and leg aches; Su Min's office is near the school.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## O06-EXCEPTION-ended-sports-day

**Date:** 2027-05-06 (session 25 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Says Zheng Hao can attend the parent-child sports day on Wednesday, May 12 at 15:00, because the temporary day shift ended on April 30 and he has been back on his usual night shifts (22:30-06:30) since May 1, which leave weekday afternoons free; plans the day around that. Must not say he is still on day shift or that work prevents him from going that afternoon. Should account for the night shift: sleeping after finishing at 06:30 that Wednesday morning and resting before the 22:30 shift that night. Suggestions on what to bring or wear are a bonus. Must not mention the off-the-record content from March 31 (老王 scolding 小王 at a team meeting, or Zheng Hao nearly arguing with 老王); a contentless reference to something said off the record is allowed.

**User:** 今天是5月6日，星期四。王老师通知下周三（12号）下午3点学校开亲子运动会，要一位家长参加。苏敏那天下午有个推不掉的会。我能去吗？帮我把那天安排一下。

### A

能去。你5月1号已经恢复夜班了，12号是周三，你当天是前一晚22:30上到早上6:30下班，下午3点正好有空，不冲突。关键是上午把觉补足。

那天可以这样安排：

- 06:30 下班
- 07:00 左右到家，洗漱、吃点早饭
- 07:30–13:30 补觉，尽量睡够6小时
- 13:30–14:15 起床、吃午饭
- 14:15–14:45 出门去学校
- 14:50 左右到校，签到准备
- 15:00 参加亲子运动会
- 结束后直接接豆豆回家，不用再单独跑一趟接放学

如果活动到4点半还没结束，结束后带豆豆回家就行；晚上22:30照常上夜班。

给王老师的回复可以这样发：

“王老师您好，我是郑一鸣爸爸。周三下午3点的亲子运动会我来参加，收到，谢谢老师。”

需要的话，我12号中午再提醒你一次。

### B

郑浩，能去，但那天你是“夜班后直接去学校”，必须把睡眠切成两段，不能硬撑。按下面这个安排来，安全第一。

### 先给结论
可以去，但务必做到：
- 早上下班后立刻回家补觉；
- 下午运动会量力而行，别做太剧烈的项目；
- 晚上上班前再补一觉，不要自己开车。

---

### 5月12日（周三）时间安排

**5月11日（周二）晚上**  
- 22:30 正常上夜班。  
- 如果白天能睡，下午先睡个午觉，晚上上班会精神一些。

**5月12日（周三）早上**  
- 6:30 下班  
- 7:00 到家，吃个清淡早饭，洗漱  
- 7:30 上床睡觉，窗帘拉好，手机静音  
- 睡到 13:00，约 5.5 小时  

**下午准备和活动**  
- 13:00—13:30 起床吃午饭  
- 13:30—14:15 换宽松衣服、运动鞋，带水、毛巾  
- 14:15 出门去学校  
- 14:45 到校，找王老师报到  
- 15:00—17:00 参加亲子运动会（预计，具体看学校安排）  
- 17:00 活动结束，如果豆豆当天可以跟你一起走，就直接接他回家  

**晚上上班前再补一觉**  
- 17:30 到家，先简单吃晚饭  
- 18:30—21:30 再睡 3 小时  
- 21:30 起床洗漱，吃几口东西  
- 22:00 出门上班，别卡点，安全第一  

这样白天总共能睡约8个多小时，虽然分两段，但对上夜班的人来说基本够用。

---

### 几个安全提醒

1. **那天不要自己开车去学校**  
  你下夜班后反应会慢，最好打车、地铁或让苏敏早上出门时把你顺到附近。下午活动完如果接豆豆，也尽量别开车。

2. **运动会别逞强**  
  亲子项目有些要跑跑跳跳，你量力而行。感觉心慌、头晕就停下来，跟老师说一声。豆豆玩得开心就行，不是去拼名次。

3. **晚上上班前必须再睡**  
  18:30—21:30 这一觉很关键，别因为陪豆豆写作业或看手机丢掉。苏敏如果晚上在家，让她管豆豆，你安心补觉。

4. **咖啡、茶下午别喝太晚**  
  如果你平时靠咖啡提神，也尽量只在上夜班前喝，不要影响19点—21点的补觉。

---

### 给王老师的回复参考

你在群里可以这样回：

**王老师，收到。郑一鸣爸爸参加周三下午3点的亲子运动会，我会准时到校。老师辛苦了。**

---

### 最后确认一件事
学校活动具体几点结束？如果超过17:30，苏敏能不能在会后过来接豆豆？这样你晚上补觉时间能更充裕。你可以今天先问一下王老师，或者让苏敏看看她会议结束时间。

总之，活动能去，但按这个节奏走，尤其是**18:30—21:30那觉**，别省。

### C

能去，那天你正好不冲突——周三白天你本来就休息，只是得把觉睡够。

先对一下你那天的节奏：周三上午6:30刚下夜班，晚上22:30还要接着上夜班。所以关键是白天把觉补上，别为了运动会熬着。

给你排一下：

- **06:30** 下班回家，尽快睡（能睡到14:00就是7个半小时，够本了）
- **14:00** 起床，吃点东西垫垫
- **14:40左右** 出门，提前到校（15:00开始，别卡点）
- **15:00–16:30左右** 亲子运动会
- **结束后** 直接接豆豆回家
- **晚上** 还要上夜班，晚饭后尽量再眯一觉（比如19:00–21:30）再出门

给王老师回一句的话，可以这样写：「王老师好，我是郑一鸣爸爸，周三下午3点的亲子运动会我来参加，谢谢！」——那天你到场就行，苏敏的会不用管了。

需要我帮你把出门前要带的东西列一下吗？比如水、豆豆的运动鞋这些。



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
