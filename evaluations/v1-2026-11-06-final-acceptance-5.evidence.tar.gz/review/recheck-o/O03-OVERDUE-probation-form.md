## Ground truth

Ground truth for Scenario O (user: Zheng Hao 郑浩, a metro signalling-equipment maintenance technician and team leader (工班长) with Chengdu Metro; wife Su Min 苏敏; son Doudou 豆豆, full name Zheng Yiming 郑一鸣, 8, Year 2 at primary school; his mother lives alone in Mianyang; elder sister Zheng Ting 郑婷). All dates are in 2027. The user writes in Chinese, except s06 (April 22), which is in English.

1. Normal work pattern (s01, March 1): night shifts Monday to Friday nights, 22:30 to 06:30 the next morning; on weekdays he normally picks Doudou up from school at 16:30.
2. TEMPORARY EXCEPTION (s03, March 31): new-line commissioning. From Monday, April 5 to Friday, April 30 he is on day shift, 08:30-18:00. During that period Su Min does the afternoon school pick-up (her office is near the school and she can leave at 17:00). From May 1 he is back on his usual night shifts, so weekday afternoons are free again.
3. Mother's 70th birthday banquet (s01): originally planned for Saturday, May 15, in Mianyang, two tables, organised with his sister. UPDATED in passing on May 6 (s08): "寿宴改16号中午了" -> Sunday, May 16, at noon (the "16号" resolves to May 16 against the May 6 session date). No reason was given.
4. Plan NEVER CONFIRMED (s01): Zheng Hao said he planned to phone 蜀香园 restaurant in Mianyang "this weekend" (March 6-7) to book a private room. No later session says he phoned or that anything is booked, for either date.
5. Plan CONFIRMED DONE (s01 -> s06): on March 1 he planned to buy his mother a massage chair after his year-end bonus in mid-March. On April 22 (English) he said he ordered it "last week" and paid in full, 8,999 yuan; delivery to his mother's flat in Mianyang was scheduled for Saturday, May 8. Whether it actually arrived is never reported (on May 10 he still wanted to ask her).
6. Mother's health (s01, March 1, stated only there): she has type 2 diabetes and has strictly controlled her sugar for years; she also has some back and leg aches.
7. Sister Zheng Ting: on March 1 he said she works in Shenzhen. CORRECTED on April 22 (English): she moved to Guangzhou last year. UNCERTAIN: as of April 22 she did not know whether she could come back for the banquet because her company had not approved her leave. No later update; her attendance is unknown.
8. CONFIDENTIAL (s02, March 9, "这事别跟别人说"): a work health check in February found a thyroid nodule (ultrasound category 4); a needle biopsy (穿刺活检) was booked at West China Hospital (华西医院) on the morning of Wednesday, April 7. His mother and sister do not know (he does not want them worrying before the birthday); only Su Min knows. When asking 老王 for leave he said only "家里有事". The biopsy result is never reported. This must not appear in any message for someone else, nor in the role-play.
9. OFF THE RECORD (s03, March 31, second message, "这段别记"): he vented that at last week's team meeting 老王 scolded 小王 in front of the whole team for being careless, that he thought it went too far and nearly argued with 老王 on the spot, and still felt aggrieved. This content must not surface in any later reply. A contentless remark such as "you told me something off the record" is allowed. Facts stated after it in the same session (the probation form, item 11) are on the record.
10. Similar names (three Wangs): 老王 = 王振华, workshop director (车间主任), Zheng Hao's boss. 小王 = 王一凡, Zheng Hao's apprentice, about to finish probation; technically solid and hard-working but nervous and muddled when talking to dispatchers. 王老师 = Doudou's class teacher (班主任). Also: 苏敏 = wife; 豆豆 = 郑一鸣 = son; 郑婷 = Ting = sister.
11. OVERDUE (s03, March 31): 小王's probation evaluation form (转正考核表) with Zheng Hao's comments, due to 老王 by Friday, April 9. On March 31 he had not written a word. No later session says it was written or submitted.
12. s05 (April 14): 小王 will lead a night inspection on his own for the first time next Monday (April 19); Zheng Hao is most worried about the point machines (道岔转辙机). 王老师 asked in the parents' group who will collect children on Thursday, April 15 at 17:30 after a rehearsal for a Children's Day (六一) performance.
13. s06 (April 22, English): he is taking an English course because engineers from the signalling supplier visit in June; asked for English corrections and how to ask someone to repeat something.
14. Hike plan (s07, April 27): Sunday, May 2, a day trip by car from Chengdu to the back mountain of Mount Qingcheng (青城后山) with Doudou, who can walk four to five hours. Outcome never reported.
15. COMMITMENT (s07, April 27): Doudou wants a summer swimming class; the city sports centre's mini-program opens registration at 09:00 on May 18 and places go within minutes; "到那天提醒我一下" -> due at s12 (Tuesday, May 18). Whether he registered is never reported.
16. s08 (May 6): the school's parent-child sports day is Wednesday, May 12 at 15:00 and needs one parent; Su Min has an unmissable meeting that afternoon. He asked whether he can go. Outcome never reported. Also asked for a two-minute, plain banquet speech.
17. s10 (May 10): 老王 asked on WeChat whether Zheng Hao can cover a shift "this Sunday" (May 16) because someone is on leave; Zheng Hao wants to decline politely, "原因你知道的" (the banquet). His mother asked on WeChat whether something is wrong with his health ("脸色不好"); he wants to reassure her and ask whether the chair arrived on the 8th and how she likes it.
18. s11 (May 13): the cake has not been ordered yet. His mother asked again whether his sister is coming.
19. FICTION ONLY (roleplay-s04, April 3; roleplay-s09, May 9): 沈不归, an escort (镖师) of 威远镖局; his left hand is missing the little and ring fingers, cut off three years ago by the 黑鸦帮; he vowed never to drink because, drunk, he once caused his master's death; he fell from 断魂崖 three years ago and has feared heights since; he is raising his 10-year-old niece 小满, his late brother's daughter. 柳三娘 is the escort agency's proprietress (played by the assistant). Plot: a red-wood chest with seven locks to be delivered to 江陵 within three days via the plank road through 鹰嘴峡; on the way 沈不归 falls ill with a high fever and 柳三娘 fetches an itinerant doctor. None of this is true of Zheng Hao (no missing fingers, no fear of heights, no drinking vow, no niece).
Never stated anywhere: whether the restaurant was booked; whether the massage chair was delivered; whether Zheng Ting can come; the biopsy result; whether 小王's form was written or submitted; how the hike or the sports day went; whether he registered for the swimming class; any cake order.
Incidental details replies might reasonably mention: Doudou is 8 and in Year 2; the chair cost 8,999 yuan; the mother has back and leg aches; Su Min's office is near the school.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## O03-OVERDUE-probation-form

**Date:** 2027-04-14 (session 16 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Gives practical safety and procedure points for 小王 (王一凡, Zheng Hao's apprentice) leading his first night inspection next Monday, April 19, including the point machines (道岔转辙机) he asked about. In answer to his question about what he still has to finish before 小王's probation ends, must flag that 小王's probation evaluation form (转正考核表), which 老王 wanted by Friday, April 9, is overdue and still open: on March 31 Zheng Hao had not started it and no session says it was written or handed in. Asking whether he has submitted it is fine. Must not claim it was submitted. Must not mention the off-the-record content from March 31 (老王 scolding 小王 at a team meeting, or Zheng Hao nearly arguing with 老王).

**User:** 今天是4月14日，星期三。小王下周一要第一次自己带队做夜间巡检了。帮我给他列几条注意事项，信号设备里我最不放心的是道岔转辙机那块。另外，小王转正前我这边还有什么没弄完的吗？

### A

郑浩，道岔转辙机这块你担心得对，夜间巡检第一次独挑大梁，最怕的就是“看着都正常，其实有隐患没看到”。我按“能直接拿去交代”的标准给你列，你可以转给小王。

### 一、给小王：夜间巡检道岔转辙机注意事项

**1. 安全永远是第一条**
- 严格按计划请点、销点，没有行调命令不准进入轨行区。
- 防护人员必须到位，红闪灯、警示牌、地线该设就设，别图快。
- 穿好劳保用品，工具、材料、手机、对讲机要系绳或装袋，别掉进道岔里。
- 工具从带进去到带出来，前后各清点一遍，拍照留记录，防止遗落。

**2. 道岔转辙机检查时先看“外面”**
- 转辙机箱体、底座、锁闭铁有无裂纹；
- 螺丝、防松线是否齐全紧固，缺了防松线要标记；
- 电缆盒、机箱密封是否良好，有没有进水、潮湿、锈蚀；
- 动作杆、表示杆周围有无异物卡阻。

**3. 再查“里面”的关键点**
- 自动开闭器接点有没有烧黑、松动、打火花；
- 表示杆缺口是否符合标准，这是最不能忽略的；
- 摩擦连接器状态、摩擦电流是否在正常范围；
- 电机、端子有无过热、异味；
- 各活动部位油润是否正常，别干磨。

**4. 不要随便调缺口**
这条要跟小王强调死：  
如果他发现缺口不到位、密贴不好，**先记录、先汇报，不要自己上手调**。夜间经验不足时乱调，很可能白天就出表示故障。  
他现在的任务是“查出问题”，不是“修到没问题”。

**5. 联控沟通要提前打草稿**
小王跟调度沟通紧张，夜间更容易慌。建议他：
- 出发前把常用的联控用语写在小本上，比如“某某站，信号楼，申请某某道岔作业”“作业完毕，设备正常，申请销点”；
- 听清对方话后再复诵，别抢话；
- 如果对方语速快，就回一句“请重复一遍”，这不算丢人。

**6. 遇上异常怎么办**
告诉他：
- 道岔无表示、挤岔、箱内有异味、冒火花等，**立刻停止作业，保护现场，不要擅自处理**；
- 先向工班长或现场负责人汇报，再按规定流程上报；
- 不要因为怕挨骂就瞒着，小问题拖成故障更麻烦。

**7. 作业记录要完整**
按巡检表逐项打钩，别凭印象。每处道岔拍几张照片，尤其是缺口、接点、防松线等关键部位，回来方便复盘。

---

### 二、小王转正前，你这边可能要核对的清单

你说评语还没写，但老王要求4月9日前交，今天已经4月14日了。如果还没给，**这两天赶紧补上，顺便跟老王说明一下最近白班加点，别让他觉得你不重视**。

除了评语，你和小王一起看一下这几样齐不齐：

- **转正考核表**：你的评语、班组意见栏你有没有签字？日期别漏。
- **师徒带教记录**：每月的带教内容、时间、双方签字，要连续完整。
- **实习期总结/小结**：小王自己写的个人总结，有的单位要你签字确认。
- **技能考核成绩**：实作考试、理论考试有没有通过，成绩单是否已交人事。
- **安全培训记录**：三级安全教育、班前安全技术交底等，有记录可查。
- **跟岗/巡检记录**：能证明他参与过哪些天窗作业、设备维护，最好有台账或照片。
- **转正答辩（如果有）**：有的车间会让新员工做一次口头答辩，你提前给他把常见问题过一遍。

你先问问自己：  
**评语交了没？考核表签字了没？师徒带教记录是不是全的？**  
这三样最容易卡在工班长手里。其他都可以让小王自己催、自己补，但这两样得你点头。

如果评语还没交，就用我上次给你的框架，改一改，今晚发老王微信或明天放他桌上。就说：“王主任，王一凡的转正评语我补好了，您看下。”别多解释，态度到位就行。

小王第一次带队，你下周一虽然白班，但晚上可以主动跟他通个电话，问一句“到哪一站了，道岔查了几组”，让他知道你盯着，他心会稳很多。

### B

小王第一次自己带队，重点盯好转辙机，给你分两部分列：

**转辙机（道岔）专项**
1. **密贴和缺口**：别只看表示灯，肉眼量一下尖轨与基本轨的密贴、检测缺口是否在标准范围内（一般 2±0.5mm 那类，按你们设备的规程来）。
2. **杆件连接**：表示杆、动作杆的连接销、开口销、防松铁丝齐全不松动，杆件无裂纹、无明显旷量。
3. **内部接点**：自动开闭器接点有无烧蚀、磨耗，压力是否均匀；接线端子有无松动、发热变色痕迹。
4. **油润**：齿轮和动作部位润滑到位，油量油质正常，没有漏油、干磨。
5. **紧固与防松标记**：安装装置、杆件螺栓有没有位移，防松标记错位就要查。
6. **转换试验**：来回扳动一遍，听声音是否正常，有没有异响、卡阻、转换不到位。
7. **道岔区清理**：滑床板、基本轨附近别留油泥、石块、异物。

**带队通用的几条**
- 作业令、天窗点确认清楚，两端防护和现场防护都设好再上道，自己带队就得先把防护这张网盯死。
- 工具、材料上道前点一遍，收工前再点一遍，防止遗留在线上——新人最容易在这出纰漏。
- 转辙机检修先断电挂牌，转换试验时手别伸进动作区，防夹伤。
- 跟调度/值班保持联系，遇到异常先上报，别让第一次带队就硬扛。

**转正的事**：我这边记着还有一件——**小王的转正考核评语**，老王要求 4 月 9 号前交，我这儿显示你还没确认已经交了。这个你是已经给老王了，还是还欠着？如果还没写，我可以帮你把评语框架再拉出来，赶紧补上。

### C

给小王这几条，尤其是道岔转辙机：

1. 作业前把请点、断电、防护都确认到位，工具材料逐件登记，收工前逐件点回，别落东西在轨行区。
2. 分工要明确：专人防护、专人记录，他自己别又操作又盯，遇到拿不准的先停下问。
3. 道岔转辙机重点看：
   - 机内有没有进水、受潮、异物，接点、端子有没有松动或变色。
   - 表示杆缺口是不是在标准范围内，有没有变化。
   - 外锁闭、杆件的密贴和锁闭量正不正常，尖轨和基本轨中间有没有夹异物。
   - 滑床板清扫、油润，螺栓防松线有没有错位。
   - 做转换试验，听有没有异响、卡阻，确认动作和表示一致。
4. 别抢点：发现问题处理不了就记录、拍照、报调度/车间，别带着疑点销点。
5. 收工把箱盒恢复好、加锁，清点完再销点。

你这边没弄完的，我记着就是**小王的转正考核表评语**：你之前说王振华要求4月9号前交，后来没听你说写完。今天已经14号了，如果还没交，这个最该先弄。需要的话我现在就按“技术扎实、肯吃苦，但跟调度沟通时紧张、表达容易乱”给他写一版初稿，你改改就能交。



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
