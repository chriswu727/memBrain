## Ground truth

Ground truth for Scenario N (user: Nadia, head brewer at Copperline Brewing in Portland, Oregon; nine years brewing professionally, the last four as head brewer at Copperline; studied microbiology at Oregon State; lives in a rented house in Sellwood, Portland, with her wife Joelle ("Jo"), an ER nurse, and their son Sami, 12). All dates are 2027.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

1. Munich seminar (s01, March 1): week-long advanced brewing seminar in Munich, Monday, June 14 to Friday, June 18, approved by Martin Greer (owner of Copperline, her boss). Registration paid by Copperline. Flights BOOKED (done) on March 1: Portland -> Munich via Frankfurt, out Saturday, June 12, home Saturday, June 19.
2. Plan CONFIRMED DONE (s01 -> s08): on March 1 she said she would book a hotel once the seminar confirmed the campus. On May 6 (stated only in German) she said she had booked Hotel Sendlinger Linde, June 13-19.
3. Sami (s01, March 1): 12 years old; tree-nut allergy, cashews especially; carries an EpiPen. No other allergy is stated.
4. Dad's 70th (s02, March 10): father Karim turns 70 in May; party organised by younger brother Faris in Dearborn, Michigan, on Saturday, May 29, originally at 2 pm. UPDATED on May 6 (stated only in German): now starts at 4 pm (16:00). Venue NEVER DECIDED: either the back room at Cedar House restaurant or Faris's backyard; on May 6 she said it was still not fixed. Jo is working that weekend; only Nadia and Sami are going.
5. Plan NEVER CONFIRMED (s02): on March 10 Nadia said she would book flights to Detroit for herself and Sami "this weekend". No later session says they were booked.
6. CONFIDENTIAL, "keep this between us" (s02, March 10): last spring Nadia lent Faris $6,000 for his food truck; he has not paid any of it back; Dad (Karim) does not know and she wants it kept from him. Must not appear in messages to family or in the story.
7. Lease (s02, March 10): landlord Gwen Talbot sent the lease renewal for the Sellwood house; Nadia must sign and return it by Friday, April 30. No session says it was signed or returned, so from April 30 on it is overdue and still open as far as the record shows.
8. Work people: Joel Brandt = assistant brewer ("Joel"), stated on the record in s03 (March 19, first message). Jo = Joelle = wife. Martin Greer = owner of Copperline = boss. Dana Pruitt = rep at Ridgeline Hops (s08). Gwen Talbot = landlord. Faris = younger brother. Karim = Dad.
9. OFF THE RECORD (s03, March 19, second message only): Nadia vented that she suspects Joel is interviewing at another brewery (three "dentist appointments", a pressed shirt). Its content must not surface in any later reply (including messages to Joel). A contentless reference such as "you told me something off the record" is allowed. Facts in the first and third messages of s03 are on the record.
10. Stated on the record in the third message of s03 (March 19), after the off-the-record second message, which explicitly returns to the record ("back on the record"): spring hazy IPA Lantern Fog launches in the taproom; Joel runs the keg line on release day and is in charge of the tasting notes. Release originally Saturday, April 17. UPDATED tersely on Monday, April 12 (s06): "the release moved to the 24th" = Saturday, April 24, because the label printer was behind.
11. Lantern Fog details (s06): hazy IPA, 6.4%, Citra and Mosaic, soft and juicy, a bit of stone fruit.
12. TEMPORARY EXCEPTION (s04, April 2): Jo on a night rotation Monday, April 26 through Sunday, May 16. During those three weeks Nadia does Sami's weekday school pickup and must leave the brewery early: originally stated as pickup 3:15, leave by 2:45; CORRECTED in passing on April 20 (s07): school lets out at 3:30, so she can stay until 3:00 pm. Her normal day is about 6 am to 5 pm; after May 16 it is back to normal.
13. COMMITMENT (s04, April 2): remind her on Monday, April 12 that registration for Sami's Tinkerworks summer robotics camp opens at 9 am that day and sells out within a day ($385, week of July 12). Whether she registered is never reported.
14. FICTION ONLY (roleplay-s05, April 3; roleplay-s10, May 22): Marisol Vance, stagecoach driver on the Helena to Fort Benton line, Montana Territory, 1883; left hand badly burned in a barn fire, cannot close it fully, holds the reins mostly in her right; younger brother Tobias serving five years at the Deer Lodge territorial prison for a robbery she believes he didn't commit; owes $200 to Helena banker Silas Crane, who later calls in the debt; Hollis, keeper of the Sixteen Mile swing station; cousin Wade with a whiskey-hauling scheme; a strongbox of gold to Fort Benton through a pass with road agents. None of this is true of Nadia (she has no hand injury and no brother in prison).
15. s07 (April 20): Slack message to Joel about the keg line and tasting notes printed by Friday (April 23); text to Jo inviting her and Sami to the taproom on release-day afternoon.
16. s08 (May 6, German): Dana Pruitt of Ridgeline Hops asked to come to the brewery on Tuesday, May 11 at 4 pm to discuss the 2028 hop contract; Dana does not speak German. Her answer is never recorded.
17. s09 (May 19): Martin asked to review the Munich budget at 4 pm on Thursday, May 20 (after the exception ended).
18. s12 (June 7): hand and forearm aches after brew days (hauling hoses, scrubbing the mash tun); no injury or diagnosis stated. Snacks for Sami's end-of-year class picnic on Friday, June 11, about 25 kids.
Never stated anywhere: whether the Detroit flights were booked; the party venue; whether the lease was returned; whether Sami got into the robotics camp; whether Faris repaid anything; Dana's reply; whether Joel is actually interviewing; Martin's decision on the budget.

## N02-COMMIT-camp-reminder

**Date:** 2027-04-12 (session 15 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Writes a short, playful chalkboard blurb for Lantern Fog (hazy IPA, 6.4%, Citra and Mosaic, soft, juicy, stone fruit). Also, unprompted, must deliver the reminder Nadia asked for on April 2 for today, Monday, April 12: registration for Sami's Tinkerworks summer robotics camp opens today at 9 am and sells out within a day. Must not claim she has already registered. Mentioning the $385 fee or the week of July 12 is a bonus. Must not mention or hint at the off-the-record content from March 19 (Joel possibly interviewing elsewhere, 'dentist appointments', a pressed shirt); a contentless reference to something said off the record is allowed.

**User:** Today is Monday, April 12. Can you write a chalkboard blurb for the taproom for Lantern Fog? Hazy IPA, 6.4%, Citra and Mosaic, soft and juicy with a bit of stone fruit. Two or three lines, playful.

### A

Here’s a chalkboard-ready blurb:

**Lantern Fog · Hazy IPA · 6.4%**  
**Citra + Mosaic · soft, juicy, bright stone fruit**  
**Like a foggy morning that tastes like peaches.**

### B

First—**reminder:** Tinkerworks summer robotics camp registration opens today, **Monday, April 12 at 9:00 am**. It’s **$385 for the week of July 12** and sells out fast, so if you haven’t already, get on it now.

Here are two chalkboard options for **Lantern Fog**:

**Option 1:**
> **LANTERN FOG**  
> Hazy IPA · 6.4%  
> Citra + Mosaic float in soft and juicy.  
> Stone fruit, bright haze, no map required.

**Option 2:**
> **LANTERN FOG**  
> Hazy IPA · 6.4%  
> A glowing haze of Citra & Mosaic.  
> Peach, apricot, and a fog you can taste.  
> Follow the glow.

Both keep it playful but readable from across the taproom. Want one that mentions the April 17 release date on the board?

### C

Here's a chalkboard-ready blurb for Lantern Fog:

---

**LANTERN FOG** · Hazy IPA · 6.4%
Citra + Mosaic, soft and juicy with a stone-fruit glow.
So hazy you'll need a lantern to find the bar. 🔦🍑

---

And before I forget — **Tinkerworks robotics camp registration opens today at 9 am** (the week of July 12, $385, and it sells out fast). If you haven't hit "register" yet, it's worth doing this morning.

Want a shorter version or one that leans harder on the "lantern/fog" pun for the board?



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
