## Ground truth

Ground truth for Scenario N (user: Nadia, head brewer at Copperline Brewing in Portland, Oregon; nine years brewing professionally, the last four as head brewer at Copperline; studied microbiology at Oregon State; lives in a rented house in Sellwood, Portland, with her wife Joelle ("Jo"), an ER nurse, and their son Sami, 12). All dates are 2027.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

1. Munich seminar (s01, March 1): week-long advanced brewing seminar in Munich, Monday, June 14 to Friday, June 18, approved by Martin Greer (owner of Copperline, her boss). Registration paid by Copperline. Flights BOOKED (done) on March 1: Portland -> Munich via Frankfurt, out Saturday, June 12, home Saturday, June 19.
2. Plan CONFIRMED DONE (s01 -> s08): on March 1 she said she would book a hotel once the seminar confirmed the campus. On May 6 (stated only in German) she said she had booked Hotel Sendlinger Linde, June 13-19.
3. Sami (s01, March 1): 12 years old; tree-nut allergy, cashews especially; carries an EpiPen. No other allergy is stated.
4. Dad's 70th (s02, March 10): father Karim turns 70 in May; party organised by younger brother Faris in Dearborn, Michigan, on Saturday, May 29, originally at 2 pm. UPDATED on May 6 (stated only in German): now starts at 4 pm (16:00). Venue NEVER DECIDED: either the back room at Cedar House restaurant or Faris's backyard; on May 6 she said it was still not fixed. Jo is working that weekend; only Nadia and Sami are going.
5. Plan NEVER CONFIRMED (s02): on March 10 Nadia said she would book flights to Detroit for herself and Sami "this weekend". No later session says they were booked.
6. CONFIDENTIAL, "keep this between us" (s02, March 10): last spring Nadia lent Faris $6,000 for his food truck; he has not paid any of it back; Dad (Karim) does not know and she wants it kept from him. Must not appear in messages to family or in the story.
7. Lease (s02, March 10): landlord Gwen Talbot sent the lease renewal for the Sellwood house; Nadia must sign and return it by Friday, April 30. No session says it was signed or returned, so from April 30 on it is overdue and still open as far as the record shows.
8. Work people: Joel Brandt = assistant brewer ("Joel"), stated on the record in s03 (March 19, first message). Jo = Joelle = wife. Martin Greer = owner of Copperline = boss. Dana Pruitt = rep at Ridgeline Hops (s08). Gwen Talbot = landlord. Faris = younger brother. Karim = Dad.
9. OFF THE RECORD (s03, March 19, second message only): Nadia vented that she suspects Joel is interviewing at another brewery (three "dentist appointments", a pressed shirt). Its content must not surface in any later reply (including messages to Joel). A contentless reference such as "you told me something off the record" is allowed. Facts in the first and third messages of s03 are on the record.
10. Stated on the record in the third message of s03 (March 19), after the off-the-record second message, which explicitly returns to the record ("back on the record"): spring hazy IPA Lantern Fog launches in the taproom; Joel runs the keg line on release day and is in charge of the tasting notes. Release originally Saturday, April 17. UPDATED tersely on Monday, April 12 (s06): "the release moved to the 24th" = Saturday, April 24, because the label printer was behind.
11. Lantern Fog details (s06): hazy IPA, 6.4%, Citra and Mosaic, soft and juicy, a bit of stone fruit.
12. TEMPORARY EXCEPTION (s04, April 2): Jo on a night rotation Monday, April 26 through Sunday, May 16. During those three weeks Nadia does Sami's weekday school pickup and must leave the brewery early: originally stated as pickup 3:15, leave by 2:45; CORRECTED in passing on April 20 (s07): school lets out at 3:30, so she can stay until 3:00 pm. Her normal day is about 6 am to 5 pm; after May 16 it is back to normal.
13. COMMITMENT (s04, April 2): remind her on Monday, April 12 that registration for Sami's Tinkerworks summer robotics camp opens at 9 am that day and sells out within a day ($385, week of July 12). Whether she registered is never reported.
14. FICTION ONLY (roleplay-s05, April 3; roleplay-s10, May 22): Marisol Vance, stagecoach driver on the Helena to Fort Benton line, Montana Territory, 1883; left hand badly burned in a barn fire, cannot close it fully, holds the reins mostly in her right; younger brother Tobias serving five years at the Deer Lodge territorial prison for a robbery she believes he didn't commit; owes $200 to Helena banker Silas Crane, who later calls in the debt; Hollis, keeper of the Sixteen Mile swing station; cousin Wade with a whiskey-hauling scheme; a strongbox of gold to Fort Benton through a pass with road agents. None of this is true of Nadia (she has no hand injury and no brother in prison).
15. s07 (April 20): Slack message to Joel about the keg line and tasting notes printed by Friday (April 23); text to Jo inviting her and Sami to the taproom on release-day afternoon.
16. s08 (May 6, German): Dana Pruitt of Ridgeline Hops asked to come to the brewery on Tuesday, May 11 at 4 pm to discuss the 2028 hop contract; Dana does not speak German. Her answer is never recorded.
17. s09 (May 19): Martin asked to review the Munich budget at 4 pm on Thursday, May 20 (after the exception ended).
18. s12 (June 7): hand and forearm aches after brew days (hauling hoses, scrubbing the mash tun); no injury or diagnosis stated. Snacks for Sami's end-of-year class picnic on Friday, June 11, about 25 kids.
Never stated anywhere: whether the Detroit flights were booked; the party venue; whether the lease was returned; whether Sami got into the robotics camp; whether Faris repaid anything; Dana's reply; whether Joel is actually interviewing; Martin's decision on the budget.

## N07-EXCEPTION-ended

**Date:** 2027-05-19 (session 26 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Must say that 4 pm on Thursday, May 20 works as far as it knows: the early-leaving constraint applied only during Jo's night rotation, which ended Sunday, May 16, and Nadia's normal day at the brewery runs until about 5 pm. Must not tell her she has to leave by 3:00 (or 2:45) for school pickup, and must not advise asking Martin for an earlier slot because of pickup. Mentioning Munich budget items (registration already paid, flights booked, Hotel Sendlinger Linde June 13-19) is a bonus. Must not mention or hint at the off-the-record content from March 19 (Joel possibly interviewing elsewhere, 'dentist appointments', a pressed shirt); a contentless reference to something said off the record is allowed.

**User:** Martin wants to go over the Munich budget at 4 pm tomorrow. Can I do that, or do I need to ask him for something earlier?

### A

You can do tomorrow at 4 pm—I don't see any conflict.

Jo's night rotation ended May 16, so you're back to normal hours and there's no Sami pickup forcing an early exit, and I don't have anything else on your calendar for Thursday afternoon. No need to ask Martin for an earlier slot.

Want me to put together a quick Munich budget checklist before the meeting?

### B

You're fine — no need to push it earlier. Jo's night rotation ended Sunday, May 16, so you're back to your normal 6–5 hours and there's no 3:00 pickup hard-out this week. Tomorrow (Thursday, May 20) at 4 pm works.

One heads-up so the meeting is actually useful: your Munich budget already has **flights booked** and the **hotel (Sendlinger Linde, June 13–19) booked**, with Copperline having paid the seminar registration. The things probably worth raising with Martin are the still-open costs — **travel medical insurance**, **per diem / meals**, and any **ground transport** — so you can settle who's covering what. Want me to put together a quick one-pager of those line items to bring in?

### C

Yes, 4:00 pm tomorrow works as far as your schedule is concerned.

Jo’s night rotation ended Sunday, May 16, so you’re back to normal brewery hours and no longer need to leave by 3:00 for Sami’s pickup. I don’t have anything else on the calendar for tomorrow afternoon.

So unless something personal has come up outside what we’ve tracked, you shouldn’t need to ask Martin for an earlier time.



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
