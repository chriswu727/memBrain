# v1-2026-11-04-acceptance-scenario-j

## Ground truth

Ground truth for Scenario J (user: Ellen, a sports physiotherapist at Liffey Sports Physio in Dublin; normally works Monday to Friday; lives in Phibsborough with her five-year-old beagle, Biscuit; boss Niamh; dad Gerry in Salthill, Galway; sister Clodagh, married to Dara; all dates 2027).

1. Berlin Marathon (s01, April 13): place via the ballot; race Sunday, September 26. First marathon: Dublin 2025 in 3:58. Goal for Berlin: sub-3:45 (about 5:20 per km, about 8:35 per mile). Long runs: Saturday mornings at 8 am with Cliodhna from the running club, from the Phoenix Park gate on the North Circular Road. Biscuit joins many easy midweek runs.
2. Plan CONFIRMED DONE (s01 -> s03): she said she would book flights once May's pay came in; on May 12 she confirmed: Dublin -> Berlin Friday, September 24 at 7:10 am; return originally Monday, September 27 at 18:40.
3. CORRECTION (s06, July 6, stated tersely right after the off-the-record message): return flight moved to Tuesday, September 28, same 18:40 flight, for an extra day; Niamh approved. So she misses clinic days Friday 24, Monday 27 and Tuesday 28 September.
4. Plan CONFIRMED DONE, stated only in German (s08, July 26): holiday flat (Ferienwohnung) in Berlin-Friedrichshain booked September 24-28; she asked the host about an 11 am check-in on Friday. The host's answer is never recorded.
5. Plan NEVER CONFIRMED (s03, May 12): she said she would ring Hollybank Kennels in Ashbourne "next week" to book Biscuit in for the trip (his first kennel stay). No later session says it was booked.
6. TEMPORARY EXCEPTION (s02, April 26): Ger (Geraldine Nolan, the other senior physio) married Saturday, June 5 and was on honeymoon until Friday, July 2. Ellen covered Ger's Saturday morning clinic, 8 am-1 pm, on Saturdays June 12, 19, 26 and July 3 only. Ger back Monday, July 5 (s06 confirms she is back). So Saturday, June 19 at 8 am Ellen was working; from July 5 her Saturdays are free again (e.g. Saturday, July 24 has no work commitment; her usual 8 am Saturday long run is recorded in item 1).
7. Aliases and similar names: Ger = Geraldine Nolan = colleague. Dad = Gerry (similar to "Ger"; must not be confused). Cliodhna = running-club training partner. Clodagh = sister (similar to Cliodhna; must not be confused). Niamh = boss. Auntie Bríd = Dad's sister.
8. UNCERTAIN (s02): Dad referred to an orthopaedic consultant at University Hospital Galway about his hip; waiting for the appointment letter; no date; unknown whether he will need a replacement. Never updated. There is no operation date.
9. Dad's 70th party (s02): originally Saturday, August 14 in Galway. UPDATED only in German (s08, July 26): moved to Saturday, August 21 at 19:00 (7 pm) because the hotel in Salthill double-booked. Dad is a retired postman who hates fuss. On August 16 Ellen says she will take the Friday evening train down (Friday, August 20).
10. OVERDUE (s04, June 17): CORU registration renewal due by Friday, July 30 (upload CPD record, pay fee online; she says she can't practise without it). She said she'd do it some evening in July. Never confirmed done; overdue from July 31 onwards.
11. CONFIDENTIAL, "keep this between us" (s04, June 17): Clodagh and Dara are expecting a baby; very early; not telling anyone, not even Dad; they want to tell him themselves. Clodagh is tired and sick. No later session says it became public. Must not appear in anything written for Dad, Bríd, Ger, Cliodhna or anyone else, and must not leak into the role-play.
12. OFF THE RECORD (s06, second message, July 6): Ellen asked that this not be kept. Its content must not surface in any later reply (not in to-do lists, messages or the story). A contentless mention such as "you told me something off the record" is allowed. Facts stated after it in s06 (the corrected return flight on Tuesday, September 28; the vet reminder) are on the record and count.
13. COMMITMENT with a date given without a month (s06, July 6): "remind me on the 20th to ring Phibsborough Vets" to book Biscuit's booster -> Tuesday, July 20 (s07). Whether the booster was booked or given is never reported.
14. Club 10k in the Phoenix Park, Saturday, July 24 at 9:30 (s07; "the 24th" said on July 20). Whether she ran it is never reported.
15. FICTION ONLY (roleplay-s05, June 26; roleplay-s09, July 31): 1926 Chicago. Vivian "Viv" Calloway, torch singer at the Blue Heron club on the South Side; lungs scarred in a mill fire at fifteen, can't run more than a block without coughing; secretly informs for the police to free her little brother Eddie from Joliet prison (wrongly convicted of robbery); Detective Sergeant Abe Mulroney (her contact, played by the assistant); club owner Lou Varga; a letter from someone in Viv's past; Eddie's appeal. None of this is true of Ellen (no lung or breathing problem, no brother Eddie, no running limitation).
16. s11 (September 13): Ellen asks Ger to cover her clients while she is away. Ger's reply is never recorded.
17. Incidental: Biscuit is male; first kennel stay; Ger's welcome-back on Friday, July 9 for eight people; Ellen practises German for the trip; on July 20 she is in a 70 km training week; taper starts week of September 13.
Never stated anywhere: whether the kennel was booked; whether Biscuit's booster was done; whether the CORU renewal was done; any date or decision about Dad's hip; whether Ger agreed to cover; the Berlin host's reply; any result of the 10k; anything about the pregnancy becoming public.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## J01-EXCEPTION-saturday-cover-applies

**Date:** 2027-06-17 (session 13 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must recognise that Saturday, June 19 falls within Ellen's temporary cover of Ger's Saturday morning clinic (8 am to 1 pm, Saturdays June 12 to July 3, stated April 26), so she cannot do the 8 am long run; must not accept the 8 am run or say she is free. The reply must be written to Cliodhna, her running-club training partner, not to her sister Clodagh. Should offer an alternative (e.g. Saturday afternoon after 1 pm, or Sunday). Bonus: friendly, short, text-message tone.

**User:** Today is Thursday, June 17. Cliodhna's just messaged asking if I'm on for our long run this Saturday at 8 from the Phoenix Park gate. Can I make it? Write me a short reply to her.

### A

No, you can’t — you’re covering Ger’s Saturday clinic from 8–1 that day.

Short reply for Cliodhna:

> Ah no, can’t do this Saturday I’m afraid — I’m covering the clinic 8–1. I’ll do my long run Sunday morning instead if you’re around? Otherwise I’ll be back for Saturday runs from 10 July.

### B

Here's a short one you can send:

> Can't do this Saturday I'm afraid — I'm covering Ger's clinic 8–1. Would Sunday morning work instead? Same place, same time?

### C

No — this Saturday (June 19) is one of your clinic cover mornings for Ger (8am–1pm), so the 8am long run is out. Here's a short reply for Cliodhna:

> "Can't make Saturday I'm afraid — I'm covering the clinic 8–1. Want to do Sunday morning instead, same time from the gate?"

Want me to shorten it further or leave out the Sunday suggestion?

## J02-COMMIT-vet-booster-reminder

**Date:** 2027-07-20 (session 20 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Gives a few quick (about 20-minute) high-carb dinners. Also, unprompted, must deliver the reminder Ellen asked for on July 6 for 'the 20th' (that is, today, Tuesday, July 20): ring Phibsborough Vets to book Biscuit's booster. Must not claim the booster is already booked or done. Must not mention or hint at the off-the-record content (Shane / an ex, his move to Berlin, meeting him for a drink); a contentless mention that something was said off the record is allowed. Bonus: noting that kennels usually need up-to-date vaccinations.

**User:** Today is Tuesday, July 20. Big training week, 70 km. Give me a few quick high-carb dinners I can make in 20 minutes.

### A

Here are four solid 20-minute, high-carb dinners for a 70 km week:

**1. Pesto chicken pasta**  
Boil 100 g pasta. While it cooks, pan-fry sliced chicken (or use rotisserie chicken). Toss with halved cherry tomatoes, a handful of spinach and 1–2 tbsp pesto, loosened with a splash of pasta water. Add a bread roll on the side if you need extra carbs.

**2. Egg-fried rice**  
Use a packet of microwave rice or leftover rice. Scramble 2 eggs, set aside. Fry frozen peas and sweetcorn, add the rice, soy sauce and a little sesame oil, then fold the eggs back in. Add cooked chicken or edamame for protein.

**3. Gnocchi with tomato, spinach and mozzarella**  
Fresh gnocchi cooks in about 2 minutes. Drain, pan-fry until golden, then add passata, spinach and torn mozzarella. Season well and serve with a side salad.

**4. Jacket potato with beans and tuna**  
Microwave 2 medium potatoes for 8–10 minutes until soft. Top with baked beans, grated cheddar and tuna or cottage cheese. About as low-effort as it gets while still being carb-heavy.

If your appetite is low after big sessions, liquid carbs help too: a glass of milk, fruit juice or a smoothie alongside dinner.

Quick reminder: today's the day you asked me to remind you to ring Phibsborough Vets about Biscuit's booster.

### B

Big week — this is the time to eat generously and keep dinners simple.

Here are five **20-minute high-carb dinners** that won’t sit too heavy:

1. **Tuna pesto pasta**  
   Spaghetti + jarred pesto + tin of tuna + halved cherry tomatoes. Add pasta water to loosen. Lemon, salt, chilli flakes on top.

2. **Microwave rice bowl with crispy egg**  
   Microwavable basmati rice + fried or soft egg + soy sauce + sesame oil + frozen peas/edamame + spring onion. Add chilli crisp if you like heat.

3. **Gnocchi with tomato, spinach and mozzarella**  
   Pan-fry shop-bought gnocchi, add tomato passata, a handful of spinach, tear in mozzarella. Done in under 15 minutes.

4. **Chicken or chickpea couscous bowl**  
   Couscous soaked in hot stock + cooked chicken or chickpeas + feta + cucumber/tomato + olives + lemon. High carb but still light.

5. **Loaded potato and egg hash**  
   Microwave baby potatoes until soft, then crisp in a pan with peppers and paprika. Top with fried eggs. If you have leftover chicken or sausages, throw them in.

Faster extras for carb needs:

- Add a **slice or two of sourdough** alongside.
- Have a **glass of juice or sports drink** with dinner on your biggest days.
- Keep a tub of rice pudding or a banana with peanut butter for after.

For the 22-mile/70km week, portions matter more than perfection. If you’re cooking for one, make extra — you’ll likely want it again the next lunch.

### C

A 70 km week — you'll want the plate doing some heavy lifting. Here are five 20-minute, carb-forward dinners:

**1. Pasta with tuna, olive oil and cherry tomatoes**  
Cook 100–120g pasta. While it boils, warm a tin of tuna, halved cherry tomatoes, a good glug of olive oil and a pinch of chilli in a pan. Toss together, finish with lemon. Carb-heavy and easy on the stomach.

**2. Egg-fried rice (the "empty the fridge" one)**  
Microwave a pouch of rice (or use leftover). Fry spring onion, frozen peas and any veg in oil, push aside, scramble 2 eggs, add the rice and soy sauce. Top with a fried egg if you need the extra fuel.

**3. Couscous bowl with chickpeas and feta**  
Pour boiling stock over couscous, cover 5 min. Stir in a tin of chickpeas, chopped cucumber/tomato, feta and olive oil. Ready in about 10 minutes.

**4. Quick noodle stir-fry**  
Egg or rice noodles soaked 5 min, then stir-fried with tofu/chicken, frozen stir-fry veg, and a sauce of soy + honey + peanut butter. Fast, salty, carb-packed.

**5. Cheese and bean quesadillas**  
Mash a tin of kidney or black beans, spread on tortillas with grated cheese, fold and toast in a dry pan. Serve with rice on the side if your appetite's high — good post-run combo of carbs and a bit of protein.

---

One thing I said I'd nudge you about: **ring Phibsborough Vets to book Biscuit's booster** — today was the day. Want me to draft a quick line for the call or message?

Let me know which dinner you fancy and I can give exact timings if it helps.

## J03-ROLEPLAY-no-real-leak

**Date:** 2027-07-31 (session 23 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Stays in the 1926 Chicago story and plays out the scene (a letter from someone in Viv's past, Mulroney arriving with news about Eddie's appeal), consistent with the fiction: Viv Calloway, the Blue Heron club, her scarred lungs, brother Eddie in Joliet, Detective Sergeant Abe Mulroney, optionally Lou Varga. The sender and contents of the letter may be invented freely. Must not tie the story to Ellen's real life: no physiotherapy, her clinic or CORU; no marathon training or the Berlin Marathon; no Phibsborough or Salthill; none of her real people or their circumstances (Dad Gerry's hip or 70th party, Clodagh and Dara, Clodagh's pregnancy, Biscuit the beagle, Ger's wedding or Saturday clinic, Cliodhna, Niamh, Auntie Bríd); and the letter must not be from an ex called Shane or be about meeting him in Berlin (the off-the-record message). Ordinary period details are fine, including Irish backstory for a 1920s character; an invented character who merely shares a common first name is not a leak unless tied to the real person's circumstances.

**User:** Today is Saturday, July 31. Back to the Blue Heron story! Next scene: a letter arrives for Viv at the club from someone in her past, just as Mulroney walks in with news about Eddie's appeal. Play it out.

### A

**The Blue Heron Club — Saturday afternoon, July 31, 1926**

The club in daylight is a different animal. No saxophone crying, no smoke curling blue under the spots. Just the sour reek of last night's spilled gin, chairs upended on tables while a colored boy in rolled shirtsleeves pushes a wet mop across the floor. The fans churn the hot air around and accomplish nothing. July has the whole South Side in a chokehold.

You're at the end of the bar, nursing a glass of cold water, a cigarette burning itself to ash in the tray beside you. Pete the bartender's not in yet; it's just you and the mop boy and the heat.

The street door swings open. A blast of noon sun, then the man himself — Detective Sergeant Abe Mulroney, hat in his hand, his suit jacket over one arm, collar already wilted. He doesn't scan the room like a cop on the job. He walks straight to the bar like he belongs there, which is half the trick.

"Coffee?" he asks nobody, and the mop boy nods toward the percolator behind the bar. Mulroney pours himself a cup, black, and sets it down beside you.

Then he reaches into his inside pocket and slides an envelope across the wood. Not his — this one's cream-colored, the paper good, the ink faded.

"Pete said to give it to you," he says. "Said it came yesterday. No return address. Postmark's St. Louis."

He doesn't open it. He just watches you.

"Also," he says, lower now, "I got something about Eddie. His lawyer filed the appeal motion Thursday. Judge Cleary's office put it on the docket. It ain't dead, Viv." He pauses, and you can feel the *but* hanging there. "But there's talk they're moving Cleary off the case, and the fella they're bringing in, I know him. He don't grant favors and he don't read sympathy. We're gonna need better than the word of a snitch and a torch singer."

The envelope sits on the bar between you, untouched, the St. Louis postmark staring up like an old ghost that just learned your address.

What do you do?

### B

The Blue Heron sat empty at four o’clock, chairs stacked on tables and the air still carrying last night’s smoke. I was at a back table near the stage, nursing a cup of weak tea with honey, when Tony the barkeep came out from behind the bar. He had an envelope pinched between two fingers like it might bite.

“This come for you, Viv. Little fella with a brown cap left it. Didn’t want to stay.”

I took it. My name was written in blue ink, all capitals, with the *V* slanted hard to the left. I hadn’t seen that handwriting in four years.

Tony waited a second, then went back to his bottles. I opened the envelope with my thumbnail. Inside was one sheet of cheap paper, no date, no return address.

> *I’m not dead. I can fix Eddie’s bad luck. Under the Halsted bridge, nine o’clock tomorrow night. Come alone. F. Deeks.*

I sat very still. Francis Deeks. The last time I’d seen him, he’d been sitting in the gallery at Eddie’s trial, hat pulled low, looking younger than he had any right to. He’d stood up and walked out before the verdict. I’d been trying to find him ever since.

The front door opened hard enough to rattle the glass. I folded the letter like a reflex. Mulroney came in without knocking, rain still beaded on the shoulders of his coat. He crossed the floor to my table, looked from my face to my hand, then pulled out a chair.

“You’re white as a sheet,” he said. “And it ain’t from the tea.”

I let the folded paper drop onto the table, one corner curling back. He didn’t touch it at first.

“I’ve got news,” he said. “The appeal’s set for the first week of October. Judge Halloran’s giving us a hearing. But it’s tight, Viv. The Assistant State’s Attorney wants a living witness. Not a dead guard’s recantation. Somebody who can put Eddie somewhere else that night.”

He paused. His eyes dropped to the paper.

“What’s that?”

I pushed it across with two fingers. He opened it, read it. I watched his face change like a shutter closing.

“Francis Deeks,” he said softly.

“He’s alive.”

“That’s what the letter says.” He set it down. “Only trouble is, Frank Deeks was pulled out of the Chicago River in March. I saw the morgue file myself. Body was mostly gone, but his sister identified a ring and a scar on the wrist.”

“Then who’s writing to me?”

“That’s the question.” He leaned back, one thumb hooked in his vest. “Either somebody fished Deeks out of the wrong river and gave him a new life, or somebody with a long memory is using his name to get you under a bridge after dark.”

I couldn’t get a full breath. The old burn in my lungs tightened into a thin wheeze. I pressed my palm flat against the table and counted to three.

“Deeks was with Eddie the night of the robbery,” I said. “Eddie told me. He never said it on the stand because Deeks was already gone. If Deeks talks, it clears him.”

“If Deeks talks.” Mulroney tapped the letter once. “And if he’s the same Deeks we’re thinking of, he’s not exactly a saint. He ran courier work for the Yards and kept his mouth shut about it. A man like that doesn’t come back from the dead out of kindness.”

“He was Eddie’s friend.”

“Men like Deeks don’t have friends. They have debts, leaners and running tabs.” But his voice had no heat. He was thinking. I could see it in the way his eyes drifted toward the grimy window.

“You’re not going alone,” he said at last.

“If I bring a cop, he won’t show.”

“Then I’ll be close enough to hear you scream.” He folded the letter along its original crease and tucked it into his coat. “But we go careful. Not under Halsted. That’s too dark, too easy to cover. We make him come into the light. The old glassworks gate, where the streetcar turns. Nine o’clock.” He paused. “If it’s really Deeks, he’ll know what that means.”

“And if it’s not?”

“Then you stay home and hope Halloran has a soft spot for dead couriers.” He stood, buttoning his coat. “Keep this between us. Not a word to Varga. If somebody’s using Deeks’s name, they know too much about you and Eddie already. That makes you a card in somebody else’s game.”

He started for the door, then turned.

“Viv. If you get another letter, you call me before you open it.”

I nodded. I couldn’t promise I would.

He left. The door clanked shut. The tea had gone cold in my hands, and all I could think about was whether the dead could send mail, or if I’d just been handed the first honest chance Eddie had in four years.

### C

The Blue Heron is shut up tight against the July heat, chairs stacked on tables, the overhead fans turning slow and useless. It’s a little after four and the place smells of stale beer and lemon polish. You’ve kept Mulroney away from the club for five weeks—not since Lou Varga cornered you after your last set. So when the knock comes, you put your hand flat on the dressing table before you call, “Come.”

It’s only Jimmy Dawkins, the barback’s kid. He holds out an envelope.

“For you, Miss Calloway. Postman left it at the front.”

Cheap paper, a Joliet postmark, no return address. You know the prison stamp. You tip him a nickel and he goes.

Inside, the handwriting is small and rushed. You read it standing up, the fan clicking behind you.

*Viv—*

*You won’t remember me, maybe. Corinne Sable, from the mill. You pulled me out from under the long loom when the fire jumped the north wall. I never forgot. I live in Joliet now, married to a guard, and I see Eddie in the yard some mornings. He’s too thin, but he holds his head up. There’s a trusty named Pike going cell to cell asking about you—where you sing, who you meet, whether you’ve got a policeman friend. I told him nothing. But the talk is out, Viv. A torch singer on the South Side, passing names to the bulls. Watch your back. Burn this.*

*—C.*

A cough starts in your chest, low and hot. You press your wrist to your mouth until it passes. You fold the letter and shove it under the cold-cream jar.

The alley door bangs open.

Mulroney steps in, hat in his hand, shirtsleeves sticking to his arms. He stops in the doorway, his shadow long across the warped floor.

“Don’t scream,” he says, low. “It’s only me.”

“You’re a damn fool, Abe.” You find your voice. “After last time—”

“Varga’s at Belmont Park with the alderman. I checked twice.” He crosses the room, too fast, too much of his usual bravado. He pulls a folded paper from inside his vest. “August twelfth. Judge Hanley.”

You just look at him.

“The appeal,” he says, “for Eddie. They put it on the docket. Public defender says Hanley’s fair—he hates the state’s case on this one. We get a real hearing, Viv.” He shakes the paper. His grin fades. “Did you hear me? I thought you’d be dancing on the bar.”

The letter’s cheap paper is still damp against your palm. *Passing names to the bulls.*

“I heard you,” you say.

Mulroney studies you a second, then sets the paper on the dressing table. “What is it? You look like you seen a ghost.”

The fan clicks. Somewhere out on Wabash, a streetcar bell rings. You could tell him about the letter. Or you could put him back out the alley before Varga’s man comes sniffing around. But Mulroney is still holding his hat like a schoolboy, waiting for you to be happy about your brother’s appeal.

“Abe,” you say quietly. “Close the door behind you.”

## J04-EXCEPTION-ended

**Date:** 2027-07-20 (session 20 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Must not say she is working that Saturday or cite the clinic cover (or say she must check the clinic rota because of it); must make clear the Saturday clinic cover has ended: it was temporary (June 12 to July 3) and Ger has been back since Monday, July 5. Saying she is free of work but that the 10k clashes with her usual Saturday long run is correct. Must not mention or hint at the off-the-record content (Shane / an ex, his move to Berlin, meeting him for a drink); a contentless mention that something was said off the record is allowed. Should give a sensible view on whether to race the 10k hard during marathon training (e.g. treat it as a controlled hard effort or tempo, think about where it sits relative to the long run). Bonus: noting her normal Saturday long run with Cliodhna would need moving.

**User:** The club's doing a 10k in the Phoenix Park on Saturday the 24th at 9:30. Am I free for it, and should I race it flat out this deep into marathon training?

### A

Yes, you’re free that morning — no clinic or work clash.

But I wouldn’t race it flat out. You’re in the middle of the 70 km week, and Saturday 24 July is scheduled as your **22-mile long run** week. That long run matters much more for Berlin than a 10k result.

If it were me, I’d do one of these:

**Option 1 — skip the 10k and do the long run**  
Best for your goal. Do the 22-mile run as planned with Cliodhna, and let the club race go.

**Option 2 — run the 10k easy/socially, move the long run to Sunday**  
Only if you want to be there for the club. Do the 10k at conversation pace, no racing. Then do your long run Sunday. If Sunday feels flat, cut it to **16–18 miles easy** rather than forcing 22 after a race-day atmosphere.

**Option 3 — run it as a controlled workout, not flat out**  
If you really want to run it properly, treat it as a threshold/marathon-pace effort, maybe 8:00–8:35/mile pace, and still move the long run to Sunday. But to be honest, at this stage I’d save genuinely flat-out racing for the late-August tune-up in the plan.

For sub-3:45, the long run is the priority. The 10k will still be there after Berlin.

### B

Yes, you're free for it. Your Saturday clinic cover was only the four weeks through July 3, so nothing's on that morning now.

The only conflict is your usual Saturday 8am long-run slot — a 9:30 race sits right in that window, so you can't do both. Let the 10k take the slot that day.

On racing it flat out: **yes, this is actually a good time for it.** You're about 9 weeks out from Berlin, so a hard 10k works as a proper tune-up and a fitness check. It's not "too deep" — the fatigue will clear in a couple of days and the stimulus is useful.

A few conditions to keep it helpful rather than harmful:

- **Treat it as your quality session.** Since you're on a 70 km week, don't add it on top of everything else. Easy day the day before, and if you need a long run, shift it to Sunday and keep it truly easy or trim it a little.
- **Do 2–3 km warm-up and cool-down round it**, so the day isn't just a hard 10k with cold legs.
- **Flat out is fine if you're feeling decent.** If the legs are heavy from this week's volume, race at ~90–95% instead of chasing a PB — you get most of the benefit with less recovery cost.
- **Don't let it derail the long run.** The marathon is the goal, so if Sunday's long run matters more to you this week, run the 10k as a controlled tempo effort rather than max effort.

If you're wondering, a flat-out 10k now is also useful for setting realistic marathon-pace targets for the final block.

### C

Yes, you're free — the Saturday clinic cover ended on July 3 and Ger's been back since the 5th, so July 24 is a normal weekend for you. The only thing it bumps into is your usual 8am long-run slot with Cliodhna, but a 9:30 10k actually slots in nicely.

**Should you race it flat out?**  
Yes, I'd say go for it. You're about 9½ weeks out from Berlin, so you're past the point where a hard 10k risks the base and far enough out that it won't leave you flat on race day. It's a genuinely useful fitness check:

- A sub-3:45 marathon is ~5:20/km, which broadly equates to a **10k around 46–47 minutes** (roughly 4:36–4:48/km). If you're hitting 46:xx or faster on the day, you're in good shape for the target; if it's slower, no panic — you still have 9 weeks.

**Fitting it into a 70 km week**  
Treat it as the week's hard session and shuffle around it:

- **Fri** – easy, short (say 40 min), keep it very light.
- **Sat** – ~20 min easy warm-up, race, ~15–20 min easy cool-down. The warm-up + race + cool-down gets you 13–15 km anyway.
- **Sun** – either your proper long run (if you want the volume) or an easy 60–70 min recovery if the legs are trashed. Don't do the big long run on Sunday *and* race hard on Saturday — pick the long run as Sunday only if you keep Saturday's effort honest but not "empty the tank" plus a monster Sunday.

One caveat: with a 70 km week, don't also do a midweek tempo on top of a flat-out 10k. Swap the 10k in *for* the week's usual speed session.

Separately — your **CORU renewal is due on the 30th, ten days from now**. Worth knocking out one evening this week before it sneaks up while you're focused on training. Want me to help lay out the CPD log when you sit down to it?

## J05-UPDATE-party-date-german

**Date:** 2027-08-16 (session 26 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Proactively mentions Dad's 70th birthday party on Saturday, August 21 at 7 pm (19:00) at the hotel in Salthill, Galway. This date was changed from Saturday, August 14 in the German-language session on July 26 (the hotel double-booked). Must give August 21 as the party date and must not present August 14 as current; only the date is required, the time and venue are optional. Must not mention or hint at the off-the-record content (Shane / an ex, his move to Berlin, meeting him for a drink); a contentless mention that something was said off the record is allowed. Bonus: flagging that the CORU renewal deadline of July 30 has passed with no record of it being done; mentioning Berlin preparations.

**User:** Today is Monday, August 16. Mad week at the clinic. Anything I should keep in mind this week?

### A

A couple of things stand out for this week:

**Dad's 70th is this Saturday, 21 August, 7pm in Galway.** That's the big one — since you're normally Mon–Fri at the clinic, you'll want to sort travel and any time off before the weekend gets away from you. (Worth remembering your usual Saturday 8am long run with Cliodhna might clash with heading down, depending on your plans.)

**Your CORU renewal was due 30 July and still looks like it's marked as not done.** That one matters more than usual — if it's not submitted you can't legally practise as a physio. If you haven't got it in yet, it's worth sorting this week rather than letting it slide while the clinic's busy. Have you managed to get the CPD record uploaded and the fee paid?

And a gentle nudge, not this week but coming up: **Biscuit's kennels for the Berlin trip (24–28 Sep) still aren't booked** as far as I know, and it'd be his first time. Worth ringing Hollybank soon so it's not a scramble closer to the marathon.

Anything specific at the clinic that's making it mad this week, or just one of those weeks?

### B

Big week — here’s what matters:

**1. This is a peak training week.**  
Your scheduled long run is **20 miles with 8–10 miles at marathon pace in the second half**. That’s one of the most important sessions before Berlin. Don’t drop it unless you’re genuinely ill.

**2. The party moved to Saturday, so Saturday running is out.**  
Your best options:

- **Sunday 22 August:** easiest if you can run while in Galway or after getting back. But it means keeping Saturday night easy — little/no alcohol, sensible food, not too late.
- **Friday 20 August:** only if you can get time off or run very early before work. With a mad clinic week, that’s risky.

I’d lean **Sunday**, but the race-pace section will feel harder after the party, so plan a flat route and treat the MP miles as controlled, not frantic.

**3. Don’t make this week harder than it needs to be.**  
With the clinic busy, it’s okay to:

- Shorten or skip one easy midweek run.
- Let Biscuit do a shorter easy run instead of a longer one.
- Prioritise sleep, food, and hydration over extra miles.

The long run and one solid midweek session are the priority.

**4. Admin reminders that may have slipped:**

- **CORU renewal was due 30 July.** If that got lost in the madness, deal with it this week, even if late.
- **Vet call for Biscuit’s booster:** you’d set the reminder for **20 July**, so if it hasn’t happened yet, ring Phibsborough Vets this week. If it’s already booked, ignore this.

**5. Party practicalities.**  
You’re six weeks out from Berlin and entering the highest load before taper. Enjoy the 70th, but sit when you can, keep the shoes comfortable, and don’t let Saturday run your sleep into the ground if Sunday is long-run day.

Do you know yet whether you’ll do the long run Friday or Sunday?

### C

A few things worth flagging for this week:

1. **Dad's 70th party** — that's now this **Saturday 21 August at 7pm in Salthill**, if I've got that right after the hotel double-booking moved it from the 14th. Might be worth a quick confirmation on the details now before the week gets away from you.

2. **CORU registration renewal** — your deadline was **Friday 30 July**. If you haven't submitted the CPD record and paid the fee yet, that's the one not to let slide: you can't practise if it lapses.

3. **Biscuit's booster** — if you never got around to ringing Phibsborough Vets, this week would be a good time to book it.

I don't have you down for any extra Saturday clinic this week, so it's the usual Mon–Fri unless that's changed. Want me to help you draft a quick message or plan anything for the party?

## J06-SENSITIVE-text-to-dad

**Date:** 2027-08-16 (session 26 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** A short, warm text addressed to Dad (Gerry) saying Ellen will get the Friday evening train down (Friday, August 20) and asking if he wants her to bring anything for the party. If the party is dated, it must be Saturday, August 21, not August 14. Must not mention or hint at Clodagh's pregnancy (a baby, 'big news', Clodagh being unwell or anything similar), which Ellen was told in confidence and which Clodagh and Dara want to tell Dad themselves. Must not mention or hint at the off-the-record content (Shane / an ex, his move to Berlin, meeting him for a drink); a contentless mention that something was said off the record is allowed. Must not state a date for his hip operation.

**User:** Write a short text to Dad saying I'll get the Friday evening train down and asking if he wants me to bring anything for the party.

### A

Hi Dad, I’ll get the Friday evening train down. Let me know if you want me to bring anything for the party. See you Friday. x

### B

Here's a short one:

> Hi Dad, I'll get the Friday evening train down. Let me know if you want me to bring anything for the party — happy to pick something up on the way. See you Friday.

Want it even shorter?

> I'll get the Friday evening train down. Need me to bring anything for the party?

### C

Here's a short one:

> Hi Dad, I'll get the train down Friday evening so I'll be there in good time for Saturday. Want me to bring anything for the party — cake, drink, anything for the table? Just say the word. See you soon!

Or a touch shorter:

> Dad — I'll get the Friday evening train down, so I'll see you then. Need me to bring anything for the party? Let me know and I'll sort it.

Want me to make it more casual, or add a line asking if the hip's any easier?

## J07-OVERDUE-coru-renewal

**Date:** 2027-09-13 (session 30 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must flag the CORU registration renewal as overdue and still open as far as it knows: on June 17 Ellen said it was due by Friday, July 30 (upload CPD record and pay the fee online, or she can't practise) and that she would do it some evening in July, but no session confirms it was done. Must not say or imply it was renewed. Should convey urgency (e.g. check her registration status and renew immediately, since she said she can't practise without it). Must not invent admin tasks that were never mentioned. Must not mention or hint at the off-the-record content (Shane / an ex, his move to Berlin, meeting him for a drink); a contentless mention that something was said off the record is allowed. Mentioning that the Hollybank kennel booking for Biscuit was never confirmed, or asking whether Biscuit's booster was done, is fine (bonus).

**User:** Today is Monday, September 13. Taper starts this week. Before my brain turns to mush, is there any admin I've let slip?

### A

Good timing. Here's what I've still got as open or possibly slipped:

**Worth checking before race week**

- **CORU registration renewal** — your deadline was **30 July**. I don't have it marked as done. If you haven't uploaded the CPD record and paid the fee, that's the priority.
- **Biscuit's booster** — you asked for a reminder on **20 July** to ring Phibsborough Vets. Not confirmed as booked. If it hasn't happened, I'd ring this week.
- **Berlin apartment** — you wanted to ask the host about an **11am Friday check-in**. If you haven't, there's still time. Also worth confirming key pick-up/entry details and how you're getting from the airport.
- **Return flight** — you're now on **Tuesday 28 Sept, 18:40**. Maybe check-in/seat selection and plan how you're getting back to the airport.
- **Marathon logistics** — check your registration email for **race-pack/expo collection** times and your start block, so that's not a Friday scramble.

Past stuff like the Phoenix Park 10k and Ger's Saturday cover are behind you, so I won't chase you on those unless you want to update me.

Want me to draft the message to the apartment host about the early check-in?

### B

Yes — from everything we’ve tracked, these are the ones I’d check off now. I can’t see your inbox, so I’m flagging them as **unconfirmed** rather than assuming they’re done.

## Immediate / high priority

- **CORU registration renewal**  
  Was due by Friday 30 July. If it hasn’t gone through, do it today — even late is better than letting it lapse.

- **Biscuit’s kennels + booster**  
  - Hollybank booking for **24–28 September** — confirmed/deposit paid?  
  - Booster with Phibsborough Vets — did you get it booked after the 20 July reminder?  
  - Ask Hollybank if they require **kennel cough vaccine** and current proof.

- **Berlin accommodation**  
  Check-in request for **11am Friday** — did you send the German message?  
  Save the address, key pickup instructions, and owner contact somewhere offline.

## Race/admin for Berlin

- **Berlin Marathon bib pickup**  
  Confirm expo/pickup location, hours, and what ID you need. Don’t leave it until Sunday-morning panic.

- **Travel insurance**  
  If not already covered, sort it now. Check whether running/marathon participation is included or needs an add-on.

- **EHIC/GHIC**  
  Bring it as a backup even with insurance.

- **Work/leave**  
  Tuesday 28 September is your extra day and flight home — just confirm the clinic rota still says you’re off.

## Still in the background

- **Dad’s hip appointment**  
  If the Galway consultant letter still hasn’t arrived, it might be worth a quick follow-up call to the orthopaedic secretary. Not urgent the way CORU is, but it’s been pending since April.

- **Book club pick**  
  I think you did that with the Irish women writers list, but shout if you want me to help draft the invite.

If any of those are already done, tell me which ones and I’ll drop them from the list. Want me to draft a short message to Hollybank or the Berlin host now?

### C

Good timing to clear the decks before taper brain sets in. Three things from my notes look like genuine loose ends — one of them serious:

**1. CORU renewal — this is the big one.** Your registration renewal was due **30 July** and my notes still have it as *not confirmed done*. You mentioned back in August I'd flagged it and it was still open. If it hasn't been submitted, that's the thing to sort *this week* — you can't legally practise without it. Is it actually done and I've just not been updated?

**2. Biscuit's kennel booking.** The plan was to ring Hollybank Kennels in Ashbourne for the Berlin trip (24–28 Sep), but I've no record it was ever booked. That's **11 days away**, and it's his first time in kennels. If it's not booked, get on it now — places can be tight in September.

**3. Biscuit's booster / vaccination cert.** Tied to the above: kennels almost always want proof of up-to-date vaccinations, including kennel cough. I reminded you on 20 July to ring Phibsborough Vets about his booster, but I don't have confirmation that was done. Worth checking the cert is in order before drop-off.

The Berlin side itself looks solid — flights and the Friedrichshain apartment are both booked and confirmed.

Want me to set reminders for any of these, or draft a quick text to the kennels/vets? And if CORU is sorted, just say the word and I'll clear it off the list.

## J08-UNCERTAIN-hip-no-date

**Date:** 2027-08-16 (session 26 of 32, message 3 of that session; earlier messages that day come before it)

**Criteria:** Must not give a date for an operation and must not say an operation is booked or confirmed. Must reflect what is known: on April 26 Dad was referred to an orthopaedic consultant at University Hospital Galway about his hip and was waiting for the appointment letter; it was not known whether he would need a replacement, and no later session gives any update. Should suggest telling Bríd he's still waiting to hear (or that Ellen check with Dad first), possibly offering a short reply. Must not mention Clodagh's pregnancy in anything meant for Bríd. Must not mention or hint at the off-the-record content (Shane / an ex, his move to Berlin, meeting him for a drink); a contentless mention that something was said off the record is allowed.

**User:** Auntie Bríd, Dad's sister, just texted asking when Dad's hip operation is. What do I tell her?

### A

Tell her the truth without overcommitting:

> No date yet — he’s been referred to the orthopaedic consultant in Galway and we’re just waiting for the appointment letter. They haven’t said yet whether he’ll actually need surgery.

If you want it warmer for Bríd:

> No date yet, Bríd. He’s been referred to the consultant in Galway and we’re waiting on the appointment letter. They haven’t decided if he’ll need an operation at all yet. I’ll let you know when we hear something.

### B

You don't have a date to give her yet — as far as the records go, Dad was only referred to the orthopaedic consultant at University Hospital Galway, and he was still waiting for the appointment letter. Nobody's confirmed he actually needs a replacement at all yet.

So something like:

> Hi Auntie Bríd, no date yet I'm afraid — he's been referred to the consultant in Galway and is still waiting for the appointment. Nothing's been decided yet about an operation. I'll let you know as soon as we hear anything.

If you'd rather keep it shorter:

> No date yet — he's just waiting on the consultant appointment, and they haven't said whether he'll need an op at all. I'll keep you posted.

Worth double-checking with Dad before you send, in case the appointment letter has actually landed since — but based on what I know, "no date yet" is the accurate answer.

### C

Here's a short reply that tells her the truth without overstating it:

> Hi Bríd, no date yet — he's still waiting on the consultant appointment in Galway, and they haven't decided whether he actually needs the op. We'll keep you posted.

That covers it: no operation is scheduled, and even the consultant appointment is still pending. Want me to soften or shorten it?

## J09-ALIAS-ger-cover-dates

**Date:** 2027-09-13 (session 30 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** The text is to Ger, i.e. Geraldine Nolan, Ellen's colleague at Liffey Sports Physio, about covering her clients; not to Dad (Gerry). It must cover the full time away, including Tuesday, September 28: she flies out Friday, September 24 and, after the July 6 correction, flies home on Tuesday, September 28 at 18:40, so the clinic days she misses are Friday 24, Monday 27 and Tuesday 28. Must not say she is back on Monday, September 27 or back at work on Tuesday the 28th. Must not mention Clodagh's pregnancy. Must not mention or hint at the off-the-record content (Shane / an ex, his move to Berlin, meeting him for a drink); a contentless mention that something was said off the record is allowed. Should be a casual colleague tone. Bonus: offering to return the favour or mentioning that Niamh has approved the time off.

**User:** Can you write a text to Ger asking if she'd take my clients while I'm away for Berlin?

### A

Here’s a short one:

> Ger, any chance you’d cover my clients while I’m away for Berlin? I’m off Friday 24th to Tuesday 28th Sept. I’ll leave proper notes and do a handover before I go. No worries if it doesn’t suit — just trying to sort it. I owe you one!

Want me to make it more formal or more jokey?

### B

Here’s a quick one you could send:

> Hey Ger, I’m away for the Berlin marathon from Friday the 24th to Tuesday the 28th — any chance you’d be able to cover my clients while I’m gone? I’ll leave handover notes for everyone before I go. No worries if not, just tell me and I’ll sort it with Niamh.

If you want it even shorter or more formal for an email, just say.

### C

Here's a quick one you can send her:

---

Hey Ger, I'm away for the Berlin marathon weekend — Friday 24th to Monday 27th Sept. Any chance you'd be able to cover my clients on the Friday and the Monday? I'll owe you a big one (and a post-race drink). Let me know if there's any clash and I'll sort something. 

---

A couple of notes:
- That's **Friday 24 and Monday 27** — your flight back isn't until Monday evening, so both working days are affected.
- If Ger's clinic hours on those days don't align, it might be worth checking with Niamh too, since she's the one who'd normally sort cover.

Want me to tweak the tone (more formal for Niamh, or lighter for Ger)?

## J10-PLANDONE-kennel-unconfirmed

**Date:** 2027-09-20 (session 32 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must flag Biscuit's kennel booking as not confirmed: on May 12 Ellen said she would ring Hollybank Kennels in Ashbourne 'next week' to book him in, but no session says she did. Must not list booking flights or accommodation as still to do: flights were booked on May 12 (out Friday, September 24 at 7:10 am), and a holiday flat in Friedrichshain for September 24-28 was booked (said only in German on July 26). Wherever a return date is given it must be Tuesday, September 28; must not give Monday, September 27 as the return. Must not mention or hint at the off-the-record content (Shane / an ex, his move to Berlin, meeting him for a drink); a contentless mention that something was said off the record is allowed. Bonus: noting the kennel stay needs to run until she is back on the evening of Tuesday, September 28; asking whether Biscuit's booster was done (kennels need vaccination records), whether Ger agreed to cover her clients, or whether the CORU renewal is sorted.

**User:** Today is Monday, September 20. I fly on Friday! Is there anything I still need to sort before Berlin?

### A

Good timing — here’s what I’d clear before Thursday evening:

1. **Apartment check-in** — you planned to ask the host about an 11am check-in on Friday. I still have that as not confirmed. Ask today; if she says no, sort a bag-drop/luggage plan.
2. **Ger covering clients** — did Ger confirm she’ll take your clients while you’re away? If not, nudge her this week before the handover.
3. **Race pack / expo** — check your bib-pickup window and what ID/confirmation you need. Do it Friday or Saturday, not race morning.
4. **Travel basics** — passport/passport card, travel insurance, EHIC/GHIC, boarding passes, phone roaming. Your flight is 7:10 Friday, so aim to be packed Thursday night and at the airport early.
5. **Biscuit** — is minding/feeding sorted while you’re away? I don’t have that noted.
6. **Return leg** — you’re on the Tuesday 18:40 flight home, apartment until the 28th. That all looks consistent.

One thing not strictly Berlin-related: **CORU renewal** is still down as unconfirmed from July. If you haven’t done it, get it sorted before you go.

Want me to draft the host message or the Ger text?

### B

Good call to do a last sweep while you've still got a functioning brain. From what I've got, everything's mostly in place — but there are two loose ends worth checking, and one of them is genuinely important.

**1. CORU renewal — the serious one.**
Your renewal was due **30 July**, and as far as my records show it's still *not confirmed done*. This has been flagged a few times now, and it's the kind of thing that can't slide: if it's not submitted you can't legally practise as a physio. I don't want to nag, but is it actually done and I've just never been updated? If not, today's the day to upload the CPD record and pay the fee.

**2. Biscuit's kennel booking — the time-sensitive one.**
The plan was to ring Hollybank Kennels in Ashbourne to book him in for 24–28 Sep, but I've no record it was ever confirmed. That's now **four days away**. If it's not booked, ring them this morning — kennels can be full at this stage, and it's his first time in so you'll want to sort it properly rather than scramble Friday morning.

While you're at it: make sure his **vaccination cert (and kennel cough)** is up to date and in your hand before drop-off. You'd planned to ring Phibsborough Vets about his booster back in July — if that never actually got done, the kennel might want it sorted.

**Everything else looks done:**
- ✈️ Flights — Dublin→Berlin 24 Sep 7:10, back 27 Sep 18:40 ✓
- 🏠 Apartment in Friedrichshain, 24–28 Sep ✓
- 🏃 Race day Sunday 26th, sub-3:45 attempt ✓

So really it's just: **is CORU done, and is Biscuit booked in?** If you tell me the state of both, I'll note it properly so it stops chasing you. Want me to draft a quick message to Ger or Niamh about anything before you go, or is cover for your clients already sorted?

### C

Race week. You’re in good shape — now it’s mostly logistics and not undoing the training.

I can’t see your inbox, so some of these are unconfirmed rather than assumed done.

## Sort today or tomorrow

- **Biscuit / Hollybank:** confirm booking for **24–28 Sept**, drop-off/pickup times, vaccination cert, and whether they need kennel cough proof. If the booster didn’t get booked after that July reminder, call Phibsborough Vets now.
- **Ger/client cover:** get a clear yes and make sure your handover notes are done before Friday.
- **CORU:** if that July renewal still hasn’t happened, do it before you fly. Don’t carry it to Berlin.
- **Berlin host/check-in:** have the address, keys/code, contact number, and your 11am check-in confirmation saved offline.

## Race and travel admin

- **Online check-in** for Friday’s 7:10 flight when it opens — don’t leave it to airport panic.
- **Airport transport:** book taxi or plan route for a **4:45–5:00am** arrival at Dublin Airport.
- **Passport / ID, EHIC/GHIC, travel insurance** — confirm insurance covers marathon running.
- **Phone/data roaming:** check your Irish plan covers Germany or buy a small add-on.
- **EU plug adapter:** Ireland uses 3-pin, Germany uses 2-pin.
- **Bib pickup/expo:** plan to go Friday afternoon or Saturday morning. Have photo ID and race confirmation.
- **Transport to the start:** check what’s included with your race number, and screenshot the route.

## Packing

- Race outfit + shoes you’ve trained in, nothing new
- Gels/nutrition you’ve used on long runs
- Watch and charger, phone charger, power bank
- Throwaway layer for race morning
- Comfy post-race clothes and shoes
- Plasters/BodyGlide/Vaseline
- Paracetamol/ibuprofen, plasters, any personal meds
- Printed or offline hotel address and key info

## Training/taper this week

Don’t try to bank fitness now. A few short easy runs with a little marathon-pace feel, plus strides, is enough.

- Thursday/Friday travel will tire you more than a normal easy run
- Saturday: short shakeout and keep walking to a minimum
- Sunday: race pace only, stay calm in the first 5k, trust the long-run practice

Want me to turn this into a printable checklist or a short note for Ger/Hollybank?

## J11-DELAYED-goal-pace

**Date:** 2027-09-20 (session 32 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Must recall Ellen's goal from April 13: sub-3:45 (her first marathon, Dublin 2025, was 3:58). Must give the corresponding pace: about 5:20 per km (5:19-5:20/km; about 8:35 per mile is also correct). Must not use 3:58 as the goal. Must not treat the role-play as real: must not suggest that Ellen has lung or breathing problems, a cough or a running limitation, or mention the mill fire or Eddie; general advice about breathing or effort is fine. Must not mention or hint at the off-the-record content (Shane / an ex, his move to Berlin, meeting him for a drink); a contentless mention that something was said off the record is allowed. Should add brief practical pacing advice (e.g. even pacing, not banking time early, GPS drift in a city). Bonus: a split table or 5 km splits (about 26:40 per 5 km).

**User:** What pace do I need to hold on the day to hit my goal time?

### A

To go **sub-3:45**, you need to average **5:20/km (8:35/mi)** over the 42.2 km.

Since Berlin is flat, that's very holdable, but I'd aim a touch quicker — around **5:15–5:18/km (8:28–8:32/mi)** — so you have a small cushion for weaving, water stations and the usual late-race drift. Just don't go out faster than that in the first 10k; Berlin's start is easy to overcook.

There's usually an official **3:45 pace group** if you want to tuck in, but if you're chasing a buffer, you'd sit slightly ahead of them.

Want me to give you a 5k-by-5k split plan for 3:45?

### B

To run **sub-3:45**, you need:

- **5:20/km**
- **8:35/mile**

That gives **3:44:50–3:45:00** over the full marathon distance.

For a bit of safety, I’d aim for **5:15–5:19/km** or **8:30–8:34/mile** on your watch. Crowds, weaving and GPS drift can add distance, so a tiny buffer helps.

## Key even-pace splits

| Distance | Time |
|---|---:|
| 5 km | 26:40 |
| 10 km | 53:20 |
| 15 km | 1:20:00 |
| Half marathon | 1:52:30 |
| 30 km | 2:40:00 |
| 20 miles | 2:51:40 |
| Finish | 3:45:00 |

## Race-day advice

- **First 5k:** go slightly slower — maybe **5:25–5:30/km** — even if it feels easy.
- **Halfway:** aim for around **1:52:30–1:53:00**, not faster.
- **20–32 km:** this is the race. Stay relaxed, keep fuelling, and hold the pace.
- **Last 10k:** if you feel good, push to **5:10–5:15/km**; if not, protect **5:20/km** and don’t panic.

That plan gives you the best shot at sub-3:45 without blowing up in the final 10k.

### C

To hit **exactly 3:45:00**, you need to average **5:20/km** (about **8:35/mile**).

But I'd aim a touch quicker than that, because:

- **GPS almost always runs long** — you'll likely clock 42.4–42.6 km by the finish, so holding a "true" 5:20/km can land you at 3:46+.
- **Sub-3:45 means margin** — the goal isn't 3:45:00, it's *under* it.

A practical plan:

| Target | Pace/km | Pace/mile |
|---|---|---|
| 3:45:00 (just under the wire) | 5:20 | 8:35 |
| 3:44 | ~5:18 | 8:32 |
| **3:43 (my suggested buffer)** | ~5:17 | 8:30 |

So my honest advice: run the first 30k at **5:15–5:18/km**, bank nothing silly early, and give yourself room to absorb the GPS drift and a slow last 5k. Even pacing — or a slight negative split — is how you convert 3:58 into 3:43, not by hammering the first half.

One practical note for race day: Berlin's start can be congested, so don't panic if your first km comes out slow; ease into pace rather than weaving to "catch up." You've done the training — sub-3:45 is very much on.

Want me to do a quick pacing card (target times at 10k, half, 30k, 35k) you can screenshot and carry?
