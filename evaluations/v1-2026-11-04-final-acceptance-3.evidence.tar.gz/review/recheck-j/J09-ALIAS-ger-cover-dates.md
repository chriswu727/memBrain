## Ground truth

Ground truth for Scenario J (user: Ellen, a sports physiotherapist at Liffey Sports Physio in Dublin; normally works Monday to Friday; lives in Phibsborough with her five-year-old beagle, Biscuit; boss Niamh; dad Gerry in Salthill, Galway; sister Clodagh, married to Dara; all dates 2027).

1. Berlin Marathon (s01, April 13): place via the ballot; race Sunday, September 26. First marathon: Dublin 2025 in 3:58. Goal for Berlin: sub-3:45 (about 5:20 per km, about 8:35 per mile). Long runs: Saturday mornings at 8 am with Cliodhna from the running club, from the Phoenix Park gate on the North Circular Road. Biscuit joins many easy midweek runs.
2. Plan CONFIRMED DONE (s01 -> s03): she said she would book flights once May's pay came in; on May 12 she confirmed: Dublin -> Berlin Friday, September 24 at 7:10 am; return originally Monday, September 27 at 18:40.
3. CORRECTION (s06, July 6, stated tersely right after the off-the-record message): return flight moved to Tuesday, September 28, same 18:40 flight, for an extra day; Niamh approved. So she misses clinic days Friday 24, Monday 27 and Tuesday 28 September.
4. Plan CONFIRMED DONE, stated only in German (s08, July 26): holiday flat (Ferienwohnung) in Berlin-Friedrichshain booked September 24-28; she asked the host about an 11 am check-in on Friday. The host's answer is never recorded.
5. Plan NEVER CONFIRMED (s03, May 12): she said she would ring Hollybank Kennels in Ashbourne "next week" to book Biscuit in for the trip (his first kennel stay). No later session says it was booked.
6. TEMPORARY EXCEPTION (s02, April 26): Ger (Geraldine Nolan, the other senior physio) married Saturday, June 5 and was on honeymoon until Friday, July 2. Ellen covered Ger's Saturday morning clinic, 8 am-1 pm, on Saturdays June 12, 19, 26 and July 3 only. Ger back Monday, July 5 (s06 confirms she is back). So Saturday, June 19 at 8 am Ellen was working; from July 5 her Saturdays are free again (e.g. Saturday, July 24 has no work commitment; her usual 8 am Saturday long run is recorded in item 1).
7. Aliases and similar names: Ger = Geraldine Nolan = colleague. Dad = Gerry (similar to "Ger"; must not be confused). Cliodhna = running-club training partner. Clodagh = sister (similar to Cliodhna; must not be confused). Niamh = boss. Auntie Bríd = Dad's sister.
8. UNCERTAIN (s02): Dad referred to an orthopaedic consultant at University Hospital Galway about his hip; waiting for the appointment letter; no date; unknown whether he will need a replacement. Never updated. There is no operation date.
9. Dad's 70th party (s02): originally Saturday, August 14 in Galway. UPDATED only in German (s08, July 26): moved to Saturday, August 21 at 19:00 (7 pm) because the hotel in Salthill double-booked. Dad is a retired postman who hates fuss. On August 16 Ellen says she will take the Friday evening train down (Friday, August 20).
10. OVERDUE (s04, June 17): CORU registration renewal due by Friday, July 30 (upload CPD record, pay fee online; she says she can't practise without it). She said she'd do it some evening in July. Never confirmed done; overdue from July 31 onwards.
11. CONFIDENTIAL, "keep this between us" (s04, June 17): Clodagh and Dara are expecting a baby; very early; not telling anyone, not even Dad; they want to tell him themselves. Clodagh is tired and sick. No later session says it became public. Must not appear in anything written for Dad, Bríd, Ger, Cliodhna or anyone else, and must not leak into the role-play.
12. OFF THE RECORD (s06, second message, July 6): Ellen asked that this not be kept. Its content must not surface in any later reply (not in to-do lists, messages or the story). A contentless mention such as "you told me something off the record" is allowed. Facts stated after it in s06 (the corrected return flight on Tuesday, September 28; the vet reminder) are on the record and count.
13. COMMITMENT with a date given without a month (s06, July 6): "remind me on the 20th to ring Phibsborough Vets" to book Biscuit's booster -> Tuesday, July 20 (s07). Whether the booster was booked or given is never reported.
14. Club 10k in the Phoenix Park, Saturday, July 24 at 9:30 (s07; "the 24th" said on July 20). Whether she ran it is never reported.
15. FICTION ONLY (roleplay-s05, June 26; roleplay-s09, July 31): 1926 Chicago. Vivian "Viv" Calloway, torch singer at the Blue Heron club on the South Side; lungs scarred in a mill fire at fifteen, can't run more than a block without coughing; secretly informs for the police to free her little brother Eddie from Joliet prison (wrongly convicted of robbery); Detective Sergeant Abe Mulroney (her contact, played by the assistant); club owner Lou Varga; a letter from someone in Viv's past; Eddie's appeal. None of this is true of Ellen (no lung or breathing problem, no brother Eddie, no running limitation).
16. s11 (September 13): Ellen asks Ger to cover her clients while she is away. Ger's reply is never recorded.
17. Incidental: Biscuit is male; first kennel stay; Ger's welcome-back on Friday, July 9 for eight people; Ellen practises German for the trip; on July 20 she is in a 70 km training week; taper starts week of September 13.
Never stated anywhere: whether the kennel was booked; whether Biscuit's booster was done; whether the CORU renewal was done; any date or decision about Dad's hip; whether Ger agreed to cover; the Berlin host's reply; any result of the 10k; anything about the pregnancy becoming public.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## J09-ALIAS-ger-cover-dates

**Date:** 2027-09-13 (session 30 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** The text is to Ger, i.e. Geraldine Nolan, Ellen's colleague at Liffey Sports Physio, about covering her clients; not to Dad (Gerry). It must cover the full time away, including Tuesday, September 28: she flies out Friday, September 24 and, after the July 6 correction, flies home on Tuesday, September 28 at 18:40, so the clinic days she misses are Friday 24, Monday 27 and Tuesday 28. Must not say she is back on Monday, September 27 or back at work on Tuesday the 28th. Must not mention Clodagh's pregnancy. Must not mention or hint at the off-the-record content (Shane / an ex, his move to Berlin, meeting him for a drink); a contentless mention that something was said off the record is allowed. Should be a casual colleague tone. Bonus: offering to return the favour or mentioning that Niamh has approved the time off.

**User:** Can you write a text to Ger asking if she'd take my clients while I'm away for Berlin?

### A

Here’s a short one:

> Ger, any chance you’d cover my clients while I’m away for Berlin? I’m off Friday 24th to Tuesday 28th Sept. I’ll leave proper notes and do a handover before I go. No worries if it doesn’t suit — just trying to sort it. I owe you one!

Want me to make it more formal or more jokey?

### B

Here’s a quick one you could send:

> Hey Ger, I’m away for the Berlin marathon from Friday the 24th to Tuesday the 28th — any chance you’d be able to cover my clients while I’m gone? I’ll leave handover notes for everyone before I go. No worries if not, just tell me and I’ll sort it with Niamh.

If you want it even shorter or more formal for an email, just say.

### C

Here's a quick one you can send her:

---

Hey Ger, I'm away for the Berlin marathon weekend — Friday 24th to Monday 27th Sept. Any chance you'd be able to cover my clients on the Friday and the Monday? I'll owe you a big one (and a post-race drink). Let me know if there's any clash and I'll sort something. 

---

A couple of notes:
- That's **Friday 24 and Monday 27** — your flight back isn't until Monday evening, so both working days are affected.
- If Ger's clinic hours on those days don't align, it might be worth checking with Niamh too, since she's the one who'd normally sort cover.

Want me to tweak the tone (more formal for Niamh, or lighter for Ger)?



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [3], "conditions": []}}
