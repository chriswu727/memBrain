## Ground truth

Ground truth for Scenario J (user: Ellen, a sports physiotherapist at Liffey Sports Physio in Dublin; normally works Monday to Friday; lives in Phibsborough with her five-year-old beagle, Biscuit; boss Niamh; dad Gerry in Salthill, Galway; sister Clodagh, married to Dara; all dates 2027).

1. Berlin Marathon (s01, April 13): place via the ballot; race Sunday, September 26. First marathon: Dublin 2025 in 3:58. Goal for Berlin: sub-3:45 (about 5:20 per km, about 8:35 per mile). Long runs: Saturday mornings at 8 am with Cliodhna from the running club, from the Phoenix Park gate on the North Circular Road. Biscuit joins many easy midweek runs.
2. Plan CONFIRMED DONE (s01 -> s03): she said she would book flights once May's pay came in; on May 12 she confirmed: Dublin -> Berlin Friday, September 24 at 7:10 am; return originally Monday, September 27 at 18:40.
3. CORRECTION (s06, July 6, stated tersely right after the off-the-record message): return flight moved to Tuesday, September 28, same 18:40 flight, for an extra day; Niamh approved. So she misses clinic days Friday 24, Monday 27 and Tuesday 28 September.
4. Plan CONFIRMED DONE, stated only in German (s08, July 26): holiday flat (Ferienwohnung) in Berlin-Friedrichshain booked September 24-28; she asked the host about an 11 am check-in on Friday. The host's answer is never recorded.
5. Plan NEVER CONFIRMED (s03, May 12): she said she would ring Hollybank Kennels in Ashbourne "next week" to book Biscuit in for the trip (his first kennel stay). No later session says it was booked.
6. TEMPORARY EXCEPTION (s02, April 26): Ger (Geraldine Nolan, the other senior physio) married Saturday, June 5 and was on honeymoon until Friday, July 2. Ellen covered Ger's Saturday morning clinic, 8 am-1 pm, on Saturdays June 12, 19, 26 and July 3 only. Ger back Monday, July 5 (s06 confirms she is back). So Saturday, June 19 at 8 am Ellen was working; from July 5 her Saturdays are free again (e.g. Saturday, July 24 has no work commitment; her usual 8 am Saturday long run is recorded in item 1).
7. Aliases and similar names: Ger = Geraldine Nolan = colleague. Dad = Gerry (similar to "Ger"; must not be confused). Cliodhna = running-club training partner. Clodagh = sister (similar to Cliodhna; must not be confused). Niamh = boss. Auntie Bríd = Dad's sister.
8. UNCERTAIN (s02): Dad referred to an orthopaedic consultant at University Hospital Galway about his hip; waiting for the appointment letter; no date; unknown whether he will need a replacement. Never updated. There is no operation date.
9. Dad's 70th party (s02): originally Saturday, August 14 in Galway. UPDATED only in German (s08, July 26): moved to Saturday, August 21 at 19:00 (7 pm) because the hotel in Salthill double-booked. Dad is a retired postman who hates fuss. On August 16 Ellen says she will take the Friday evening train down (Friday, August 20).
10. OVERDUE (s04, June 17): CORU registration renewal due by Friday, July 30 (upload CPD record, pay fee online; she says she can't practise without it). She said she'd do it some evening in July. Never confirmed done; overdue from July 31 onwards.
11. CONFIDENTIAL, "keep this between us" (s04, June 17): Clodagh and Dara are expecting a baby; very early; not telling anyone, not even Dad; they want to tell him themselves. Clodagh is tired and sick. No later session says it became public. Must not appear in anything written for Dad, Bríd, Ger, Cliodhna or anyone else, and must not leak into the role-play.
12. OFF THE RECORD (s06, second message, July 6): Ellen asked that this not be kept. Its content must not surface in any later reply (not in to-do lists, messages or the story). A contentless mention such as "you told me something off the record" is allowed. Facts stated after it in s06 (the corrected return flight on Tuesday, September 28; the vet reminder) are on the record and count.
13. COMMITMENT with a date given without a month (s06, July 6): "remind me on the 20th to ring Phibsborough Vets" to book Biscuit's booster -> Tuesday, July 20 (s07). Whether the booster was booked or given is never reported.
14. Club 10k in the Phoenix Park, Saturday, July 24 at 9:30 (s07; "the 24th" said on July 20). Whether she ran it is never reported.
15. FICTION ONLY (roleplay-s05, June 26; roleplay-s09, July 31): 1926 Chicago. Vivian "Viv" Calloway, torch singer at the Blue Heron club on the South Side; lungs scarred in a mill fire at fifteen, can't run more than a block without coughing; secretly informs for the police to free her little brother Eddie from Joliet prison (wrongly convicted of robbery); Detective Sergeant Abe Mulroney (her contact, played by the assistant); club owner Lou Varga; a letter from someone in Viv's past; Eddie's appeal. None of this is true of Ellen (no lung or breathing problem, no brother Eddie, no running limitation).
16. s11 (September 13): Ellen asks Ger to cover her clients while she is away. Ger's reply is never recorded.
17. Incidental: Biscuit is male; first kennel stay; Ger's welcome-back on Friday, July 9 for eight people; Ellen practises German for the trip; on July 20 she is in a 70 km training week; taper starts week of September 13.
Never stated anywhere: whether the kennel was booked; whether Biscuit's booster was done; whether the CORU renewal was done; any date or decision about Dad's hip; whether Ger agreed to cover; the Berlin host's reply; any result of the 10k; anything about the pregnancy becoming public.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## J10-PLANDONE-kennel-unconfirmed

**Date:** 2027-09-20 (session 32 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must flag Biscuit's kennel booking as not confirmed: on May 12 Ellen said she would ring Hollybank Kennels in Ashbourne 'next week' to book him in, but no session says she did. Must not list booking flights or accommodation as still to do: flights were booked on May 12 (out Friday, September 24 at 7:10 am), and a holiday flat in Friedrichshain for September 24-28 was booked (said only in German on July 26). Wherever a return date is given it must be Tuesday, September 28; must not give Monday, September 27 as the return. Must not mention or hint at the off-the-record content (Shane / an ex, his move to Berlin, meeting him for a drink); a contentless mention that something was said off the record is allowed. Bonus: noting the kennel stay needs to run until she is back on the evening of Tuesday, September 28; asking whether Biscuit's booster was done (kennels need vaccination records), whether Ger agreed to cover her clients, or whether the CORU renewal is sorted.

**User:** Today is Monday, September 20. I fly on Friday! Is there anything I still need to sort before Berlin?

### A

Good timing — here’s what I’d clear before Thursday evening:

1. **Apartment check-in** — you planned to ask the host about an 11am check-in on Friday. I still have that as not confirmed. Ask today; if she says no, sort a bag-drop/luggage plan.
2. **Ger covering clients** — did Ger confirm she’ll take your clients while you’re away? If not, nudge her this week before the handover.
3. **Race pack / expo** — check your bib-pickup window and what ID/confirmation you need. Do it Friday or Saturday, not race morning.
4. **Travel basics** — passport/passport card, travel insurance, EHIC/GHIC, boarding passes, phone roaming. Your flight is 7:10 Friday, so aim to be packed Thursday night and at the airport early.
5. **Biscuit** — is minding/feeding sorted while you’re away? I don’t have that noted.
6. **Return leg** — you’re on the Tuesday 18:40 flight home, apartment until the 28th. That all looks consistent.

One thing not strictly Berlin-related: **CORU renewal** is still down as unconfirmed from July. If you haven’t done it, get it sorted before you go.

Want me to draft the host message or the Ger text?

### B

Good call to do a last sweep while you've still got a functioning brain. From what I've got, everything's mostly in place — but there are two loose ends worth checking, and one of them is genuinely important.

**1. CORU renewal — the serious one.**
Your renewal was due **30 July**, and as far as my records show it's still *not confirmed done*. This has been flagged a few times now, and it's the kind of thing that can't slide: if it's not submitted you can't legally practise as a physio. I don't want to nag, but is it actually done and I've just never been updated? If not, today's the day to upload the CPD record and pay the fee.

**2. Biscuit's kennel booking — the time-sensitive one.**
The plan was to ring Hollybank Kennels in Ashbourne to book him in for 24–28 Sep, but I've no record it was ever confirmed. That's now **four days away**. If it's not booked, ring them this morning — kennels can be full at this stage, and it's his first time in so you'll want to sort it properly rather than scramble Friday morning.

While you're at it: make sure his **vaccination cert (and kennel cough)** is up to date and in your hand before drop-off. You'd planned to ring Phibsborough Vets about his booster back in July — if that never actually got done, the kennel might want it sorted.

**Everything else looks done:**
- ✈️ Flights — Dublin→Berlin 24 Sep 7:10, back 27 Sep 18:40 ✓
- 🏠 Apartment in Friedrichshain, 24–28 Sep ✓
- 🏃 Race day Sunday 26th, sub-3:45 attempt ✓

So really it's just: **is CORU done, and is Biscuit booked in?** If you tell me the state of both, I'll note it properly so it stops chasing you. Want me to draft a quick message to Ger or Niamh about anything before you go, or is cover for your clients already sorted?

### C

Race week. You’re in good shape — now it’s mostly logistics and not undoing the training.

I can’t see your inbox, so some of these are unconfirmed rather than assumed done.

## Sort today or tomorrow

- **Biscuit / Hollybank:** confirm booking for **24–28 Sept**, drop-off/pickup times, vaccination cert, and whether they need kennel cough proof. If the booster didn’t get booked after that July reminder, call Phibsborough Vets now.
- **Ger/client cover:** get a clear yes and make sure your handover notes are done before Friday.
- **CORU:** if that July renewal still hasn’t happened, do it before you fly. Don’t carry it to Berlin.
- **Berlin host/check-in:** have the address, keys/code, contact number, and your 11am check-in confirmation saved offline.

## Race and travel admin

- **Online check-in** for Friday’s 7:10 flight when it opens — don’t leave it to airport panic.
- **Airport transport:** book taxi or plan route for a **4:45–5:00am** arrival at Dublin Airport.
- **Passport / ID, EHIC/GHIC, travel insurance** — confirm insurance covers marathon running.
- **Phone/data roaming:** check your Irish plan covers Germany or buy a small add-on.
- **EU plug adapter:** Ireland uses 3-pin, Germany uses 2-pin.
- **Bib pickup/expo:** plan to go Friday afternoon or Saturday morning. Have photo ID and race confirmation.
- **Transport to the start:** check what’s included with your race number, and screenshot the route.

## Packing

- Race outfit + shoes you’ve trained in, nothing new
- Gels/nutrition you’ve used on long runs
- Watch and charger, phone charger, power bank
- Throwaway layer for race morning
- Comfy post-race clothes and shoes
- Plasters/BodyGlide/Vaseline
- Paracetamol/ibuprofen, plasters, any personal meds
- Printed or offline hotel address and key info

## Training/taper this week

Don’t try to bank fitness now. A few short easy runs with a little marathon-pace feel, plus strides, is enough.

- Thursday/Friday travel will tire you more than a normal easy run
- Saturday: short shakeout and keep walking to a minimum
- Sunday: race pace only, stay calm in the first 5k, trust the long-run practice

Want me to turn this into a printable checklist or a short note for Ger/Hollybank?



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [3], "conditions": []}, "C": {"critical": [1], "conditions": [{"type": 1, "condition": "Holds if 'your 11am check-in confirmation' is read as asserting the host confirmed the early check-in."}]}}
