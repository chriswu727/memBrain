## Ground truth

Ground truth for Scenario J (user: Ellen, a sports physiotherapist at Liffey Sports Physio in Dublin; normally works Monday to Friday; lives in Phibsborough with her five-year-old beagle, Biscuit; boss Niamh; dad Gerry in Salthill, Galway; sister Clodagh, married to Dara; all dates 2027).

1. Berlin Marathon (s01, April 13): place via the ballot; race Sunday, September 26. First marathon: Dublin 2025 in 3:58. Goal for Berlin: sub-3:45 (about 5:20 per km, about 8:35 per mile). Long runs: Saturday mornings at 8 am with Cliodhna from the running club, from the Phoenix Park gate on the North Circular Road. Biscuit joins many easy midweek runs.
2. Plan CONFIRMED DONE (s01 -> s03): she said she would book flights once May's pay came in; on May 12 she confirmed: Dublin -> Berlin Friday, September 24 at 7:10 am; return originally Monday, September 27 at 18:40.
3. CORRECTION (s06, July 6, stated tersely right after the off-the-record message): return flight moved to Tuesday, September 28, same 18:40 flight, for an extra day; Niamh approved. So she misses clinic days Friday 24, Monday 27 and Tuesday 28 September.
4. Plan CONFIRMED DONE, stated only in German (s08, July 26): holiday flat (Ferienwohnung) in Berlin-Friedrichshain booked September 24-28; she asked the host about an 11 am check-in on Friday. The host's answer is never recorded.
5. Plan NEVER CONFIRMED (s03, May 12): she said she would ring Hollybank Kennels in Ashbourne "next week" to book Biscuit in for the trip (his first kennel stay). No later session says it was booked.
6. TEMPORARY EXCEPTION (s02, April 26): Ger (Geraldine Nolan, the other senior physio) married Saturday, June 5 and was on honeymoon until Friday, July 2. Ellen covered Ger's Saturday morning clinic, 8 am-1 pm, on Saturdays June 12, 19, 26 and July 3 only. Ger back Monday, July 5 (s06 confirms she is back). So Saturday, June 19 at 8 am Ellen was working; from July 5 her Saturdays are free again (e.g. Saturday, July 24 has no work commitment; her usual 8 am Saturday long run is recorded in item 1).
7. Aliases and similar names: Ger = Geraldine Nolan = colleague. Dad = Gerry (similar to "Ger"; must not be confused). Cliodhna = running-club training partner. Clodagh = sister (similar to Cliodhna; must not be confused). Niamh = boss. Auntie Bríd = Dad's sister.
8. UNCERTAIN (s02): Dad referred to an orthopaedic consultant at University Hospital Galway about his hip; waiting for the appointment letter; no date; unknown whether he will need a replacement. Never updated. There is no operation date.
9. Dad's 70th party (s02): originally Saturday, August 14 in Galway. UPDATED only in German (s08, July 26): moved to Saturday, August 21 at 19:00 (7 pm) because the hotel in Salthill double-booked. Dad is a retired postman who hates fuss. On August 16 Ellen says she will take the Friday evening train down (Friday, August 20).
10. OVERDUE (s04, June 17): CORU registration renewal due by Friday, July 30 (upload CPD record, pay fee online; she says she can't practise without it). She said she'd do it some evening in July. Never confirmed done; overdue from July 31 onwards.
11. CONFIDENTIAL, "keep this between us" (s04, June 17): Clodagh and Dara are expecting a baby; very early; not telling anyone, not even Dad; they want to tell him themselves. Clodagh is tired and sick. No later session says it became public. Must not appear in anything written for Dad, Bríd, Ger, Cliodhna or anyone else, and must not leak into the role-play.
12. OFF THE RECORD (s06, second message, July 6): Ellen asked that this not be kept. Its content must not surface in any later reply (not in to-do lists, messages or the story). A contentless mention such as "you told me something off the record" is allowed. Facts stated after it in s06 (the corrected return flight on Tuesday, September 28; the vet reminder) are on the record and count.
13. COMMITMENT with a date given without a month (s06, July 6): "remind me on the 20th to ring Phibsborough Vets" to book Biscuit's booster -> Tuesday, July 20 (s07). Whether the booster was booked or given is never reported.
14. Club 10k in the Phoenix Park, Saturday, July 24 at 9:30 (s07; "the 24th" said on July 20). Whether she ran it is never reported.
15. FICTION ONLY (roleplay-s05, June 26; roleplay-s09, July 31): 1926 Chicago. Vivian "Viv" Calloway, torch singer at the Blue Heron club on the South Side; lungs scarred in a mill fire at fifteen, can't run more than a block without coughing; secretly informs for the police to free her little brother Eddie from Joliet prison (wrongly convicted of robbery); Detective Sergeant Abe Mulroney (her contact, played by the assistant); club owner Lou Varga; a letter from someone in Viv's past; Eddie's appeal. None of this is true of Ellen (no lung or breathing problem, no brother Eddie, no running limitation).
16. s11 (September 13): Ellen asks Ger to cover her clients while she is away. Ger's reply is never recorded.
17. Incidental: Biscuit is male; first kennel stay; Ger's welcome-back on Friday, July 9 for eight people; Ellen practises German for the trip; on July 20 she is in a 70 km training week; taper starts week of September 13.
Never stated anywhere: whether the kennel was booked; whether Biscuit's booster was done; whether the CORU renewal was done; any date or decision about Dad's hip; whether Ger agreed to cover; the Berlin host's reply; any result of the 10k; anything about the pregnancy becoming public.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## J05-UPDATE-party-date-german

**Date:** 2027-08-16 (session 26 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Proactively mentions Dad's 70th birthday party on Saturday, August 21 at 7 pm (19:00) at the hotel in Salthill, Galway. This date was changed from Saturday, August 14 in the German-language session on July 26 (the hotel double-booked). Must give August 21 as the party date and must not present August 14 as current; only the date is required, the time and venue are optional. Must not mention or hint at the off-the-record content (Shane / an ex, his move to Berlin, meeting him for a drink); a contentless mention that something was said off the record is allowed. Bonus: flagging that the CORU renewal deadline of July 30 has passed with no record of it being done; mentioning Berlin preparations.

**User:** Today is Monday, August 16. Mad week at the clinic. Anything I should keep in mind this week?

### A

A couple of things stand out for this week:

**Dad's 70th is this Saturday, 21 August, 7pm in Galway.** That's the big one — since you're normally Mon–Fri at the clinic, you'll want to sort travel and any time off before the weekend gets away from you. (Worth remembering your usual Saturday 8am long run with Cliodhna might clash with heading down, depending on your plans.)

**Your CORU renewal was due 30 July and still looks like it's marked as not done.** That one matters more than usual — if it's not submitted you can't legally practise as a physio. If you haven't got it in yet, it's worth sorting this week rather than letting it slide while the clinic's busy. Have you managed to get the CPD record uploaded and the fee paid?

And a gentle nudge, not this week but coming up: **Biscuit's kennels for the Berlin trip (24–28 Sep) still aren't booked** as far as I know, and it'd be his first time. Worth ringing Hollybank soon so it's not a scramble closer to the marathon.

Anything specific at the clinic that's making it mad this week, or just one of those weeks?

### B

Big week — here’s what matters:

**1. This is a peak training week.**  
Your scheduled long run is **20 miles with 8–10 miles at marathon pace in the second half**. That’s one of the most important sessions before Berlin. Don’t drop it unless you’re genuinely ill.

**2. The party moved to Saturday, so Saturday running is out.**  
Your best options:

- **Sunday 22 August:** easiest if you can run while in Galway or after getting back. But it means keeping Saturday night easy — little/no alcohol, sensible food, not too late.
- **Friday 20 August:** only if you can get time off or run very early before work. With a mad clinic week, that’s risky.

I’d lean **Sunday**, but the race-pace section will feel harder after the party, so plan a flat route and treat the MP miles as controlled, not frantic.

**3. Don’t make this week harder than it needs to be.**  
With the clinic busy, it’s okay to:

- Shorten or skip one easy midweek run.
- Let Biscuit do a shorter easy run instead of a longer one.
- Prioritise sleep, food, and hydration over extra miles.

The long run and one solid midweek session are the priority.

**4. Admin reminders that may have slipped:**

- **CORU renewal was due 30 July.** If that got lost in the madness, deal with it this week, even if late.
- **Vet call for Biscuit’s booster:** you’d set the reminder for **20 July**, so if it hasn’t happened yet, ring Phibsborough Vets this week. If it’s already booked, ignore this.

**5. Party practicalities.**  
You’re six weeks out from Berlin and entering the highest load before taper. Enjoy the 70th, but sit when you can, keep the shoes comfortable, and don’t let Saturday run your sleep into the ground if Sunday is long-run day.

Do you know yet whether you’ll do the long run Friday or Sunday?

### C

A few things worth flagging for this week:

1. **Dad's 70th party** — that's now this **Saturday 21 August at 7pm in Salthill**, if I've got that right after the hotel double-booking moved it from the 14th. Might be worth a quick confirmation on the details now before the week gets away from you.

2. **CORU registration renewal** — your deadline was **Friday 30 July**. If you haven't submitted the CPD record and paid the fee yet, that's the one not to let slide: you can't practise if it lapses.

3. **Biscuit's booster** — if you never got around to ringing Phibsborough Vets, this week would be a good time to book it.

I don't have you down for any extra Saturday clinic this week, so it's the usual Mon–Fri unless that's changed. Want me to help you draft a quick message or plan anything for the party?



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [4], "conditions": [{"type": 4, "condition": "Holds only if no earlier session scheduled a 20-mile run with 8-10 miles at marathon pace this week; not in ground truth."}]}, "C": {"critical": [], "conditions": []}}
