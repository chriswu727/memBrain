import importlib.util
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

root=Path('/Users/yichen/tmp/membrain-neural-evidence-20261103')
spec=importlib.util.spec_from_file_location('topology_measure',Path('scripts/measure_observatory.py').resolve())
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
report={'runtime_pin':'84e973a8686ee6716bcf11123498a914a28db804','fixture':'Actual structure-map responses from a fictional 1000-message database fixture; not a dense maximum-edge test','machine':m._machine(),'runs':[]}
server=m.StaticServer()
try:
    with sync_playwright() as pw:
        browser=pw.chromium.launch(headless=False)
        report['browser']=browser.version
        for limit in (200,500):
            payload=json.loads((root/f'topology-real-fixture-map{limit}.json').read_text())
            m.fixture_map=lambda *_: payload
            context=browser.new_context(viewport={'width':1280,'height':900},device_scale_factor=1,locale='en-US')
            context.add_init_script(m.RAF_COUNTER)
            page=context.new_page()
            errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
            cdp=context.new_cdp_session(page);cdp.send('Performance.enable')
            run=m.measure(page,server,len(payload['nodes']),len(payload['edges']),40,cdp)
            run['node_limit']=limit
            run['renderer']=page.evaluate('() => window.observatory.renderer()')
            page.locator('#brain-showcase').click()
            page.wait_for_function('() => window.memoryHologram.snapshot().ready')
            state=page.evaluate('() => window.memoryHologram.snapshot()')
            assert set(state['nodeIds'])=={node['id'] for node in payload['nodes']}
            assert state['edges']==payload['edges']
            page.screenshot(path=str(root/f'topology-hologram-{limit}.png'))
            sample=page.evaluate('''() => new Promise(resolve => {
                const start=performance.now(), frames=window.memoryHologram.snapshot().frames;
                setTimeout(()=>resolve({elapsed_ms:performance.now()-start,frames:window.memoryHologram.snapshot().frames-frames}),5000);
            })''')
            sample['frames_per_second']=round(sample['frames']*1000/sample['elapsed_ms'],2)
            page.locator('#show-pause').click()
            before=page.evaluate('() => window.memoryHologram.snapshot().frames')
            page.wait_for_timeout(500)
            sample['paused_frames_500ms']=page.evaluate('() => window.memoryHologram.snapshot().frames')-before
            assert sample['paused_frames_500ms']==0
            page.locator('#show-close').click()
            assert not page.evaluate('() => window.memoryHologram.snapshot().ready')
            run['hologram']=sample
            run['page_errors']=errors
            assert not errors
            report['runs'].append(run)
            context.close()
        browser.close()
finally:
    server.close()
report['completed']=True
(root/'topology-real-render-mac.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps([{k:run[k] for k in ('node_limit','nodes','edges','renderer','interaction_input_to_frame_ms','hologram')} for run in report['runs']],indent=2))
