import cProfile
import io
import pstats
from pathlib import Path
from membrain import embedded_database, host
from membrain.client import MemoryClient
from membrain.helpers import Principal
from membrain.local_profile import load_profile
from membrain.service import MemoryService
from membrain.storage import Database

root=Path('/Users/yichen/tmp/membrain-neural-evidence-20261103')
profile=load_profile(root/'perf-8dc0ac3-installation')
embedded_database.start(profile)
db=Database(profile.database_url, pool=True)
try:
    principal=Principal(profile.tenant_id, profile.principal_id)
    service=MemoryService(db)
    client=MemoryClient(profile.base_url, profile.api_key, brain_id=host.user_brain_id('bench-user-0'))
    client.send=lambda request, **kw: service.handle(principal, request)
    host.recall(client, 'What is the appointment for project0007?')
    profiler=cProfile.Profile()
    profiler.enable()
    for i in range(5):
        result=host.recall(client, f'What is the appointment for project{i:04d}?')
        assert result['outcome']=='completed', result.get('error')
        assert result['result']['items']
    profiler.disable()
    stream=io.StringIO()
    pstats.Stats(profiler,stream=stream).sort_stats('cumulative').print_stats(55)
    (root/'recall-profile-after-flat.txt').write_text(stream.getvalue())
    print(stream.getvalue())
    client.close()
finally:
    db.close()
    embedded_database.stop(profile)
