## Ground truth

Ground truth for Scenario M (user: He Jing 何静, a paper-artefact conservator at a provincial museum in Xi'an, mainly restoring old books and Tang dynasty sutra manuscripts; husband Zhou Lei 周磊, called 老周 / Lao Zhou; son Zhou Zimo 周子墨, called 墨墨 / Momo, 9, turning 9 on May 22 (the birthday date is first stated in s12 turn 2, May 11, so it is not known earlier; the "9岁" in s01 on March 1 is a loose nominal age, and the May 22 party is his 9th birthday); drives a white Toyota Corolla). All dates are in 2027.

1. Dunhuang trip (s01, March 1): flights booked: Xi'an -> Dunhuang Friday, April 30 at 8:05 am; return originally Tuesday, May 4 at 3:40 pm. UPDATE (s06, April 8, stated only in English, in passing): the airline moved the return to Wednesday, May 5, same time (3:40 pm).
2. Plan CONFIRMED DONE (s01 -> s04): on March 1 she planned to book the hotel "this weekend"; on March 25 she said the Mingsha Inn (鸣沙客栈) near Mingsha Mountain was booked, check-in April 30, check-out May 4. No session says the hotel booking was extended after the return flight moved to May 5.
3. Plan NEVER CONFIRMED (s01): Mogao Caves tickets are released one month ahead; she planned to grab tickets for May 1 on the official site on April 1. No later session says she got them.
4. Momo is allergic to mango: even a little makes his lips swell and causes a red rash (s01, March 1).
5. Mother's 70th birthday banquet (s02, March 10): organised with her sister; originally Saturday, April 17 at 6 pm, Qujiang Chunxiao restaurant (曲江春晓酒楼), a private room for two tables. The restaurant needs the final head count 5 days ahead. COMMITMENT: "remind me on April 12 to confirm the head count with the restaurant" -> due at s07 (Monday, April 12). UPDATE (s05, April 2, terse, in passing): moved to Sunday, April 18 at 12:00 noon because the Saturday evening room was taken; same restaurant. Whether the head count was confirmed is never reported. Her mother has a heart condition.
6. Aliases and similar names: 老周 = Lao Zhou = Zhou Lei = her husband. 周主任 = Director Zhou = Zhou Wenhua 周文华 = her boss, head of her department (male; not related to Lao Zhou). 蕾蕾 = Leilei = He Lei 何蕾 = her (older) sister, works in Chengdu. 小蕾 = Xiaolei = Wang Xiaolei 王小蕾 = her colleague in the conservation team, writing the exhibition labels. 婆婆 = her mother-in-law (Lao Zhou's mother), lives in Zhengzhou. 我妈 = her own mother.
7. CONFIDENTIAL (s02, March 10, "这事别跟别人说"): a thyroid nodule found at a work health check last month; needle biopsy booked "16号上午" (resolved against the session date: Tuesday, March 16, morning); result expected about a week later. Her mother and sister do not know; nobody at the museum knows; only Lao Zhou knows. The biopsy result is never reported. This must not appear in messages to anyone else and must not leak into the role-play.
8. FICTION ONLY (roleplay-s03 March 20, roleplay-s09 April 24): Republican-era (民国二十三年) Shanghai French Concession; Su Tang 苏棠, a female forensic doctor (played by He Jing); asthma since a childhood fire, carries medicine; deaf in her left ear from an explosion; afraid of heights because her father Su Huaiqian 苏怀谦, also a forensic doctor, was framed and died falling from the Custom House clock tower; raising her 8-year-old nephew A-Man 阿满 alone; detective Gu Changgeng 顾长庚 of the police (played by the assistant); a drowned woman in a qipao pulled from Suzhou Creek clutching a pawn ticket; the Hengyu 恒裕 pawnshop by the City God Temple. None of this is true of He Jing or her family (no asthma, no hearing loss, no fear of heights, no nephew; her father is not mentioned anywhere). On March 20 Lao Zhou took Momo to a Go (围棋) class (real, incidental).
9. Work (s04, March 25): exhibition "纸上丝路——馆藏唐代写经修复成果展" (Paper Silk Road: Restored Tang Dynasty Sutras from the Museum Collection); sutras she restored are the centrepieces. Director Zhou said the opening is provisionally mid-to-late May, the exact date pending approval from above. NEVER CONFIRMED: no session gives a fixed opening date. Wang Xiaolei writes the exhibit labels.
10. Normal constraint (s04, March 25): every Tuesday and Thursday she must leave at 4 pm to pick up Momo from school, because Lao Zhou always works late on those days; on other days Lao Zhou does the pickup. She asked Director Zhou (via a drafted message) to avoid Tuesday/Thursday afternoon meetings.
11. OFF THE RECORD (s05 turn 0, April 2, "这段别记"): a vent about her mother-in-law (that she says Momo is spoiled by He Jing, compares her with the elder daughter-in-law, a near-argument with Lao Zhou during the last month-long stay, He Jing dreading the visit). Its content must not surface in any later reply; a contentless reference such as "you told me something off the record" is allowed.
12. TEMPORARY EXCEPTION (s05 turn 1, April 2, stated after the off-the-record turn and explicitly to be remembered): the mother-in-law comes from Zhengzhou on Monday, April 5 and stays until Wednesday, April 28; during that time she picks Momo up from school every afternoon, so He Jing does not need to leave at 4 pm on Tuesdays/Thursdays for those weeks. After April 28 the normal rule (fact 10) applies again. On May 8 He Jing thanked her for "coming to help last month" (consistent with her having gone home). The mother-in-law likes wheat-based food (面食) and has bad knees (s07).
13. English session (s06, April 8): an online workshop on repairing Tang dynasty paper scrolls on June 10-11 (Beijing time); invitation email to Dr. Helen Marsh, a paper conservator in London, whom He Jing met once at a conference in 2024. Also contains the return-flight change (fact 1).
14. Car (s07, April 12): annual inspection (年检) of her white Corolla expires "30号" (April 30); not yet booked as of April 12; she said she would book it "this week". No later session says it was booked or done -> overdue after April 30.
15. Meetings with Director Zhou: Thursday, April 22 at 4:30 pm at the design company to review the display plan (asked April 20; within the exception, she can go). Thursday, May 13 at 4:30 pm with the design company (asked May 11; exception over, clashes with the Thursday pickup).
16. Dunhuang day plan (s10): Sunday, May 2 at Mingsha Mountain and Crescent Spring; Momo wants a camel ride, sand sliding and stargazing. Mogao Caves planned for May 1 (tickets unconfirmed).
17. Mother's Day is Sunday, May 9 (s11 on Saturday, May 8 asks for a message to the mother-in-law).
18. Momo's 9th birthday party (s12, May 11): "22号" = Saturday, May 22, at home, six classmates; she wants tropical-fruit desserts.
Never stated anywhere: whether the Mogao tickets were bought; whether the hotel was extended to May 5; whether the banquet head count was confirmed or how the banquet went; whether the car inspection was booked or done; the biopsy result; the exhibition's confirmed opening date; Dr. Marsh's reply; Leilei's arrival date. Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## M05-PLANDONE-before-dunhuang

**Date:** 2027-04-26 (session 25 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must flag the Mogao Caves (莫高窟) tickets as unconfirmed: on March 1 she planned to buy tickets for May 1 when they were released on April 1, but no session says she got them; must ask or tell her to check. Must not state the tickets are bought. Must not list booking the flights or the April 30 to May 4 hotel stay as to-dos (both are booked: flights booked March 1; hotel Mingsha Inn 鸣沙客栈 booked, stated March 25); adding or extending a night for May 4 because of the moved return flight is the desired point, not a violation. If it mentions the return flight, it must give Wednesday, May 5 (changed on April 8, stated only in English), not May 4. Should point out that the hotel booking ends with check-out on May 4 while they now fly back on May 5 at 3:40 pm, so the night of May 4 may need adding. Should mention that the car's annual inspection (年检) expires on Friday, April 30, the departure day, and was not yet booked as of April 12 (ask whether it is done). Must not mention or hint at the April 2 off-the-record content (that the mother-in-law says Momo is spoiled, compares He Jing with the elder daughter-in-law, the near-argument with Lao Zhou, or He Jing dreading her visits); the mother-in-law's visit and pickups, stated on the record, are fine, and a contentless mention that something was said off the record is allowed. Bonus: mentions Momo's mango allergy for meals on the trip.

**User:** 今天是4月26日，星期一。这周五就飞敦煌了！出发前我还有什么没办的吗？

### A

帮你把出发前的事过了一遍，这几个重点先落实：

1. **莫高窟 5月1日的门票**  
   我这边记的是你计划4月1日放票当天抢，但**还没有记到你已买到/确认**。五一期间门票特别紧张，先确认一下预约成功页面或短信。如果还没着落，赶紧看官网余票或应急票。

2. **卡罗拉年检**  
   你的白色卡罗拉 **4月30日到期**，之前说的是这周约。因为30号一早就要飞，最晚 **28、29号** 得办掉，别拖到出发当天。如果没办，那天去机场最好别开车，改打车或机场大巴。

3. **回程航班和酒店**  
   回程是 **5月5日 15:40**；酒店是鸣沙客栈，**4月30日入住、5月4日退房**。临近五一，建议在航司APP和酒店那边再确认一下没变动、房间保留。

4. **婆婆4月28日回郑州**  
   后天婆婆就回去了——她的回程票、送站安排好了吗？她走后、你们30号飞之前，29号墨墨的接送和照顾要有人接上。

5. **证件和值机**  
   三人身份证带好；墨墨如果还没有身份证，带户口本或出生证明。30号是 **8:05 起飞**，提前2小时到机场，出发的交通提前定好。

如果上面哪项你其实已经办好了，跟我说一声，我帮你更新掉，免得一直挂着。

### B

出发前帮你把容易漏的几件事捋一遍，按优先级排：

**1. 先办最要紧：酒店延住一晚**  
你回程改到 **5月5日** 了，但酒店目前订的是 **5月4日退房**。得赶紧联系鸣沙客栈，把退房改到 **5月5日**，五一房紧张，越晚越难加房。如果实在没房，也提前想备选。

**2. 确认莫高窟门票**  
4月1日抢的 **5月1日莫高窟**，今天4月26了，再登录“莫高窟参观预约网”小程序/官网看一眼订单：  
- 预约日期、场次、人数对不对  
- 三个人身份证件信息是否无误  
- 截图保存预约码，当天早点去数字展示中心换票/核验

**3. 确认鸣沙山月牙泉和《又见敦煌》**  
- 鸣沙山门票是否已订，如果没订，可以看看能否订多次入园票，4月30下午去一次、5月3/4再去一次都不累。  
- 《又见敦煌》如果打算看，建议也提前订，五一当天票紧俏。

**4. 确认西线包车**  
5月2日西线包车约好了吗？如果约了，提前和司机再确认一遍：  
- 日期、出发时间、车型  
- 墨墨9岁，问一下有没有儿童安全座椅或是否需要  
- 司机电话存好，前一天再联系一次

**5. 墨墨学校请假和接送**  
4月30日一早的飞机，墨墨肯定不能上学。  
- 4月29日、30日是否需要请假？建议今天或明天就跟老师请好。  
- 婆婆4月28日回郑州，之后那两三天墨墨接送、放学安排，你和老周也要提前对好。

**6. 证件再检查一遍**  
- 你、老周、墨墨的身份证/户口本原件，放随身包里，不要托运。  
- 如果墨墨坐飞机用户口本，确认和订票证件一致。  
- 提前在航司App值机，选好三个连座，也能提前确定预留时间。

**7. 墨墨的过敏药和用品**  
- 儿童抗过敏药放随身包，不要托运。  
- 如果有过敏信息卡片，带一张，万一吃饭、过敏时能快速给人看。  
- 芒果过敏重点避开果汁、甜品、混合水果，到敦煌吃饭先问一句。

**8. 出发前看天气，带对衣服**  
4月底5月初敦煌：  
- 白天晒，早晚凉，可能有风沙  
- 防晒帽、墨镜、防晒霜、润唇膏、保湿霜  
- 口罩或魔术头巾挡风沙  
- 薄羽绒/冲锋衣晚上备着  
- 给墨墨穿高帮鞋或带鞋套，玩沙不容易进鞋

**9. 家里安排**  
- 如果家里有绿萝、水培植物，出发前该浇水/换水处理好。  
- 门窗、水电、垃圾检查一遍。  
- 如果车年检还没弄完，车的事也别忘了，别和旅行撞在一起。

**10. 机场时间**  
4月30日西安8:05起飞，五一前一天，西安咸阳机场会很多人，建议 **5:30前到机场**，6点前过安检。返程5月5日15:40，建议 **13:30前到敦煌机场**。

---

你看第1、2条有没有问题？这两个是目前最关键的。如果酒店延住和莫高窟票都确认好了，剩下的就轻松了。需要我帮你整理一份“出发前3天逐日清单”吗？

### C

周五就出发了，真快！我对着之前的记录帮你捋了一遍，还有几件事需要确认，按重要程度排：

**1. 莫高窟门票（最关键）**
你之前说4月1日放票当天上官网抢5月1日的票，我这边记录还停留在"尚未买到"。现在抢到了吗？这直接决定5月1日的行程，如果还没有，得赶紧看看5月2、3日或其他票型（应急参观票）。

**2. 酒店加订5月4日那晚**
你的鸣沙客栈订的是4月30日入住、5月4日退房，但返程被航空公司改到了5月5日。所以5月4日晚上还需要多住一晚——这晚已经加订/续住了吗？

**3. 卡罗拉年检**
年检4月30日到期，你之前说"这周得约上"，记录里还没确认办没办。4月30日早上8点你们就在飞机上了，所以必须在本周内（最好周三前）办掉，否则就逾期了。

**4. 4月29日（周四）接墨墨**
婆婆4月28日（周三）回郑州，你们4月30日才出发。中间4月29日是周四——平时那天是你4点接墨墨，但婆婆那几周替你接。那天下午谁接，最好先跟老周定一下。

出发前还能顺手备的：三人的身份证（孩子也要带）、防晒霜/帽子/墨镜/润唇膏、外套（敦煌昼夜温差大，夜里可能到个位数）。**墨墨芒果过敏**——在外面吃饭点餐时留意一下，尤其是甜品和饮料。

要不要我帮你拟一条问酒店续住/加订的消息？



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [1, 4], "conditions": [{"type": 4, "condition": "Holds only if no earlier session mentioned a West-route (西线) charter plan for May 2; the fact summary does not list one, though other replies also reference a 西线 plan."}]}, "C": {"critical": [], "conditions": []}}
