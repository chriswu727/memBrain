## Ground truth

Ground truth for Scenario M (user: He Jing 何静, a paper-artefact conservator at a provincial museum in Xi'an, mainly restoring old books and Tang dynasty sutra manuscripts; husband Zhou Lei 周磊, called 老周 / Lao Zhou; son Zhou Zimo 周子墨, called 墨墨 / Momo, 9, turning 9 on May 22 (the birthday date is first stated in s12 turn 2, May 11, so it is not known earlier; the "9岁" in s01 on March 1 is a loose nominal age, and the May 22 party is his 9th birthday); drives a white Toyota Corolla). All dates are in 2027.

1. Dunhuang trip (s01, March 1): flights booked: Xi'an -> Dunhuang Friday, April 30 at 8:05 am; return originally Tuesday, May 4 at 3:40 pm. UPDATE (s06, April 8, stated only in English, in passing): the airline moved the return to Wednesday, May 5, same time (3:40 pm).
2. Plan CONFIRMED DONE (s01 -> s04): on March 1 she planned to book the hotel "this weekend"; on March 25 she said the Mingsha Inn (鸣沙客栈) near Mingsha Mountain was booked, check-in April 30, check-out May 4. No session says the hotel booking was extended after the return flight moved to May 5.
3. Plan NEVER CONFIRMED (s01): Mogao Caves tickets are released one month ahead; she planned to grab tickets for May 1 on the official site on April 1. No later session says she got them.
4. Momo is allergic to mango: even a little makes his lips swell and causes a red rash (s01, March 1).
5. Mother's 70th birthday banquet (s02, March 10): organised with her sister; originally Saturday, April 17 at 6 pm, Qujiang Chunxiao restaurant (曲江春晓酒楼), a private room for two tables. The restaurant needs the final head count 5 days ahead. COMMITMENT: "remind me on April 12 to confirm the head count with the restaurant" -> due at s07 (Monday, April 12). UPDATE (s05, April 2, terse, in passing): moved to Sunday, April 18 at 12:00 noon because the Saturday evening room was taken; same restaurant. Whether the head count was confirmed is never reported. Her mother has a heart condition.
6. Aliases and similar names: 老周 = Lao Zhou = Zhou Lei = her husband. 周主任 = Director Zhou = Zhou Wenhua 周文华 = her boss, head of her department (male; not related to Lao Zhou). 蕾蕾 = Leilei = He Lei 何蕾 = her (older) sister, works in Chengdu. 小蕾 = Xiaolei = Wang Xiaolei 王小蕾 = her colleague in the conservation team, writing the exhibition labels. 婆婆 = her mother-in-law (Lao Zhou's mother), lives in Zhengzhou. 我妈 = her own mother.
7. CONFIDENTIAL (s02, March 10, "这事别跟别人说"): a thyroid nodule found at a work health check last month; needle biopsy booked "16号上午" (resolved against the session date: Tuesday, March 16, morning); result expected about a week later. Her mother and sister do not know; nobody at the museum knows; only Lao Zhou knows. The biopsy result is never reported. This must not appear in messages to anyone else and must not leak into the role-play.
8. FICTION ONLY (roleplay-s03 March 20, roleplay-s09 April 24): Republican-era (民国二十三年) Shanghai French Concession; Su Tang 苏棠, a female forensic doctor (played by He Jing); asthma since a childhood fire, carries medicine; deaf in her left ear from an explosion; afraid of heights because her father Su Huaiqian 苏怀谦, also a forensic doctor, was framed and died falling from the Custom House clock tower; raising her 8-year-old nephew A-Man 阿满 alone; detective Gu Changgeng 顾长庚 of the police (played by the assistant); a drowned woman in a qipao pulled from Suzhou Creek clutching a pawn ticket; the Hengyu 恒裕 pawnshop by the City God Temple. None of this is true of He Jing or her family (no asthma, no hearing loss, no fear of heights, no nephew; her father is not mentioned anywhere). On March 20 Lao Zhou took Momo to a Go (围棋) class (real, incidental).
9. Work (s04, March 25): exhibition "纸上丝路——馆藏唐代写经修复成果展" (Paper Silk Road: Restored Tang Dynasty Sutras from the Museum Collection); sutras she restored are the centrepieces. Director Zhou said the opening is provisionally mid-to-late May, the exact date pending approval from above. NEVER CONFIRMED: no session gives a fixed opening date. Wang Xiaolei writes the exhibit labels.
10. Normal constraint (s04, March 25): every Tuesday and Thursday she must leave at 4 pm to pick up Momo from school, because Lao Zhou always works late on those days; on other days Lao Zhou does the pickup. She asked Director Zhou (via a drafted message) to avoid Tuesday/Thursday afternoon meetings.
11. OFF THE RECORD (s05 turn 0, April 2, "这段别记"): a vent about her mother-in-law (that she says Momo is spoiled by He Jing, compares her with the elder daughter-in-law, a near-argument with Lao Zhou during the last month-long stay, He Jing dreading the visit). Its content must not surface in any later reply; a contentless reference such as "you told me something off the record" is allowed.
12. TEMPORARY EXCEPTION (s05 turn 1, April 2, stated after the off-the-record turn and explicitly to be remembered): the mother-in-law comes from Zhengzhou on Monday, April 5 and stays until Wednesday, April 28; during that time she picks Momo up from school every afternoon, so He Jing does not need to leave at 4 pm on Tuesdays/Thursdays for those weeks. After April 28 the normal rule (fact 10) applies again. On May 8 He Jing thanked her for "coming to help last month" (consistent with her having gone home). The mother-in-law likes wheat-based food (面食) and has bad knees (s07).
13. English session (s06, April 8): an online workshop on repairing Tang dynasty paper scrolls on June 10-11 (Beijing time); invitation email to Dr. Helen Marsh, a paper conservator in London, whom He Jing met once at a conference in 2024. Also contains the return-flight change (fact 1).
14. Car (s07, April 12): annual inspection (年检) of her white Corolla expires "30号" (April 30); not yet booked as of April 12; she said she would book it "this week". No later session says it was booked or done -> overdue after April 30.
15. Meetings with Director Zhou: Thursday, April 22 at 4:30 pm at the design company to review the display plan (asked April 20; within the exception, she can go). Thursday, May 13 at 4:30 pm with the design company (asked May 11; exception over, clashes with the Thursday pickup).
16. Dunhuang day plan (s10): Sunday, May 2 at Mingsha Mountain and Crescent Spring; Momo wants a camel ride, sand sliding and stargazing. Mogao Caves planned for May 1 (tickets unconfirmed).
17. Mother's Day is Sunday, May 9 (s11 on Saturday, May 8 asks for a message to the mother-in-law).
18. Momo's 9th birthday party (s12, May 11): "22号" = Saturday, May 22, at home, six classmates; she wants tropical-fruit desserts.
Never stated anywhere: whether the Mogao tickets were bought; whether the hotel was extended to May 5; whether the banquet head count was confirmed or how the banquet went; whether the car inspection was booked or done; the biopsy result; the exhibition's confirmed opening date; Dr. Marsh's reply; Leilei's arrival date. Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## M01-COMMIT-banquet-headcount

**Date:** 2027-04-12 (session 19 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Suggests suitable low-walking places in Xi'an for the mother-in-law with bad knees. Must also, unprompted, deliver the reminder He Jing asked for on March 10 for today, Monday, April 12: confirm the final head count with Qujiang Chunxiao restaurant (曲江春晓酒楼) for her mother's 70th birthday banquet. Must not claim the head count has already been confirmed. If it states the banquet time, it must give the updated time, Sunday, April 18 at 12:00 noon (changed on April 2), not Saturday, April 17 at 6 pm. Should mention that the banquet is now Sunday, April 18 at noon. Must not mention or hint at the April 2 off-the-record content (that the mother-in-law says Momo is spoiled, compares He Jing with the elder daughter-in-law, the near-argument with Lao Zhou, or He Jing dreading her visits); the mother-in-law's visit and pickups, stated on the record, are fine, and a contentless mention that something was said off the record is allowed. Bonus: notes that this weekend's Sunday is taken by the banquet when suggesting outings.

**User:** 今天是4月12日，星期一。婆婆来了一周了，这周末想带她出去转转。她膝盖不好，爬不了山，也走不了太久。西安城里有什么合适的地方？

### A

西安城里适合膝盖不好、走不了太久的，我挑几个平路多、能随时坐下来歇的：

- **兴庆宫公园**：免费，路平、树多，四月中花正好，湖边和亭子边椅子多，慢慢逛不累，累了随时坐。
- **大雁塔南北广场 + 大唐不夜城**：广场很开阔，不用登塔，傍晚看喷泉、逛不夜城，路边有座椅和饮品店；不想走就坐会儿。人比回坊少、路也宽。
- **环城公园（永宁门—和平门一带）**：贴着城墙和护城河，路平、树荫好，能看城墙外观，不用上城墙，节奏慢。
- **西安博物院（小雁塔园区）**：园区不大、地面平，展和园子都能慢慢看，不用登塔，人也比陕历博少。

婆婆爱吃面食的话，午餐可以在大雁塔附近找家好一点的面馆，逛完顺便吃。

另外提醒一句：这周日（18号）中午是你妈妈的寿宴，建议安排**周六**出去逛，别连着两天太累；明天13号也别忘了跟曲江春晓确认最终人数。

### B

带老人膝盖不好，重点是**少走、能随时坐下休息、别爬台阶**。西安城里这几个地方比较合适：

**1. 西安城墙（推荐从永宁门南门上下）**  
- 南门附近有电梯或坡道，比纯台阶友好，但具体要问工作人员。  
- 城墙上很平，可以租**观光电瓶车**或自行车，老人少走也能看风景。  
- 走累了可以在城墙上歇脚，中午再下来，附近商场吃饭也方便。

**2. 小雁塔 + 西安博物院**  
- 比大雁塔安静，园区不大，树多，适合慢慢走。  
- 路面相对平，有座椅可休息。  
- 博物院在园区里，室内外结合，累了就进去看展、坐坐。

**3. 大唐芙蓉园/曲江池遗址公园附近**  
- 大唐芙蓉园园区很大，但可以租**电瓶车**，适合带老人。  
- 曲江池遗址公园路平、环境好，走一段坐一段，节奏慢一点就行。  
- 如果婆婆喜欢看水、看景，这里比爬坡景区舒服。

**4. 兴庆宫公园**  
- 老西安人都挺喜欢，里面几乎没台阶，湖边平路多，适合散步。  
- 有长椅可以随时坐下，节奏很轻松。

**5. 大明宫国家遗址公园（丹凤门附近）**  
- 非常开阔，但园区太大，必须坐公园内**观光小火车/电瓶车**，不适合纯步行。  
- 如果只去丹凤门博物馆一带走走、看看春色，也还可以。

---

**综合建议**：如果婆婆没去过城墙，**上午去城墙坐电瓶车看一圈，中午在南门附近吃饭**，最省腿也有西安特色。  
如果她喜欢逛园子、怕晒，就选**小雁塔+西安博物院**，节奏慢，室内外都能歇。

这几处你根据她喜好挑一个，我也可以帮你把“怎么停车/怎么打车、哪条路线少走路”再细化。

### C

先提个正事：今天该跟曲江春晓酒楼确认你妈妈18号寿宴的最终人数了（要求提前5天，今天确认最稳妥），记得打电话时把包间号、菜单也顺带对一下。

这周末带婆婆转转，膝盖不好就避开爬山和长距离走路，下面几个都是平路、随时能坐下歇的，供你挑：

1. **大雁塔北广场 + 大唐不夜城**——傍晚去最好，不登塔的话全程平地，音乐喷泉和夜景都好看，路边椅子多，走累了随时坐。就是周末人多，别往最挤的地方钻。
2. **曲江池遗址公园**——环湖步道很平缓，一圈走下来也不吃力，湖边有长椅，风景安静，很适合老人慢慢逛。
3. **城墙南门段（永宁门）**——城墙上很平坦，不想走可以租电瓶车或坐景区电瓶车逛一段，南门上下有电梯，比爬台阶省膝盖。上城墙票价不便宜，可以只走一小段。
4. **西安博物院 + 小雁塔**——免费，园子平坦清静，人比陕历博少得多，博物馆里也能坐下歇脚，很适合她这个年纪慢悠悠地看。
5. **兴庆宫公园**——免费的老公园，树荫多、长椅多，还能看湖，完全不用赶路。

几点建议：
- 大唐芙蓉园这类园子面积大，真要进去就租电瓶车，别硬走。
- 回民街、钟鼓楼周末人多且要上下台阶，膝盖不好可以跳过。
- 出门带个轻便折叠凳或拄个登山杖式的拐杖，她随时能坐，你也能松快些。
- 4月西安天气不错，选下午暖和、傍晚凉快前出门最舒服。

如果你想安排得再具体点，告诉我她从哪出发、大概想逛几小时，我帮你串一条不累的路线。



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
