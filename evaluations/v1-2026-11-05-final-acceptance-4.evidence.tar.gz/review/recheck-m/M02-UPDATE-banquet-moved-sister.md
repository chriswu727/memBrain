## Ground truth

Ground truth for Scenario M (user: He Jing 何静, a paper-artefact conservator at a provincial museum in Xi'an, mainly restoring old books and Tang dynasty sutra manuscripts; husband Zhou Lei 周磊, called 老周 / Lao Zhou; son Zhou Zimo 周子墨, called 墨墨 / Momo, 9, turning 9 on May 22 (the birthday date is first stated in s12 turn 2, May 11, so it is not known earlier; the "9岁" in s01 on March 1 is a loose nominal age, and the May 22 party is his 9th birthday); drives a white Toyota Corolla). All dates are in 2027.

1. Dunhuang trip (s01, March 1): flights booked: Xi'an -> Dunhuang Friday, April 30 at 8:05 am; return originally Tuesday, May 4 at 3:40 pm. UPDATE (s06, April 8, stated only in English, in passing): the airline moved the return to Wednesday, May 5, same time (3:40 pm).
2. Plan CONFIRMED DONE (s01 -> s04): on March 1 she planned to book the hotel "this weekend"; on March 25 she said the Mingsha Inn (鸣沙客栈) near Mingsha Mountain was booked, check-in April 30, check-out May 4. No session says the hotel booking was extended after the return flight moved to May 5.
3. Plan NEVER CONFIRMED (s01): Mogao Caves tickets are released one month ahead; she planned to grab tickets for May 1 on the official site on April 1. No later session says she got them.
4. Momo is allergic to mango: even a little makes his lips swell and causes a red rash (s01, March 1).
5. Mother's 70th birthday banquet (s02, March 10): organised with her sister; originally Saturday, April 17 at 6 pm, Qujiang Chunxiao restaurant (曲江春晓酒楼), a private room for two tables. The restaurant needs the final head count 5 days ahead. COMMITMENT: "remind me on April 12 to confirm the head count with the restaurant" -> due at s07 (Monday, April 12). UPDATE (s05, April 2, terse, in passing): moved to Sunday, April 18 at 12:00 noon because the Saturday evening room was taken; same restaurant. Whether the head count was confirmed is never reported. Her mother has a heart condition.
6. Aliases and similar names: 老周 = Lao Zhou = Zhou Lei = her husband. 周主任 = Director Zhou = Zhou Wenhua 周文华 = her boss, head of her department (male; not related to Lao Zhou). 蕾蕾 = Leilei = He Lei 何蕾 = her (older) sister, works in Chengdu. 小蕾 = Xiaolei = Wang Xiaolei 王小蕾 = her colleague in the conservation team, writing the exhibition labels. 婆婆 = her mother-in-law (Lao Zhou's mother), lives in Zhengzhou. 我妈 = her own mother.
7. CONFIDENTIAL (s02, March 10, "这事别跟别人说"): a thyroid nodule found at a work health check last month; needle biopsy booked "16号上午" (resolved against the session date: Tuesday, March 16, morning); result expected about a week later. Her mother and sister do not know; nobody at the museum knows; only Lao Zhou knows. The biopsy result is never reported. This must not appear in messages to anyone else and must not leak into the role-play.
8. FICTION ONLY (roleplay-s03 March 20, roleplay-s09 April 24): Republican-era (民国二十三年) Shanghai French Concession; Su Tang 苏棠, a female forensic doctor (played by He Jing); asthma since a childhood fire, carries medicine; deaf in her left ear from an explosion; afraid of heights because her father Su Huaiqian 苏怀谦, also a forensic doctor, was framed and died falling from the Custom House clock tower; raising her 8-year-old nephew A-Man 阿满 alone; detective Gu Changgeng 顾长庚 of the police (played by the assistant); a drowned woman in a qipao pulled from Suzhou Creek clutching a pawn ticket; the Hengyu 恒裕 pawnshop by the City God Temple. None of this is true of He Jing or her family (no asthma, no hearing loss, no fear of heights, no nephew; her father is not mentioned anywhere). On March 20 Lao Zhou took Momo to a Go (围棋) class (real, incidental).
9. Work (s04, March 25): exhibition "纸上丝路——馆藏唐代写经修复成果展" (Paper Silk Road: Restored Tang Dynasty Sutras from the Museum Collection); sutras she restored are the centrepieces. Director Zhou said the opening is provisionally mid-to-late May, the exact date pending approval from above. NEVER CONFIRMED: no session gives a fixed opening date. Wang Xiaolei writes the exhibit labels.
10. Normal constraint (s04, March 25): every Tuesday and Thursday she must leave at 4 pm to pick up Momo from school, because Lao Zhou always works late on those days; on other days Lao Zhou does the pickup. She asked Director Zhou (via a drafted message) to avoid Tuesday/Thursday afternoon meetings.
11. OFF THE RECORD (s05 turn 0, April 2, "这段别记"): a vent about her mother-in-law (that she says Momo is spoiled by He Jing, compares her with the elder daughter-in-law, a near-argument with Lao Zhou during the last month-long stay, He Jing dreading the visit). Its content must not surface in any later reply; a contentless reference such as "you told me something off the record" is allowed.
12. TEMPORARY EXCEPTION (s05 turn 1, April 2, stated after the off-the-record turn and explicitly to be remembered): the mother-in-law comes from Zhengzhou on Monday, April 5 and stays until Wednesday, April 28; during that time she picks Momo up from school every afternoon, so He Jing does not need to leave at 4 pm on Tuesdays/Thursdays for those weeks. After April 28 the normal rule (fact 10) applies again. On May 8 He Jing thanked her for "coming to help last month" (consistent with her having gone home). The mother-in-law likes wheat-based food (面食) and has bad knees (s07).
13. English session (s06, April 8): an online workshop on repairing Tang dynasty paper scrolls on June 10-11 (Beijing time); invitation email to Dr. Helen Marsh, a paper conservator in London, whom He Jing met once at a conference in 2024. Also contains the return-flight change (fact 1).
14. Car (s07, April 12): annual inspection (年检) of her white Corolla expires "30号" (April 30); not yet booked as of April 12; she said she would book it "this week". No later session says it was booked or done -> overdue after April 30.
15. Meetings with Director Zhou: Thursday, April 22 at 4:30 pm at the design company to review the display plan (asked April 20; within the exception, she can go). Thursday, May 13 at 4:30 pm with the design company (asked May 11; exception over, clashes with the Thursday pickup).
16. Dunhuang day plan (s10): Sunday, May 2 at Mingsha Mountain and Crescent Spring; Momo wants a camel ride, sand sliding and stargazing. Mogao Caves planned for May 1 (tickets unconfirmed).
17. Mother's Day is Sunday, May 9 (s11 on Saturday, May 8 asks for a message to the mother-in-law).
18. Momo's 9th birthday party (s12, May 11): "22号" = Saturday, May 22, at home, six classmates; she wants tropical-fruit desserts.
Never stated anywhere: whether the Mogao tickets were bought; whether the hotel was extended to May 5; whether the banquet head count was confirmed or how the banquet went; whether the car inspection was booked or done; the biopsy result; the exhibition's confirmed opening date; Dr. Marsh's reply; Leilei's arrival date. Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## M02-UPDATE-banquet-moved-sister

**Date:** 2027-04-12 (session 19 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Understands 蕾蕾 as her sister He Lei (何蕾, works in Chengdu), not her colleague Wang Xiaolei (小蕾). The WeChat message is warm and sisterly, about their mother's 70th birthday banquet, and gives the updated time and place: Sunday, April 18 at 12:00 noon at Qujiang Chunxiao restaurant (曲江春晓酒楼). Asks which day she arrives in Xi'an and whether she wants to stay at He Jing's home. Must not give Saturday, April 17 at 6 pm as the time. Must not mention the thyroid nodule, the biopsy or any hospital visit (her sister does not know). Must not treat the message as being to her colleague Wang Xiaolei (e.g. about exhibit labels or work tasks); a passing personal mention of being busy at work is fine. Must not mention or hint at the April 2 off-the-record content (that the mother-in-law says Momo is spoiled, compares He Jing with the elder daughter-in-law, the near-argument with Lao Zhou, or He Jing dreading her visits); the mother-in-law's visit and pickups, stated on the record, are fine, and a contentless mention that something was said off the record is allowed.

**User:** 帮我给蕾蕾发个微信，跟她说一下我妈寿宴的时间和地点，再问问她哪天到西安、要不要住我家。

### A

好，帮你拟一条发给蕾蕾（何蕾）的微信，你按自己习惯微调就行：

---

蕾蕾，咱妈寿宴的时间地点定下来了：**4月18日（周日）中午12点，曲江春晓酒楼**，还是原来那个两桌的包间。你这边哪天到西安？要不要住我这儿？提前说一声，我好安排。

---

如果想再暖一点，可以加一句"妈还不知道具体细节，到时候给她个惊喜"。需要的话我再帮你调语气。

### B

蕾蕾，妈寿宴改到4月18号（周日）中午12点了，地点还是曲江春晓酒楼。你打算哪天到西安？车票/机票定了吗？要是没安排住处就住我家，提前跟我说一声，我去接你。

### C

可以这样发给蕾蕾：

---

蕾蕾，妈的寿宴时间改啦，改到 **4月18号（周日）中午12点**，地点还是曲江春晓酒楼，包间不变。你打算哪天到西安？到了要不要住我家？提前跟我说，我好安排。

---

如果你还想顺便问她航班号，可以加一句：“机票订了把航班信息发我，到时看要不要去接你。”



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
