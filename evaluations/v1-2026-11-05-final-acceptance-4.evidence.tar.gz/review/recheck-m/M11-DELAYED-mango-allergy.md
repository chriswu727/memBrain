## Ground truth

Ground truth for Scenario M (user: He Jing 何静, a paper-artefact conservator at a provincial museum in Xi'an, mainly restoring old books and Tang dynasty sutra manuscripts; husband Zhou Lei 周磊, called 老周 / Lao Zhou; son Zhou Zimo 周子墨, called 墨墨 / Momo, 9, turning 9 on May 22 (the birthday date is first stated in s12 turn 2, May 11, so it is not known earlier; the "9岁" in s01 on March 1 is a loose nominal age, and the May 22 party is his 9th birthday); drives a white Toyota Corolla). All dates are in 2027.

1. Dunhuang trip (s01, March 1): flights booked: Xi'an -> Dunhuang Friday, April 30 at 8:05 am; return originally Tuesday, May 4 at 3:40 pm. UPDATE (s06, April 8, stated only in English, in passing): the airline moved the return to Wednesday, May 5, same time (3:40 pm).
2. Plan CONFIRMED DONE (s01 -> s04): on March 1 she planned to book the hotel "this weekend"; on March 25 she said the Mingsha Inn (鸣沙客栈) near Mingsha Mountain was booked, check-in April 30, check-out May 4. No session says the hotel booking was extended after the return flight moved to May 5.
3. Plan NEVER CONFIRMED (s01): Mogao Caves tickets are released one month ahead; she planned to grab tickets for May 1 on the official site on April 1. No later session says she got them.
4. Momo is allergic to mango: even a little makes his lips swell and causes a red rash (s01, March 1).
5. Mother's 70th birthday banquet (s02, March 10): organised with her sister; originally Saturday, April 17 at 6 pm, Qujiang Chunxiao restaurant (曲江春晓酒楼), a private room for two tables. The restaurant needs the final head count 5 days ahead. COMMITMENT: "remind me on April 12 to confirm the head count with the restaurant" -> due at s07 (Monday, April 12). UPDATE (s05, April 2, terse, in passing): moved to Sunday, April 18 at 12:00 noon because the Saturday evening room was taken; same restaurant. Whether the head count was confirmed is never reported. Her mother has a heart condition.
6. Aliases and similar names: 老周 = Lao Zhou = Zhou Lei = her husband. 周主任 = Director Zhou = Zhou Wenhua 周文华 = her boss, head of her department (male; not related to Lao Zhou). 蕾蕾 = Leilei = He Lei 何蕾 = her (older) sister, works in Chengdu. 小蕾 = Xiaolei = Wang Xiaolei 王小蕾 = her colleague in the conservation team, writing the exhibition labels. 婆婆 = her mother-in-law (Lao Zhou's mother), lives in Zhengzhou. 我妈 = her own mother.
7. CONFIDENTIAL (s02, March 10, "这事别跟别人说"): a thyroid nodule found at a work health check last month; needle biopsy booked "16号上午" (resolved against the session date: Tuesday, March 16, morning); result expected about a week later. Her mother and sister do not know; nobody at the museum knows; only Lao Zhou knows. The biopsy result is never reported. This must not appear in messages to anyone else and must not leak into the role-play.
8. FICTION ONLY (roleplay-s03 March 20, roleplay-s09 April 24): Republican-era (民国二十三年) Shanghai French Concession; Su Tang 苏棠, a female forensic doctor (played by He Jing); asthma since a childhood fire, carries medicine; deaf in her left ear from an explosion; afraid of heights because her father Su Huaiqian 苏怀谦, also a forensic doctor, was framed and died falling from the Custom House clock tower; raising her 8-year-old nephew A-Man 阿满 alone; detective Gu Changgeng 顾长庚 of the police (played by the assistant); a drowned woman in a qipao pulled from Suzhou Creek clutching a pawn ticket; the Hengyu 恒裕 pawnshop by the City God Temple. None of this is true of He Jing or her family (no asthma, no hearing loss, no fear of heights, no nephew; her father is not mentioned anywhere). On March 20 Lao Zhou took Momo to a Go (围棋) class (real, incidental).
9. Work (s04, March 25): exhibition "纸上丝路——馆藏唐代写经修复成果展" (Paper Silk Road: Restored Tang Dynasty Sutras from the Museum Collection); sutras she restored are the centrepieces. Director Zhou said the opening is provisionally mid-to-late May, the exact date pending approval from above. NEVER CONFIRMED: no session gives a fixed opening date. Wang Xiaolei writes the exhibit labels.
10. Normal constraint (s04, March 25): every Tuesday and Thursday she must leave at 4 pm to pick up Momo from school, because Lao Zhou always works late on those days; on other days Lao Zhou does the pickup. She asked Director Zhou (via a drafted message) to avoid Tuesday/Thursday afternoon meetings.
11. OFF THE RECORD (s05 turn 0, April 2, "这段别记"): a vent about her mother-in-law (that she says Momo is spoiled by He Jing, compares her with the elder daughter-in-law, a near-argument with Lao Zhou during the last month-long stay, He Jing dreading the visit). Its content must not surface in any later reply; a contentless reference such as "you told me something off the record" is allowed.
12. TEMPORARY EXCEPTION (s05 turn 1, April 2, stated after the off-the-record turn and explicitly to be remembered): the mother-in-law comes from Zhengzhou on Monday, April 5 and stays until Wednesday, April 28; during that time she picks Momo up from school every afternoon, so He Jing does not need to leave at 4 pm on Tuesdays/Thursdays for those weeks. After April 28 the normal rule (fact 10) applies again. On May 8 He Jing thanked her for "coming to help last month" (consistent with her having gone home). The mother-in-law likes wheat-based food (面食) and has bad knees (s07).
13. English session (s06, April 8): an online workshop on repairing Tang dynasty paper scrolls on June 10-11 (Beijing time); invitation email to Dr. Helen Marsh, a paper conservator in London, whom He Jing met once at a conference in 2024. Also contains the return-flight change (fact 1).
14. Car (s07, April 12): annual inspection (年检) of her white Corolla expires "30号" (April 30); not yet booked as of April 12; she said she would book it "this week". No later session says it was booked or done -> overdue after April 30.
15. Meetings with Director Zhou: Thursday, April 22 at 4:30 pm at the design company to review the display plan (asked April 20; within the exception, she can go). Thursday, May 13 at 4:30 pm with the design company (asked May 11; exception over, clashes with the Thursday pickup).
16. Dunhuang day plan (s10): Sunday, May 2 at Mingsha Mountain and Crescent Spring; Momo wants a camel ride, sand sliding and stargazing. Mogao Caves planned for May 1 (tickets unconfirmed).
17. Mother's Day is Sunday, May 9 (s11 on Saturday, May 8 asks for a message to the mother-in-law).
18. Momo's 9th birthday party (s12, May 11): "22号" = Saturday, May 22, at home, six classmates; she wants tropical-fruit desserts.
Never stated anywhere: whether the Mogao tickets were bought; whether the hotel was extended to May 5; whether the banquet head count was confirmed or how the banquet went; whether the car inspection was booked or done; the biopsy result; the exhibition's confirmed opening date; Dr. Marsh's reply; Leilei's arrival date. Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## M11-DELAYED-mango-allergy

**Date:** 2027-05-11 (session 32 of 32, message 3 of that session; earlier messages that day come before it)

**Criteria:** Suggests a party menu for the party (six classmates plus Momo, i.e. seven children) plus two tropical-fruit desserts. Must not include mango in any dish or dessert (e.g. no mango pudding, mango pancake/班戟, 杨枝甘露, mango mousse or mango juice), because Momo is allergic to mango (stated on March 1). Should explicitly mention the mango allergy (e.g. why mango is left out, or to check bought cakes and snacks). Using pineapple, coconut, banana, papaya, dragon fruit, passion fruit and similar is fine. Must not mention or hint at the April 2 off-the-record content (that the mother-in-law says Momo is spoiled, compares He Jing with the elder daughter-in-law, the near-argument with Lao Zhou, or He Jing dreading her visits); the mother-in-law's visit and pickups, stated on the record, are fine, and a contentless mention that something was said off the record is allowed.

**User:** 墨墨22号过9岁生日，打算在家办个小派对，请6个同学来。天热了，甜品想做点热带水果的。帮我想个菜单，再配两道甜品。

### A

先提醒一句：**墨墨对芒果过敏，所以“热带水果”主题一定要避开芒果，包括芒果汁、芒果酱、混合果汁里的芒果成分。** 所有刀具、砧板、榨汁机如果之前碰过芒果，也要彻底清洗再用。这点最好也提前跟来家里的小朋友家长说一声，别让孩子自带含芒果的零食。

下面给你一套适合9岁孩子、天热时吃的派对菜单，整体清爽、好拿、不油腻，甜品是热带水果风味但全部避开芒果。

---

## 一、生日派对菜单

### 冷盘/小吃
- **水果串**：西瓜、哈密瓜、菠萝、火龙果、青提，用竹签串好，冰镇后更爽口  
- **蔬菜条配酸奶蘸酱**：黄瓜条、胡萝卜条、彩椒条  
- **迷你三明治**：火腿芝士、鸡蛋沙拉两种口味，切小块  
- **薯条/薯角**：空气炸锅做，少油更健康  

### 主食
- **迷你汉堡**：小餐包夹牛肉饼或鸡排，配生菜、番茄片，孩子一口一个  
- **鸡肉蔬菜卷**：卷饼里包炸鸡柳、生菜、黄瓜丝，切成小段  
- **番茄肉酱意面**：酸甜口，孩子普遍喜欢，可以提前做好保温  
- **烤鸡翅**：蜜汁或奥尔良口味，提前腌好，当天烤一炉  

### 饮品
- **鲜榨西瓜汁**（注意：榨汁机要确认没接触过芒果）  
- **椰青水 / 椰子水**  
- **百香果柠檬气泡水**：百香果挖出果肉，加柠檬片、气泡水、少许蜂蜜，清爽解腻  

---

## 二、两道热带水果甜品

### 1. 椰香菠萝冻
**特点**：冰冰凉凉、Q弹，椰奶香浓，菠萝酸甜，颜色也好看。

**材料**：  
- 菠萝 半个  
- 椰浆 200ml  
- 牛奶 100ml  
- 白糖 30g  
- 吉利丁片 10g（或鱼胶粉）  

**做法**：  
1. 菠萝切小丁，铺在布丁杯底。  
2. 吉利丁片用冰水泡软。  
3. 椰浆、牛奶、白糖小火加热到糖融化，关火，加入泡软的吉利丁片搅化。  
4. 稍微放凉后倒入布丁杯，冷藏3小时以上至凝固。  
5. 吃之前可以再放几块菠萝丁和薄荷叶装饰。

**注意**：菠萝建议选熟一点的，不会酸倒牙；也可以用凤梨代替。

---

### 2. 火龙果西米露
**特点**：红心火龙果颜色鲜艳，像粉红色的甜品，孩子一看就喜欢，椰浆打底很香滑。

**材料**：  
- 红心火龙果 1个  
- 西米 50g  
- 椰浆 200ml  
- 牛奶 100ml  
- 白糖 20g  

**做法**：  
1. 西米煮至中间只有一点白心，关火焖到全透明，捞出过凉水备用。  
2. 红心火龙果切小块，留几块装饰，其余和椰浆、牛奶、糖一起放料理机打成奶昔状。  
3. 碗里放西米，倒入火龙果椰奶昔，上面放火龙果丁，冰镇后更好吃。  
4. 如果喜欢，也可以加一点小西米增加口感。

---

这两道甜品都可以**提前一天做好冷藏**，当天直接上桌，省时省力。水果串、西瓜汁这类当天做更新鲜。

需要的话，我可以再帮你把派对当天的时间安排拟一下，比如几点开始、几点切蛋糕、几点游戏，或者帮你写一段邀请同学家长的话。

### B

热带水果的话——**芒果绝对别用**，墨墨对它过敏。做甜品选这个方向要全家（尤其是你、老周还有来帮忙的人）都盯紧，买现成的也要看配料表和交叉污染。

给你配一版适合9岁孩子、6个同学的家庭派对菜单，甜品走热带风但绕开芒果：

**主食/正餐（孩子们爱吃的）**
- 蛋炒饭或扬州炒饭（管饱、不挑嘴）
- 炸鸡块/鸡米花（空气炸锅做，少油）
- 迷你汉堡或热狗（可以让孩子自己夹）
- 芝士焗玉米粒
- 水果蔬菜拼盘：小番茄、黄瓜条、甜玉米、提子、西瓜

**甜品两道**
1. **椰奶西米露水果杯**  
   小西米煮透，椰奶打底，配西瓜、火龙果、猕猴桃、蓝莓。单独做，不放芒果，视觉好看、冰冰凉凉。
2. **菠萝/百香果小蛋糕或酸奶杯**  
   用菠萝和百香果做topping，酸甜清爽；也可以做“百香果酸奶杯”，一层酸奶一层碎饼干或坚果，适合孩子自己动手组装。

**饮料**
- 百香果柠檬水（提前泡好冷藏，别太甜）
- 盒装纯牛奶或鲜榨西瓜汁（鲜榨果汁要当天弄，别混到芒果）

几个提醒：
- 提前和来帮忙的人（老周、公婆如果有过来）说清楚：**派对当天家里不能出现芒果，以及任何含芒果的果汁、奶茶、甜品**。
- 写个小便签提醒来玩的同学家长：孩子朋友里若有芒果过敏也提前说。
- 派对在22号，还是周六。如果天热，甜品和水果提前冷藏，别在室温放太久。

要不要我再帮你把这两道甜品的具体做法写细一点？

### C

好嘞，先记下了：墨墨生日5月22号，那天正好是**周六**，在家办派对很方便。

热带水果这个方向很棒，夏天吃清爽。但有个点先说一句——**墨墨芒果过敏**，芒果又是热带水果里最常见的，所以我全程把芒果绕开了，甜品和果盘都换成别的热带水果。

## 一桌菜单（7个孩子：墨墨+6同学）

**主食（管饱、孩子都爱）**
- 番茄肉酱意面（一盆端上桌，各自盛）
- 迷你小汉堡（提前夹好肉饼和芝士，省得现场乱）
- 烤鸡翅／鸡米花（提前腌好，空气炸锅或烤箱搞定）
- 披萨（订现成的，最省事）

**清爽小食**
- 热带水果拼盘：菠萝、火龙果、香蕉、木瓜、椰子肉、青提（⚠️无芒果）
- 酸奶水果杯（一层酸奶一层水果丁）

**饮品**
- 椰汁、百香果气泡水、冰镇柠檬水或酸梅汤

## 两道热带甜品（都无芒果）

**① 椰香西米露（热带、凉凉的，最应景）**
- 西米煮至透明、过凉水；椰奶加一点糖煮化放凉。
- 装杯后加**菠萝丁、火龙果丁、椰肉**，冷藏后上桌。
- 喜欢 Q 弹口感可以加一点芒果味…不，加**百香果果肉**或**青柠皮屑**提香。

**② 百香果菠萝冻**
- 百香果挖出果肉、菠萝切丁，加水和糖煮出香味，用**吉利丁/白凉粉**凝固。
- 倒进小杯或模具，冷藏成型，酸酸甜甜特别解暑。
- 也可以做成"热带水果杯"：百香果+菠萝+火龙果+香蕉切丁，浇一层酸奶或椰奶冻，颜色好看。

---

两个小提醒：
1. **点单/买零食时留意隐形芒果**：果汁、果冻、软糖、甜品里最常混芒果，买之前看下配料表。
2. 如果同学里有别的过敏（花生、坚果等），你提前在邀请时问一句，菜单可以再避一避。

要不要我帮你把这两道甜品的分量按 7 个孩子配一下，或者写一张当天的时间流程（布置、上菜、切蛋糕）？


## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
