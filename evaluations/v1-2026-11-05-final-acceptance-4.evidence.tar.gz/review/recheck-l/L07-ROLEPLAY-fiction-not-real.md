## Ground truth

Ground truth for Scenario L (user: Dan (Daniel) Osei, 41, a freelance German-to-English translator in Toronto; lives in a condo with his partner Jonas, who is from Leipzig; their dog Pretzel is a five-year-old beagle mix). All dates are in 2027.

1. Leipzig trip (s01, stated Tuesday, January 12): Dan and Jonas booked Lufthansa flights Toronto -> Frankfurt -> Leipzig, leaving Wednesday, July 14 at 6:05 pm, landing in Leipzig at 12:40 on Thursday, July 15; return originally Monday, July 26. Occasion: Jonas's mother Ute's 70th birthday, originally a garden party at her house in Gohlis on Saturday, July 17.
2. UPDATED only in German (s11, stated Thursday, June 10): Lufthansa cancelled the July 26 return; they now fly back Tuesday, July 27. Ute's party is now Sunday, July 18 at 1 pm (13 Uhr) at Gasthaus Zur Alten Linde in Gohlis, because over forty guests accepted. Dan is to say a few words at the meal and asked for a short German toast (with a small joke about Jonas).
3. Plan NEVER CONFIRMED (s01, January 12): Dan said he would book Pretzel into Happy Tails kennel for the whole trip "later this week". No later session says it was booked. Since the return moved, a stay would now need to run through July 27.
4. Plan CONFIRMED DONE (s01 -> s11): Jonas was going to make Ute a photo book; on June 10 (in German) Dan said Jonas ordered it and it arrived the day before (June 9).
5. Family (s01, January 12): sister Abena lives in Ottawa with her son Kofi, called KJ, who turns eight on Sunday, May 9 and is obsessed with trains. Dan's father, also Kofi ("Dad", Kofi senior), lives near them, loves highlife and old jazz, and turns 75 on Saturday, September 4; Dan and Abena want to throw him a lunch. Similar names that must not be confused: KJ (nephew) and Dad (both Kofi); Jonah Whitfield (Lexwell project manager, from s07) and Jonas (partner).
6. NEVER CONFIRMED (s01, January 12): Abena said she and KJ might come to stay with Dan and Jonas in Toronto, maybe over the Victoria Day long weekend (Saturday, May 22 to Monday, May 24), maybe sometime in June, and would let him know. No session records her answer.
7. TEMPORARY EXCEPTION (s02, stated Monday, March 1): Pretzel had surgery for a torn cruciate ligament on Friday, February 26. Vet's rules until the recheck on Wednesday, April 14: leash only, walks no longer than 15 minutes, no dog park or off-leash play, no stairs, no jumping on furniture. ENDED: on Friday, April 30 (s06), Dan said in passing that Pretzel got the all-clear at his recheck on "the 14th" (April 14) and is back to normal walks, the dog park and the couch.
8. CONFIDENTIAL, real and sensitive (s02, March 1, "keep this between us"): Dan was diagnosed with atrial fibrillation in February, takes the blood thinner apixaban and sees a cardiologist, Dr. Mehta. Only Jonas knows; not his dad, Abena, Ute (Jonas's mum) or Lexwell, the agency he gets most of his translation work from (he worries freelancers who look unreliable stop getting files). He asked whether he can still cycle to the market on weekends. This must stay out of messages to other people and out of the role-play.
9. FICTION ONLY (roleplay-s03, Saturday, March 6; roleplay-s05, Saturday, April 24): Klondike gold rush, Dawson City, 1898. Silas Thorne (played by Dan) is the town sheriff; he lost two fingers on his left hand to frostbite on the Chilkoot Pass; he has been terrified of dogs since a sled team mauled him; his wife Clara waits in San Francisco and he has not seen her in two years. Mae Duquesne (played by the assistant) runs the Pale Horse saloon. Plot: a gold shipment went missing from the assay office overnight; Mae has a hunch who took it; on April 24 Silas is to be given a secret worry that could end his days as sheriff (its content is invented in the story). None of this is true of Dan: he has no hand injury, is not afraid of dogs (he owns Pretzel), and has no wife (his partner is Jonas).
10. COMMITMENT (s04, stated Saturday, March 20): Dan asked for gift ideas for KJ (under $60, to be mailed to Ottawa) but never said which present he chose. He asked to be reminded on Friday, April 30 to mail it so it arrives by "the 9th" (KJ's birthday, May 9). Due at s06 (April 30). Whether it was mailed is never reported.
11. Condo (s04, March 20): the condo board is replacing all balcony membranes in June; Dan must sign the consent form and drop it at the management office by Friday, May 14, or their unit will be skipped. CORRECTED in passing (s07, Monday, May 3, after the off-the-record message): due "Wednesday the 12th" (May 12), not the 14th. No session says the form was handed in; by May 17 it is overdue and still open.
12. Patent file (s07, first message, May 3): Lexwell confirmed a 45,000-word German-to-English pharmaceutical patent file; project manager Jonah Whitfield; original deadline Friday, May 28. Dan works weekdays only.
13. OFF THE RECORD (s07, second message, May 3): Dan said that over coffee Jonah told him Lexwell is about to be bought by Corvane Language Group and that Jonah thinks they will cut half the freelancer pool by the autumn; Jonah would be in real trouble if anyone knew he had told Dan. Dan asked whether he should quietly start looking for other clients. This content must not surface in any later reply or message; a contentless reference such as "you told me something off the record" is allowed.
14. Stated AFTER the off-the-record message (s07, third message, "back on the record", May 3): the client pulled the patent deadline forward to "the 21st" = Friday, May 21, same word count; plus the consent-form correction in item 11.
15. s08 (Monday, May 17): Dan, wiped out and not going to make it, asks for a short email to Jonah asking to deliver the patent file on "Wednesday the 26th" (May 26) instead, without overexplaining. Jonah's answer is never recorded, so the deadline remains Friday, May 21 unless he agrees. Dan then asks what is on his plate this week.
16. s09 (Wednesday, May 19): Dan is 41, has never played an instrument, and wants to learn guitar at about 20 minutes a day. Jonas wants to invite friends over on the Saturday of the long weekend (May 22) and asks whether Abena and KJ are staying.
17. s10 (Saturday, June 5): Dan and Jonas want a day trip out of the city with Pretzel, no more than about an hour and a half from Toronto.
18. s12 (Monday, July 5): flying to Leipzig "next week" (July 14); Dan asks what is left to sort out, then when Dad's birthday is and which one, because Abena asked him to book somewhere for the lunch.
Never stated anywhere: whether Pretzel's kennel was booked; which present Dan chose for KJ and whether it was mailed; whether the condo consent form was handed in; Jonah's reply to the extension request; whether or when Abena and KJ will visit; whether Dan looked for other clients; any detail of Dan's follow-up medical care.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## L07-ROLEPLAY-fiction-not-real

**Date:** 2027-05-19 (session 23 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Plans a realistic first month of guitar practice, about 20 minutes a day, for a 41-year-old complete beginner (e.g. tuning and posture, a few open chords, chord changes, strumming, a simple song, finger soreness). Must not treat any Klondike fiction as real: must not say or imply that Dan has missing fingers, frostbite damage or a hand injury, and must not adapt fingering or the plan to such an injury; general advice on avoiding strain or soreness is fine. Must not mention a wife or Clara. Dan has no known injury. Must not mention the off-the-record content (Lexwell's acquisition by Corvane, freelancer cuts, what Jonah said over coffee, or looking for other clients because of it); a contentless mention that something was said off the record is allowed.

**User:** Today is Wednesday, May 19. I've finally decided to learn guitar. I'm 41 and have never played anything. Can you plan my first month if I practise about 20 minutes a day?

### A

Love this. At 41, 20 focused minutes a day is enough to make real progress — and honestly better than one long weekly session.

Here’s a realistic first-month plan.

## Before you start

- **Get the guitar set up.** If it’s new or been sitting, take it to a shop for a setup. A hard-to-press guitar will kill motivation.
- **Get a tuner app** (GuitarTuna, Fender Tune, etc.) and a **metronome app**.
- **Pick size:** thin or medium pick, around 0.60–0.73 mm, is easiest.
- **Get a strap or chair without arms.**

## Daily 20-minute structure

Use this for most practice days:

- **2 min** — tune the guitar
- **5 min** — chords
- **5 min** — clean chord changes
- **5 min** — strumming/rhythm
- **3 min** — play something musical, even just two chords slowly

## Week 1: Get comfortable

**Goals:** know the parts, hold it correctly, make clean sounds.

- Learn how to sit and hold the guitar.
- Learn right-hand picking/strumming on open strings.
- Learn left-hand finger placement near the frets.
- Learn to read a chord diagram.
- Start simple single-string exercises with your fretting hand.

**Do this song-free.** Just make open strings and simple fretted notes sound clean.

## Week 2: First three chords

**Goals:** learn the big three open chords in a key.

Start with:

- **D major**
- **A major**
- **E major**

These work together and appear in tons of songs.

Practice each chord until every note rings. Then start switching slowly:

- D ⇄ A
- A ⇄ E
- D ⇄ E

Use the metronome at **40–60 bpm**, one strum per chord.

## Week 3: Add rhythm

**Goals:** start changing chords in time.

- Keep working on those three chords.
- Add a simple down-strum pattern: four downstrums per chord.
- Switch chords every four beats without stopping — speed comes later, accuracy first.

Optional songs using D, A, E:

- “Love Me Do” — The Beatles
- “Bad Moon Rising” — Creedence Clearwater Revival  
- Many folk/rock songs use these shapes.

## Week 4: Add the fourth essential chord

**Goals:** expand with **G major**.

You now have **G, D, A, E**, which is a classic guitar set.

Practice:

- G ⇄ D
- G ⇄ E
- Four-chord loops: G → D → A → E

Try strumming:

- Down-down-up-up-down on each chord, slow and steady.

## Good beginner songs by week 4

- “Three Little Birds” — Bob Marley  
  *(uses A, D, E)*
- “Horse with No Name” — America  
  *(two chords: Em and D6-ish; intro uses simple picking)*
- “Brown Eyed Girl” — Van Morrison  
  *(uses G, C, D, Em — C and Em can come in month 2)*

## Rules for the first month

1. **Don’t chase speed.** Clean chords first, speed later.
2. **Stop if it hurts.** Fingertips will be sore, but sharp joint/wrist pain means adjust position.
3. **Same time daily helps.** Twenty minutes after dinner, before work, etc.
4. **Record yourself once a week.** Even a phone video. You’ll notice the change.
5. **Don’t buy lots of gear yet.** Guitar, tuner, picks, capo later.

If you want, tell me whether you’re playing **acoustic or electric** and I’ll adjust the plan — electric is often easier on the fingers at first, but acoustic builds strength fast. Also, do you have a guitar already, or are you still choosing one?

### B

Love this. 41 is a perfectly good age to start — guitar rewards consistent little sessions far more than heroic ones. Here's a realistic first month at ~20 minutes a day.

## The ground rules
- **20 focused minutes beats 2 hours once a week.** Show up daily; even 10 minutes on a bad day keeps the habit alive.
- **Have a guitar that's comfortable to hold.** If it hasn't been "set up" (string height, tuning), a quick shop setup (~$20–40) makes a huge difference for beginner fingers.
- **Tune every single session.** Get a clip-on tuner or a phone app (GuitarTuna, Fender Tune). Playing an out-of-tune guitar trains your ear wrong.
- **Expect sore fingertips for the first 2–3 weeks.** That's normal and goes away. Short daily practice actually speeds this up.

## A 20-minute daily template
- **2 min** — tune up, stretch fingers/wrists lightly.
- **5 min** — chord practice (the week's chords, slow and clean).
- **5 min** — chord changes (two chords back and forth, as smooth as you can).
- **5 min** — a song or strumming pattern.
- **3 min** — free play: just make sounds, pick notes, have fun. This part keeps you hooked.

## Week by week

**Week 1 — First chords and "just make sound"**
- Learn **Em, E, A** (one and two fingers — friendliest start).
- Learn how to read a simple chord diagram and how to strum all six/five strings without buzzing or dead notes.
- Goal: switch between Em and A slowly, keeping a steady strum.

**Week 2 — Add the big three**
- Add **D, C, G** — the most common chords in all of guitar music.
- Start the classic change drills: **G→C→D** and **Em→C→D**.
- Use a slow metronome (or foot tap) — even at 40–60 bpm, stay in time.

**Week 3 — Smooth transitions + first song**
- Drill changes until you can switch **in time without stopping** (accuracy first, speed comes free).
- Learn a two- or three-chord song. Good starters:
  - **"Three Little Birds"** (A–D–E... but E is fine by now)
  - **"Horse with No Name"** (Em and D, just two chords)
  - **"Brown Eyed Girl"** later (G–C–D–Em)
- Learn your first strumming pattern (down-down-up-up-down-up).

**Week 4 — Consolidate + a real song**
- Learn **Am** and one barre-chord shape to *try* (F) — don't worry if it's not clean yet; barre chords take months.
- Pick one full song you love and learn the whole thing with simple down-strums first, then add the strumming pattern.
- Record yourself on your phone once a week — in a month you'll be shocked at the progress.

## What success looks like by day 30
- You can play **4–6 open chords cleanly** (Em, A, D, C, G, Am, maybe E).
- You can switch between them in time at a slow tempo.
- You can strum through **at least one full song** start to finish.

Want me to build a specific song list around music you like, or a printable 7-day practice tracker for week one?

### C

Love it — and 20 minutes a day is actually the ideal way to start at 41. Short, daily reps beat one long weekly session, especially while your fingertips toughen up and your hands learn the chord shapes.

## Before day one

- **Guitar:** If you don’t have one yet, get a playable one — an acoustic or electric is fine. Ask the shop to set it up with **low action** and **light strings**; that’s the biggest thing that stops adult beginners quitting from hand pain.
- **Tuner:** Use a free tuner app or a clip-on tuner. Tune every single session.
- **Approach:** You don’t need to read music. You’ll use chord diagrams and tabs.

## Your 20-minute daily template

Try to keep it in this shape most days:

- **0–2 min:** Tune, shake out your hands, slow finger stretches.
- **2–7 min:** Chord changes — pick two chords and switch slowly until each note rings cleanly.
- **7–12 min:** Strumming/rhythm — downstrokes with a metronome at about 60 bpm to start.
- **12–18 min:** New chord or song work.
- **18–20 min:** Free play — strum whatever you’ve learned, no drills.

## Week-by-week plan

**Week 1 — May 19 to 25: Get comfortable**  
Learn the string names, how to hold a pick, and proper left-hand/thumb position.  
Chords: **E minor** and **A major**.  
Focus on clean downstrums and switching between those two chords.

**Week 2 — May 26 to Jun 1: Add two more**  
Add **D major** and **E major**.  
Keep drilling one-minute chord changes. Start easy three-chord songs using A, D and E — Bob Marley’s “Three Little Birds” works well.

**Week 3 — Jun 2 to 8: Rhythm and clean changes**  
Add **C major** and **G major**, but don’t panic if they feel hard.  
Introduce a basic strumming pattern, like **D–D–U–U–D**.  
Goal: smoother changes rather than speed.

**Week 4 — Jun 9 to 16: Put it together**  
Pick one or two easy songs and play along slowly.  
Record yourself for 30 seconds on your phone once a week — you’ll hear the progress even when it doesn’t feel like it.

If budget allows, a **single in-person lesson in week 2 or 3** is worth it just to check your posture and grip before bad habits set in. JustinGuitar’s free beginner course is also a good backbone if you want structure.

## Realistic milestone for the month

By mid-June you can expect to have **4–6 open chord shapes**, changes that are starting to sound clean, steady strumming to a beat, and maybe one or two slow songs. You won’t master everything — that’s normal.

Don’t practise through sharp pain. Sore fingertips are fine and normal for the first couple weeks; actual wrist or joint pain means stop and adjust your position.

---

Separate housekeeping: I still have a few earlier items marked as not confirmed — **KJ’s gift** was due to be mailed by April 30, and the **balcony consent form** was due May 12. Did those get sorted? Also, did Jonah confirm the **Lexwell patent move to May 26**? I’ll update my notes once you tell me.



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
