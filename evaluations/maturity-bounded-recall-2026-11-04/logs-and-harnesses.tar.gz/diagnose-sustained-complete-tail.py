import hashlib
import json
import os
import signal
import socket
import statistics
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import httpx
import psycopg
from psycopg.rows import dict_row

import gc_trace_complete as gc_trace
from membrain import embedded_database, host
from membrain.client import MemoryClient
from membrain.local_profile import load_profile

ROOT = Path('/Users/yichen/tmp/membrain-sql-recall-20261104')
INSTALLATION = ROOT / 'perf-38c948a-installation'
profile = load_profile(INSTALLATION)
assert profile.cognition is None
environment = {key: value for key, value in os.environ.items()
               if not key.startswith(('MEMORY_', 'MEMBRAIN_')) and not key.endswith(('_API_KEY', '_API_TOKEN'))}
environment.update(MEMBRAIN_SEMANTIC='0', PYTHON_DOTENV_DISABLED='1')
boot = '''
import signal,sys,time
from pathlib import Path
sys.path.insert(0,'/Users/yichen/tmp/membrain-sql-recall-20261104')
import gc_trace_complete as gc_trace
gc_trace.start(Path(sys.argv[3]),signum=signal.SIGUSR1)
import uvicorn
from membrain.api import create_app
from membrain.local_profile import load_profile
profile=load_profile(Path(sys.argv[1]))
uvicorn.run(create_app(profile.settings()),host='127.0.0.1',port=int(sys.argv[2]),log_level='error')
'''
client_gc = gc_trace.start(ROOT / 'sustained-complete-client.gc.json')
activity, sampling_errors = [], []
stopping = threading.Event()


def sample():
    try:
        with psycopg.connect(profile.migration_database_url, autocommit=True, row_factory=dict_row,
                             connect_timeout=5, options='-c statement_timeout=1000') as conn:
            while not stopping.is_set():
                rows = conn.execute(
                    "SELECT backend_type,state,wait_event_type,wait_event,CASE WHEN backend_type LIKE 'autovacuum%' "
                    "THEN left(query,120) ELSE split_part(ltrim(query),' ',1) END AS operation "
                    "FROM pg_stat_activity WHERE datname=current_database() AND pid<>pg_backend_pid()"
                ).fetchall()
                if len(activity) < 5000:
                    activity.append({'at': time.perf_counter(), 'backends': rows})
                stopping.wait(.1)
    except Exception as error:
        sampling_errors.append(type(error).__name__)


result = {'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
          'runtime_pin': '60b8b746d5f389ef4a89e50564cc6280284dce44', 'model_calls': 0,
          'protocol': 'Diagnostic only, not R5 qualification: 8 brains x 181 keyword recalls, discard each first. '
                      'Normal automatic GC observed in client/server, with complete per-generation counts/maxima and bounded top-64 event details rather than a truncating initial event buffer; PostgreSQL activity sampled every 100ms. '
                      'No GC policy change or forced collection; visualization unloaded.', 'completed': False}
embedded_database.start(profile)
clients, process, sampler = [], None, None
log = (ROOT / 'sustained-complete-api.log').open('w')
try:
    with socket.socket() as listener:
        listener.bind(('127.0.0.1', 0))
        port = listener.getsockname()[1]
    base = f'http://127.0.0.1:{port}'
    gc_path = ROOT / 'sustained-complete-server.gc.json'
    process = subprocess.Popen([sys.executable, '-c', boot, str(INSTALLATION), str(port), str(gc_path)],
                               env=environment, stdout=log, stderr=subprocess.STDOUT)
    with httpx.Client(timeout=.5, trust_env=False) as health:
        deadline = time.monotonic() + 30
        while True:
            assert process.poll() is None
            try:
                if health.get(base + '/health').status_code == 200:
                    break
            except httpx.TransportError:
                pass
            if time.monotonic() > deadline:
                raise RuntimeError('API readiness timed out')
            time.sleep(.1)
    clients = [MemoryClient(base, profile.api_key, brain_id=host.user_brain_id(f'bench-user-{index}')) for index in range(8)]
    sampler = threading.Thread(target=sample, daemon=True)
    sampler.start()

    def worker(client):
        rows = []
        for number in range(181):
            begin = time.perf_counter()
            found = host.recall_context(client, f'What is the appointment for project{number % 20:04d}?',
                                        current_conversation='benchmark')
            end = time.perf_counter()
            assert found
            rows.append({'begin': begin, 'end': end, 'elapsed_ms': (end - begin) * 1000,
                         'context_sha256': hashlib.sha256(found.encode()).hexdigest()})
        return rows[1:]

    with ThreadPoolExecutor(max_workers=8) as pool:
        rows = list(pool.map(worker, clients))
    process.send_signal(signal.SIGUSR1)
    deadline = time.monotonic() + 5
    while not gc_path.exists() and time.monotonic() < deadline:
        time.sleep(.05)
    assert gc_path.exists(), 'Server GC must be saved before SIGTERM'
    server_gc = json.loads(gc_path.read_text())
    values = sorted(row['elapsed_ms'] for part in rows for row in part)
    result.update(n=len(values), nonempty=len(values), median_ms=statistics.median(values),
                  p95_ms=values[int(.95 * (len(values) - 1))], max_ms=max(values), requests=rows,
                  server_gc=server_gc, client_gc={'event_count': client_gc['event_count'], 'generations': client_gc['generations'], 'top_events': [item[2] for item in sorted(client_gc['top_events'], reverse=True)]},
                  activity=activity, sampling_errors=sampling_errors, completed=True)
finally:
    stopping.set()
    if sampler is not None:
        sampler.join(timeout=5)
    for client in clients:
        client.close()
    if process is not None:
        process.terminate()
        try:
            process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
    log.close()
    embedded_database.stop(profile)
    (ROOT / 'sustained-complete-diagnostic.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('completed', 'n', 'nonempty', 'median_ms', 'p95_ms', 'max_ms')}))
