import json
import os
import socket
import subprocess
import sys
import time
import traceback
from pathlib import Path

for key in list(os.environ):
    if key.startswith(('MEMORY_', 'MEMBRAIN_')) or key.endswith(('_API_KEY', '_API_TOKEN')):
        del os.environ[key]
os.environ.update(MEMBRAIN_SEMANTIC='0', PYTHON_DOTENV_DISABLED='1', DEBUG='pw:browser')

import httpx
from playwright.sync_api import sync_playwright

from membrain import embedded_database, host
from membrain.local_profile import load_profile

root = Path('/Users/yichen/tmp/membrain-sql-recall-20261104')
installation = root / 'perf-38c948a-installation'
profile = load_profile(installation)
report = {'cycles': [], 'events': [], 'completed': False, 'passed': False}
closing = False
boot = '''
import sys
from pathlib import Path
import uvicorn
from membrain.api import create_app
from membrain.local_profile import load_profile
profile=load_profile(Path(sys.argv[1]))
uvicorn.run(create_app(profile.settings()),host='127.0.0.1',port=int(sys.argv[2]),log_level='error')
'''
embedded_database.start(profile)
process = None
log = (root / 'browser-lifetime-v2-api.log').open('w')
try:
    with socket.socket() as listener:
        listener.bind(('127.0.0.1', 0))
        port = listener.getsockname()[1]
    base = f'http://127.0.0.1:{port}'
    process = subprocess.Popen([sys.executable, '-c', boot, str(installation), str(port)],
                               stdout=log, stderr=subprocess.STDOUT)
    with httpx.Client(timeout=.5, trust_env=False) as health:
        deadline = time.monotonic() + 30
        while True:
            assert process.poll() is None
            try:
                if health.get(base + '/health').status_code == 200:
                    break
            except httpx.TransportError:
                pass
            if time.monotonic() > deadline:
                raise RuntimeError('API readiness timed out')
            time.sleep(.1)
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=False)
        browser.on('disconnected', lambda: report['events'].append(
            {'kind': 'browser_disconnected', 'expected': closing, 'at': time.monotonic()}))
        for index in range(8):
            context = browser.new_context(viewport={'width': 1280, 'height': 900}, device_scale_factor=1,
                                          reduced_motion='no-preference')
            cycle = {'index': index, 'closing': False, 'errors': []}
            report['cycles'].append(cycle)
            try:
                page = context.new_page()
                page.on('crash', lambda _page, i=index: report['events'].append({'kind': 'page_crash', 'index': i}))
                page.on('close', lambda _page, c=cycle: report['events'].append(
                    {'kind': 'page_close', 'index': c['index'], 'expected': c['closing']}))
                page.on('pageerror', lambda error, c=cycle: c['errors'].append(str(error)))
                saved = json.dumps({'key': profile.api_key, 'brain': host.user_brain_id('bench-user-0'), 'view': 'brain'})
                page.add_init_script('sessionStorage.setItem("membrain-page", ' + json.dumps(saved) + ');')
                page.goto(base + '/memory')
                page.wait_for_function('() => window.observatory?.snapshot().nodes.length > 0')
                cycle['renderer'] = page.evaluate('() => window.observatory.renderer()')
                page.locator('#brain-showcase').click()
                page.wait_for_function('() => window.memoryHologram.snapshot().ready')
                before = page.evaluate('() => window.memoryHologram.snapshot()')
                page.wait_for_timeout(1000)
                after = page.evaluate('() => window.memoryHologram.snapshot()')
                cycle['frames'] = after['frames'] - before['frames']
                assert cycle['frames'] > 0 and not cycle['errors']
                page.locator('#show-pause').click()
                assert page.locator('#show-pause').get_attribute('aria-pressed') == 'true'
                if index % 2:
                    page.screenshot(path=str(root / f'browser-lifetime-v2-{index}.png'), timeout=10000)
                page.locator('#show-close').click()
                assert not page.evaluate('() => window.memoryHologram.snapshot().ready')
            finally:
                cycle['closing'] = True
                context.close()
            assert browser.is_connected()
        closing = True
        browser.close()
    report['completed'] = report['passed'] = True
except Exception as error:
    report['error'] = {'type': type(error).__name__, 'message': str(error)[:1000]}
    traceback.print_exc()
finally:
    if process is not None:
        process.terminate()
        try:
            process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
    log.close()
    embedded_database.stop(profile)
    (root / 'browser-lifetime-v2.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'completed': report['completed'], 'passed': report['passed'], 'cycles': len(report['cycles'])}))
raise SystemExit(0 if report['passed'] else 1)
