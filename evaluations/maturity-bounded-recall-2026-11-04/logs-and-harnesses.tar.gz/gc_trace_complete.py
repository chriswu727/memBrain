import atexit
import gc
import heapq
import json
import resource
import signal
import time


def start(path, *, signum=None):
    state = {'event_count': 0, 'generations': {}, 'top_events': [],
             'thresholds': list(gc.get_threshold()), 'enabled': gc.isenabled()}
    pending = {}

    def track(action, info):
        generation = info['generation']
        if action == 'start':
            pending[generation] = (time.perf_counter(), time.process_time())
        elif generation in pending:
            end, cpu_end = time.perf_counter(), time.process_time()
            begin, cpu_begin = pending.pop(generation)
            duration = (end - begin) * 1000
            state['event_count'] += 1
            summary = state['generations'].setdefault(str(generation),
                {'count': 0, 'total_ms': 0, 'max_ms': 0, 'collected': 0, 'uncollectable': 0})
            summary['count'] += 1
            summary['total_ms'] += duration
            summary['max_ms'] = max(summary['max_ms'], duration)
            summary['collected'] += info.get('collected', 0)
            summary['uncollectable'] += info.get('uncollectable', 0)
            event = {'generation': generation, 'begin': begin, 'end': end, 'duration_ms': duration,
                     'process_cpu_ms': (cpu_end - cpu_begin) * 1000,
                     'collected': info.get('collected'), 'uncollectable': info.get('uncollectable')}
            item = (duration, state['event_count'], event)
            if len(state['top_events']) < 64:
                heapq.heappush(state['top_events'], item)
            elif duration > state['top_events'][0][0]:
                heapq.heapreplace(state['top_events'], item)

    def flush(*args):
        usage = resource.getrusage(resource.RUSAGE_SELF)
        snapshot = {**state, 'top_events': [item[2] for item in sorted(state['top_events'], reverse=True)],
                    'thresholds_at_flush': list(gc.get_threshold()), 'enabled_at_flush': gc.isenabled(),
                    'max_rss_platform_units': usage.ru_maxrss, 'process_user_seconds': usage.ru_utime,
                    'process_system_seconds': usage.ru_stime}
        path.write_text(json.dumps(snapshot, indent=2) + '\n')

    def save():
        if track in gc.callbacks:
            gc.callbacks.remove(track)
        flush()

    gc.callbacks.append(track)
    if signum is not None:
        signal.signal(signum, flush)
    atexit.register(save)
    return state
