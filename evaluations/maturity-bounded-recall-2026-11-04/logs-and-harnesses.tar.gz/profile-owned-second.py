import cProfile
import io
import os
import pstats
import sys
from pathlib import Path

for key in list(os.environ):
    if key.endswith(('_API_KEY', '_API_TOKEN')) or key.startswith(('MEMORY_', 'MEMBRAIN_')):
        del os.environ[key]
os.environ.update(MEMBRAIN_SEMANTIC='0', PYTHON_DOTENV_DISABLED='1')

import httpx
from fastapi.testclient import TestClient

from membrain import embedded_database, host
from membrain.api import create_app
from membrain.client import MemoryClient
from membrain.config import configured_service
from membrain.local_profile import load_profile
from membrain.service import MemoryService

base = Path('/Users/yichen/tmp/membrain-sql-recall-20261104')
mode = sys.argv[1]
assert mode in ('core', 'client')
profile = load_profile(Path('/Users/yichen/tmp/membrain-performance-followup-20261103/perf-15fa8ec-installation'))
profiler = cProfile.Profile()
respond = MemoryService.respond
recording = False


def measured(self, *args, **kwargs):
    if recording and mode == 'core':
        profiler.enable()
    try:
        return respond(self, *args, **kwargs)
    finally:
        if recording and mode == 'core':
            profiler.disable()


MemoryService.respond = measured
embedded_database.start(profile)
try:
    settings = profile.settings()
    with configured_service(settings) as service:
        with TestClient(create_app(settings, service), base_url=profile.base_url) as api:
            def transport(request):
                result = api.request(request.method, request.url.raw_path.decode(),
                                     headers=dict(request.headers), content=request.content)
                return httpx.Response(result.status_code, content=result.content, headers=result.headers)

            with MemoryClient(profile.base_url, profile.api_key, host.user_brain_id('bench-user-0'),
                              transport=httpx.MockTransport(transport)) as client:
                for index in range(5):
                    assert host.recall_context(client, f'What is the appointment for project{index:04d}?',
                                               current_conversation='benchmark')
                recording = True
                if mode == 'client': profiler.enable()
                for index in range(20):
                    assert host.recall_context(client, f'What is the appointment for project{index:04d}?',
                                               current_conversation='benchmark')
                if mode == 'client': profiler.disable()
                recording = False
finally:
    embedded_database.stop(profile)
    MemoryService.respond = respond
profiler.dump_stats(base / f'recall-owned-{mode}-7d8d45a.pstats')
output = io.StringIO()
pstats.Stats(profiler, stream=output).strip_dirs().sort_stats('cumulative').print_stats(45)
pstats.Stats(profiler, stream=output).strip_dirs().sort_stats('tottime').print_stats(30)
(base / f'recall-owned-{mode}-7d8d45a.txt').write_text(output.getvalue())
print(output.getvalue())
