from pathlib import Path

from membrain import contracts

source = Path('/Users/yichen/tmp/membrain-sql-recall-20261104/candidate-contracts.py')
exec(compile(source.read_text(), contracts.__file__, 'exec'), contracts.__dict__)

import pytest

raise SystemExit(pytest.main(['-q', 'tests/test_contract_linking.py']))
