import atexit
import gc
import json
import signal
import time


def start(path, *, signum=None):
    state = {'events': [], 'dropped': 0}
    pending = {}

    def track(action, info):
        generation = info['generation']
        if action == 'start':
            pending[generation] = time.perf_counter()
        elif generation in pending:
            end = time.perf_counter()
            begin = pending.pop(generation)
            if len(state['events']) < 10000:
                state['events'].append({'generation': generation, 'begin': begin, 'end': end,
                                        'duration_ms': (end - begin) * 1000,
                                        'collected': info.get('collected'), 'uncollectable': info.get('uncollectable')})
            else:
                state['dropped'] += 1

    def flush(*args):
        snapshot = {'events': list(state['events']), 'dropped': state['dropped']}
        path.write_text(json.dumps(snapshot, indent=2) + '\n')

    def save():
        if track in gc.callbacks:
            gc.callbacks.remove(track)
        flush()

    gc.callbacks.append(track)
    if signum is not None:
        signal.signal(signum, flush)
    atexit.register(save)
    return state
