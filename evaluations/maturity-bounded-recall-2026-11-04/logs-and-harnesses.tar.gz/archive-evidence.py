import hashlib
import io
import json
import re
import subprocess
import tarfile
from pathlib import Path

root = Path(__file__).resolve().parent
repository = Path('/Users/yichen/tmp/membrain-review-20261029')
destination = repository / 'evaluations/maturity-bounded-recall-2026-11-04'
destination.mkdir(exist_ok=False)
secrets = set()
for task in (root, Path('/Users/yichen/tmp/membrain-goal-polish-20261104'),
             Path('/Users/yichen/tmp/membrain-performance-followup-20261103')):
    for profile in task.rglob('profile.json'):
        document = json.loads(profile.read_text())
        secrets.update(value for key, value in document.items()
                       if isinstance(value, str) and len(value) >= 8 and ('password' in key or key == 'api_key'))


def sanitized(data):
    text = data.decode()
    for secret in sorted(secrets, key=len, reverse=True):
        text = text.replace(secret, '[redacted-fixture-secret]')
    text = re.sub(r'postgres(?:ql)?://([^:@\s]+):[^@\s\x22\x27]+@',
                  r'postgresql://\1:[redacted-fixture-password]@', text)
    text = re.sub(r'am_[A-Za-z0-9_-]{30,}', '[redacted-fixture-api-key]', text)
    assert not any(secret in text for secret in secrets)
    return text.encode()


copies = ['canonical-38c948a.json', 'canonical-38c948a-command.json', 'canonical-ded4ae2.json',
          'canonical-command.json', 'sql-parity.json', 'sql-keys-http-abba.json', 'schema-types-http-abba.json',
          'custom-validator.json', 'bundle-http-abba.json', 'visual-poll-recall-abba.json',
          'visual-final-abba.json', 'visual-observed-abba.json', 'visual-window-audit.json',
          'browser-lifetime.json', 'browser-lifetime-v2.json', 'sustained-summary.json',
          'sustained-complete-summary.json', 'installed-followup-smoke.json', 'cleanup-current.json']
manifest = {'source_commit': '38c948a2f63664db6e169e324fce0522154ec563',
            'runtime_pin': '60b8b746d5f389ef4a89e50564cc6280284dce44',
            'files': {}, 'archive_members': {}, 'current_module_sha256': {},
            'note': 'Disposable profile secrets and PostgreSQL passwords are redacted. Original failed runs remain failed. '
                    'The observed four-phase script passes aggregate bars; the separate offline window audit exits 1. '
                    'Full current CI: 6994 Python, zero skips; 44 TypeScript, typecheck and build pass. '
                    'ci-e5260bc.log is truncated CLI output; use ci-e5260bc-full.log for that historical run.'}
for name in copies:
    data = sanitized((root / name).read_bytes())
    (destination / name).write_bytes(data)
    manifest['files'][name] = hashlib.sha256(data).hexdigest()
data = sanitized((root / 'install-final/results.json').read_bytes())
(destination / 'install-results.json').write_bytes(data)
manifest['files']['install-results.json'] = hashlib.sha256(data).hexdigest()
for name in ('contracts.py', 'context_views.py', 'lexical_candidates.py'):
    data = (repository / 'src/membrain' / name).read_bytes()
    prototype = {'contracts.py': 'candidate-contracts.py', 'context_views.py': 'candidate-context_views.py',
                 'lexical_candidates.py': 'candidate-bounded-lexical.py'}[name]
    assert data == (root / prototype).read_bytes()
    manifest['current_module_sha256'][name] = hashlib.sha256(data).hexdigest()
    assert data == subprocess.check_output(['git', 'show', manifest['runtime_pin'] + ':src/membrain/' + name], cwd=repository)
archive = destination / 'logs-and-harnesses.tar.gz'
with tarfile.open(archive, 'w:gz') as saved:
    for path in sorted(root.iterdir()):
        if not path.is_file() or path.suffix not in ('.py', '.log', '.txt', '.json'):
            continue
        if path.name == 'continuation.json':
            continue
        data = sanitized(path.read_bytes())
        info = tarfile.TarInfo(path.name)
        info.size = len(data)
        saved.addfile(info, io.BytesIO(data))
        manifest['archive_members'][path.name] = hashlib.sha256(data).hexdigest()
manifest['files'][archive.name] = hashlib.sha256(archive.read_bytes()).hexdigest()
(destination / 'sha256.json').write_text(json.dumps(manifest, indent=2) + '\n')
for name, digest in manifest['files'].items():
    assert hashlib.sha256((destination / name).read_bytes()).hexdigest() == digest
with tarfile.open(archive) as saved:
    assert set(saved.getnames()) == set(manifest['archive_members'])
    for name, digest in manifest['archive_members'].items():
        assert hashlib.sha256(saved.extractfile(name).read()).hexdigest() == digest
print(json.dumps({'files': len(manifest['files']), 'archive_members': len(manifest['archive_members']),
                  'archive_bytes': archive.stat().st_size, 'hashes_verified': True}))
