import os
from pathlib import Path

for key in list(os.environ):
    if key.startswith(('MEMORY_', 'MEMBRAIN_')) or key.endswith(('_API_KEY', '_API_TOKEN')):
        del os.environ[key]
os.environ.update(MEMBRAIN_SEMANTIC='0', PYTHON_DOTENV_DISABLED='1')

from membrain import cognition, context_views, lexical_candidates

root = Path('/Users/yichen/tmp/membrain-sql-recall-20261104')
for module, filename in ((context_views, 'candidate-context_views.py'),
                         (lexical_candidates, 'candidate-bounded-lexical.py')):
    exec(compile((root / filename).read_text(), module.__file__, 'exec'), module.__dict__)
cognition.FittingMeasure = context_views.FittingMeasure

from collections import Counter

original_terms = cognition._terms
calls = Counter()
def counted(text):
    calls[text] += 1
    return original_terms(text)
cognition._terms = counted
try:
    scorer = lexical_candidates.LexicalScorer("blue map", [])
    for number in range(1000):
        scorer("blue map", f"Unrelated label{number:05d} belongs to the garden.")
    assert len(scorer._term_cache) == 512 and scorer._cached_characters <= 65536
    characters = lexical_candidates.LexicalScorer("blue map", [])
    for number in range(100):
        characters("blue map", f"label{number:05d} " + "garden " * 150)
    assert characters._cached_characters <= 65536 and len(characters._term_cache) < 512
    oversized = lexical_candidates.LexicalScorer("blue map", [])
    large = "山" * 65537
    oversized("blue map", large)
    oversized("blue map", large)
    assert calls[large] >= 2 and large not in oversized._term_cache
finally:
    cognition._terms = original_terms
print("512-text and 65536-character bounds checked independently; oversized text is not cached.")

import pytest

raise SystemExit(pytest.main(['-q', 'tests/test_context_views.py', 'tests/test_recall_measure_parity.py',
                             'tests/test_lexical_candidates.py::test_term_reuse_preserves_scores_and_source_frequency']))
