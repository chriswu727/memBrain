import importlib.util
import json
import os
from pathlib import Path

for key in list(os.environ):
    if key.startswith(('MEMORY_', 'MEMBRAIN_')) or key.endswith(('_API_KEY', '_API_TOKEN')):
        del os.environ[key]
os.environ.update(MEMBRAIN_SEMANTIC='0', PYTHON_DOTENV_DISABLED='1')

from membrain import embedded_database, host
from membrain.helpers import Principal
from membrain.lexical_candidates import lexical_rows
from membrain.local_profile import load_profile
from membrain.service import MemoryService, reading
from membrain.storage import Database

root = Path('/Users/yichen/tmp/membrain-sql-recall-20261104')
spec = importlib.util.spec_from_file_location('membrain._lexical_sql_probe', root / 'candidate-lexical_candidates.py')
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)
profile = load_profile(Path('/Users/yichen/tmp/membrain-performance-followup-20261103/perf-15fa8ec-installation'))
embedded_database.start(profile)
database = Database(profile.database_url, pool=True)
service = MemoryService(database)
principal = Principal(profile.tenant_id, profile.principal_id)
cases = []
try:
    for number in (0, 1, 7):
        with database.transaction(principal) as conn, reading():
            brain = service._brain(conn, principal, host.user_brain_id(f'bench-user-{number}'))
            params = service._params(principal, brain['id'])
            baseline, _ = lexical_rows(conn, params, {}, 'project0000 appointment', limit=4)
            versions = [(row['document']['memory_id'], row['document']['revision']) for row in baseline]
            sources = [ref['event_id'] for row in baseline for ref in row['document']['evidence_refs']]
            for query in ('project0000 appointment', 'project0019', '银杏树旁的小学', "label' | !('private'); --", 'x' * 257,
                          ' '.join(f'word{index:04d}' for index in range(130))):
                for limit in (0, 1, 4, 64, 512):
                    for options in ({}, {'through_sequence': 1}, {'through_sequence': 0},
                                    {'excluded_versions': versions}, {'independent_of_event_ids': sources}):
                        target = {'conversation_ref': 'history', 'branch_ref': 'main'}
                        expected = lexical_rows(conn, params, target, query, limit=limit, **options)
                        actual = candidate.lexical_rows(conn, params, target, query, limit=limit, **options)
                        assert actual == expected, (number, query, limit, options, actual[1], expected[1])
                        cases.append({'brain': number, 'limit': limit, 'query_length': len(query),
                                      'option': list(options), 'rows': len(actual[0]), 'truncated': actual[1]})
            for target in ({'conversation_ref': 'history', 'branch_ref': 'other'},
                           {'conversation_ref': 'elsewhere', 'branch_ref': 'other'}):
                assert candidate.lexical_rows(conn, params, target, 'appointment', limit=4) == lexical_rows(
                    conn, params, target, 'appointment', limit=4)
            empty = (*params[:2], 'no-such-probe-brain')
            assert candidate.lexical_rows(conn, empty, {}, 'appointment', limit=4) == ([], False)
finally:
    database.close()
    embedded_database.stop(profile)
(root / 'sql-parity.json').write_text(json.dumps({'cases': len(cases), 'details': cases, 'completed': True}, indent=2) + '\n')
print(json.dumps({'cases': len(cases), 'completed': True}))
