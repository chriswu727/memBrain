import json
import hashlib
import os
import socket
import statistics
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import httpx
from membrain import embedded_database, host
from membrain.client import MemoryClient
from membrain.local_profile import load_profile

root=Path('/Users/yichen/tmp/membrain-sql-recall-20261104')
installation=Path('/Users/yichen/tmp/membrain-performance-followup-20261103/perf-15fa8ec-installation')
profile=load_profile(installation)
assert not profile.cognition
boot='''
import sys
from pathlib import Path
import uvicorn
from membrain import contracts
from membrain.local_profile import load_profile
sys.path.insert(0, '/Users/yichen/tmp/membrain-sql-recall-20261104')
import gc_trace
gc_path=Path('/Users/yichen/tmp/membrain-sql-recall-20261104')/('bundle-'+sys.argv[2]+'-'+sys.argv[3]+'.gc.json')
gc_trace.start(gc_path)
if sys.argv[2]=='candidate':
    from membrain import cognition, context_views, lexical_candidates
    root=Path('/Users/yichen/tmp/membrain-sql-recall-20261104')
    for module, name in [(context_views,'candidate-context_views.py'),(lexical_candidates,'candidate-bounded-lexical.py')]:
        exec(compile((root/name).read_text(), module.__file__, 'exec'), module.__dict__)
    cognition.FittingMeasure=context_views.FittingMeasure
from membrain.api import create_app
profile=load_profile(Path(sys.argv[1]))
uvicorn.run(create_app(profile.settings()),host='127.0.0.1',port=int(sys.argv[3]),log_level='error')
'''
environment={k:v for k,v in os.environ.items() if not k.startswith(('MEMORY_','MEMBRAIN_')) and not k.endswith(('_API_KEY','_API_TOKEN'))}
environment.update(MEMBRAIN_SEMANTIC='0',PYTHON_DOTENV_DISABLED='1')
result={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        'reference_commit':'ded4ae2f5faddd40146abe2c0d6504adf105228d','candidate_runtime':'isolated fixed-key byte measure and bounded 512-text/64Ki-character parse cache','protocol':'Prepared-type runtime compared to request-local byte metadata and parse-cache changes; automatic GC observed on both client and server without changing its policy; exact rendered context hashes compared for all measured recalls. Fixed corpus; 8 brains x 21 queries, discard each first query; reference/candidate/candidate/reference; no model calls; visualizer unloaded.', 'phases':[]}
import gc_trace
client_gc=gc_trace.start(root/'bundle-client.gc.json')
embedded_database.start(profile)
try:
    for index,variant in enumerate(('reference','candidate','candidate','reference')):
        with socket.socket() as listener:
            listener.bind(('127.0.0.1',0)); port=listener.getsockname()[1]
        base=f'http://127.0.0.1:{port}'
        stream=(root/f'bundle-http-{index}-{variant}.log').open('w')
        process=subprocess.Popen([sys.executable,'-c',boot,str(installation),variant,str(port)],env=environment,stdout=stream,stderr=subprocess.STDOUT)
        clients=[]
        phase=None
        try:
            with httpx.Client(timeout=.5,trust_env=False) as health:
                deadline=time.monotonic()+30
                while True:
                    if process.poll() is not None:raise RuntimeError(f'{variant} service exited')
                    try:
                        if health.get(base+'/health').status_code==200:break
                    except httpx.TransportError:pass
                    if time.monotonic()>deadline:raise RuntimeError('service health timed out')
                    time.sleep(.1)
            clients=[MemoryClient(base,profile.api_key,brain_id=host.user_brain_id(f'bench-user-{worker}')) for worker in range(8)]
            def worker(client):
                samples=[]; digests=[]; windows=[]
                for round_index in range(21):
                    begin=time.perf_counter()
                    found=host.recall_context(client,f'What is the appointment for project{round_index%20:04d}?',current_conversation='benchmark')
                    elapsed=(time.perf_counter()-begin)*1000
                    assert found
                    samples.append(elapsed)
                    windows.append((begin,time.perf_counter()))
                    digests.append(hashlib.sha256(found.encode()).hexdigest())
                return samples[1:],digests[1:],windows[1:]
            with ThreadPoolExecutor(max_workers=8) as pool:
                outcomes=list(pool.map(worker,clients))
                raw=[item[0] for item in outcomes]
                digests=[item[1] for item in outcomes]
                windows=[item[2] for item in outcomes]
            values=sorted(x for part in raw for x in part)
            phase={'variant':variant,'port':port,'request_windows':windows,'client_gc_events':list(client_gc['events']),'context_sha256':digests,'n':len(values),'median_ms':round(statistics.median(values),2),'p95_ms':round(values[int(.95*(len(values)-1))],2),'rss_kb':int(subprocess.check_output(['ps','-p',str(process.pid),'-o','rss='],text=True).strip()),'raw_ms':[[round(x,2) for x in part] for part in raw]}
            if result['phases']:
                assert digests == result['phases'][0]['context_sha256'], 'Rendered context differs from the reference phase'
            result['phases'].append(phase)
            (root/'bundle-http-abba.json').write_text(json.dumps(result,indent=2)+'\n')
            print(json.dumps({k:v for k,v in phase.items() if k not in ('raw_ms','context_sha256','request_windows','client_gc_events','server_gc')}),flush=True)
        finally:
            for client in clients:client.close()
            process.terminate()
            try:process.wait(timeout=15)
            except subprocess.TimeoutExpired:process.kill();process.wait()
            stream.close()
            gc_file=root/f'bundle-{variant}-{port}.gc.json'
            if phase is not None and gc_file.exists():
                phase['server_gc']=json.loads(gc_file.read_text())
finally:
    embedded_database.stop(profile)
result['completed']=True
(root/'bundle-http-abba.json').write_text(json.dumps(result,indent=2)+'\n')
