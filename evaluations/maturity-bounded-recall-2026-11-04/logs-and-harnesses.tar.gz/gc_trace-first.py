import atexit
import gc
import json
import time


def start(path):
    state = {'events': [], 'dropped': 0}
    pending = {}

    def track(action, info):
        generation = info['generation']
        if action == 'start':
            pending[generation] = time.perf_counter()
        elif generation in pending:
            end = time.perf_counter()
            begin = pending.pop(generation)
            if len(state['events']) < 10000:
                state['events'].append({'generation': generation, 'begin': begin, 'end': end,
                                        'duration_ms': (end - begin) * 1000,
                                        'collected': info.get('collected'), 'uncollectable': info.get('uncollectable')})
            else:
                state['dropped'] += 1

    def save():
        gc.callbacks.remove(track)
        path.write_text(json.dumps(state, indent=2) + '\n')

    gc.callbacks.append(track)
    atexit.register(save)
    return state
