import json
from pathlib import Path

from jsonschema import Draft202012Validator
from jsonschema.validators import extend

from membrain import contracts

root = Path('/Users/yichen/tmp/membrain-sql-recall-20261104')
cases = [
    ({'properties': {'value': {'type': 'integer'}}}, [{'value': 'alias'}, {'value': 1}]),
    ({'items': {'type': 'integer'}}, [['alias'], [1]]),
    ({'allOf': [{'type': 'integer'}]}, ['alias', 1]),
    ({'if': {'type': 'integer'}, 'then': {'const': 'alias'}, 'else': {'const': 1}}, ['alias', 1, 'other', 2]),
]


def clear():
    contracts.validator.cache_clear()
    contracts._prepared_root.cache_clear()
    contracts._linked_definitions.cache_clear()


def check():
    original_schema = contracts.schema
    outcomes = []
    checker = Draft202012Validator.TYPE_CHECKER.redefine('integer', lambda checker, value: value == 'alias')
    plain = extend(Draft202012Validator, type_checker=checker)
    try:
        for definition, values in cases:
            document = {'$schema': 'https://json-schema.org/draft/2020-12/schema', '$defs': {'Value': definition}}
            contracts.schema = lambda: document
            clear()
            base = contracts.validator('Value')
            custom = extend(type(base), type_checker=checker)(base.schema, format_checker=base.format_checker)
            expected = plain(definition, format_checker=base.format_checker)
            outcomes.append({'schema': definition, 'expected': [expected.is_valid(value) for value in values],
                             'actual': [custom.is_valid(value) for value in values]})
    finally:
        contracts.schema = original_schema
        clear()
    return outcomes


before = check()
source = root / 'candidate-contracts.py'
exec(compile(source.read_text(), contracts.__file__, 'exec'), contracts.__dict__)
after = check()
assert any(item['actual'] != item['expected'] for item in before)
assert all(item['actual'] == item['expected'] for item in after)
result = {'before': before, 'after': after, 'completed': True}
(root / 'custom-validator.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'before_mismatches': sum(item['actual'] != item['expected'] for item in before),
                  'after_mismatches': sum(item['actual'] != item['expected'] for item in after)}))
