import json
from pathlib import Path

root = Path(__file__).resolve().parent
original = json.loads((root / 'visual-observed-abba.json').read_text())
windows = []
for index, phase in enumerate(original['phases']):
    for cycle in phase['cycles']:
        for name, bar, inclusive in [('serial', 500, False), ('one_brain_8_concurrent', 1000, True),
                                      ('eight_brains_8_concurrent', 600, True)]:
            measured = cycle[name]
            values = sorted(value for worker in measured['raw_ms'] for value in worker)
            assert len(values) == measured['n'] == measured['nonempty']
            p95 = values[int(.95 * (len(values) - 1))]
            assert p95 == measured['p95_ms']
            windows.append({'phase': index, 'mode': phase['mode'], 'cycle': cycle['index'],
                            'workload': name, 'n': len(values), 'p95_ms': p95, 'bar_ms': bar,
                            'passed': p95 <= bar if inclusive else p95 < bar})
report = {'source_commit': original['source_commit'], 'runtime_pin': original['runtime_pin'],
          'original_completed': original['completed'], 'original_aggregate_passed': original['passed'],
          'protocol': 'Offline audit only: reapply the unchanged recall bars to every existing canonical-size cycle. '
                      'No new request, excluded sample or modification of the original aggregate result.',
          'windows': windows, 'all_windows_passed': all(item['passed'] for item in windows)}
(root / 'visual-window-audit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'original_aggregate_passed': report['original_aggregate_passed'],
                  'all_windows_passed': report['all_windows_passed'],
                  'failed_windows': [item for item in windows if not item['passed']]}))
raise SystemExit(0 if report['all_windows_passed'] else 1)
