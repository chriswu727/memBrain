import json
import os
from pathlib import Path

from test_turns import turns as turns
from test_vector_jobs import drain, recall_request

from membrain import host
from membrain.local_embeddings import LocalEmbeddingProvider, installed


def test_real_model_tail_delivery_across_the_existing_timeline_limit(turns):
    report = []
    directory = installed(Path(os.environ['MEMBRAIN_TEST_EMBEDDING_MODEL']))
    assert directory is not None
    with LocalEmbeddingProvider(directory) as provider:
        turns.service.embedding_provider = provider
        for repeat in (70, 500):
            text = 'I reviewed ordinary office receipts and sorted supplies ' * repeat + 'and my passport is in the blue kitchen drawer'
            event = turns.observe(text, conversation=f'original-{repeat}')
            drain(turns)

            class Client:
                brain_id = turns.brain

                def recall(self, query, **options):
                    request = recall_request(turns, query)
                    request['payload'].update(options)
                    self.response = turns.service.handle(turns.principal, request)
                    return self.response

                def timeline(self, **options):
                    return turns.service.timeline(turns.principal, turns.brain, **options)

                def following(self, ids):
                    return turns.service.following(turns.principal, turns.brain, ids)

                def trace_recall(self, ids):
                    self.traced = ids

            client = Client()
            context = host.recall_context(client, 'Where do I keep my passport?', current_conversation='new', boundaries=[])
            items = (client.response.get('result') or {}).get('items', [])
            targets = [item for item in items if any(ref['event_id'] == event['event_id']
                       for ref in item['memory']['evidence_refs'])]
            report.append({'source_characters':len(text), 'target_event_id':event['event_id'],
                           'api_outcome':client.response.get('outcome'), 'api_target_items':len(targets),
                           'matched_spans':[item.get('matched_statement_span') for item in targets],
                           'context':context,'trace':getattr(client,'traced',[]),
                           'target_source_delivered':event['event_id'] in getattr(client,'traced',[]),
                           'tail_visible': 'passport is in the blue kitchen drawer' in (context or '')})
            turns.action('forget', {'idempotency_key':f'probe-forget-{repeat}',
                                   'selector':{'kind':'events','ids':[event['event_id']]},
                                   'mode':'erase_content', 'expected_scope_generation':repeat // 500 + 1})
    Path(__file__).with_suffix('.json').write_text(json.dumps(report, indent=2))
    assert all(row['target_source_delivered'] and row['tail_visible'] for row in report), report
