import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile

sys.path.insert(0, '/Users/yichen/tmp/membrain-passage-index-20261107/tests')
from test_passage_index import PassageProvider, TEXT
from test_recall_windows import Client
from test_turns import Turns
from test_vector_jobs import drain

from membrain import desktop, host
from membrain.build_identity import BUILD_ID, SCHEMA_ID
from membrain.desktop_backup import backup
from membrain.desktop_restore import activate, restore
from membrain.helpers import Principal, uid
from membrain.local_profile import ensure_profile, load_profile
from membrain.recovery_profile import authority_for
from membrain.service import MemoryService
from membrain.storage import Database

root = Path(__file__).parent
os.environ.update(MEMBRAIN_SEMANTIC='0', PYTHON_DOTENV_DISABLED='1')
report = {'build_id': BUILD_ID, 'schema_id': SCHEMA_ID, 'completed': False, 'provider': 'deterministic 3D test vectors'}

def harness(profile):
    turns = Turns.__new__(Turns)
    turns.database = Database(profile.database_url)
    turns.database.recovery_authority = authority_for(profile)
    turns.service = MemoryService(turns.database, embedding_provider=PassageProvider())
    turns.principal = Principal(profile.tenant_id, profile.principal_id)
    turns.brain = profile.brain_id
    turns.conversation = 'backup-passage-source'
    turns.branch = 'main'
    return turns

def snapshot(turns):
    with turns.database.transaction(turns.principal) as conn:
        rows = conn.execute('SELECT memory_id,memory_revision,model,model_version,passage_index,'
                            'start_offset,end_offset,embedding::text AS vector FROM memory_embedding_passages '
                            'WHERE brain_id=%s ORDER BY memory_id,passage_index', (turns.brain,)).fetchall()
    return rows

with tempfile.TemporaryDirectory(prefix='backup-passage-', dir=root) as temporary:
    directory = Path(temporary)
    owned = []
    try:
        profile = ensure_profile(directory / 'source', database_engine='embedded')
        owned.append(profile.directory)
        desktop._prepare_database(profile)
        profile = load_profile(profile.directory)
        turns = harness(profile)
        turns.observe(TEXT)
        removed = turns.observe(TEXT.replace('blue kitchen drawer', 'red cellar cupboard'), conversation='obsolete')
        drain(turns)
        before = snapshot(turns)
        completed = backup(profile.directory, output=directory / 'backup', request_id='passage-backup')
        turns.action('forget', {'idempotency_key': uid(), 'selector': {'kind': 'events', 'ids': [removed['event_id']]},
                                'mode': 'erase_content', 'expected_scope_generation': 1})
        remaining = snapshot(turns)
        assert 0 < len(remaining) < len(before)
        authority = authority_for(profile)
        owned.append(directory / 'restored')
        result = restore(backup_path=directory / 'backup', directory=directory / 'restored',
                         registry_path=authority.registry.directory, request_id='passage-restore')
        assert result['state'] == 'quarantined'
        restored = load_profile(directory / 'restored')
        with harness(restored).database.transaction(turns.principal) as conn:
            assert conn.execute('SELECT state FROM memory_recovery_installations').fetchone()['state'] == 'quarantined'
        head = authority.registry.head()
        active = activate(restored.directory, recovery_epoch=result['recovery_epoch'], backup_id=completed['backup_id'],
                          checkpoint_at=result['checkpoint']['checkpoint_at'], retire_installation_id=profile.installation_id,
                          expected_sequence=head['sequence'], expected_head_hash=head['head_hash'],
                          acknowledge_host_reconciliation=True)
        assert active['state'] == 'active'
        recovered = harness(restored)
        after = snapshot(recovered)
        assert after == remaining
        context = host.recall_context(Client(recovered), 'travel document location', boundaries=[])
        assert 'passport is in the blue kitchen drawer' in context
        assert 'red cellar cupboard' not in context
        report.update(completed=True, backed_up_passages=len(before), restored_passages=len(after),
                      erased_passages_not_resurrected=len(before)-len(after), exact_retained_passage_rows=True,
                      retained_sha256=hashlib.sha256(json.dumps(after, sort_keys=True).encode()).hexdigest(),
                      restored_tail_delivered=True, quarantine_before_activation=True)
    finally:
        for path in reversed(owned):
            if (path / 'profile.json').exists():
                current = load_profile(path)
                if desktop._port_open(current.api_port) or desktop._port_open(current.database_port):
                    desktop.stop(path)
                assert not desktop._port_open(current.api_port) and not desktop._port_open(current.database_port)
        report['owned_ports_closed'] = True
        (root / 'backup-probe.json').write_text(json.dumps(report, indent=2)+'\n')
report['temporary_profiles_and_dump_removed'] = not directory.exists()
(root / 'backup-probe.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
