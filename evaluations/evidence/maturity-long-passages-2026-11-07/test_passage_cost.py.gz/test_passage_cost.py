import json
import statistics
import subprocess
import time
import types
from pathlib import Path

from psycopg.types.json import Jsonb
from test_candidates import candidates as candidates

from membrain import candidates as current
from membrain.build_identity import BUILD_ID
from membrain.client import default_budget, default_read_fence
from membrain.embeddings import EmbeddingResult, EmbeddingSpace
from membrain.helpers import digest


def test_compare_short_record_index_cost_and_mixed_passage_storage(candidates):
    previous = types.ModuleType('membrain.previous_candidates')
    previous.__package__ = 'membrain'
    exec(subprocess.check_output(['git', 'show', 'badc404:src/membrain/candidates.py'], text=True), previous.__dict__)
    memory = candidates.add('Office supplies are kept in the yellow cabinet.')
    space = EmbeddingSpace('cost-fixture', 'v1', 384)
    vector = '[' + ','.join(['1'] + ['0'] * 383) + ']'
    report = {'build_id': BUILD_ID, 'fixture': 'Synthetic 384-dimensional vectors; shared source; no semantic quality claim',
              'samples': [], 'complete': False}
    query = {'query': 'office cabinet', 'intent': 'explore', 'budget': default_budget(2048),
             'read_fence': default_read_fence(), 'cue_event_ids': [], 'additional_cues': []}
    embedding = EmbeddingResult(space, (tuple([1.] + [0.] * 383),), None, 'fixture', 0)
    with candidates.database.transaction(candidates.principal) as conn:
        conn.execute('INSERT INTO memory_assertions(tenant_id,owner_id,brain_id,id,revision,document,event_ids,search_text) '
                     "SELECT %s,%s,%s,'cost-'||n,1,jsonb_set(%s::jsonb,'{memory_id}',to_jsonb('cost-'||n)),%s,%s "
                     'FROM generate_series(1,10000) AS n',
                     (*candidates.params, Jsonb(memory), [ref['event_id'] for ref in memory['evidence_refs']], memory['statement']))
        conn.execute('INSERT INTO memory_embeddings(tenant_id,owner_id,brain_id,memory_id,memory_revision,model,model_version,'
                     'content_hash,dimensions,embedding) SELECT tenant_id,owner_id,brain_id,id,revision,%s,%s,%s,384,%s::vector '
                     'FROM memory_assertions WHERE brain_id=%s',
                     (space.model, space.model_version, digest(memory['statement']), vector, candidates.brain_id))
    for phase in ('short_records', 'ten_percent_with_eight_passages'):
        with candidates.database.transaction(candidates.principal) as conn:
            if phase != 'short_records':
                conn.execute('INSERT INTO memory_embedding_passages(tenant_id,owner_id,brain_id,memory_id,memory_revision,'
                             'model,model_version,passage_index,start_offset,end_offset,embedding) '
                             'SELECT tenant_id,owner_id,brain_id,memory_id,memory_revision,model,model_version,p,0,40,embedding '
                             'FROM memory_embeddings CROSS JOIN generate_series(0,7) p '
                             "WHERE brain_id=%s AND memory_id LIKE 'cost-%%0'", (candidates.brain_id,))
            brain = candidates.service._brain(conn, candidates.principal, candidates.brain_id)
            durations = {'previous_head_only': [], 'current_passages': []}
            for iteration in range(14):
                methods = [('previous_head_only', previous.collect_candidates), ('current_passages', current.collect_candidates)]
                if iteration % 2:
                    methods.reverse()
                for name, method in methods:
                    start = time.perf_counter()
                    _, state = method(conn, candidates.service, candidates.principal, brain, candidates.target, query,
                                      query_embedding=embedding)
                    elapsed = 1000 * (time.perf_counter() - start)
                    assert state['candidate_versions']
                    if iteration > 1:
                        durations[name].append(elapsed)
            storage = conn.execute("SELECT pg_total_relation_size('memory_embeddings') AS parents,"
                                   "pg_total_relation_size('memory_embedding_passages') AS passages").fetchone()
            report['samples'].append({'phase': phase, 'timings_ms': durations, 'storage_bytes': storage,
                                      'median_ms': {key: statistics.median(value) for key, value in durations.items()},
                                      'max_ms': {key: max(value) for key, value in durations.items()}})
    report['complete'] = True
    Path(__file__).with_suffix('.json').write_text(json.dumps(report, indent=2)+'\n')
