import hashlib
import json
from pathlib import Path
import resource
import time

from membrain.build_identity import BUILD_ID
from membrain.local_embeddings import FILES, LocalEmbeddingProvider, installed

root = Path(__file__).parent
directory = installed(Path('/Users/yichen/tmp/membrain-neural-evidence-20261103/perf-topology-9bc9893-installation'))
assert directory is not None
for name, (expected, size) in FILES.items():
    content = (directory / name).read_bytes()
    assert len(content) == size and hashlib.sha256(content).hexdigest() == expected
del content
report = {'build_id': BUILD_ID, 'model_checksums_verified': True, 'platform': 'macOS Apple M4',
          'rss_unit': 'bytes; cumulative process peak, including model verification/load', 'samples': []}
with LocalEmbeddingProvider(directory) as provider:
    for length in (40, 4000, 28000, 48000, 65500):
        text = ('ordinary office records ' * 3000)[:length-45] + ' my passport is stored in the blue drawer'
        if length == 40:
            text = 'My passport is in the blue drawer.'
        start = time.perf_counter()
        result = provider.embed([text])
        duration = time.perf_counter() - start
        assert len(result.vectors) == 1
        assert not result.passages[0] or result.passages[0][-1].end == len(text)
        report['samples'].append({'characters': len(text), 'input_bytes': len(text.encode()),
                                  'encoding_seconds': duration, 'passages': len(result.passages[0]),
                                  'input_tokens': result.usage['input_tokens'],
                                  'peak_rss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
(root / 'model-resource-probe.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
