import json
import os
from pathlib import Path
import socket
import sys
import tempfile

import pytest
from membrain import desktop, embedded_database
from membrain.local_profile import ensure_profile, load_profile

root = Path(__file__).parent
label = sys.argv[1]
os.environ.update(MEMBRAIN_SEMANTIC='0', PYTHON_DOTENV_DISABLED='1')
with tempfile.TemporaryDirectory(prefix='membrain-episode-test-', dir=root) as temporary:
    directory = Path(temporary) / 'installation'
    profile = ensure_profile(directory, database_engine='embedded')
    try:
        desktop._prepare_database(profile)
        profile = load_profile(directory)
        os.environ['MEMORY_DATABASE_URL'] = profile.database_url
        os.environ['MEMORY_MIGRATION_DATABASE_URL'] = profile.migration_database_url
        os.environ.pop('MEMORY_TEST_DATABASE_URL', None)
        result = pytest.main(sys.argv[2:])
    finally:
        embedded_database.stop(load_profile(directory))
        with socket.socket() as sock:
            sock.settimeout(1)
            stopped = sock.connect_ex(('127.0.0.1', profile.database_port)) != 0
        assert stopped
(root / f'{label}-cleanup.json').write_text(json.dumps({'pytest_exit':result, 'database_stopped':stopped, 'profile_removed':not directory.exists()})+'\n')
raise SystemExit(result)
