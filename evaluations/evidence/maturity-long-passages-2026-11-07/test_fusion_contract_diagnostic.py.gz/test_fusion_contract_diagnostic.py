import json
import ast
import subprocess
import types
from pathlib import Path

from test_candidates import Candidates, candidates as candidates, key, query_vector

from membrain import candidates as candidate_module


def test_compare_parent_only_ranking_before_and_after_passage_query(candidates):
    previous = types.ModuleType('membrain.previous_candidates')
    previous.__package__ = 'membrain'
    exec(subprocess.check_output(['git', 'show', 'badc404:src/membrain/candidates.py'], text=True), previous.__dict__)
    source = subprocess.check_output(['git', 'show', '0c8ea88:src/membrain/candidates.py'], text=True)
    node = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == '_direct_candidates')
    legacy_scope = dict(previous.__dict__)
    exec(ast.get_source_segment(source, node), legacy_scope)
    results = []
    for _ in range(24):
        fixture = Candidates(candidates.database)
        for number in range(20):
            memory = fixture.add(f'A marble ornament on display number {number}.')
            fixture.embed(memory, [1.0, (number + 1) * .05, 0.0])
        target = fixture.add('出国用的证件收在柜子里。')
        fixture.embed(target, [1.0, 0.0, 0.0])
        _, current = fixture.query('passport visa consulate marble', budget=2048, query_embedding=query_vector())
        original = candidate_module.collect_candidates
        try:
            candidate_module.collect_candidates = previous.collect_candidates
            from test_candidates import collect_candidates as bound
            import test_candidates
            test_candidates.collect_candidates = previous.collect_candidates
            _, old = fixture.query('passport visa consulate marble', budget=2048, query_embedding=query_vector())
        finally:
            candidate_module.collect_candidates = original
            test_candidates.collect_candidates = bound
        target_key = key(target)
        corrected = previous._direct_candidates
        previous._direct_candidates = legacy_scope['_direct_candidates']
        try:
            test_candidates.collect_candidates = previous.collect_candidates
            _, unfixed = fixture.query('passport visa consulate marble', budget=2048, query_embedding=query_vector())
        finally:
            previous._direct_candidates = corrected
            test_candidates.collect_candidates = bound
        results.append({'old_position': old['candidate_versions'].index(target_key),
                        'new_position': current['candidate_versions'].index(target_key),
                        'unfixed_target_admitted': target_key in unfixed['candidate_versions'],
                        'same_roots': old['candidate_versions'] == current['candidate_versions'],
                        'signals': {str(k):v for k,v in current['rank_signals'].items()}})
    Path(__file__).with_suffix('.json').write_text(json.dumps(results, indent=2))
    assert all(item['same_roots'] and not item['unfixed_target_admitted'] for item in results)
