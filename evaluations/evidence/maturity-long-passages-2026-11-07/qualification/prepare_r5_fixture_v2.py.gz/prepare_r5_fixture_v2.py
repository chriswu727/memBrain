import hashlib
import json
import os
from pathlib import Path

import psycopg
from psycopg import sql

from membrain import desktop, embedded_database
from membrain.backup_transport import stream_process
from membrain.build_identity import BUILD_ID
from membrain.local_profile import load_profile

root = Path(__file__).parent
profile = load_profile(Path('/Users/yichen/tmp/membrain-xml-integration-20261105/performance/perf-recall-cache-installation'))
private = root / 'private-r5-snapshot-v2'
private.mkdir(mode=0o700)
assert private.stat().st_mode & 0o777 == 0o700
report = {'build_id': BUILD_ID, 'completed': False, 'snapshot_private': True,
          'purpose': 'Preserve complete schema025 synthetic fixture before additive026 upgrade; every existing nonmigration table must retain identical row counts and order-independent sums of per-row SHA256; stream256 rows at a time and compress the complete private dump.'}


def snapshot():
    result = {}
    with psycopg.connect(profile.migration_database_url) as conn:
        conn.execute('SET TRANSACTION READ ONLY')
        tables = conn.execute("SELECT tablename FROM pg_tables WHERE schemaname='public' AND tablename LIKE 'memory_%' ORDER BY tablename").fetchall()
        for (name,) in tables:
            count, total = 0, 0
            with conn.cursor(name='fixture_rows') as cursor:
                cursor.itersize = 256
                cursor.execute(sql.SQL("SELECT sha256(convert_to(row_to_json(t)::text,'UTF8')) FROM {} t")
                               .format(sql.Identifier(name)))
                for (value,) in cursor:
                    count += 1
                    total = (total + int.from_bytes(value, 'big')) % 2**256
            result[name] = {'rows': count, 'sum_sha256': f'{total:064x}'}
            print(name, count, flush=True)
        migrations = [row[0] for row in conn.execute('SELECT name FROM memory_migrations ORDER BY name')]
    return result, migrations


assert not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
try:
    embedded_database.start(profile)
    before, migrations = snapshot()
    assert migrations[-1].startswith('025_')
    assert before['memory_embeddings']['rows'] == 0
    report['before'] = before
    report['migrations_before'] = migrations
    command, environment = embedded_database.client_command(profile, 'pg_dump', '--username=postgres',
        '--dbname=agent_memory', '--no-owner', '--no-acl', '--format=custom', '--compress=6')
    report['dump'] = stream_process(command, environment, private / 'schema025.dump', write=True,
                                    max_bytes=1024**3, timeout_seconds=600)
    assert (private / 'schema025.dump').stat().st_mode & 0o777 == 0o600
    (private / 'profile.json').write_bytes((profile.directory / 'profile.json').read_bytes())
    os.chmod(private / 'profile.json', 0o600)
    (root / 'r5-fixture-upgrade-v2.json').write_text(json.dumps(report, indent=2)+'\n')
    desktop._prepare_database(profile)
    after, migrations = snapshot()
    report['after'] = after
    report['migrations_after'] = migrations
    assert migrations[-1] == '026_embedding_passages.sql'
    assert {key: value for key, value in before.items() if key != 'memory_migrations'} == {
        key: after[key] for key in before if key != 'memory_migrations'}
    assert after['memory_embedding_passages']['rows'] == 0
    report['completed'] = True
finally:
    embedded_database.stop(load_profile(profile.directory))
    report['all_ports_closed'] = not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
    (root / 'r5-fixture-upgrade-v2.json').write_text(json.dumps(report, indent=2)+'\n')
    assert report['all_ports_closed']
print(json.dumps({'completed': report['completed'], 'existing_tables_unchanged': len(before)-1,
                  'dump_bytes': report['dump']['size'], 'all_ports_closed': report['all_ports_closed']}))
