import gzip,hashlib,json
from pathlib import Path
root=Path(__file__).parent
repo=Path('/Users/yichen/tmp/membrain-recall-trace-storage-20261107')
target=repo/'evaluations/evidence/maturity-long-passages-2026-11-07'
manifest=json.loads((target/'manifest.json').read_text())
names=['http_long_tail.py','http-long-tail.json','http-long-tail.log','visual-summary.json','summarize-visual.py','prepare_r5_fixture.py','r5-fixture-upgrade.json','r5-fixture-upgrade.log','prepare_r5_fixture_v2.py','r5-fixture-upgrade-v2.json','r5-fixture-upgrade-v2.log','prepare_r5_fixture_v3.py','r5-fixture-upgrade-v3.json','r5-fixture-upgrade-v3.log','cleanup-old-installations.json','cleanup-previous-installations.json','prepare_semantic_1000.py','prepare_semantic_10000.py','semantic-1000-upgrade.json','semantic-10000-upgrade.json','semantic-1000-upgrade.log','semantic-10000-upgrade.log','semantic_host.py','semantic-host.log','semantic-host/report.json','archive_qualification.py']
files=[('qualification/'+name,root/name) for name in names]
for directory in ['visual','ci']:
    files.extend(('qualification/'+str(p.relative_to(root)),p) for p in (root/directory).rglob('*') if p.is_file() and p.suffix in ('.py','.json','.log','.png','.txt'))
profiles=list((root/'install-final').rglob('profile.json'))
profiles += [Path('/Users/yichen/tmp')/directory/'installation/profile.json' for directory in ['membrain-semantic-balance-1000-20261107','membrain-semantic-scale-20261107']]
profiles += [Path('/Users/yichen/tmp/membrain-xml-integration-20261105/performance/perf-recall-cache-installation/profile.json')]
secrets=set()
for p in profiles:
    data=json.loads(p.read_text())
    for key in ('api_key','admin_password','app_password'):
        if data.get(key): secrets.add(data[key].encode())
old={entry['path'] for entry in manifest['files']}
for name,p in files:
    data=p.read_bytes()
    assert not any(secret in data for secret in secrets),name
    out=target/(name if p.suffix=='.png' else name+'.gz')
    assert str(out.relative_to(target)) not in old
    out.parent.mkdir(parents=True,exist_ok=True)
    payload=data if p.suffix=='.png' else gzip.compress(data,mtime=0)
    out.write_bytes(payload)
    manifest['files'].append({'path':str(out.relative_to(target)),'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest(),'original_bytes':len(data),'original_sha256':hashlib.sha256(data).hexdigest()})
for entry in manifest['files']:
    payload=(target/entry['path']).read_bytes()
    raw=gzip.decompress(payload) if entry['path'].endswith('.gz') else payload
    if 'original_sha256' in entry:
        assert hashlib.sha256(payload).hexdigest()==entry['sha256']
        assert hashlib.sha256(raw).hexdigest()==entry['original_sha256']
    else:
        assert hashlib.sha256(raw).hexdigest()==entry['sha256']
        assert len(raw)==entry['bytes']
manifest['qualification_privacy_scan']={'owned_credential_values':len(secrets),'matches':0,'private_database_dumps_and_profiles_excluded':True}
manifest['qualification_scope']='Exact installed3b HTTP long-tail, full R5, same-source public1k/10k host replay and native5platform/47summaries. Both interrupted fixture preparation attempts preserved. Corpus dumps stay private and exclude operational history; not product recovery bundles. No new behavioral acceptance.'
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print({'added':len(files),'total':len(manifest['files']),'owned_credentials_checked':len(secrets),'matches':0})
