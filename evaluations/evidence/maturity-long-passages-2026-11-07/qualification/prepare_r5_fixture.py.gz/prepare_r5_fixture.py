import hashlib
import json
import os
from pathlib import Path

import psycopg
from psycopg import sql

from membrain import desktop, embedded_database
from membrain.backup_transport import database_stream
from membrain.build_identity import BUILD_ID
from membrain.local_profile import load_profile

root = Path(__file__).parent
profile = load_profile(Path('/Users/yichen/tmp/membrain-xml-integration-20261105/performance/perf-recall-cache-installation'))
private = root / 'private-r5-snapshot'
private.mkdir(mode=0o700)
assert private.stat().st_mode & 0o777 == 0o700
report = {'build_id': BUILD_ID, 'completed': False, 'snapshot_private': True,
          'purpose': 'Preserve complete schema025 synthetic fixture before additive026 upgrade; every existing nonmigration table must retain identical row hashes.'}


def snapshot():
    result = {}
    with psycopg.connect(profile.migration_database_url) as conn:
        conn.execute('SET TRANSACTION READ ONLY')
        tables = conn.execute("SELECT tablename FROM pg_tables WHERE schemaname='public' AND tablename LIKE 'memory_%' ORDER BY tablename").fetchall()
        for (name,) in tables:
            hashes = sorted(hashlib.sha256(row[0].encode()).hexdigest() for row in conn.execute(
                sql.SQL('SELECT row_to_json(t)::text FROM {} t').format(sql.Identifier(name))))
            result[name] = {'rows': len(hashes), 'sha256': hashlib.sha256('\n'.join(hashes).encode()).hexdigest()}
        migrations = [row[0] for row in conn.execute('SELECT name FROM memory_migrations ORDER BY name')]
    return result, migrations


assert not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
try:
    embedded_database.start(profile)
    before, migrations = snapshot()
    assert migrations[-1].startswith('025_')
    assert before['memory_embeddings']['rows'] == 0
    report['before'] = before
    report['migrations_before'] = migrations
    report['dump'] = database_stream(profile, private / 'schema025.dump', max_bytes=1024**3, timeout_seconds=120)
    assert (private / 'schema025.dump').stat().st_mode & 0o777 == 0o600
    (private / 'profile.json').write_bytes((profile.directory / 'profile.json').read_bytes())
    os.chmod(private / 'profile.json', 0o600)
    (root / 'r5-fixture-upgrade.json').write_text(json.dumps(report, indent=2)+'\n')
    desktop._prepare_database(profile)
    after, migrations = snapshot()
    report['after'] = after
    report['migrations_after'] = migrations
    assert migrations[-1] == '026_embedding_passages.sql'
    assert {key: value for key, value in before.items() if key != 'memory_migrations'} == {
        key: after[key] for key in before if key != 'memory_migrations'}
    assert after['memory_embedding_passages']['rows'] == 0
    report['completed'] = True
finally:
    embedded_database.stop(load_profile(profile.directory))
    report['all_ports_closed'] = not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
    (root / 'r5-fixture-upgrade.json').write_text(json.dumps(report, indent=2)+'\n')
    assert report['all_ports_closed']
print(json.dumps({'completed': report['completed'], 'existing_tables_unchanged': len(before)-1,
                  'dump_bytes': report['dump']['size'], 'all_ports_closed': report['all_ports_closed']}))
