import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time

import psycopg
from psycopg.rows import dict_row

import membrain
from membrain import desktop, host
from membrain.build_identity import BUILD_ID, SCHEMA_ID
from membrain.client import MemoryClient
from membrain.local_embeddings import FILES, installed, model_directory
from membrain.local_profile import ensure_profile, load_profile

ROOT = Path(__file__).parent
EXPECTED = '80dec3b1782ede0349ceafe436f481ed8fb7ea16957bd62f435c74cdd9fe011a'
assert BUILD_ID == EXPECTED
assert '/install-final/uv-tools/membrain-ai/' in membrain.__file__
for name in list(os.environ):
    if name.startswith(('MEMORY_', 'MEMBRAIN_')) or name.endswith(('_API_KEY', '_API_TOKEN')):
        del os.environ[name]
os.environ['PYTHON_DOTENV_DISABLED'] = '1'
os.environ['MEMBRAIN_SEMANTIC'] = '0'
source = installed(Path('/Users/yichen/tmp/membrain-neural-evidence-20261103/perf-topology-9bc9893-installation'))
assert source is not None
report = {'build_id': BUILD_ID, 'schema_id': SCHEMA_ID, 'actual_package': membrain.__file__,
          'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'completed': False, 'samples': [], 'paid_or_subscription_calls': 0}


def save():
    (ROOT / 'http-long-tail.json').write_text(json.dumps(report, indent=2)+'\n')


class TracedClient(MemoryClient):
    def recall(self, *args, **kwargs):
        self.response = super().recall(*args, **kwargs)
        return self.response

    def recall_windows(self, windows, query, **kwargs):
        self.window_request = windows
        self.window_response = super().recall_windows(windows, query, **kwargs)
        return self.window_response

    def trace_recall(self, ids, **kwargs):
        self.trace = ids
        return super().trace_recall(ids, **kwargs)


def wait_indexed(profile, event_id):
    deadline = time.monotonic() + 120
    while True:
        with psycopg.connect(profile.migration_database_url, row_factory=dict_row) as conn:
            row = conn.execute('SELECT count(DISTINCT v.memory_id) AS parents,count(p.passage_index) AS passages '
                               'FROM memory_assertions a JOIN memory_embeddings v ON v.tenant_id=a.tenant_id '
                               'AND v.brain_id=a.brain_id AND v.memory_id=a.id AND v.memory_revision=a.revision '
                               'JOIN memory_embedding_passages p ON p.tenant_id=v.tenant_id AND p.brain_id=v.brain_id '
                               'AND p.memory_id=v.memory_id AND p.memory_revision=v.memory_revision '
                               'WHERE a.brain_id=%s AND %s=ANY(a.event_ids)', (profile.brain_id, event_id)).fetchone()
        if row['parents'] == 1 and row['passages'] > 1:
            return row
        if time.monotonic() > deadline:
            raise AssertionError({'index_not_ready': row, 'event': event_id})
        time.sleep(.2)


with tempfile.TemporaryDirectory(prefix='http-long-tail-', dir=ROOT) as temporary:
    directory = Path(temporary) / 'installation'
    profile = ensure_profile(directory, database_engine='embedded')
    try:
        target = model_directory(directory)
        for name, (expected, size) in FILES.items():
            original, copied = source / name, target / name
            assert original.stat().st_size == size and hashlib.sha256(original.read_bytes()).hexdigest() == expected
            copied.parent.mkdir(parents=True, exist_ok=True)
            subprocess.run(['cp', '-c', str(original), str(copied)], check=True)
            assert not copied.is_symlink() and hashlib.sha256(copied.read_bytes()).hexdigest() == expected
        started = desktop.start(directory)
        assert started['ready'] and started['build_id'] == BUILD_ID
        profile = load_profile(directory)
        with TracedClient(profile.base_url, profile.api_key, profile.brain_id, timeout=30, trust_env=False) as client:
            for phase, repeat in enumerate((70, 500, 850), 1):
                text = 'I reviewed ordinary office receipts and sorted supplies ' * repeat + 'and my passport is in the blue kitchen drawer'
                observed = client.observe(text, conversation_id=f'original-{repeat}', branch_id='main',
                                          source_event_key=f'long-{repeat}', interpretation_hint='real_world_report')
                event = observed['result']['accepted_event_ids'][0]
                counts = wait_indexed(profile, event)
                start = time.perf_counter()
                context = host.recall_context(client, 'Where do I keep my passport?', current_conversation='new', boundaries=[])
                sample = {'characters': len(text), 'event': event, 'index_counts': counts,
                          'elapsed_seconds': time.perf_counter()-start, 'response': client.response,
                          'window_request': client.window_request, 'window_response': client.window_response,
                          'context': context, 'trace': client.trace}
                report['samples'].append(sample)
                save()
                assert 'passport is in the blue kitchen drawer' in (context or '') and event in client.trace
                assert len(context) <= host.CONTEXT_CHARACTERS
                client.forget([event], kind='events', mode='erase_content', expected_scope_generation=phase)
                assert client.recall_windows(sample['window_request'], 'Where do I keep my passport?')['items'] == []
            text = 'my confidential diagnosis ' + 'ordinary office paperwork ' * 850
            text += 'and my passport is in the blue kitchen drawer'
            observed = client.observe(text, conversation_id='private-source', branch_id='main',
                                      source_event_key='privacy', interpretation_hint='real_world_report')
            event = observed['result']['accepted_event_ids'][0]
            wait_indexed(profile, event)
            context = host.recall_context(client, 'Where do I keep my passport?', current_conversation='new', boundaries=[])
            assert 'passport is in the blue kitchen drawer' in context
            window_request = client.window_request
            assert all('diagnosis' not in item['text'] for item in client.window_response['items'])
            client.add_boundary('diagnosis')
            blocked = client.recall_windows(window_request, 'Where do I keep my passport?')
            assert blocked['items'] == []
            assert host.recall_context(client, 'Where do I keep my passport?', boundaries=[]) is None
            assert client.trace == []
            report['privacy_outside_excerpt'] = {'blocked_window': blocked, 'empty_final_context': True,
                                               'empty_trace': True, 'source_characters': len(text)}
            report['completed'] = True
    finally:
        profile = load_profile(directory)
        if desktop._port_open(profile.api_port) or desktop._port_open(profile.database_port):
            desktop.stop(directory)
        report['all_ports_closed'] = not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
        save()
        assert report['all_ports_closed']
report['temporary_profile_removed'] = not directory.exists()
save()
print(json.dumps({'completed': report['completed'], 'lengths': [x['characters'] for x in report['samples']],
                  'all_ports_closed': report['all_ports_closed'], 'temporary_profile_removed': report['temporary_profile_removed']}))
