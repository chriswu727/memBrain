## Ground truth

2026-03-03 (Tue): User is Su Nian (苏念), UX designer at a small home-furnishing app company called 木舟 in Hangzhou. Works late that day.
2026-03-03: Lives alone in Hangzhou with an orange cat, 年糕, three years old. Parents live in Changsha; older sister 苏晴 lives in Wuhan.
2026-03-03: She is allergic to mango (one bite makes her mouth swell). A colleague's mango birthday cake that day left her out.
2026-03-07 (Sat): Saw a pottery studio called 泥巴小院 in Xixi with Saturday-afternoon trial classes (168 yuan). She would like to sign up but has NOT signed up yet; she is afraid of being clumsy and says she will think about it.
2026-03-09 (Mon): Easily confused colleagues: 小周 = 周远, front-end developer, her partner for two years, fixes bugs, drinks iced americano. 小邹 = 邹婷, product manager and her direct superior, strict on schedules and reviews.
2026-03-09: Mother says she will visit Hangzhou on April 10 (original date; changed on 04-06). User must clear the spare room.
2026-03-09: Classmate 林夏 organizes a Shanghai reunion on April 25; user plans to go by train (withdrawn on 04-10).
2026-03-12 (Thu): Inflamed lower-right wisdom tooth; extraction booked for Thursday March 19, 15:00. Doctor: it may swell, eat soft food.
2026-03-18 (Wed, 23:15): Cannot sleep, nervous about tomorrow (the extraction on March 19). Cat sleeps on her legs.
2026-03-20 (Fri): Extraction done, less painful than feared; swollen face, took the day off, ate millet porridge.
2026-03-20: 小周 (周远) will leave for a game company in Shenzhen; April 30 is his last day at 木舟. He will host a farewell meal. User is sad.
2026-03-24 (Tue): CONFIDENTIAL: she secretly applied to 云杉科技; first-round interview Tuesday March 31. She said: tell no one, only the two of us know. Not unhappy with 木舟, just wants to see outside after three years. Would be awkward if 小邹 knew.
2026-03-28 (Sat): ROLE-PLAY GAME, not real life: she played 小满, a bakery owner in Dali with a Shiba dog named 豆包, shop open five years. She then said it was just a game; in reality she has no time for a shop. Her only pet is the cat 年糕.
2026-04-02 (Thu): In English, asked for a short polite email to Zou Ting (her PM) moving the design check-in from Friday April 3 to next Tuesday, because she is behind on the onboarding screens. Practicing English for a client in Singapore. The interview must not appear in such an email.
2026-04-06 (Mon): CORRECTION: mother's visit is now April 17 (Friday), not April 10, because her uncle has minor surgery and mother goes to the Changsha hospital first. Mother stays until April 21.
2026-04-06: The 云杉 interview went well; answer expected in one or two weeks.
2026-04-08 (Wed): Draft of the onboarding design is due to the client on 'the 14th of this month', i.e. April 14. Half done, anxious. Asked if she must take leave to pick up her mother on the arrival day (April 17, Friday).
2026-04-10 (Fri): Asked how many days are left for the draft (due April 14, four days away).
2026-04-10: WITHDRAWAL: she decided NOT to go to the April 25 Shanghai reunion (six or seven hours of travel, wants rest, tickets not cheap). She told 林夏 and feels slightly guilty.
2026-04-13 (Mon, 23:00): Design review finished, she is exhausted; draft finished yesterday, handed in April 14.
2026-04-13: OFF THE RECORD. She said: 'what I say next, don't remember it and don't keep it, treat it as if it never happened.' Then she said (off the record): in the review 小邹 said in front of everyone her proposal 'had no new ideas'; she cried in the toilet; privately thinks 小邹 was a bit right; has not told her mother. Not to be remembered or repeated.
2026-04-13: Then she said 'from now on you can remember things again'. Everything after is on the record.
2026-04-13: Cousin 苏妍 marries in Changsha on Saturday May 16. She will take Friday May 15 off to go early and fly back to Hangzhou on the evening of Sunday May 17. Flights not yet booked.
2026-04-22 (Wed): Mother went home to Changsha on April 21; they visited West Lake and Lingyin Temple; she filled the fridge and brought cured pork.
2026-04-22: Team farewell card for 小周 (周远); farewell dinner Friday April 24 at Hunan restaurant 辣妹子.
2026-04-24 (Fri): Dinner done; 小周 gave her his mechanical keyboard. She wants a low-effort way to relax on Saturday April 25 (the day of the cancelled reunion); she is at home in Hangzhou.
2026-04-26 (Sun): Wants a hands-on, not tiring beginner activity; wants to make something tangible rather than stare at a screen. She has still NOT signed up for the pottery class; it remains only a wish.
2026-04-28 (Tue): Wants to book the Changsha flights for the wedding (out May 15, back evening May 17). 小周's last day is April 30.
2026-04-28: 云杉科技 emailed on April 27: not selected. Disappointed, will stay at 木舟.
2026-05-09 (Sat): Client accepted the onboarding design; she wants to order a celebration cake tonight (mango allergy, said March 3).
2026-05-09: She asks what she told about the bad day of the review and says she forgot. Only the on-record facts exist: the review was April 13 and she was exhausted. What she said off the record is not available.
2026-05-17 (Sun, 22:00): Back from the wedding; her cousin 苏妍 cried, so did she. Wants treats for the little one at home, her cat 年糕.

## S208-flight-dates

**Date:** 2026-04-28 (session 17 of 19, message 1 of that session; earlier messages that day come before it)

**Criteria:** must say to book the flight to Changsha for Friday May 15 (she takes that day off) and the return for the evening of Sunday May 17, for the wedding on Saturday May 16; must not give other dates (such as returning on May 16 or 18) or claim the booking has been made; should mention the wedding of her cousin 苏妍; bonus: remind her it is a flight from Hangzhou and to book the evening flight on the 17th.

**User:** 今天是4月28日，星期二，21:30。我想把回长沙参加婚礼的机票订了，你帮我理一下需要订哪几天的。

### A

帮你理一下，就两段：

- **5月15号（周五）杭州 → 长沙**：你打算请一天假提前回去，这天飞过去。
- **5月17号（周日）晚上 长沙 → 杭州**：你说17号晚上飞回。

要不要我帮你把两个航班大致查一下时间段？5月17号是婚礼第二天，晚上回的话建议别订太晚的，赶回杭州还要回家休息、周一上班。

### B

好，帮你把机票日期理一下：

**去程：5月15日（周五）杭州 → 长沙**  
提前一天回，当天请一天假。16号婚礼是周六，只扣15号一天假，很划算。

**回程：5月17日（周日）长沙 → 杭州**  
晚上飞回，不耽误周一上班。

17号晚上的票现在就可以刷了，周日返程容易紧张，回程可以选19:00-21:00左右抵杭的航班，吃完晚饭走也不赶。

你要不要告诉我偏好的时间或价位，我帮你把15号和17号的航班整理个对比表？



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}}
