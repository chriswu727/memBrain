# Assignment

- Case prefix: `S2` (case ids `S201-<slug>` to `S211-<slug>`).
- Main language: Chinese.
- Second language: English, used in exactly one session (its first message uses the English date form).
- Size: exactly 11 cases and 60 to 66 user messages, as the brief says.
