# Assignment

- Case prefix: `S1` (case ids `S101-<slug>` to `S111-<slug>`).
- Main language: English.
- Second language: German, used in exactly one session (its first message uses the German date form).
- Size: exactly 11 cases and 60 to 66 user messages, as the brief says.
