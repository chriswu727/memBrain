#!/usr/bin/env python3
"""Blind-scoring reviewer sessions for the seventh maturity attempt (maturity-20261116a), R4 unit.

Usage: python3 -I sessions.py JOBS.json
JOBS.json is a list of jobs {"role", "key", "item", "inputs": {"<name in session dir>": "<source path>"}, "dest"}.
Runs up to four sessions at a time. Each session: a new empty directory under SESSION_ROOT (named by number only),
the role's instruction file and the job's inputs copied in by path, the kit's exact claude argv (model sonnet) with
the role's fixed prompt, only the eight kept environment variables, stdout/stderr to a log the operator never opens.
Afterwards the output file (if any) is moved to "dest" (never overwriting), its sha256 recorded, and the session
directory emptied without being opened. Writes one JSON line per session to sessions.jsonl. Prints nothing from
any session, only numbers, exit codes and hashes.
"""
import concurrent.futures
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
CLONE = Path("/home/yichen/.local/state/membrain-setup/runs/r4-attempt7/clone")
PRIV = CLONE / "evaluations/.maturity-heldout-20261116a"
SESSION_ROOT = Path("/home/yichen/.local/state/acceptance-sessions/20261116a-review")
LOGS = PRIV / "logs/scoring"
REVIEW_DOCS = CLONE / "evaluations/acceptance-review"
KIT = CLONE / "evaluations/acceptance-kit/session-commands.json"
ALLOWED = PRIV / "control/allowed-models.json"
MODEL = "sonnet"
KEPT = ("PATH", "HOME", "USER", "LOGNAME", "LANG", "LC_ALL", "TERM", "TMPDIR")
TIMEOUT = 3300
PARALLEL = 4

ROLES = {
    "first": ("first.md", "verdicts.json",
              "Read first.md in this directory and do what it says with the sheet file sheet.md in this directory. "
              "Write verdicts.json in this directory. Do not read, list or search anything outside this directory."),
    "second": ("recheck.md", "recheck.json",
               "Read recheck.md in this directory and do what it says with the case file case.md in this directory. "
               "Write recheck.json in this directory. Do not read, list or search anything outside this directory."),
    "r5": ("assistant-claims.md", "answer.json",
           "Read assistant-claims.md in this directory and do what it says with the file input.md in this directory. "
           "Write answer.json in this directory. Do not read, list or search anything outside this directory."),
    "resolution": ("resolve.md", "resolution.json",
                   "Read resolve.md in this directory and do what it says with the files listed in files.txt in this "
                   "directory. Write resolution.json in this directory. Do not read, list or search anything outside "
                   "this directory."),
    "attribution": ("attribute.md", "attribution.json",
                    "Read attribute.md in this directory and do what it says with the file input.md in this "
                    "directory. Write attribution.json in this directory. Do not read, list or search anything "
                    "outside this directory."),
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def new_dir() -> tuple[int, Path]:
    number = 1 + len([p for p in SESSION_ROOT.iterdir() if p.name.startswith("s")])
    while True:
        workdir = SESSION_ROOT / f"s{number:03d}"
        try:
            workdir.mkdir(mode=0o700)
            return number, workdir
        except FileExistsError:
            number += 1


def run(job: dict) -> dict:
    role = job["role"]
    instructions, output_name, prompt = ROLES[role]
    dest = Path(job["dest"])
    if dest.exists():
        return {"role": role, "key": job["key"], "item": job["item"], "refused": "destination exists"}
    number, workdir = new_dir()
    shutil.copyfile(REVIEW_DOCS / instructions, workdir / instructions)
    for name, source in job["inputs"].items():
        target = workdir / name
        target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    template = json.loads(KIT.read_text())["claude"]["argv"]
    argv = [part.format(prompt=prompt, model=MODEL, workdir=str(workdir)) for part in template]
    environment = {name: os.environ[name] for name in KEPT if name in os.environ}
    log = LOGS / f"s{number:03d}.log"
    started = now()
    with log.open("ab") as out:
        try:
            done = subprocess.run(argv, cwd=workdir, env=environment, stdin=subprocess.DEVNULL, stdout=out,
                                  stderr=subprocess.STDOUT, timeout=TIMEOUT)
            code = done.returncode
        except subprocess.TimeoutExpired:
            code = "timeout"
        except OSError:
            code = "not_started"
    log.chmod(0o600)
    produced = workdir / output_name
    digest = None
    if produced.is_file():
        dest.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        shutil.move(str(produced), str(dest))
        dest.chmod(0o600)
        digest = sha256(dest)
    subprocess.run(["find", str(workdir), "-mindepth", "1", "-delete"], check=False)
    record = {"session": number, "role": role, "key": job["key"], "item": job["item"], "exit": code,
              "output_sha256": digest, "dest": str(dest), "started": started, "finished": now(),
              "prompt_sha256": hashlib.sha256(prompt.encode()).hexdigest(), "model": MODEL}
    with (HERE / "sessions.jsonl").open("a") as ledger:
        ledger.write(json.dumps(record) + "\n")
    return record


def main() -> int:
    if json.loads(ALLOWED.read_text()) != [MODEL]:
        print("refused: allowed models")
        return 2
    leaked = [name for name in os.environ if name.endswith("_API_KEY")]
    jobs = json.loads(Path(sys.argv[1]).read_text())
    with concurrent.futures.ThreadPoolExecutor(PARALLEL) as pool:
        for record in pool.map(run, jobs):
            print(json.dumps({k: record.get(k) for k in ("session", "role", "key", "item", "exit", "output_sha256",
                                                          "refused")}), flush=True)
    print(json.dumps({"done": len(jobs), "api_key_variables_in_operator_env": len(leaked)}), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
