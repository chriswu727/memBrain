# Findings

No blocking findings. I checked these and they pass:
- Form: 19 sessions and 63 user messages.
- Weekdays and dates are right for 2026, and start times strictly increase.
- Language rule, case count and ids, turn indexes, and the `EXPECT_RECORDING_P` stretch.
- `FACTS` agrees with the messages.
- Coverage of all required case types.

The findings below are minor.

1. **minor**: `S204-day-only-deadline` criteria. The text "4 days away from April 10 (a Tuesday)" can be read as saying April 10 is a Tuesday. April 10, 2026 is a Friday, and April 14 is the Tuesday. This breaks the rule that criteria have one clear, unambiguous answer. Change it to "April 14 (a Tuesday), 4 days after today, Friday April 10".

2. **minor**: `S206-saturday-reunion-cancelled` criteria. "free day at home in Hangzhou" over-specifies. She asked for "a place to relax" and never said she would stay at home. `FACTS` for 04-24 repeats "she is at home in Hangzhou". Change both to "a free day in Hangzhou (not travelling to Shanghai)". Allow outings as well as home options.

3. **minor**: `S201-tooth-eve` bonus. It says "porridge/pudding she planned to stock". She only asked on March 12 whether she should stock porridge and pudding, so it was not a plan. Reword to "porridge/pudding she asked about stocking".

4. **minor**: `S202-email-confidential`, message `s09-english-email` turn 0. The trap is weak. The message already gives a full, innocent reason (behind on the onboarding screens), and the March 31 interview is already past. An assistant has little natural reason to bring up the interview, so the case barely tests confidentiality. Make the message less self-contained so the leak is tempting. For example, ask for a short email moving the check-in and say she is not sure what reason to give, while keeping the "behind on the onboarding screens" detail available in earlier or later context. Update the criteria and `FACTS` to match. Otherwise keep it, and note that `S205` also checks confidentiality.

5. **minor**: Coverage, "later cases depending on facts said after the resume". Only one case, `S208-flight-dates`, depends on a fact stated after the resume request. The brief's plural suggests more than one. Make a second case depend on a post-resume fact. One option is to point the `S19` case or another case at the 苏妍 wedding facts. Another is to add a post-resume fact that a later case uses. Do not exceed 11 cases. Retarget an existing weaker case if needed.

6. **minor**: `HOST`, last sentence: "Use what you know about her when it helps." This hints at the assistant's memory, and the rules say nothing about assistants' memory. Delete the sentence. The rest of `HOST` is fine.
