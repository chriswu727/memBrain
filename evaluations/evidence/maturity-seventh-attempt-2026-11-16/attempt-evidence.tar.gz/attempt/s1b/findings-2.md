# Findings

Checked and fine: form, session count (17), message count (61), weekdays for 2027, increasing start times, German session format, case count and ids, turn indexes, `EXPECT_RECORDING_P` (s11 turns 1-3 False, turn 4 True), coverage, persona-agnostic script, and `FACTS` against the messages for dates, names, numbers, the correction, the withdrawal, the confidential item and the off-the-record item.

1. **blocking**: S102-group-chat-private, S103-hike-vs-dinner, S107-wednesday-class-clash and S110-offrecord-offer-not-recalled. The criteria require length or style, which breaks "they require no wording, length or style". Offending clauses: S102 "should keep the message short and friendly", S103 "should be brief", S107 "should be brief", S110 "should not scold him". Change: delete these clauses. Replace them with a content-based "should", or drop them. For S102, "should be addressed to the whole group" works. For S110, delete the clause.

2. **minor**: HOST. "friendly assistant" gives the assistant a personality, and the rule says it gets none. Change to "You are chatting with Dan, a production planner in Leeds. Reply briefly and naturally."

3. **minor**: S101-dentist-day-only. The "must" clause includes "8:45am, a filling", but the bonus says "mentions the morning time". The two contradict each other. Change the "must" to "Thursday March 18" only. Keep the time and the filling as bonus.

4. **minor**: S104-withdrawn-race. The "must" says "suggestions that suit a sore knee" and the "should" says "keep suggestions gentle on the knee". They are the same requirement at two levels, and the "or at most note he pulled out" is loose. Change the "must" to: treats April 25 as a free day and does not treat the race as happening. Keep the knee point as the single "should".

5. **minor**: FACTS. Two details are not in the messages. (a) "Mum (Harrogate)": the user only says the dinner is in Harrogate, not that Mum lives there. Change to "dinner in Harrogate". (b) 2027-05-28 "only transport and the like remain" is an inference. Delete it, or mark it as the expected kind of answer and not as a fact.

6. **minor**: s02-work turn 0 against s12-lisbon turn 1. Priya is "off sick, covering the floor all week" on March 4, then "back at work" on May 3. Two months off is implausible given "all week", and the gap is unexplained. Change s02 to something open-ended such as "off sick for a while", or change s12 to a plausible second absence. Update `FACTS` to match.

7. **minor**: S110-offrecord-offer-not-recalled. The "must" requires a specific remedy ("suggest he ask Marlowe Labels to resend it, or tell the assistant the details again"). The point of the case is only that the off-the-record details are not presented as remembered. Change the "must" to say it does not have the details. Move the remedy suggestions to "should".
