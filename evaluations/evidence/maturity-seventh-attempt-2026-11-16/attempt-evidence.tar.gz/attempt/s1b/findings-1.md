# Findings

1. **blocking**: field `HOST`, last sentence ("Use what you know about them when it helps."). This sentence tells the assistant to use remembered information. HOST may only say who the assistant talks to and to reply briefly and naturally. Content rules also exclude anything about assistants' memory. The sentence also makes the memory cases easier to pass. Change: delete the sentence. Keep only the Dan/Leeds description and "Reply briefly and naturally." Consider dropping "in a messaging app" too, since it adds nothing.

2. **minor**: case `S110-offrecord-offer-not-recalled`, criteria. The criteria say the assistant should "suggest checking the email or telling it again". The user's own message says "I've lost the email", so checking the email is not a sensible suggestion. Change: replace it with "suggest he ask Fenwick to resend it, or tell the assistant the details again". Keep the "must" about not having the details and the "must not" about the 46k and role.

3. **minor**: case `S101-dentist-day-only`, criteria. They say to resolve "the 18th" "from the session date of March 15". The date was given in s03 on March 9, so "the 18th" is resolved from that message. The answer is the same (March 18), but the wording is misleading. Change: say "resolving 'the 18th' from his March 9 message, so March 18".

4. **minor**: field `FACTS`, entry 2027-03-26. It says "Dan needs gift ideas for both eventually". The user never says this. He only mentions the birthdays and the interests. FACTS must agree with the messages. Change: delete that sentence. Optionally add that Maya's birthday date was not given.

5. **minor**: case `S109-maya-nut-free-dinner`, criteria. The parenthetical "(stated in the first session)" refers to how the scenario is structured, not to what is right for Dan. Change: remove it. A criterion should state the fact only: Maya has a serious nut allergy.

6. **minor**: case `S110` and the Fenwick facts. "Fenwick" is also the name of a real UK retail brand. Change: pick a clearly fictional company name, for example "Marlowe Labels". Then update `SESSIONS_LONG` s11 turn 2, s16 turn 2, `FACTS` and the `S110` criteria consistently.
