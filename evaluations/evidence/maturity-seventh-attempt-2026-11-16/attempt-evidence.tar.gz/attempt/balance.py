"""Print the provider balance as one JSON line: the HTTP status and the amounts only.

Read in-process (no curl); the key comes from DEEPSEEK_API_KEY in the environment and goes only into the
Authorization header. Nothing from the reply is printed except currency codes and amounts that look like numbers;
on any error only the exception's type is printed, never its text. Exit 0 on status 200, 1 otherwise.
"""
import json
import os
import re
import sys
import time

import httpx

AMOUNT = re.compile(r"^-?[0-9]{1,12}(\.[0-9]{1,6})?$")
CURRENCY = re.compile(r"^[A-Z]{3}$")
FIELDS = ("total_balance", "granted_balance", "topped_up_balance")


def stamp() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def main() -> int:
    try:
        reply = httpx.get("https://api.deepseek.com/user/balance",
                          headers={"Authorization": "Bearer " + os.environ["DEEPSEEK_API_KEY"]}, timeout=30)
        status = reply.status_code
        amounts = []
        available = None
        if status == 200:
            data = reply.json()
            available = data.get("is_available") if isinstance(data.get("is_available"), bool) else None
            for info in data.get("balance_infos") or []:
                if not isinstance(info, dict) or not CURRENCY.match(str(info.get("currency", ""))):
                    continue
                entry = {"currency": info["currency"]}
                for field in FIELDS:
                    value = str(info.get(field, ""))
                    entry[field] = value if AMOUNT.match(value) else None
                amounts.append(entry)
        print(json.dumps({"at_utc": stamp(), "status": status, "balances": amounts, "is_available": available}))
        return 0 if status == 200 else 1
    except Exception as error:  # noqa: BLE001 - the type only: an exception's text could carry a header
        print(json.dumps({"at_utc": stamp(), "error": type(error).__name__}))
        return 1


if __name__ == "__main__":
    sys.exit(main())
