import json
import socket
from pathlib import Path

import psycopg
from psycopg.rows import dict_row
from membrain import embedded_database, host, local_embeddings
from membrain.candidates import _CJK, CROSS_SCRIPT_CANDIDATES, _interleave
from membrain.local_profile import load_profile

root = Path(__file__).parent
baseline = json.loads(Path('/Users/yichen/tmp/membrain-semantic-scale-20261107/report.json').read_text())
profile = load_profile(Path('/Users/yichen/tmp/membrain-semantic-scale-20261107/installation'))
targets = {sample['case']: sample['target_event'] for sample in baseline['phases'][0]['samples']}
limit = min(128, max(4, host.recall_budget()['max_context_tokens'] // 512))
report = {'candidate_limit': limit, 'scan_limit': min(512, limit * 4), 'rows': [], 'completed': False}
try:
    embedded_database.start(profile)
    with local_embeddings.LocalEmbeddingProvider(local_embeddings.model_directory(profile.directory)) as provider:
        with psycopg.connect(profile.migration_database_url, row_factory=dict_row) as conn:
            conn.execute('SET TRANSACTION READ ONLY')
            for index in (0, 5, 6, 9, 11, 12, 16):
                query = baseline['cases'][index]['query']
                vector = provider.embed([query], purpose='query').vectors[0]
                rows = conn.execute(
                    'SELECT a.id,a.document,a.search_text,e.sequence,(v.embedding <=> %s::vector) AS distance '
                    'FROM memory_assertions a JOIN memory_embeddings v ON '
                    'v.tenant_id=a.tenant_id AND v.owner_id=a.owner_id AND v.brain_id=a.brain_id '
                    'AND v.memory_id=a.id AND v.memory_revision=a.revision '
                    'JOIN memory_events e ON e.tenant_id=a.tenant_id AND e.brain_id=a.brain_id AND e.id=ANY(a.event_ids) '
                    'WHERE a.brain_id=%s AND a.is_current AND NOT a.invalidated AND NOT a.deleted '
                    'AND NOT a.suppressed AND e.is_current AND NOT e.deleted '
                    'ORDER BY distance,a.id', (str(list(vector)), profile.brain_id)).fetchall()
                for count in (1000, 10000):
                    ranked = [row for row in rows if row['sequence'] <= count]
                    target = next(row for row in ranked if any(ref['event_id'] == targets[index]
                                  for ref in row['document']['evidence_refs']))
                    other = [row for row in ranked if bool(_CJK.search(row['search_text'])) != bool(_CJK.search(query))]
                    primary = ranked[:report['scan_limit']]
                    original_ids = {row['id'] for row in primary}
                    extra = [row for row in other[:CROSS_SCRIPT_CANDIDATES] if row['id'] not in original_ids]
                    original = []
                    for position, row in enumerate(primary):
                        original.append(row)
                        if extra and (position + 1) % 3 == 0:
                            original.append(extra.pop(0))
                    original += extra
                    revised = _interleave(primary, other[:CROSS_SCRIPT_CANDIDATES])
                    def rank(pool):
                        return next((i + 1 for i, row in enumerate(pool) if row['id'] == target['id']), None)
                    report['rows'].append({'case': index, 'messages': count, 'query': query,
                                           'target': target['document']['statement'], 'distance': target['distance'],
                                           'global_rank': rank(ranked), 'other_script_rank': rank(other),
                                           'original_vector_rank': rank(original), 'revised_vector_rank': rank(revised),
                                           'nearest_other_script': [{'text': row['document']['statement'], 'distance': row['distance']}
                                                                    for row in other[:3]]})
    report['completed'] = True
finally:
    embedded_database.stop(profile)
    with socket.socket() as sock:
        report['database_port_closed'] = sock.connect_ex(('127.0.0.1', profile.database_port)) != 0
    (root / 'rank-diagnosis.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key != 'rows'}))
for row in report['rows']:
    print(json.dumps({key: value for key, value in row.items() if key not in ('target', 'query', 'nearest_other_script')}))
