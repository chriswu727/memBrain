import hashlib
import json
import math
import os
import socket
import statistics
import time
from pathlib import Path

for key in list(os.environ):
    if key.startswith(('MEMORY_', 'MEMBRAIN_', 'C5_')) or key.endswith(('_API_KEY', '_API_TOKEN')):
        del os.environ[key]
os.environ.update(MEMBRAIN_SEMANTIC='0', PYTHON_DOTENV_DISABLED='1')

from membrain import desktop, host
from membrain.build_identity import BUILD_ID
from membrain.client import MemoryClient
from membrain.local_profile import load_profile

root = Path(__file__).parent
repository = Path('/Users/yichen/tmp/membrain-semantic-balance-20261107')
baseline = json.loads(Path('/Users/yichen/tmp/membrain-semantic-scale-20261107/report.json').read_text())
assert baseline['completed'] and baseline['all_ports_closed'] and baseline['script_unchanged']
assert baseline['phases'][-1]['messages'] == 10000
original = [sample for sample in baseline['phases'][-1]['samples'] if sample['mode'] == 'semantic']
assert len(original) == 20
paths = [p for p in (repository / 'src').rglob('*') if p.is_file() and '__pycache__' not in p.parts]
hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
profile = load_profile(Path('/Users/yichen/tmp/membrain-semantic-scale-20261107/installation'))
report = {'build_id': BUILD_ID, 'baseline_build_id': baseline['build_id'], 'completed': False,
          'paid_provider_calls': 0, 'subscription_calls': 0, 'samples': [], 'source_sha256': hashes,
          'protocol': 'Same retained 10000-message synthetic corpus and 20 original multilingual queries, one semantic HTTP request per query. No new ingestion, changed queries, warmups, discarded samples or retries. Compare exact target source identities. This is an engineering regression replay, not independent held-out behavioral acceptance or a controlled latency speedup claim.'}

def save():
    (root / 'replay.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')

save()
try:
    for port in (profile.api_port, profile.database_port):
        with socket.socket() as sock:
            assert sock.connect_ex(('127.0.0.1', port)) != 0
    host.start(profile.directory)
    status = desktop.status(profile.directory)
    assert status['configuration_current'] and status['ready']
    report['service_configuration_matches_source'] = True
    with MemoryClient(profile.base_url, profile.api_key, profile.brain_id, timeout=120) as client:
        assert client._request('GET', 'v1/local/memory-status')['semantic_recall'] == 'ready'
        for sample in original:
            began = time.perf_counter()
            response = client.recall(sample['query'], conversation_id='synthetic-query', branch_id='main',
                                     budget=host.recall_budget())
            elapsed = round((time.perf_counter() - began) * 1000, 3)
            assert response['outcome'] == 'completed'
            matches = [item for item in response['result']['items']
                       if any(ref.get('event_id') == sample['target_event']
                              for ref in item['memory'].get('evidence_refs', []))]
            report['samples'].append({'case': sample['case'], 'query': sample['query'],
                                      'target_event': sample['target_event'], 'baseline_hit': sample['hit'],
                                      'hit': bool(matches), 'baseline_ms': sample['ms'], 'ms': elapsed,
                                      'response': response})
            save()
        values = sorted(row['ms'] for row in report['samples'])
        report['summary'] = {'queries': len(values), 'baseline_hits': sum(s['hit'] for s in original),
                             'hits': sum(s['hit'] for s in report['samples']), 'median_ms': statistics.median(values),
                             'p95_ms': values[math.ceil(len(values) * .95) - 1], 'max_ms': max(values)}
        report['completed'] = True
except Exception as error:
    report['failure'] = {'type': type(error).__name__, 'message': str(error)[:500]}
finally:
    try:
        desktop.stop(profile.directory)
    except Exception as error:
        report['cleanup_failure'] = type(error).__name__
    ports = {}
    for port in (profile.api_port, profile.database_port):
        with socket.socket() as sock:
            ports[str(port)] = sock.connect_ex(('127.0.0.1', port)) != 0
    report['ports'] = ports
    report['all_ports_closed'] = all(ports.values())
    report['source_unchanged'] = all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == value for p, value in hashes.items())
    save()
print(json.dumps({key: value for key, value in report.items() if key not in ('samples', 'source_sha256')}))
raise SystemExit(0 if report['completed'] and report['all_ports_closed'] and report['source_unchanged'] else 1)
