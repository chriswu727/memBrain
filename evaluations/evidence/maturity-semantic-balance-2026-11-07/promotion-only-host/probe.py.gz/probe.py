import hashlib
import json
import math
import os
import socket
import statistics
import time
from pathlib import Path

for key in list(os.environ):
    if key.startswith(('MEMORY_', 'MEMBRAIN_', 'C5_')) or key.endswith(('_API_KEY', '_API_TOKEN')):
        del os.environ[key]
os.environ.update(MEMBRAIN_SEMANTIC='0', PYTHON_DOTENV_DISABLED='1')

from membrain import desktop, host
from membrain.build_identity import BUILD_ID
from membrain.client import MemoryClient
from membrain.local_profile import load_profile

root = Path(__file__).parent
repository = Path('/Users/yichen/tmp/membrain-semantic-balance-20261107')
hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (repository / 'src').rglob('*')
          if p.is_file() and '__pycache__' not in p.parts}
report = {'runtime_pin': 'bd10c4e504cffa034634ef1d43a35841c397451d', 'build_id': BUILD_ID,
          'source_sha256': hashes, 'paid_provider_calls': 0, 'subscription_calls': 0, 'completed': False,
          'protocol': 'Actual host.recall_context over retained public 1000/10000 corpora. Same 20 original queries, one call each, no changed budgets, warmups, retries or generation. Record API target inclusion, host source selection, actual returned trace and final context inclusion separately. Each corpus starts and stops its own service; preserve every miss and cold latency.', 'phases': []}
assert BUILD_ID == 'b58d3e3c362f17da7c311625ae0217fbe56c0032c6a35eb8b73d0c132666198d'

def save():
    (root / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')

class RecordingClient:
    def __init__(self, client):
        self.client = client
        self.response = None
        self.trace = None

    def __getattr__(self, name):
        return getattr(self.client, name)

    def recall(self, *args, **kwargs):
        self.response = self.client.recall(*args, **kwargs)
        return self.response

    def trace_recall(self, events):
        self.trace = list(events)
        return self.client.trace_recall(events)

save()
try:
    for count, directory in (
        (1000, Path('/Users/yichen/tmp/membrain-semantic-balance-1000-20261107')),
        (10000, Path('/Users/yichen/tmp/membrain-semantic-scale-20261107')),
    ):
        original = json.loads((directory / 'report.json').read_text())
        assert original['completed'] and original['all_ports_closed']
        samples = [s for p in original['phases'] if p['messages'] == count
                   for s in p['samples'] if s['mode'] == 'semantic']
        assert len(samples) == 20
        profile = load_profile(directory / 'installation')
        phase = {'messages': count, 'samples': [], 'completed': False}
        report['phases'].append(phase)
        try:
            for port in (profile.api_port, profile.database_port):
                with socket.socket() as sock:
                    assert sock.connect_ex(('127.0.0.1', port)) != 0
            host.start(profile.directory)
            status = desktop.status(profile.directory)
            assert status['configuration_current'] and status['ready']
            with MemoryClient(profile.base_url, profile.api_key, profile.brain_id, timeout=120) as live:
                assert live._request('GET', 'v1/local/memory-status')['semantic_recall'] == 'ready'
                for sample in samples:
                    client = RecordingClient(live)
                    began = time.perf_counter()
                    context = host.recall_context(client, sample['query'], current_conversation='synthetic-query')
                    elapsed = round((time.perf_counter() - began) * 1000, 3)
                    target = sample['target_event']
                    items = client.response['result']['items']
                    api_hit = any(ref.get('event_id') == target for item in items
                                  for ref in item['memory'].get('evidence_refs', []))
                    source_ids = [event for event, _ in host._sources(client.response, 'synthetic-query')]
                    source_text = original['cases'][sample['case']]['source']
                    phase['samples'].append({'case': sample['case'], 'query': sample['query'], 'target_event': target,
                                              'api_hit': api_hit, 'source_filter_hit': target in source_ids,
                                              'trace_hit': target in (client.trace or []),
                                              'context_hit': source_text in (context or ''), 'ms': elapsed,
                                              'selected_source_ids': source_ids, 'trace': client.trace,
                                              'context': context, 'response': client.response})
                    save()
            values = sorted(sample['ms'] for sample in phase['samples'])
            phase['summary'] = {key: sum(s[key] for s in phase['samples'])
                                for key in ('api_hit', 'source_filter_hit', 'trace_hit', 'context_hit')}
            phase['summary'].update(queries=len(values), median_ms=statistics.median(values),
                                    p95_ms=values[math.ceil(len(values) * .95) - 1], max_ms=max(values))
            phase['completed'] = True
        finally:
            desktop.stop(profile.directory)
            phase['ports'] = {}
            for port in (profile.api_port, profile.database_port):
                with socket.socket() as sock:
                    phase['ports'][str(port)] = sock.connect_ex(('127.0.0.1', port)) != 0
            phase['all_ports_closed'] = all(phase['ports'].values())
            save()
        print(json.dumps({'messages': count, 'summary': phase.get('summary'), 'all_ports_closed': phase['all_ports_closed']}), flush=True)
    report['completed'] = True
except Exception as error:
    report['failure'] = {'type': type(error).__name__, 'message': str(error)[:500]}
finally:
    report['source_unchanged'] = all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == value for p, value in hashes.items())
    save()
raise SystemExit(0 if report['completed'] and report['source_unchanged']
                 and all(p['all_ports_closed'] for p in report['phases']) else 1)
