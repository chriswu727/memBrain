import hashlib
import json
import math
import os
import platform
import shutil
import socket
import statistics
import time
from pathlib import Path

for key in list(os.environ):
    if key.startswith(('MEMORY_', 'MEMBRAIN_', 'C5_')) or key.endswith(('_API_KEY', '_API_TOKEN')):
        del os.environ[key]
os.environ.update(MEMBRAIN_SEMANTIC='0', PYTHON_DOTENV_DISABLED='1')

import psycopg
from membrain import desktop, host, local_embeddings
from membrain.build_identity import BUILD_ID
from membrain.client import MemoryClient
from membrain.helpers import uid
from membrain.local_profile import ensure_profile, load_profile

ROOT = Path(__file__).parent
MODEL = Path('/Users/yichen/tmp/membrain-neural-evidence-20261103/perf-topology-9bc9893-installation/models/multilingual-e5-small-761b726dd34f')
CASES = [
    ('I do not eat meat or fish.', '给我推荐晚餐前，需要记住什么饮食限制？'),
    ('My sister is getting married in Lisbon in December.', 'Where and when is the family wedding taking place?'),
    ('猫毛会让我打喷嚏，所以家里不能养猫。', 'Which pet causes my allergy?'),
    ('My bicycle was stolen outside the library last Tuesday.', '我的两轮交通工具是在哪里丢的？'),
    ('我每周四晚上去游泳馆练自由泳。', 'When do I practise swimming?'),
    ('I am learning Portuguese because I plan to move to Porto.', '我为什么在学葡萄牙语？'),
    ('我的护照放在书桌最下面的抽屉里。', 'Where did I put my travel document?'),
    ('I prefer written instructions because phone calls make me anxious.', '我更希望别人用什么方式给我说明？'),
    ('我在十月十五日开始新的工作，第一天要早上九点到。', 'What is the starting date and arrival time for my new job?'),
    ('My favourite way to relax is tending the tomatoes on my balcony.', '我通常做什么来放松心情？'),
    ('我的笔记本电脑一插电，风扇就会很吵。', '¿Por qué hace ruido mi ordenador al cargar?'),
    ('I promised my grandfather that I would visit him every Sunday.', '我答应过爷爷多久去看他一次？'),
    ('我不喜欢别人突然来家里，来之前请先发消息。', 'What boundary did I set about unexpected visitors?'),
    ('I am saving money to buy a second-hand piano.', '我存钱是为了买什么乐器？'),
    ('我们把周六的野餐改到周日，因为天气预报说周六下雨。', 'Why did we move the picnic to a different day?'),
    ('My presentation is next Wednesday and I want to rehearse the night before.', '我打算什么时候练习演讲？'),
    ('我的钥匙串上挂着一个蓝色的小鲸鱼。', '¿Cómo puedo reconocer mi llavero?'),
    ('I stopped drinking coffee after lunch because it keeps me awake at night.', '为什么我下午不喝咖啡了？'),
    ('我更喜欢别人直接指出错误，不要绕着说。', 'How would I like people to give me corrective feedback?'),
    ('The emergency spare glasses are in the red box beside my bed.', '¿Dónde guardo las gafas de repuesto?'),
]
TEMPLATES = [
    'On {day} I sorted {n} printed invoices into the {color} office folder.',
    'I bought {n} apples at the {place} market and put them in a basket.',
    'The {color} parcel for the {place} workshop arrived on {day}.',
    'I spent {n} minutes reorganizing the bookshelf in the {place} room.',
    'I checked the receipt for {n} envelopes from the {place} stationery shop.',
    '我在{place}活动室整理了{n}张照片，放进{color}相册。',
    '我用了{n}分钟清理{place}走廊，随后把工具放回柜子。',
    '我给{place}图书角捐了{n}本杂志，收据放在{color}信封里。',
]

def corpus(count):
    positions = {round(i * 999 / 19): i for i in range(20)}
    rows = []
    for number in range(count):
        case = positions.get(number)
        text = CASES[case][0] if case is not None else TEMPLATES[number % len(TEMPLATES)].format(
            n=number + 1, day=('Monday', 'Tuesday', 'Friday')[number % 3],
            color=('blue', 'green', 'yellow', '紫色')[number % 4],
            place=('North', 'East', 'West', '中心', '河畔')[number % 5])
        rows.append({'number': number, 'case': case, 'text': text})
    return rows

def port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]

def summarize(rows):
    values = sorted(row['ms'] for row in rows)
    return {'n': len(rows), 'hits': sum(row['hit'] for row in rows),
            'median_ms': statistics.median(values), 'p95_ms': values[math.ceil(len(values) * .95) - 1],
            'max_ms': max(values)}

report = {
    'runtime_pin': '0c8ea88ad61e782ce03628195f8758fc395726b6', 'build_id': BUILD_ID,
    'platform': platform.platform(), 'paid_provider_calls': 0, 'subscription_calls': 0,
    'local_embedding_model': local_embeddings.SPACE.descriptor(), 'completed': False,
    'protocol': 'Fresh installed HTTP service, ordinary background indexing. 20 public bilingual source/query pairs interleaved through the first 1000 messages, then 9000 synthetic distractors. All sources are received user messages. At each size, wait for complete indexing and one stored vector per message; issue each query once in semantic and lexical-only modes with alternating order. Retain every response and timing, including cold query and misses. No warmups, retries, generation or semantic judge. Target hit means an exact source event reference is returned. Diagnostic corpus, not R4/C5, capacity certification or a speedup claim.',
    'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'corpus_sha256': hashlib.sha256(json.dumps(corpus(10000), ensure_ascii=False).encode()).hexdigest(),
    'cases': [{'source': text, 'query': query} for text, query in CASES], 'phases': [],
}
assert BUILD_ID == 'ccab88610a3fdabeb8f127a14b140c93d1a43e41d6c0c47f89c6b384d0fb4928'

def save():
    (ROOT / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')

profile = None
save()
try:
    assert not (ROOT / 'installation').exists(), 'A fresh diagnostic installation is required.'
    assert local_embeddings.runtime_available()
    profile = ensure_profile(ROOT / 'installation', database_engine='embedded', api_port=port(), database_port=port())
    assert profile.cognition is None
    for name, (checksum, size) in local_embeddings.FILES.items():
        source = MODEL / name
        assert source.stat().st_size == size and hashlib.sha256(source.read_bytes()).hexdigest() == checksum
        target = local_embeddings.model_directory(profile.directory) / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    host.start(profile.directory)
    profile = load_profile(profile.directory)
    with MemoryClient(profile.base_url, profile.api_key, profile.brain_id, timeout=120) as client:
        assert client._request('GET', 'v1/local/memory-status')['semantic_recall'] == 'ready'
        have, targets = 0, {}
        for count in (1000, 10000):
            phase = {'messages': count, 'observations': [], 'samples': []}
            report['phases'].append(phase)
            began = time.perf_counter()
            all_rows = corpus(count)
            for start in range(have, count, 250):
                rows = all_rows[start:min(start + 250, count)]
                events = [{'source_event_key': f'semantic-scale-{row["number"]}', 'source_revision': 1,
                           'producer_ref': 'public-semantic-scale', 'actor_ref': 'user', 'actor_role': 'user',
                           'event_kind': 'message', 'content': {'media_type': 'text/plain', 'text': row['text']},
                           'occurred_time': {'start': None, 'end': None, 'precision': 'unknown', 'basis': 'unknown'},
                           'interpretation_hint': 'real_world_report', 'delivery_state': 'received',
                           'parent_source_event_keys': []} for row in rows]
                result = client.action('observe', {'idempotency_key': uid(), 'events': events},
                                       conversation_id='synthetic-source', branch_id='main')
                assert result['outcome'] == 'completed'
                ids = result['result']['accepted_event_ids']
                assert len(ids) == len(rows)
                for row, event in zip(rows, ids, strict=True):
                    if row['case'] is not None:
                        targets[row['case']] = event
            phase['ingest_seconds'] = round(time.perf_counter() - began, 3)
            assert len(targets) == 20
            deadline, last_log = time.monotonic() + 1800, 0
            while True:
                state = client.dashboard()['status']
                with psycopg.connect(profile.migration_database_url) as conn:
                    conn.execute('SET TRANSACTION READ ONLY')
                    vectors = conn.execute('SELECT count(*) FROM memory_embeddings WHERE brain_id=%s',
                                           (profile.brain_id,)).fetchone()[0]
                snapshot = {key: state.get(key) for key in ('durable_sequence', 'indexed_sequence', 'index_lag', 'pending_jobs')}
                snapshot.update(vectors=vectors, elapsed_seconds=round(time.perf_counter() - began, 3))
                if time.monotonic() - last_log >= 10:
                    phase['observations'].append(snapshot)
                    save()
                    print(json.dumps({'messages': count, 'index': snapshot}), flush=True)
                    last_log = time.monotonic()
                if not state.get('pending_jobs') and not state.get('index_lag') and vectors >= count:
                    phase['settled'] = snapshot
                    break
                if time.monotonic() >= deadline:
                    raise TimeoutError('Background lexical and semantic indexing did not settle within 1800 seconds.')
                time.sleep(1)
            for index, (_, query) in enumerate(CASES):
                for mode in (('semantic', 'lexical') if index % 2 == 0 else ('lexical', 'semantic')):
                    began_query = time.perf_counter()
                    response = client.recall(query, conversation_id='synthetic-query', branch_id='main',
                                             budget=host.recall_budget(embeddings=int(mode == 'semantic')))
                    elapsed = round((time.perf_counter() - began_query) * 1000, 3)
                    assert response['outcome'] == 'completed'
                    items = response['result']['items']
                    matched = [item for item in items if any(ref.get('event_id') == targets[index]
                               for ref in item['memory'].get('evidence_refs', []))]
                    row = {'case': index, 'mode': mode, 'query': query, 'target_event': targets[index],
                           'hit': bool(matched), 'ms': elapsed, 'returned': len(items),
                           'vector_ranked_target': any(signal.get('method') == 'vector'
                               for item in matched for signal in item.get('rank_signals', [])), 'response': response}
                    phase['samples'].append(row)
                    save()
            phase['summaries'] = {mode: summarize([r for r in phase['samples'] if r['mode'] == mode])
                                  for mode in ('semantic', 'lexical')}
            have = count
            save()
            print(json.dumps({'messages': count, 'summaries': phase['summaries']}), flush=True)
    report['completed'] = True
except Exception as error:
    report['failure'] = {'type': type(error).__name__, 'message': str(error)[:500]}
finally:
    if profile:
        try:
            desktop.stop(profile.directory)
        except Exception as error:
            report['cleanup_failure'] = type(error).__name__
        report['ports'] = {}
        for value in (profile.api_port, profile.database_port):
            with socket.socket() as sock:
                report['ports'][str(value)] = sock.connect_ex(('127.0.0.1', value)) != 0
        report['all_ports_closed'] = all(report['ports'].values())
    report['script_unchanged'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest() == report['script_sha256']
    save()
raise SystemExit(0 if report['completed'] and report.get('all_ports_closed') and report['script_unchanged'] else 1)
