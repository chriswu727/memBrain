import hashlib
import json
import os
import shutil
import socket
import subprocess
from pathlib import Path

root = Path(__file__).parent
evidence = Path('/Users/yichen/tmp/membrain-extraction-write-20261107/evaluations/evidence/maturity-extraction-sources-2026-11-07')
manifest = json.loads((evidence / 'manifest.json').read_text())
retained = {item['original_sha256'] for item in manifest['files']}
processes = subprocess.check_output(['ps', '-axo', 'command'], text=True)
report = {'available_bytes_before': shutil.disk_usage(root).free, 'installations': []}
for base in (Path('/Users/yichen/tmp/membrain-extraction-source-delivery-20261107'),
             Path('/Users/yichen/tmp/membrain-extraction-final-delivery-20261107')):
    installation = base / 'install-final'
    assert str(installation) not in processes
    for receipt in (installation / 'results.json', base / 'installed-and-ports.json'):
        assert hashlib.sha256(receipt.read_bytes()).hexdigest() in retained, receipt
    profiles = []
    for path in installation.rglob('profile.json'):
        if any(part in ('site-packages', 'uv-cache') for part in path.parts):
            continue
        profile = json.loads(path.read_text())
        if not all(key in profile for key in ('api_port', 'database_port', 'installation_id')):
            continue
        ports = [profile[key] for key in ('api_port', 'database_port')]
        for port in ports:
            with socket.socket() as sock:
                assert sock.connect_ex(('127.0.0.1', port)) != 0, (path, port)
        profiles.append({'path': str(path.relative_to(installation)), 'closed_ports': ports})
    assert len(profiles) == 4, profiles
    removed = []
    for relative in ('uv-tools', 'home', 'restored', 'companion/uv-tools', 'companion/home', 'companion/restored'):
        path = installation / relative
        assert path.is_dir() and not path.is_symlink(), path
        allocated = sum(p.lstat().st_blocks * 512 for p in path.rglob('*') if not p.is_symlink())
        shutil.rmtree(path)
        assert not path.exists()
        removed.append({'path': str(path), 'allocated_bytes_before': allocated})
    report['installations'].append({'root': str(installation), 'profiles': profiles, 'removed': removed,
                                    'results_and_parity_receipts_retained': True})
report['available_bytes_after'] = shutil.disk_usage(root).free
(root / 'prior-install-cleanup.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'completed_installations_cleaned': len(report['installations']),
                  'available_bytes_before': report['available_bytes_before'],
                  'available_bytes_after': report['available_bytes_after']}))
