import gzip, hashlib, json, os, shutil, subprocess
from pathlib import Path
root=Path('evaluations/evidence/backend-recording-controls-2026-11-08')
tmp=Path('/private/tmp');prefix='membrain-controls-surface-'
manifest=json.loads((root/'local-manifest.json').read_text())
q=json.loads((root/'qualification-receipt.json').read_text())
files={x['path']:x for x in manifest['files']}
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=list(tmp.glob(prefix+'*'))
allowed_dirs={prefix+x for x in ('qualification','visual','visual-v1','native-audit')}
processes=subprocess.check_output(['ps','-eo','pid,command'],text=True).splitlines()
records=[]
for p in paths:
    assert not p.is_symlink(),p
    if p.is_dir():
        assert p.name in allowed_dirs,p
        assert not list(p.rglob('postmaster.pid')),p
        assert not any(str(p) in line for line in processes if line.split()[0]!=str(os.getpid())),p
        if p.name.endswith('-native-audit'):
            n=json.loads((root/'native/manifest.json').read_text())
            nfiles={x['path'].removesuffix('.gz'):x for x in n['files']}
            for x in p.rglob('*'):
                if x.is_file():
                    relative=str(x.relative_to(p));item=nfiles[relative]
                    assert sha(x.read_bytes())==item['sha256']
                    assert gzip.decompress((root/'native'/item['path']).read_bytes())==x.read_bytes()
        elif p.name.endswith(('-visual','-visual-v1')):
            for x in p.iterdir():
                relative=p.name.removeprefix(prefix)+'/'+x.name
                item=next(v for v in manifest['visuals'] if v['path']==relative)
                assert sha(x.read_bytes())==item['sha256']==sha((root/relative).read_bytes())
        else:
            for x in p.iterdir():
                assert x.is_file() and x.name.startswith('identity')
                assert sha(x.read_bytes())==files[x.name+'.gz']['raw_sha256']
    elif p.name==prefix+'verify-job-full.log':
        assert sha(p.read_bytes())==q['raw_log_sha256']
        assert sha(gzip.decompress((root/'verify.log.gz').read_bytes()))==q['redacted_log_sha256']
    elif p.name==prefix+'collect.py':
        raw=p.read_bytes();(root/'collect.py.gz').write_bytes(gzip.compress(raw,mtime=0))
        assert gzip.decompress((root/'collect.py.gz').read_bytes())==raw
    else:
        name=p.name.removeprefix(prefix)
        if not name.endswith('.gz'):name+='.gz'
        item=files[name]
        assert sha(p.read_bytes())==item['raw_sha256'],p
        assert sha((root/name).read_bytes())==item['gzip_sha256']
        assert sha(gzip.decompress((root/name).read_bytes()))==item['stored_sha256']
    size=sum(x.stat().st_size for x in p.rglob('*') if x.is_file() and not x.is_symlink()) if p.is_dir() else p.stat().st_size
    records.append({'name':p.name,'bytes':size})
receipt={'owned_prefix':prefix,'verified_before_removal':True,'records':[]}
out=root/'final-cleanup.json'
for p,record in zip(paths,records):
    if p.is_dir():shutil.rmtree(p)
    else:p.unlink()
    receipt['records'].append(record)
    out.write_text(json.dumps(receipt,indent=2)+'\n')
receipt.update(bytes_removed=sum(x['bytes'] for x in records),free_bytes_after=shutil.disk_usage(tmp).free,remaining_owned_paths=[p.name for p in tmp.glob(prefix+'*')])
assert not receipt['remaining_owned_paths']
out.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='records'}))
