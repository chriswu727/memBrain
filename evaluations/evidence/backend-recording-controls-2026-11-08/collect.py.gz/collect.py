import gzip,hashlib,json,re,shutil
from pathlib import Path
from membrain.privacy import scrub
root=Path('evaluations/evidence/backend-recording-controls-2026-11-08');root.mkdir(parents=True,exist_ok=True)
prefix='membrain-controls-surface-';tmp=Path('/private/tmp')
paths=[p for p in tmp.glob(prefix+'*') if p.is_file() and p.name not in (Path(__file__).name,prefix+'verify-job-full.log')]
paths+=list((tmp/(prefix+'qualification')).glob('identity*.json'))
files=[]
for path in sorted(paths):
 raw=path.read_bytes();content=gzip.decompress(raw) if path.suffix=='.gz' else raw
 value=re.sub(r'(::test[^\[\n]+)\[.*\](?=\s+(?:PASSED|FAILED|SKIPPED|XFAIL|XPASS))',r'\1[parameters redacted]',content.decode())
 stored=('\n'.join(line.rstrip() for line in scrub(value).splitlines()).rstrip()+'\n').encode();packed=gzip.compress(stored,mtime=0)
 name=path.name.removeprefix(prefix)
 if not name.endswith('.gz'):name+='.gz'
 (root/name).write_bytes(packed)
 files.append({'path':name,'raw_sha256':hashlib.sha256(raw).hexdigest(),'stored_sha256':hashlib.sha256(stored).hexdigest(),'gzip_sha256':hashlib.sha256(packed).hexdigest()})
visuals=[]
for suffix in ('visual','visual-v1'):
 for path in sorted((tmp/(prefix+suffix)).glob('*')):
  if not path.is_file():continue
  target=root/suffix/path.name;target.parent.mkdir(exist_ok=True);shutil.copyfile(path,target)
  visuals.append({'path':str(target.relative_to(root)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
identity=json.loads((tmp/(prefix+'qualification')/'identity.json').read_text())
record={'identity':identity,'final_source_passed':403,'final_installed_passed':286,'notes':'Final-source-v2 (286), adapters (117) and installed-final (286) qualify runtime a19e943; the stronger late-response completion assertion passes separately without runtime changes. Earlier 284-source/284-installed runs and visual-v1 retain runtime 1860969 scope. Translation assertion failure, three real corrupt-control failures, initial CI port collision/secondary uv diagnostic error, actionlint numeric key failure and cancelled workflows remain retained. The state-read microprobe is not complete-hook or recall latency. No paid or subscription-backed evaluation. Logs are scrubbed and normalized; original and stored hashes may differ.','files':files,'visuals':visuals}
(root/'local-manifest.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'logs':len(files),'visuals':len(visuals),'bytes':sum(p.stat().st_size for p in root.rglob('*') if p.is_file())}))
