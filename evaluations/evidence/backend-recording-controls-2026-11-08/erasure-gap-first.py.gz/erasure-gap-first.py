import json, os, shutil, subprocess
from pathlib import Path
from membrain import desktop, host
from membrain.build_identity import BUILD_ID
from membrain.desktop_connection import open_client
os.environ['PYTHON_DOTENV_DISABLED']='1'
os.environ['MEMBRAIN_SEMANTIC']='0'
root=Path('/private/tmp/membrain-controls-surface-erasure-gap-profile')
assert not root.exists()
assert shutil.disk_usage(root.parent).free > 2*1024**3
result={'build_id':BUILD_ID,'model_calls':0,'diagnostic_only':True}
try:
    host.start(root)
    with open_client(root,start_service=False) as client:
        captured=client.recording_status()
        client.observe('Public synthetic pre-erasure record',conversation_id='erasure-fixture',branch_id='main',source_event_key='before-erase',expected_recording_revision=captured['revision'])
        generation=client.dashboard()['brain']['scope_generation']
        erased=client.forget([],kind='all_authorized_scope',mode='erase_content',expected_scope_generation=generation)
        after=client.recording_status()
        delayed=client.observe('Public synthetic delayed pre-erasure payload',conversation_id='erasure-fixture',branch_id='main',source_event_key='delayed-before-erase',expected_recording_revision=captured['revision'])
        result.update(captured_recording=captured,post_erasure_recording=after,erase_outcome=erased['outcome'],delayed_outcome=delayed['outcome'],delayed_accepted_count=len(delayed['result']['accepted_event_ids']))
        assert result['erase_outcome']=='applied'
        result['unresolved_delayed_write_gap']=bool(result['delayed_accepted_count'])
finally:
    desktop.stop(root)
    assert not list(root.rglob('postmaster.pid'))
    processes=subprocess.check_output(['ps','-eo','pid,command'],text=True).splitlines()
    assert not any(str(root) in line for line in processes if line.split()[0]!=str(os.getpid()))
    result['temporary_bytes_removed']=sum(p.stat().st_size for p in root.rglob('*') if p.is_file() and not p.is_symlink())
    shutil.rmtree(root)
    Path('/private/tmp/membrain-controls-surface-erasure-gap.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
