import json
from pathlib import Path
root=Path('evaluations/evidence/backend-recording-controls-2026-11-08')
q=json.loads((root/'qualification-receipt.json').read_text())
m=json.loads((root/'merge-receipt.json').read_text())
assert q['verify_conclusion']=='success' and q['native_qualification_conclusion']=='success'
merge=m['merge_commit'];source=q['source_commit'];runtime='a19e94381ad7ef33b8a2f3e65fe40ea04678a8ed'
report='https://github.com/chriswu727/memBrain/blob/integration/maturity-candidate/evaluations/backend-recording-controls-2026-11-08.md'
ci=f'Verify 42574397723 passes 8,174 Python/56 TypeScript tests, zero test skips, types, Ruff and builds; {q["python_warnings"]} multiprocessing fork warnings remain. Five-platform Native 42574397718 passes with 47 audited current-run summaries and fresh native builds. Python test time is {q["python_seconds"]:,.2f} seconds. [Verify](https://github.com/chriswu727/memBrain/actions/runs/42574397723), [Native](https://github.com/chriswu727/memBrain/actions/runs/42574397718).'
behavior='The memory page now distinguishes the selected brain\'s server recording policy from capture on this device, displays both causes and rejects stale mutations. Resuming either leaves the other unchanged. Corrupt or unreadable local pause metadata keeps capture paused, and expiry cleanup cannot delete a newer pause. Remote service pages retain server controls without claiming local-device access.'
validation='This batch passes 403 related source tests, 286 extracted-wheel tests and equality of all 208 runtime inputs. Real service/browser journeys cover English desktop, Chinese mobile, stale requests and unavailable state. An isolated local state-read microprobe adds about 0.05 ms per call; complete-hook and recall latency were not remeasured. Initial test failures, the CI port collision and cancelled workflows remain retained.'
body57=f'''The page previously reported only local capture state, so a paused server could appear to be recording and local resume could falsely report recording on. {behavior}

Local status and writes use the existing session lock and a file revision. Page mutations always submit their displayed revision. Verify now assigns its PostgreSQL service a free host port; the initial fixed-port collision and diagnostic setup failure remain recorded.

{validation}

{ci}

Runtime `{runtime}`; qualified source `{source}`. Integrated as `{merge}` with complete-tree equality. [Report and evidence]({report}).

Integration only. Separate conversation controls are not widened to the whole brain; automatic cross-device synchronization is not implemented. Ephemeral durable turns, receipt normalization and delayed-write erasure fencing remain open. A separate real-service diagnostic confirms that a new delayed observation carrying pre-erasure recording revision 0 can be accepted after whole-scope erasure; this is unresolved, is not a passing qualification test, and is the next backend task. R4 remains failed and C5 invalid/unscored; main merge, tag and publication remain blocked. No paid or subscription-backed evaluation was run.
'''
old=json.loads(Path('/private/tmp/membrain-controls-surface-pr43-before.json').read_text())['body']
start=old.index('All nine launchers pin runtime ');end=old.index('Current engineering qualification:')
old=old[:start]+f'All nine launchers pin runtime {runtime}. PR #57 integrated scoped recording controls as {merge}, whose complete tree equals qualified source {source}. Documentation/evidence follow-ups change no implementation inputs. Main merge, tag and publication remain blocked; this PR is not release-ready.\n\n'+old[end:]
start=old.index('Current engineering qualification:');end=old.index('- Previous [stored recall eligibility measurements]')
old=old[:start]+'Current engineering qualification:\n- '+ci+'\n- '+behavior+' '+validation+f' [Report and evidence]({report}).\n'+old[end:]
start=old.index('Remaining backend work:');end=old.index('Latest behavioral acceptance')
remaining='''Remaining backend work: the misleading page control/status path is resolved, while device-wide timed capture, conversation-specific pauses and the server's whole-brain gate remain explicitly different scopes. There is no automatic cross-device synchronization, and disconnected hosts cannot immediately discover remote changes. Automatic ChatMemory/proxy extraction and background cognition retain recording revisions. Lifecycle-integrated manual tools retain original-turn capture authority; tools-only MCP, direct API/SDK clients and file mirroring retain separate contracts. Ephemeral durable chat and receipt normalization across independent AgentRuntime remain open. Host delivery uses a local journal plus idempotent server replay, not one distributed transaction; user and assistant observations may appear separately. Replay is bounded and independently drained, but in-flight requests can exceed the between-record budget. A new real-service diagnostic confirms the next blocker: whole-scope content erasure leaves recording revision 0 unchanged, so a delayed new observation with that pre-erasure revision is accepted. Local capture revocation cannot cancel a request that already passed its check. Existing-history processing and reads may continue, and external transcripts cannot be erased by this gate. Source tests do not establish general multilingual privacy-intent understanding. https://github.com/chriswu727/memBrain/blob/integration/maturity-candidate/architecture/backend-control-flow-2026-11-07.md

'''
old=old[:start]+remaining+old[end:]
assert 'R4 therefore fails overall' in old and 'C5 is invalid/unscored' in old
out={'57':body57,'43':old}
Path('/private/tmp/membrain-controls-surface-pr-bodies.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'prepared':[57,43],'runtime':runtime}))
