import json
from pathlib import Path
root = Path('evaluations/evidence/backend-recording-controls-2026-11-08')
q = json.loads((root/'qualification-receipt.json').read_text())
m = json.loads((root/'merge-receipt.json').read_text())
n = json.loads((root/'native/manifest.json').read_text())
assert q['verify_conclusion'] == n['conclusion'] == 'success'
assert q['python_passed'] == 8174 and q['typescript_passed'] == 56
assert n['logical_summaries'] == 47 and m['complete_tree_equal']
assert q['source_commit'] == n['source_commit'] == m['source_commit'] == '27a[personal number removed]e1effeaca0e2cd1a63038ac'
merge = m['merge_commit']
for name, text in {
'README.md': '> **Pre-release.** All nine launchers pin runtime `a19e943`, with authoritative memory-page recording controls, separate device capture, combined status and stale-change protection. [This batch](evaluations/backend-recording-controls-2026-11-08.md) passes 403 targeted source tests, 286 extracted-wheel tests, full CI (8,174 Python/56 TypeScript, zero test skips) and five-platform native qualification. Damaged local pause metadata keeps capture paused. Earlier recall benchmarks retain their original runtime scope. R4, C5 and final review still block publication.',
'README.zh-CN.md': '> **发布前版本。** 全部九个启动器固定到运行时 `a19e943`，页面可直接控制记忆库记录，单独管理本机捕获，显示组合状态，并拒绝过期的修改。[本轮](evaluations/backend-recording-controls-2026-11-08.md)已通过 403 项相关源码测试、286 项解包安装测试、完整 CI（8,174 项 Python／56 项 TypeScript，测试零跳过）及五平台原生验证。本机暂停文件损坏时保持暂停。此前的召回性能结果保留原受测版本范围。R4、C5 和最终审查仍阻止正式发布。'
}.items():
    p=Path(name); lines=p.read_text().splitlines(); indices=[i for i,l in enumerate(lines) if l.startswith(('> **Pre-release.**','> **发布前版本。**'))]; assert len(indices)==1;lines[indices[0]]=text;p.write_text('\n'.join(lines)+'\n')
p=Path('evaluations/backend-recording-controls-2026-11-08.md');s=p.read_text()
s=s.replace('Full CI and merge are pending; main merge and publication remain blocked.', f'PR #57 merged as `{merge}`, whose complete tree equals qualified source `27a6107`. Documentation/evidence follow-ups change no runtime inputs. Main merge and publication remain blocked.')
old='[Verify 42574397723](https://github.com/chriswu727/memBrain/actions/runs/42574397723) and [Native 42574397718](https://github.com/chriswu727/memBrain/actions/runs/42574397718) are running on the final pinned source. Complete-host recall benchmarks were not repeated.'
new=f'[Verify 42574397723](https://github.com/chriswu727/memBrain/actions/runs/42574397723) passes **8,174 Python and 56 TypeScript tests**, zero test skips, types, Ruff and builds on the final pinned source; {q["python_warnings"]} multiprocessing fork warnings remain. Python test time is {q["python_seconds"]:,.2f} seconds. [Native 42574397718](https://github.com/chriswu727/memBrain/actions/runs/42574397718) passes all five platforms with fresh native builds and **47 audited current-run summaries**; five duplicate qualification copies are excluded. Recorded operations completed without model calls and all recorded port-closure checks pass. Platform-inapplicable workflow steps are skipped; this is not a test skip. Complete-host recall benchmarks were not repeated.'
assert old in s;s=s.replace(old,new);p.write_text(s)
p=Path('docs/releasing.md');s=p.read_text();old='**Current bounded host-replay runtime';assert old in s;s=s.replace(old,'**Preceding bounded host-replay runtime',1)
paragraph=f'**Current recording-control runtime `a19e9438` (2026-11-08):** [Qualification](../evaluations/backend-recording-controls-2026-11-08.md) passes 403 related source tests, 286 extracted-wheel tests and 208-input parity. The page separates authoritative server recording from local timed capture, displays both causes and rejects stale mutations. Corrupt or unreadable local pause metadata keeps host capture paused; timed expiry cannot delete a replacement pause. Verify 42574397723 passes 8,174 Python/56 TypeScript tests, zero test skips, types, Ruff and builds; {q["python_warnings"]} multiprocessing fork warnings remain. Five-platform Native 42574397718 passes with 47 audited current-run summaries and fresh builds. PR #57 merged as `{merge[:7]}`, whose complete tree equals qualified source `27a6107`. The isolated local state-read microprobe adds about 0.05 ms per call; complete-hook and recall performance were not remeasured. Prior test failures, the initial CI port collision and cancelled runs remain retained. The earlier misleading page status/control diagnostic is resolved; automatic synchronization across devices and distinct conversation scopes is not implemented. Ephemeral durable turns, cross-runtime receipt normalization and delayed-write erasure fencing remain open. Failed R4, invalid/unscored C5 and final review still block main merge and publication.\n\n'
assert s.startswith('# First-release closeout\n\n');s=s.replace('# First-release closeout\n\n','# First-release closeout\n\n'+paragraph,1);p.write_text(s)
q.update(native_qualification_conclusion='success',native_logical_summaries=47,native_fresh_builds=True)
(root/'qualification-receipt.json').write_text(json.dumps(q,indent=2)+'\n')
print(json.dumps({'docs_updated':4,'merge':merge,'python':q['python_passed'],'typescript':q['typescript_passed']}))
