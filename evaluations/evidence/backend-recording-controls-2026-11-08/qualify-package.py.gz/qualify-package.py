import hashlib,json,os,shutil,subprocess,zipfile
from pathlib import Path
from membrain.build_identity import BUILD_ID,SCHEMA_ID,package_manifest,manifest_digest
import membrain
prefix='membrain-'+'controls-surface-'
root=Path('/private/tmp')/(prefix+'qualification')
old=root/'wheel'
assert not list(old.rglob('postmaster.pid'))
processes=subprocess.check_output(['ps','-eo','pid,command'],text=True).splitlines()
assert not any(str(old) in p for p in processes if p.split()[0]!=str(os.getpid()))
removed=sum(p.stat().st_size for p in old.rglob('*') if p.is_file())
shutil.rmtree(old)
(root/'identity.json').rename(root/'identity-v1.json')
wheel=next(Path('dist').glob('*.whl'))
with zipfile.ZipFile(wheel) as z:z.extractall(root/'wheel')
source=package_manifest(Path(membrain.__file__).parent,Path.cwd())
installed=package_manifest(root/'wheel/membrain',root)
assert source==installed and manifest_digest(installed)==BUILD_ID
record={'runtime_commit':'a19e94381ad7ef33b8a2f3e65fe40ea04678a8ed','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'build_id':BUILD_ID,'schema_id':SCHEMA_ID,'runtime_inputs':len(source),'wheel_parity':True,'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'superseded_extraction_bytes_removed':removed}
(root/'identity.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
