import gzip,hashlib,json,os,shutil,subprocess
from pathlib import Path
prefix='membrain-'+'controls-surface-';tmp=Path('/private/tmp')
paths=[tmp/(prefix+x) for x in ('corrupt-before','stale-read','tests')]
paths+=[tmp/(prefix+'qualification')/'wheel',Path.cwd()/'dist']
logs={}
for root in paths[:3]:
 for p in root.rglob('*.log'):
  if p.stat().st_size<2_000_000:logs[str(p.relative_to(tmp))]=p.read_text(errors='replace')
if logs:(tmp/(prefix+'fixture-lifecycle.json.gz')).write_bytes(gzip.compress(json.dumps(logs).encode(),mtime=0))
receipt=[]
for root in paths:
 if not root.exists():continue
 assert not root.is_symlink() and not list(root.rglob('postmaster.pid')),root
 processes=subprocess.check_output(['ps','-eo','pid,command'],text=True).splitlines()
 assert not any(str(root) in p for p in processes if p.split()[0]!=str(os.getpid())),root
 files=[p for p in root.rglob('*') if p.is_file() and not p.is_symlink()]
 if root.name=='dist':
  assert len(files)==3 and all(p.name.startswith('membrain_ai-0.1.0') or p.name=='.gitignore' and p.read_bytes()==b'*' for p in files)
  identity=json.loads((tmp/(prefix+'qualification')/'identity.json').read_text())
  assert hashlib.sha256(next(root.glob('*.whl')).read_bytes()).hexdigest()==identity['wheel_sha256']
 record={'path':str(root),'bytes':sum(p.stat().st_size for p in files)}
 if root.name=='dist':record['hashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
 shutil.rmtree(root);receipt.append(record)
 (tmp/(prefix+'cleanup.json')).write_text(json.dumps({'removed':receipt,'free_bytes_after':shutil.disk_usage(tmp).free},indent=2)+'\n')
(tmp/(prefix+'cleanup.json')).write_text(json.dumps({'removed':receipt,'free_bytes_after':shutil.disk_usage(tmp).free,'scope':'Only stopped task-owned fixtures, extracted package and rebuildable distribution; results and identities retained.'},indent=2)+'\n')
print(json.dumps({'bytes_removed':sum(x['bytes'] for x in receipt),'free_gib':shutil.disk_usage(tmp).free/1024**3}))
