import json,os,shutil,subprocess
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
from membrain import desktop,host
from membrain.desktop_connection import open_client
from membrain.local_profile import load_profile
from membrain.build_identity import BUILD_ID
os.environ['PYTHON_DOTENV_DISABLED']='1';os.environ['MEMBRAIN_SEMANTIC']='0'
root=Path('/private/tmp/membrain-controls-surface-visual-profile');assert not root.exists()
output=Path('/private/tmp/membrain-controls-surface-visual');output.mkdir(exist_ok=True)
result={'build_id':BUILD_ID,'headless':True,'model_calls':0,'views':[]}
try:
 host.start(root);profile=load_profile(root)
 host.pause(root,hours=1)
 with sync_playwright() as p:
  browser=p.chromium.launch(headless=True)
  try:
   page=browser.new_page(viewport={'width':1280,'height':900},locale='en-US')
   page.goto(profile.base_url+'/memory?code='+host.issue_ui_code(root))
   expect(page.locator('#tabs')).to_be_visible()
   page.locator('#tabs button[data-view="privacy"]').click()
   expect(page.locator('#recording')).to_have_text('Device capture paused')
   if page.locator('#first-use').is_visible():page.locator('#first-use > summary').click()
   for name in ('desktop-en','mobile-zh'):
    if name=='mobile-zh':
     page.locator('#pause').click();expect(page.locator('#recording')).to_have_text('Recording paused')
     page.set_viewport_size({'width':390,'height':844});page.locator('#language').click()
     expect(page.locator('html')).to_have_attribute('lang','zh-CN')
     expect(page.locator('#recording')).to_have_text('记录已暂停')
     if page.locator('#first-use').is_visible() and page.locator('#first-use').get_attribute('open') is not None:page.locator('#first-use > summary').click()
    sizes=page.evaluate('({width:innerWidth,scroll:document.documentElement.scrollWidth})')
    assert sizes['scroll']<=sizes['width']
    page.screenshot(path=str(output/(name+'.png')),full_page=True)
    result['views'].append({'name':name,**sizes})
  finally:browser.close()
 with open_client(root,start_service=False) as client:assert client.recording_status()['paused']
 assert host.paused(root)
finally:
 desktop.stop(root);assert not list(root.rglob('postmaster.pid'))
 processes=subprocess.check_output(['ps','-eo','pid,command'],text=True).splitlines()
 assert not any(str(root) in line for line in processes if line.split()[0]!=str(os.getpid()))
 result['temporary_bytes_removed']=sum(p.stat().st_size for p in root.rglob('*') if p.is_file() and not p.is_symlink())
 shutil.rmtree(root)
 (output/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
