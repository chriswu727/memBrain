import ast,json,os,shutil,statistics,subprocess,time
from pathlib import Path
from membrain import host
from membrain.build_identity import BUILD_ID

source=subprocess.check_output(['git','show','c34ba4c8bd3fcb3eae0d82456342e298b11f1f09:src/membrain/host.py'],text=True)
functions=[node for node in ast.parse(source).body if isinstance(node,ast.FunctionDef) and node.name in ('_paused_file','paused')]
namespace=dict(vars(host));exec(compile(ast.Module(body=functions,type_ignores=[]),'baseline-paused','exec'),namespace)
old=namespace['paused']
root=Path('/private/tmp/membrain-controls-surface-cost-work');assert not root.exists()
root.mkdir(mode=0o700)
rows=[]
try:
 for paused in (False,True):
  if paused:host.pause(root)
  for variant in ('baseline','candidate','candidate','baseline'):
   operation=old if variant=='baseline' else host.paused
   for _ in range(20):assert bool(operation(root)) is paused
   samples=[]
   for _ in range(1000):
    started=time.perf_counter_ns();assert bool(operation(root)) is paused;samples.append((time.perf_counter_ns()-started)/1e6)
   rows.append({'paused':paused,'variant':variant,'calls':len(samples),'median_ms':statistics.median(samples),'p95_ms':sorted(samples)[949]})
finally:
 assert not list(root.rglob('postmaster.pid'))
 processes=subprocess.check_output(['ps','-eo','pid,command'],text=True).splitlines()
 assert not any(str(root) in p for p in processes if p.split()[0]!=str(os.getpid()))
 shutil.rmtree(root)
result={'build_id':BUILD_ID,'baseline_commit':'c34ba4c8bd3fcb3eae0d82456342e298b11f1f09','scope':'Public isolated paused-state reads only: exact baseline pause functions compiled from Git, shared unchanged path helpers, local filesystem, ABBA per state, 1000 calls/sample after 20 warmups. Not complete hooks, server control, recall, throughput or RSS. No provider. Temporary state removed.','samples':rows}
Path('/private/tmp/membrain-controls-surface-cost.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
