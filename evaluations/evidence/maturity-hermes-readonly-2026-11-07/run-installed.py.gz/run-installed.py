import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).parent
repo = Path('/Users/yichen/tmp/membrain-resume-scope-20261107')
environment = root / 'installed-env'
site = environment / 'lib/python3.12/site-packages'
(site / 'test-dependencies.pth').write_text('/Users/yichen/tmp/membrain-review-20261029/.venv/lib/python3.12/site-packages\n')
tests = root / 'installed-tests'
tests.mkdir(exist_ok=True)
for name in ['test_host.py', 'test_hermes_adapter.py', 'test_hermes_readonly.py']:
    shutil.copy2(repo / 'tests' / name, tests / name)
(tests / 'pytest.ini').write_text('[pytest]\nasyncio_mode = auto\n')
env = {k: v for k, v in os.environ.items() if not k.startswith(('MEMORY_', 'MEMBRAIN_', 'C5_'))
       and not k.endswith(('_API_KEY', '_API_TOKEN')) and k not in ('PYTHONPATH', 'VIRTUAL_ENV')}
env.update(PYTHON_DOTENV_DISABLED='1', MEMBRAIN_SEMANTIC='0')
code = '''import hashlib,json,sys
from pathlib import Path
import membrain
from membrain.build_identity import BUILD_ID, SCHEMA_ID, package_manifest
package = Path(membrain.__file__).parent.resolve()
assert package.is_relative_to(Path(sys.executable).parent.parent.resolve())
receipt = {'package': str(package), 'build': BUILD_ID, 'schema': SCHEMA_ID,
           'manifest': {k: hashlib.sha256(v).hexdigest() for k,v in package_manifest(package,package.parents[1]).items()}}
Path('../installed-package.json').write_text(json.dumps(receipt,indent=2)+'\\n')
import pytest
raise SystemExit(pytest.main(['-c','pytest.ini','test_hermes_adapter.py','test_hermes_readonly.py','-q',
                             '--basetemp=../installed-tests-temp']))
'''
with (root / 'installed-tests.log').open('w') as output:
    result = subprocess.run([str(environment / 'bin/python'), '-I', '-c', code], cwd=tests, env=env,
                            stdout=output, stderr=subprocess.STDOUT)
(root / 'installed-result.json').write_text(json.dumps({'exit_code': result.returncode}, indent=2) + '\n')
print((root / 'installed-tests.log').read_text())
raise SystemExit(result.returncode)
