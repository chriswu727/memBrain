import asyncio
import json
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, '/Users/yichen/tmp/membrain-recording-state-20261107/tests')
from test_host import Client
from membrain import host
from membrain.build_identity import BUILD_ID
from membrain.mcp_server import create_server

assert BUILD_ID == '44c034fefd9278d180578307e2169d6ed630f101ff2736a4c6ba7e8e1462a319'
client = Client()
with tempfile.TemporaryDirectory(prefix='public-resume-repro-') as folder, patch.object(host, 'ready_client', return_value=client):
    directory = Path(folder).resolve()
    host.pause(directory)
    host.prompt_context(directory, 'requester', 'Resume recording please.')
    host.prompt_context(directory, 'private', 'Unrelated private synthetic detail.')
    asyncio.run(create_server(client, directory=directory).call_tool('memory_resume', {}))
    records = host.finish_turn(directory, 'private', 'Private synthetic reply', prompt='Unrelated private synthetic detail.')
    result = {'baseline_build': BUILD_ID, 'wrong_conversation_records': len(records),
              'private_text_delivered': any(row['text'] == 'Unrelated private synthetic detail.' for row in client.observed),
              'requester_resumed': host.turn_resumed(directory, 'requester'), 'provider_calls': 0}
    assert result['wrong_conversation_records'] == 2 and result['private_text_delivered'] and not result['requester_resumed']
Path(__file__).with_name('baseline-observation.json').write_text(json.dumps(result, indent=2) + '\n')
print(result)
