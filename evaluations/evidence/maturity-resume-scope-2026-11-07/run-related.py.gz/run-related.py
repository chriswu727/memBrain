import json, os, subprocess, sys
from pathlib import Path
root=Path(__file__).parent
repo=Path('/Users/yichen/tmp/membrain-resume-scope-20261107')
env={k:v for k,v in os.environ.items() if not k.startswith(('MEMORY_', 'MEMBRAIN_', 'C5_')) and not k.endswith(('_API_KEY', '_API_TOKEN')) and k not in ('PYTHONPATH', 'VIRTUAL_ENV')}
env.update(PYTHONPATH=str(repo/'src')+':/Users/yichen/tmp/membrain-review-20261029/.venv/lib/python3.12/site-packages', MEMBRAIN_SEMANTIC='0', PYTHON_DOTENV_DISABLED='1')
command=['/Users/yichen/tmp/membrain-resume-scope-20261107/.venv/bin/python', '-m', 'pytest', 'tests/test_resume_scope.py', 'tests/test_recording_context.py', 'tests/test_c5_harness_hardening.py', 'tests/test_host.py', 'tests/test_easy_start.py', 'tests/test_plugin.py', 'tests/test_chatbot_adapter.py', 'tests/test_hermes_adapter.py', 'tests/test_openclaw_plugin.py', 'tests/test_proxy.py', '-q', '--basetemp='+str(root/'related-temp')]
with (root/'related.log').open('w') as log:
 result=subprocess.run(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
(root/'related-summary.json').write_text(json.dumps({'exit_code':result.returncode, 'provider_calls':0, 'command':command},indent=2)+'\n')
print((root/'related.log').read_text()[-10000:])
raise SystemExit(result.returncode)
