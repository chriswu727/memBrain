import hashlib,json,os,socket,subprocess,sys
from pathlib import Path
root=Path(__file__).parent
repo=Path('/Users/yichen/tmp/membrain-affect-window-20261106')
python='/Users/yichen/tmp/membrain-affect-window-checks-20261106/runtime-env/bin/python'
cache=Path('/Users/yichen/tmp/membrain-affect-window-delivery-20261106/install-final/home/Library/Application Support/memBrain')
env={k:v for k,v in os.environ.items() if not k.startswith(('MEMORY_','MEMBRAIN_','C5_')) and not k.endswith(('_API_KEY','_API_TOKEN')) and k not in ('PYTHONPATH','VIRTUAL_ENV')}
env.update(C5_STUB='1',MEMBRAIN_SEMANTIC='0',PYTHON_DOTENV_DISABLED='1',C5_PYTHON=python,MEMBRAIN_MODEL_CACHE=str(cache))
for port in (8893,55533,8894,55534):
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',port))!=0
paths=subprocess.check_output(['git','ls-files','src','tests','plugins','integrations','scripts','migrations','architecture','.github','pyproject.toml','uv.lock'],cwd=repo,text=True).splitlines()
paths+=['evaluations/'+n for n in ('c5-harness.py','c5-run-scenario.sh','c5-dry-run-check.py','acceptance_review.py','acceptance-attempt-driver.py','evaluation_budget.py')]
scenario='evaluations/c5-practice-scenario.py'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={'version':1,'attempt_id':'offline-current-rehearsal-20261106','files':{n:sha(repo/n) for n in paths},'pairs':[{'gate':'C5','scenarios':[{'key':'practice','path':scenario,'sha256':sha(repo/scenario)}]}],'order':['practice']}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
meta={'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'runtime_pin':'5048e13090202d3dd201227429d4d4cde66bd180','mode':'offline_test_only','model_calls':0,'external_connections_refused_by_stub':True,'protocol':'Default attempt driver and shell supervisor, public practice, existing local model cache copied but keyword recall selected; no provider credentials','completed':False}
(root/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
with (root/'driver.log').open('w') as log:
 result=subprocess.run([python,'evaluations/acceptance-attempt-driver.py','run','--manifest',str(root/'manifest.json'),'--out',str(root/'run'),'--repo',str(repo)],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
meta.update(completed=True,exit_code=result.returncode,inputs_unchanged=all(sha(repo/n)==v for n,v in manifest['files'].items()))
ports={}
for port in (8893,55533,8894,55534):
 with socket.socket() as s:ports[str(port)]=s.connect_ex(('127.0.0.1',port))!=0
(root/'ports.json').write_text(json.dumps(ports,indent=2)+'\n')
(root/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta))
assert all(ports.values()) and meta['inputs_unchanged']
if result.returncode:raise SystemExit(result.returncode)
with (root/'checks.json').open('w') as log:
 checked=subprocess.run([python,'evaluations/c5-dry-run-check.py',scenario,str(root/'run'),'practice'],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
raise SystemExit(checked.returncode)
