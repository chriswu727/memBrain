import gzip
import hashlib
import json
import re
import subprocess
from pathlib import Path
from membrain.privacy import scrub

root = Path('evaluations/evidence/backend-bounded-queue-replay-2026-11-08')
run = 42565012926
source = 'c2d1743fe97eb585f566af9d030419b9c1000fd5'
meta = json.loads(subprocess.check_output(['gh', 'run', 'view', str(run), '--json', 'databaseId,headSha,status,conclusion,jobs,url,createdAt,updatedAt']))
assert meta['status'] == 'completed' and meta['conclusion'] == 'success', meta
assert meta['headSha'] == source
raw = subprocess.check_output(['gh', 'api', f"repos/chriswu727/memBrain/actions/jobs/{meta['jobs'][0]['databaseId']}/logs"])
Path('/private/tmp/membrain-queue-batches-verify-job-full.log').write_bytes(raw)
text = raw.decode()
matches = re.findall(r'(\d+) passed(?:, (\d+) warnings?)? in ([\d.]+)s', text)
passed, warnings, seconds = max(matches, key=lambda x: int(x[0]))
assert int(passed) == 8149
assert re.search(r'# tests\s+56\b', text) and re.search(r'# fail\s+0\b', text) and re.search(r'# skipped\s+0\b', text)
assert all('skipped' not in line and 'failed' not in line for line in text.splitlines() if f'{passed} passed' in line)
redacted = re.sub(r'(::test[^\[\n]+)\[.*\](?=\s+(?:PASSED|FAILED|SKIPPED|XFAIL|XPASS))', r'\1[parameters redacted]', text)
stored = ('\n'.join(line.rstrip() for line in scrub(redacted).splitlines()).rstrip() + '\n').encode()
(root / 'verify.log.gz').write_bytes(gzip.compress(stored, mtime=0))
(root / 'verify-status.json').write_text(json.dumps(meta, indent=2) + '\n')
receipt = {'verify_run_id': run, 'verify_job_id': meta['jobs'][0]['databaseId'], 'verify_conclusion': meta['conclusion'],
           'source_commit': source, 'source_tree': subprocess.check_output(['git', 'rev-parse', source + '^{tree}'], text=True).strip(),
           'python_passed': int(passed), 'python_warnings': int(warnings or 0), 'python_seconds': float(seconds),
           'typescript_passed': 56, 'native_qualification_run_id': 42565013017,
           'raw_log_sha256': hashlib.sha256(raw).hexdigest(), 'redacted_log_sha256': hashlib.sha256(stored).hexdigest()}
(root / 'qualification-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
