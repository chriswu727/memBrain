import gzip,hashlib,json,os,shutil,subprocess
from pathlib import Path
root=Path('/private/tmp/membrain-queue-batches-native-audit')
dest=Path('evaluations/evidence/backend-bounded-queue-replay-2026-11-08/native')
m=json.loads((dest/'manifest.json').read_text())
for item in m['files']:
 data=gzip.decompress((dest/item['path']).read_bytes())
 assert hashlib.sha256(data).hexdigest()==item['decompressed_sha256']
 assert (root/item['path'].removesuffix('.gz')).read_bytes()==data
assert not list(root.rglob('postmaster.pid')) and not (root/'download.zip').exists()
processes=subprocess.check_output(['ps','-eo','pid,command'],text=True).splitlines()
assert not any(str(root) in line for line in processes if line.split()[0]!=str(os.getpid()))
receipt_path=Path('/private/tmp/membrain-queue-batches-cleanup.json')
receipt=json.loads(receipt_path.read_text())
receipt['removed'].append({'path':str(root),'logical_bytes_removed':sum(p.stat().st_size for p in root.rglob('*') if p.is_file()),'reason':'All retained JSON archived and verified; downloaded binary ZIPs removed immediately after extraction.'})
shutil.rmtree(root)
receipt['free_bytes_after']=shutil.disk_usage(root.parent).free
receipt_path.write_text(json.dumps(receipt,indent=2)+'\n')
p=Path('evaluations/backend-bounded-queue-replay-2026-11-08.md')
s=p.read_text()
old='[Verify 42565012926](https://github.com/chriswu727/memBrain/actions/runs/42565012926) and the automatically triggered [five-platform native qualification 42565013017](https://github.com/chriswu727/memBrain/actions/runs/42565013017) are running on source `c2d1743fe97eb585f566af9d030419b9c1000fd5`. Its runtime inputs are identical to installed-wheel source `e9a9f74`; only a plugin test assertion changed. Full qualification remains pending.'
new='[Five-platform native qualification 42565013017](https://github.com/chriswu727/memBrain/actions/runs/42565013017) passes on source `c2d1743fe97eb585f566af9d030419b9c1000fd5`: macOS arm64/x86_64, Linux arm64/x86_64 and Windows x86_64. All five jobs build fresh native candidates; no prior bundle is reused. The audit retains 47 logical current-run summaries (plus five identical qualification copies excluded from that count), all completed, with zero model calls and all recorded port closures true. Optional additional Linux build/current jobs are intentionally skipped. [Verify 42565012926](https://github.com/chriswu727/memBrain/actions/runs/42565012926) remains running. Its runtime inputs are identical to installed-wheel source `e9a9f74`; only a plugin test assertion changed.'
assert old in s
p.write_text(s.replace(old,new))
p=Path('/private/tmp/membrain-queue-batches-collect-evidence.py')
s=p.read_text().replace("sum(p.stat().st_size for p in root.iterdir())", "sum(p.stat().st_size for p in root.rglob('*') if p.is_file())")
p.write_text(s)
print('Archived native JSON verified; raw audit directory removed.')
