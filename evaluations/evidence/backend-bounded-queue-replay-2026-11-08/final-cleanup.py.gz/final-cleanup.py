import gzip,hashlib,json,os,shutil,subprocess
from pathlib import Path
prefix='membrain-'+'queue-batches-'
tmp=Path('/private/tmp')
evidence=Path('evaluations/evidence/backend-bounded-queue-replay-2026-11-08')
manifest=json.loads((evidence/'local-manifest.json').read_text())
index={x['path']:x for x in manifest['files']}
for name,item in index.items():
 raw=(evidence/name).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==item['gzip_sha256']
 assert hashlib.sha256(gzip.decompress(raw)).hexdigest()==item['stored_sha256']
native=json.loads((evidence/'native/manifest.json').read_text())
for item in native['files']:
 assert hashlib.sha256(gzip.decompress((evidence/'native'/item['path']).read_bytes())).hexdigest()==item['decompressed_sha256']
qualification=json.loads((evidence/'qualification-receipt.json').read_text())
assert hashlib.sha256(gzip.decompress((evidence/'verify.log.gz').read_bytes())).hexdigest()==qualification['redacted_log_sha256']
paths=[p for p in tmp.glob(prefix+'*') if p.is_file()]
paths+=list((tmp/(prefix+'qualification')).glob('identity*.json'))
removals=[]
for path in sorted(paths):
 assert not path.is_symlink(),path
 raw=path.read_bytes();name=path.name.removeprefix(prefix)
 if not name.endswith('.gz'):name+='.gz'
 if path.name==prefix+'verify-job-full.log':
  assert hashlib.sha256(raw).hexdigest()==qualification['raw_log_sha256']
 elif path.name==prefix+'collect-evidence.py':
  packed=gzip.compress(raw,mtime=0);(evidence/'collector.py.gz').write_bytes(packed)
  assert gzip.decompress((evidence/'collector.py.gz').read_bytes())==raw
 elif 'ci-watch' in path.name:
  pass
 else:
  assert name in index and hashlib.sha256(raw).hexdigest()==index[name]['raw_sha256'],path
 removals.append({'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
for directory in (tmp/(prefix+'qualification'),tmp/(prefix+'plugin-before')):
 if not directory.exists():continue
 assert not directory.is_symlink() and not list(directory.rglob('postmaster.pid'))
 processes=subprocess.check_output(['ps','-eo','pid,command'],text=True).splitlines()
 assert not any(str(directory) in p for p in processes if p.split()[0]!=str(os.getpid()))
 if directory.name==prefix+'plugin-before':
  for item in directory.rglob('*'):
   if item.is_symlink():assert item.resolve().is_relative_to(directory.resolve())
   elif item.is_file():assert item.stat().st_size==0
 else:
  assert all(p in paths for p in directory.iterdir()),directory
for item in removals:Path(item['path']).unlink()
for directory in (tmp/(prefix+'qualification'),tmp/(prefix+'plugin-before')):
 if directory.exists():
  if directory.name==prefix+'plugin-before':shutil.rmtree(directory)
  else:directory.rmdir()
receipt={'scope':'Redundant task-owned raw scripts/logs/identity copies only, after validating archived hashes. Earlier stopped databases/installations and native ZIPs were removed separately. Real profiles, models, backups, source worktrees and development environment retained.','files':removals,'logical_bytes_removed':sum(x['bytes'] for x in removals),'free_bytes_after':shutil.disk_usage(tmp).free}
(evidence/'final-cleanup.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'raw_files_removed':len(removals),'logical_bytes_removed':receipt['logical_bytes_removed'],'free_gib':receipt['free_bytes_after']/1024**3}))
