import json, os, shutil, subprocess
from pathlib import Path
from membrain import desktop, host
from membrain.build_identity import BUILD_ID
from membrain.desktop_connection import open_client

os.environ['PYTHON_DOTENV_DISABLED'] = '1'
os.environ['MEMBRAIN_SEMANTIC'] = '0'
root = Path('/private/tmp/membrain-queue-batches-control-profile')
assert not root.exists() and shutil.disk_usage(root.parent).free > 2 * 1024**3
result = {'build_id': BUILD_ID, 'scope': 'Diagnostic of existing separate controls, not a passing product acceptance. Fresh local service, synthetic public input, no providers.'}
try:
    host.start(root)
    with open_client(root, start_service=False) as client:
        local = lambda: client._http.get('/v1/local/recording').raise_for_status().json()
        policy = client.recording_status()
        client.set_recording(paused=True, expected_revision=policy['revision'])
        result['remote_pause'] = {'server': client.recording_status(), 'local_ui_endpoint': local()}
        client._http.post('/v1/local/recording', json={'paused': False}).raise_for_status()
        result['local_resume_after_remote_pause'] = {'server': client.recording_status(), 'local_ui_endpoint': local()}
        policy = client.recording_status()
        client.set_recording(paused=False, expected_revision=policy['revision'])
        client._http.post('/v1/local/recording', json={'paused': True}).raise_for_status()
        result['local_pause'] = {'server': client.recording_status(), 'local_ui_endpoint': local()}
        client.observe(role='user', text='Public control synchronization diagnostic', source_event_key='public-control-gap', conversation_id='public-control', branch_id='main')
        rows = client.timeline(roles=('user',), limit=10)['items']
        result['direct_sdk_records_while_local_paused'] = len(rows)
        assert result['remote_pause']['server']['paused'] is True
        assert result['remote_pause']['local_ui_endpoint']['recording'] == 'on'
        assert result['local_resume_after_remote_pause']['server']['paused'] is True
        assert result['local_pause']['server']['paused'] is False
        assert result['local_pause']['local_ui_endpoint']['recording'] == 'paused'
        assert len(rows) == 1
finally:
    desktop.stop(root)
    assert not list(root.rglob('postmaster.pid'))
    processes = subprocess.check_output(['ps', '-eo', 'pid,command'], text=True).splitlines()
    assert not any(str(root) in p for p in processes if p.split()[0] != str(os.getpid()))
    result['temporary_bytes_removed'] = sum(p.stat().st_size for p in root.rglob('*') if p.is_file() and not p.is_symlink())
    shutil.rmtree(root)
    Path('/private/tmp/membrain-queue-batches-control-gap.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
