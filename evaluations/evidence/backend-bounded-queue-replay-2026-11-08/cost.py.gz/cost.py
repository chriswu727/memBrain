import hashlib,json,os,shutil,statistics,subprocess,sys,tempfile,time,tracemalloc
from pathlib import Path

if len(sys.argv)>1:
    from membrain import host
    root=Path(tempfile.mkdtemp(prefix='membrain-queue-batches-cost-',dir='/private/tmp')).resolve()
    try:
        records=[host.message_record('benchmark','user',f'{i}: '+'x'*200,turn_id=str(i)) for i in range(3000)]
        assert host._spool_records(root,records)
        class Client:
            brain_id='brain'
            def __init__(self,delay):
                self.count=0
                self.checksum=hashlib.sha256()
                self.delay=delay
            def observe(self,**record):
                if self.delay:
                    time.sleep(self.delay)
                self.count+=1
                self.checksum.update(record['text'].encode())
        mode=sys.argv[1]
        client=Client(0.0002 if mode=='foreground' else 0)
        tracemalloc.start()
        begin=time.perf_counter()
        options={"max_records":64} if mode=="drain" and hasattr(host,"host_queue") else {}
        count=host.flush(client,root,**options)
        if mode=='drain':
            while client.count<3000:
                done=host.flush(client,root,**options)
                assert done>0
                count+=done
        elapsed=time.perf_counter()-begin
        peak=tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
        expected=hashlib.sha256(''.join(r['text'] for r in records[:client.count]).encode()).hexdigest()
        assert client.checksum.hexdigest()==expected and count==client.count
        print(json.dumps({'mode':mode,'seconds':elapsed,'peak_bytes':peak,'confirmed_records':count,'queue_bytes':(root/'plugin/spool.jsonl').stat().st_size,'order_sha256':expected,'package':str(Path(host.__file__).resolve())}))
    finally:
        shutil.rmtree(root)
else:
    baseline='/private/tmp/membrain-queue-batches-baseline-package/src'
    candidate=str(Path('src').resolve())
    results=[]
    for mode in ('foreground','drain'):
        for variant,source in (('baseline',baseline),('candidate',candidate),('candidate',candidate),('baseline',baseline)):
            env={**os.environ,'PYTHONPATH':source,'PYTHON_DOTENV_DISABLED':'1','MEMBRAIN_SEMANTIC':'0'}
            value=json.loads(subprocess.check_output([sys.executable,__file__,mode],env=env,text=True,cwd='/private/tmp'))
            value['variant']=variant
            results.append(value)
    document={'scope':'3000 FIFO records; filesystem and Python processing with a fake transport. Foreground injects 0.2 ms per observation and compares bounded callback work, not equal completed work. Drain compares equal complete work with no injected delay, using the supervisor 64-record batch on the candidate; it excludes HTTP, database and supervisor scheduling sleeps. tracemalloc instrumentation affects timings.','results':results}
    Path('/private/tmp/membrain-queue-batches-cost.json').write_text(json.dumps(document,indent=2)+'\n')
    for mode in ('foreground','drain'):
        for variant in ('baseline','candidate'):
            rows=[r for r in results if r['mode']==mode and r['variant']==variant]
            print(json.dumps({'mode':mode,'variant':variant,'median_ms':statistics.median(r['seconds'] for r in rows)*1000,'max_peak_bytes':max(r['peak_bytes'] for r in rows),'counts':[r['confirmed_records'] for r in rows]}))
