import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
from membrain import desktop,host,host_queue
from membrain.build_identity import BUILD_ID
from membrain.desktop_connection import open_client

os.environ['PYTHON_DOTENV_DISABLED']='1'
os.environ['MEMBRAIN_SEMANTIC']='0'
root=Path('/private/tmp/membrain-queue-batches-real-profile')
assert not root.exists() and shutil.disk_usage(root.parent).free>2*1024**3
result={'build_id':BUILD_ID,'records':1000,'scope':'Fresh local service, embedded PostgreSQL and loopback HTTP. No host callbacks after one journal append, no model provider. Timing includes polling and local indexing contention; no baseline comparison.'}
try:
    host.start(root)
    records=[host.message_record('public-backlog','user',f'Public queue record {i}',turn_id=str(i)) for i in range(1000)]
    started=time.monotonic()
    assert host._spool_records(root,records)
    result['queued_bytes']=(root/'plugin/spool.jsonl').stat().st_size
    polls=0
    with open_client(root,start_service=False) as client:
        while time.monotonic()-started<60:
            polls+=1
            rows=client.timeline(roles=('user',),limit=1000,max_characters=200000)['items']
            if len(rows)==1000 and host_queue.pending(root/'plugin/spool.jsonl')==0:
                break
            time.sleep(0.1)
    assert len(rows)==1000 and len({row['event_id'] for row in rows})==1000
    assert {row['text'] for row in rows}=={record['text'] for record in records}
    assert host_queue.pending(root/'plugin/spool.jsonl')==0
    result.update(seconds=time.monotonic()-started,polls=polls,pending_records=0,distinct_events=len(rows))
    result['event_ids_sha256']=hashlib.sha256(json.dumps(sorted(row['event_id'] for row in rows)).encode()).hexdigest()
finally:
    desktop.stop(root)
    assert not list(root.rglob('postmaster.pid'))
    lines=subprocess.check_output(['ps','-eo','pid,command'],text=True).splitlines()
    assert not any(str(root) in line for line in lines if line.split()[0]!=str(os.getpid()))
    result['temporary_bytes_removed']=sum(p.stat().st_size for p in root.rglob('*') if p.is_file() and not p.is_symlink())
    result['service_lifecycle']=(root/'service.log').read_text() if (root/'service.log').exists() else ''
    shutil.rmtree(root)
    Path('/private/tmp/membrain-queue-batches-real-backlog.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='service_lifecycle'},indent=2))
