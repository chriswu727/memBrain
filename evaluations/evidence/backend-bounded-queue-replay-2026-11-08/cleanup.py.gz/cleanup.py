import hashlib,json,os,shutil,subprocess
from pathlib import Path
prefix='membrain-'+'queue-batches-'
root=Path('/private/tmp')
paths=[root/(prefix+suffix) for suffix in ('baseline-package','baseline','focused','replacement')]
paths+=[root/(prefix+'qualification')/name for name in ('wheel','env')]
paths+=[Path.cwd()/'dist']
receipts=[]
for path in paths:
    if not path.exists():continue
    assert not path.is_symlink() and not list(path.rglob('postmaster.pid')),path
    processes=subprocess.check_output(['ps','-eo','pid,command'],text=True).splitlines()
    assert not any(str(path) in line for line in processes if line.split()[0]!=str(os.getpid())),path
    files=[p for p in path.rglob('*') if p.is_file() and not p.is_symlink()]
    size=sum(p.stat().st_size for p in files)
    hashes={str(p.relative_to(path)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files} if path.name=='dist' else None
    shutil.rmtree(path)
    receipts.append({'path':str(path),'logical_bytes_removed':size,**({'artifact_hashes':hashes} if hashes else {})})
receipt={'removed':receipts,'free_bytes_after':shutil.disk_usage(root).free,'scope':'Task-owned stopped probes, baseline/extracted packages, qualification environment and rebuildable build output only. Identities/results preserved; no real profiles, models, backups or source worktrees removed.'}
(root/(prefix+'cleanup.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'logical_bytes_removed':sum(r['logical_bytes_removed'] for r in receipts),'free_gib':receipt['free_bytes_after']/1024**3}))
