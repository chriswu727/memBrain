import gzip,hashlib,json,re
from pathlib import Path
from membrain.privacy import scrub
root=Path('evaluations/evidence/backend-bounded-queue-replay-2026-11-08');root.mkdir(parents=True,exist_ok=True)
prefix='membrain-queue-batches-'
paths=[p for p in Path('/private/tmp').glob(prefix+'*') if p.is_file() and 'ci-watch' not in p.name and p.name!=prefix+'verify-job-full.log']
paths+=list(Path('/private/tmp/membrain-queue-batches-qualification').glob('identity*.json'))
receipts=[]
for path in sorted(paths):
    if path.name==Path(__file__).name: continue
    raw=path.read_bytes();content=gzip.decompress(raw) if path.suffix=='.gz' else raw
    value=re.sub(r'(::test[^\[\n]+)\[.*\](?=\s+(?:PASSED|FAILED|SKIPPED|XFAIL|XPASS))',r'\1[parameters redacted]',content.decode())
    stored=('\n'.join(line.rstrip() for line in scrub(value).splitlines()).rstrip()+'\n').encode()
    packed=gzip.compress(stored,mtime=0)
    name=path.name.removeprefix(prefix)
    if not name.endswith('.gz'):name+='.gz'
    (root/name).write_bytes(packed)
    receipts.append({'path':name,'raw_sha256':hashlib.sha256(raw).hexdigest(),'stored_sha256':hashlib.sha256(stored).hexdigest(),'gzip_sha256':hashlib.sha256(packed).hexdigest()})
identity=json.loads(Path('/private/tmp/membrain-queue-batches-qualification/identity.json').read_text())
manifest={'identity':identity,'final_source_passed':228,'final_installed_passed':148,'notes':'Final-source and installed logs qualify runtime 72f1ae7. One same-size replacement test was strengthened and checked separately without runtime changes. Earlier host/C5 compatibility and initial focused tests retain intermediate runtime scope. Four baseline failures, two old physical-queue assumptions, a plugin retry expectation failure, benchmark path and script-quoting failures remain retained. Initial complete-drain microprobe used 16-record batches; final probe uses supervisor batch size 64, excluding scheduler waits. Real-backlog qualifies 1000 distinct events with zero pending through the installed local service. Verify 42563635096 was cancelled for the reproduced old plugin retry expectation; its paired native run was superseded. Final CI source c2d1743 has identical runtime inputs to wheel source e9a9f74; Verify 42565012926 and native 42565013017 are separate. No paid/subscription-backed evaluation. Logs are privacy scrubbed; original/stored hashes differ when text is normalized.','files':receipts}
(root/'local-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(f'{len(receipts)} evidence files, {sum(p.stat().st_size for p in root.rglob('*') if p.is_file())} bytes')
