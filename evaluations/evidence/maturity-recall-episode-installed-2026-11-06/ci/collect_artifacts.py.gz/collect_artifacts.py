import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import zipfile

root = Path(__file__).parent
repo = 'repos/chriswu727/memBrain'
run = 42344062943
inventory = json.loads(subprocess.check_output(['gh', 'api', f'{repo}/actions/runs/{run}/artifacts']))
receipt_path = root / 'artifact-receipts.json'
receipts = json.loads(receipt_path.read_text()) if receipt_path.exists() else []
collected = {item['artifact_id'] for item in receipts}
for artifact in inventory['artifacts']:
    if artifact['id'] in collected:
        continue
    assert not artifact['expired'] and artifact['name'].startswith('native-')
    platform = artifact['name'].removeprefix('native-')
    archive = root / f'{artifact["id"]}.zip'
    with archive.open('wb') as stream:
        subprocess.run(['gh','api',f'{repo}/actions/artifacts/{artifact["id"]}/zip'],stdout=stream,check=True)
    retained = []
    with zipfile.ZipFile(archive) as bundle:
        for member in bundle.infolist():
            path = PurePosixPath(member.filename)
            assert not path.is_absolute() and '..' not in path.parts
            if member.is_dir() or path.suffix not in {'.json','.log'}:
                continue
            data = bundle.read(member)
            target = root / 'artifacts' / platform / member.filename
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(data)
            retained.append({'path':str(target.relative_to(root)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    receipts.append({'platform':platform,'artifact_id':artifact['id'],'zip_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'retained':retained})
    receipt_path.write_text(json.dumps(receipts,indent=2)+'\n')
    archive.unlink()
    print(platform, len(retained), 'JSON/log files retained', flush=True)
print('Total artifacts collected:',len(receipts),flush=True)
