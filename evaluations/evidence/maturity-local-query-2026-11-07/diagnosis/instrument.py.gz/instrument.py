import contextvars
import functools
import json
import os
import time

import psycopg
from membrain import read_cache, service, vector_jobs
from membrain.jobs import JobStore
from membrain.local_embeddings import LocalEmbeddingProvider
from membrain.recall_service_executor import RecallServiceExecutor

OUTPUT = '/Users/yichen/tmp/membrain-action-profile-20261107/stages.jsonl'
REQUEST = contextvars.ContextVar('diagnostic_request', default=None)


def emit(stage, began, failed=False):
    request = REQUEST.get()
    if request is None:
        return
    item = {'request_id': request, 'pid': os.getpid(), 'stage': stage,
            'ms': (time.perf_counter() - began) * 1000, 'failed': failed}
    descriptor = os.open(OUTPUT, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
    try:
        os.write(descriptor, (json.dumps(item) + '\n').encode())
    finally:
        os.close(descriptor)


def wrap(owner, name, label, request=False):
    original = getattr(owner, name)

    @functools.wraps(original)
    def measured(*args, **kwargs):
        token = REQUEST.set(args[2].get('request_id')) if request else None
        began, failed = time.perf_counter(), False
        try:
            return original(*args, **kwargs)
        except BaseException:
            failed = True
            raise
        finally:
            emit(label, began, failed)
            if token is not None:
                REQUEST.reset(token)

    setattr(owner, name, measured)


wrap(service.MemoryService, '_respond', 'respond', request=True)
wrap(service.MemoryService, '_retrieval', 'retrieval')
wrap(vector_jobs, 'query_embedding', 'query_embedding')
wrap(LocalEmbeddingProvider, '__call__', 'onnx')
wrap(JobStore, 'claim', 'job_claim')
wrap(JobStore, 'complete', 'job_complete')
wrap(read_cache, 'store', 'cache_store')
wrap(RecallServiceExecutor, 'respond', 'worker_roundtrip')
wrap(service, 'validate', 'service_contract_validation')

original_execute = psycopg.Connection.execute


def execute(self, query, *args, **kwargs):
    stage = None
    if isinstance(query, str) and 'FROM memory_brains' in query:
        stage = 'brain_lock_update' if 'FOR UPDATE' in query else 'brain_lock_share' if 'FOR SHARE' in query else None
    if stage is None:
        return original_execute(self, query, *args, **kwargs)
    began, failed = time.perf_counter(), False
    try:
        return original_execute(self, query, *args, **kwargs)
    except BaseException:
        failed = True
        raise
    finally:
        emit(stage, began, failed)


psycopg.Connection.execute = execute
