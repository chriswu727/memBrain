import gzip
import hashlib
import json
from pathlib import Path

root = Path(__file__).parent
repo = Path('/Users/yichen/tmp/membrain-local-query-concurrency-20261107')
target = repo / 'evaluations/evidence/maturity-local-query-2026-11-07'
files = [(p, p.name) for p in root.iterdir() if p.is_file() and p.suffix in {'.py', '.log', '.json'}]
for folder in ('semantic-host', 'installed-semantic', 'ci'):
    files.extend((p, str(p.relative_to(root))) for p in (root / folder).rglob('*')
                 if p.is_file() and p.suffix in {'.json', '.py', '.log'} and p.name != 'verify-collection.log')
diagnosis = Path('/Users/yichen/tmp/membrain-action-profile-20261107')
files.extend((p, 'diagnosis/' + p.name) for p in diagnosis.iterdir()
             if p.is_file() and p.suffix in {'.py', '.log', '.json', '.jsonl'})
baseline = Path('/Users/yichen/tmp/membrain-source-script-checks-20261107')
files.extend((baseline / name, 'baseline/' + name) for name in ('semantic-concurrency.json', 'semantic_concurrency.py'))
secrets = set()
for folder in ('membrain-semantic-balance-1000-20261107', 'membrain-semantic-scale-20261107'):
    profile = json.loads((Path('/Users/yichen/tmp') / folder / 'installation/profile.json').read_text())
    for key in ('api_key', 'admin_password', 'app_password'):
        if profile.get(key):
            secrets.add(profile[key].encode())
manifest = {'build_id': '4f0ceb425c274678203a2db8bac48f986700d5d3d7c6dda617f503096209e8ab',
            'schema_id': '478061ac77337fd25d87174df1185ab1d40ad4d4216290078fb26fd2f519fe39',
            'status': 'Source and installed guards, real local-model public replay/capacity, and installed package replay passed; full CI pending. Not R4/C5 acceptance.',
            'files': []}
for path, name in sorted(files):
    data = path.read_bytes()
    assert not any(secret in data for secret in secrets), name
    packed = gzip.compress(data, mtime=0)
    output = target / (name + '.gz')
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(packed)
    assert gzip.decompress(output.read_bytes()) == data
    manifest['files'].append({'path': name + '.gz', 'bytes': len(packed),
                              'sha256': hashlib.sha256(packed).hexdigest(), 'original_bytes': len(data),
                              'original_sha256': hashlib.sha256(data).hexdigest()})
manifest['privacy_scan'] = {'owned_credential_values': len(secrets), 'matches': 0,
                            'private_profiles_dumps_excluded': True}
(target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print({'payloads': len(files), 'credential_matches': 0})
