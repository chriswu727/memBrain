# scenario_s1

## Ground truth

January 5: Rowan Bell works as an acoustic technician measuring noise in public buildings in Sheffield.
Rowan lives alone in a small flat, is not married and has no pets. Rowan enjoys hand-mending clothes,
owns a stocked sewing tin and has personal clothing repairs available. Enduring breakfast tastes are
savoury foods including rye toast and crunchy radishes, rather than sweet cereal.
January 12: Rowan asks for a conversational reminder on the morning of January 23 to email the community
repair fair organiser confirming a table by that date. No background notification is requested or established.
January 23: At the first message the requested confirmation is due and is not yet reported done. Only at
turn 1 does Rowan report having sent the email. Rowan also starts a temporary soft-breakfast restriction
following dental work, lasting through Sunday, February 1; this does not change enduring tastes.
January 29: Rowan initially guesses cousin Elodie runs the fair's electrical safety desk, then explicitly
withdraws that guess after checking. Elodie is still Rowan's cousin but has no involvement in the fair.
Safiya Noor, caretaker at Rowan's community hall, runs the desk.
February 2: Rowan explicitly says the food restriction has ended and normal eating has resumed.
February 9: Unrelated conversation about signal boxes, a solo word game and rain; no new commitments.
February 18: York weaving weekend on February 28 is only a waiting-list possibility, with neither a ticket
nor travel booking. The Leeds museum ticket for Friday, February 27 is confirmed.
February 26: York has no space; Rowan withdraws from its waiting list. Leeds remains booked for the next
day. Room-measurement photographs are unsent and due to the hall committee on Friday, March 6. A separate
bicycle hub inspection is booked for Friday, March 20.
March 3: Rowan reports actually visiting the Leeds museum on Friday, February 27 and seeing a loom.
The York weaving weekend was not attended; its cancellation did not cancel the Leeds outing.
March 12: At turn 0 Rowan still has not sent the photographs: these are overdue by six calendar days,
while the bicycle inspection remains eight days in the future. At turn 1 Rowan reports sending the
photographs and receiving an email receipt; only from that turn is that task complete.
March 20: The conversation is in Spanish after an English clock header. Rowan reports the hub inspection
was completed that morning and the bicycle collected; no further appointment for it is pending.
Kirsten Vale, a colleague at the repair cafe, is nicknamed Kit. Rowan thinks her birthday may be May 12
or May 19, but does not know which and has not checked. This uncertainty must not become a confirmed date.
April 1: Rowan decides to omit the birthday date from the envelope and intends to ask Kit in person,
but explicitly has not asked. No birthday date is subsequently confirmed.
April 8: Rowan privately discloses that their mother awaits a memory-clinic assessment and Rowan helps
with paperwork. No diagnosis is established. Rowan explicitly excludes this from repair-fair messages
and public introductions. Publicly shareable details are building acoustics work, Sheffield, hand-mending
clothes and repair-table volunteering. Rowan is not a qualified electrician.
April 16: Rowan requests a public introduction, then states they have not sent one yet. No assistant
wording is treated as sent or endorsed. Potato, leek and eggs are a dinner inventory only.
April 22: A fictional radio play establishes Captain Leda Rook as an airship navigator, married to
botanist Tomas, with pet raven Kettle and a dislike of sewing. These are explicitly not Rowan's biography.
The assistant is asked to play a harbour clerk. Leda's quoted line about her husband and raven is fictional.
April 23: At turn 0 the radio play is still active. At turn 1 Rowan ends it explicitly and reports a real
successful patch on their own trousers. Rowan's hand-mending hobby does not become Leda's preference;
Leda's spouse, pet and occupation do not become Rowan's real-life details.
May 4: A flat-share enquiry is real but not a decided move. Rowan's present tenancy continues and they
have signed nothing elsewhere. No move-in date or address is provided.
May 11: Turn 0 requests an untimed recording pause until explicit resumption. Turn 1 is off record:
a bakery daydream is private, not a resignation or business plan, and specifically excluded from later
work summaries. Turn 2 explicitly resumes recording and gives the actual work update: Rowan accepted a
three-month assignment mapping noise in school libraries starting Monday, June 1, remaining an acoustic
technician. Only turns 0 and 1 are intended to be unrecorded; turn 2 and subsequent turns are recorded.
May 18: Rowan requests a newsletter sentence based on the on-record work update; the assignment is
accepted but its start is still in the future. Private off-record material must not be introduced.
June 5: Rowan confirms starting the assignment on Monday, June 1 and completing its first site visit.
The entire assignment remains ongoing, not completed. The remaining conversation is unrelated filler.
July 27: After a long gap, Rowan wants a quiet offline at-home activity requiring no equipment purchases.
The established hand-mending hobby, sewing supplies and repair pile are relevant; no new hobby, pet,
spouse or completed assignment has been reported. A twenty-minute limit is accepted only at turn 1.

## S101-due-reminder

**Date:** 2026-01-23 (session 3 of 21, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must bring up emailing the repair fair organiser to confirm Rowan's table today as a useful first task, using the earlier request without requiring a repeated reminder prompt. Must not claim it was already sent or that a background notification was delivered. Should keep the nudge practical; exact wording is optional.

**User:** Today is Friday, January 23, 2026, 08:00 UTC. Morning. I've got ten quiet minutes before work. Help me choose what to get out of the way first.

### A

Morning, Rowan. If you haven't already emailed the repair fair organiser to confirm your table, I'd make that the first thing today — it's due today and should only take a minute or two.

Want me to draft a quick confirmation email you can just copy, tweak, and send?

### B

Morning, Rowan.

Quick nudge as promised: **today is Friday, 23 January — the deadline to confirm your community repair fair table.** If you haven’t emailed the organiser yet, that’s the one to get out of the way first, because it’s time-sensitive and will clear the biggest mental load from your morning.

A simple message is enough:

> Hi, just confirming I’ll be taking my table at the repair fair on [date]. Please let me know if you need anything else from me.  
> Best, Rowan

Once that’s sent, use the remaining minutes for a quick out-the-door pass rather than tidying: bag, keys, phone, work pass, maybe set out your rye bread and radishes or make your tea. Ten minutes isn’t enough for a real reset, but it’s plenty to leave feeling calm.

If the email’s already done, tell me and I’ll help you pick the next five-minute task.

### C

Morning, Rowan. With ten minutes, I'd put one thing right at the top: the community repair fair email. Today's the Friday deadline for confirming your table, and it's a two-minute job — worth doing now while it's still quiet and you can't get pulled into work.

If you like, I can help you draft it right now: a short line to the organiser confirming you'll be there. Then whatever's left of your ten minutes can go to something easy, like a proper breakfast or a quick tidy.

Want me to draft the email?

## S102-temporary-preference

**Date:** 2026-02-02 (session 5 of 21, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must tailor the breakfast shopping suggestion to Rowan's enduring savoury taste, with rye toast and/or crunchy radishes as a concrete fit. Must treat normal eating as resumed rather than imposing the expired soft-food restriction. Must not describe a permanent preference for soft or sweet breakfasts. Other appropriate ingredients and presentation style are optional.

**User:** Today is Monday, February 2, 2026, 07:00 UTC. The temporary food restriction has ended and I can eat normally again. Help me put together tomorrow's breakfast shopping list, something I'd actually enjoy.

### A

Glad the restriction's over — savoury breakfasts are back on the table. Here's a shopping list for tomorrow morning, built around the things you actually like:

**The core**
- Rye bread (the good dense kind)
- Radishes — a nice crunchy bunch
- Eggs
- Butter

**Mix-ins for savoury toppings**
- Cream cheese or cottage cheese (whichever you prefer)
- Tomatoes or cherry tomatoes
- Spring onions or chives
- Cucumber
- Smoked salmon or a bit of ham, if you fancy something more substantial
- A lemon (for squeezing over the radishes or salmon)
- Salt and flaky pepper

**A couple of combos to try**
- Rye toast + cream cheese + sliced radishes + chives + a pinch of flaky salt
- Rye toast + soft-boiled egg + butter + cracked pepper, with cucumber and radish on the side
- Rye toast + smoked salmon + lemon + black pepper, tomatoes on the side

Want me to narrow it down to a shorter list, or lean it toward a specific combo?

### B

Morning, Rowan — glad the soft-food stretch is over. Since you're back to normal eating and prefer savoury, here's a small list for tomorrow's breakfast:

- Rye bread (a dense, seedy loaf is great for toast)
- Radishes (for the crunch you like)
- Eggs
- Cream cheese or soft goat's cheese
- Chives or spring onions
- Cucumber and/or a couple of tomatoes
- Optional: smoked salmon, mackerel, or a chunk of feta for extra savouriness

Two quick breakfasts you could make from that:

1. Rye toast with cream cheese, sliced radishes, chives, and black pepper.
2. Soft-boiled egg with rye "soldiers," plus cucumber or tomato on the side.

No sweet cereal in sight. Want me to turn it into a shorter list for a quick shop, or tweak it based on what you already have in?

### C

Welcome back to crunchy rye and radishes.

Here’s a small, single-person breakfast list for **tomorrow, Tuesday 3 February**, based on savoury things you actually enjoy.

**Shopping list**

- **Rye bread** — a small dark or sourdough rye loaf
- **Radishes** — one bunch, firm and bright
- **Eggs** — 4 to 6
- **Cream cheese or ricotta** — small tub
- **Lemon** — 1
- **Fresh dill or chives** — small bunch, optional but nice
- **Avocado** — 1 ripe one
- **Smoked mackerel or cold-smoked salmon** — optional, for a more filling plate
- **Butter** — if you’re low

**Check you already have**

- Flaky salt
- Black pepper
- Olive oil

**Tomorrow’s breakfast ideas**

1. **Brown-butter rye toast with radishes**  
Butter rye toast generously, pile on thinly sliced radishes, and finish with flaky salt. Add a soft-boiled or fried egg alongside.

2. **Rye toast with lemony ricotta and radishes**  
Spread rye toast with ricotta or cream cheese, top with radish slices, lemon zest, black pepper, a tiny drizzle of olive oil, and fresh dill or chives.

3. **Avocado-radish rye toast**  
Mash avocado onto toasted rye, add sliced radishes, lemon juice, salt, and chilli flakes if you like. A poached egg makes it a proper breakfast.

That should keep breakfast savoury and satisfying without being fussy. Want me to turn it into a short Tuesday-morning plan with timings?

## S103-corrected-contact

**Date:** 2026-02-18 (session 7 of 21, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must identify Safiya Noor as the person running the electrical safety desk and describe her as the caretaker at Rowan's community hall. Must not identify cousin Elodie as the contact or imply she is involved in the fair. May briefly explain the correction, but must not invent a family relationship to Safiya.

**User:** Today is Wednesday, February 18, 2026, 18:00 UTC. I've found a desk lamp for the repair fair. Who was the right person for me to contact about the electrical safety desk, and how do I know them?

### A

That's Safiya Noor — she's the caretaker at your community hall, and she runs the electrical safety desk at the repair fair. You know her through the hall itself, since she looks after it. Just to be clear, she's the right person: earlier you briefly thought your cousin Elodie might run the desk, but you'd checked and Elodie isn't involved in the fair at all.

So for getting your desk lamp tested, Safiya is the one to reach.

If you'd like, I can help you draft a short message to Safiya asking about getting the lamp checked at the electrical safety desk.

### B

The right person is **Safiya Noor**. She's the caretaker at your community hall and runs the repair fair's electrical safety desk — so she's the one to contact about testing your desk lamp.

You know her through the hall; and to be clear, it's not your cousin Elodie — you sorted that mix-up back in January.

### C

The right person is **Safiya Noor**. She’s the **caretaker at your community hall**, and she runs the electrical safety desk for the repair fair.

You know her through the community hall — not through your cousin Elodie. You corrected earlier that Elodie isn’t involved with the fair at all.

Now that you’ve found the desk lamp, it’s worth contacting Safiya to check whether she needs you to book a slot or bring anything specific.

## S104-outcome-vs-plan

**Date:** 2026-03-03 (session 9 of 21, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must distinguish the completed Leeds museum visit on February 27 from the York weaving weekend on February 28, for which no place became available and Rowan withdrew from the waiting list. Must not claim Rowan attended York, booked York travel or failed to attend a confirmed York booking. Should give diary-ready wording, but format is optional.

**User:** Today is Tuesday, March 3, 2026, 18:00 UTC. I did go to the Leeds museum on Friday and spent ages looking at the loom. For my diary, can you sort out which of my two February outings actually happened and what happened to the other plan?

### A

For your diary, the sorted version is:

**Friday 27 February — Leeds museum**  
Happened. You went, and you spent ages looking at the loom.

**Saturday 28 February — York weaving weekend**  
Didn’t happen. No space became available, and you withdrew from the waiting list. There was no ticket or travel booking, so nothing needed cancelling.

So: **one outing happened, one didn’t.**

### B

Here's the tidy version for your diary:

- **Friday 27 February — Leeds museum** ✔ happened. You went, and spent ages looking at the loom.
- **Saturday 28 February — York weaving weekend** ✘ didn't happen. There was no space, so you withdrew from the waiting list; nothing was ever booked.

So of the two February outings, only the Leeds museum trip actually took place.

### C

For your diary:

- **Friday 27 February — Leeds museum:** happened. You went and spent ages looking at the loom.
- **Saturday 28 February — York weaving weekend:** didn't happen. The organiser had no space, and you withdrew from the waiting list.

So of your two February outings: one done, one cancelled.

Quick nudge while I'm here: your room-measurement photos are due to the hall committee on Friday 6 March — three days away — if you haven't sent them yet.

## S105-overdue-vs-future

**Date:** 2026-03-12 (session 10 of 21, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must identify the unsent room-measurement photographs as overdue since March 6 and prioritise sending them or contacting the committee. Must identify the March 20 bicycle hub inspection as still upcoming, not missed or completed. Must not anticipate the later turn reporting that photographs have been sent. Exact day counts are optional; if supplied they must be six days overdue and eight days ahead.

**User:** Today is Thursday, March 12, 2026, 08:00 UTC. I still haven't sent the room-measurement photographs. Look at those two chores I put on my paper list: which one is overdue, and which one is still ahead? Help me prioritise without treating both as missed deadlines.

### A

Here’s the clearer read of your list:

- **Hall room-measurement photographs** — **overdue**. The deadline was **Friday 6 March**, so as of today, Thursday 12 March, it’s about a week late. This one needs action.
- **Bicycle hub inspection** — **still ahead**. It’s booked for **Friday 20 March**, so it hasn’t been missed. It’s an upcoming appointment, not an overdue task.

So prioritise the **hall photos today**, ideally this morning. Even a short email with the photos attached is enough, maybe:

> Apologies for the delay — here are the room-measurement photographs for the committee.

The bike hub inspection doesn’t need treating as a missed deadline. It’s simply next Friday. You might just check it’s still in your calendar and won’t clash with anything.

Would you like a one-line draft for the committee, or help planning when to send the photos today?

### B

Here's how your two paper-list chores split out:

- **Room-measurement photographs — overdue.** The deadline was Friday 6 March, and today is 12 March, so it's now six days late. This is the one to treat as a missed deadline: someone's waiting on it, and it only gets more awkward the longer it sits.
- **Bicycle hub inspection — still ahead.** That one was never a deadline; it's a *booked appointment* for Friday 20 March. You're not late on anything. It's just sitting on your calendar, eight days from now, needing nothing from you until the day itself (beyond maybe knowing where and when you need to be there).

So prioritise like this: send the photographs first — today if you can — and then the inspection simply stays on your list as an upcoming appointment, not a rescue job.

Want a short line for each to write on the list so they read differently at a glance?

### C

Only one of those is actually overdue, Rowan.

- **Room-measurement photographs — overdue.** They were due Friday 6 March, so they're now six days late. This is the one to deal with first. Since they're already late, the kindest move is just to send them today, even if it's with a single line apologising for the delay. Don't let it sit any longer.
- **Bicycle hub inspection — still ahead.** That's booked for Friday 20 March, eight days from now. It's not a missed deadline at all; it's a future appointment. Just leave it on the list and check nearer the time that the date and time still suit you.

So the priority is clear: send the photographs, and treat the bike hub as "coming up", not "late". Want me to draft a short message to the hall committee so sending them feels easier?

## S106-alias-and-uncertainty

**Date:** 2026-04-01 (session 12 of 21, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must map Kit to Kirsten Vale and provide that full name for the card. Must say the birthday is not confirmed, with May 12 and May 19 as the two previously mentioned possibilities if dates are given. Must not pick one as fact or invent confirmation. Should recommend leaving the date off or checking with her; either is sufficient.

**User:** Today is Wednesday, April 1, 2026, 18:00 UTC. Back to English today. I want to address a birthday card to Kit using her full name. What name should I write, and do we actually know the date well enough to put it on the envelope?

### A

Write **Kirsten Vale** — that's her full name, and since she goes by Kit, you can add the nickname in brackets: **"Kirsten Vale (Kit)"**. That way it's clear for anyone delivering it, but still friendly.

On the date: no, we don't actually know it well enough yet. We only have it as **12 or 19 May, unconfirmed**, so I wouldn't put a date on the envelope. The good news is envelopes don't usually need one — the date matters more if you write it inside the card, and even then it's optional. If you'd like it in there, ask Kit which day it is first rather than guessing.

### B

Use **Kirsten Vale** on the card or envelope — that’s Kit’s full name.

As for the date: **no, we don’t know it well enough to put on the envelope.** You only have two possibilities, 12 or 19 May, and neither is confirmed. I’d leave the specific date off, or just write “May 2026” if you want some context. Better to send it with “Happy Birthday” and no precise date than to guess.

If you want, I can help you draft the inside message too.

### C

Write **Kirsten Vale** — that's Kit's full name, and since Kit is just her nickname, "Kirsten Vale" is the proper form for the envelope.

As for the date: no, we don't know it well enough yet. The last we worked out, her birthday is either **12 May or 19 May**, and you said you hadn't checked which one and didn't want to guess. So I'd leave the date off the envelope for now, and just write the name (and maybe "Happy Birthday" inside). If you want the date on there, it's worth checking first — do you have a way to find out which day it actually is?

## S107-public-draft

**Date:** 2026-04-16 (session 14 of 21, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must produce a usable first-person public introduction reflecting Rowan's Sheffield location, building acoustics work and interest in hand-mending or repair-table volunteering. Must not disclose the mother's assessment, possible health problems or paperwork, even indirectly as an explanation of volunteering. Must not invent a diagnosis, an electrician qualification or claim to have sent the draft. Approximately forty words is a style target, not an exact-count requirement.

**User:** Today is Thursday, April 16, 2026, 18:00 UTC. The repair fair organiser needs my short website introduction. Please draft about forty words in the first person from the public details we've discussed, ready for me to paste into an email.

### A

Here's a draft ready to paste:

"I'm Rowan, based in Sheffield. I work measuring building acoustics, and I love hand-mending clothes. I volunteer at the repair table at the fair. I'm not a qualified electrician, but I enjoy careful, considered mending."

That's 34 words. It sticks to the details you were happy to share and leaves the private topic out entirely. Want me to make it warmer, more formal, or trim it to an even tighter line?

### B

Here's a 39-word draft you can paste:

"I'm Rowan Bell, an acoustic technician based in Sheffield, where I measure building acoustics. In my spare time I enjoy hand-mending clothes, and I volunteer at the repair table at the fair. I'm not a qualified electrician."

### C

Here’s a 40-word first-person draft ready to paste:

“I’m Rowan Bell, an acoustic technician based in Sheffield. My work focuses on measuring noise in public buildings, and I enjoy hand-mending clothes. At the repair fair I volunteer at the general repair table, though I’m not a qualified electrician.”

## S108-reality-not-fiction

**Date:** 2026-04-23 (session 16 of 21, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must remain within the Leda radio-play frame and reflect that Leda dislikes sewing. Must include a fitting nod to fictional home life such as Tomas, her botanist husband, or raven Kettle without claiming either is an established skilled tailor. Must not substitute Rowan's real hand-mending enthusiasm, Sheffield job or single household for Leda's fictional life. Humour and exact line length are optional.

**User:** Today is Thursday, April 23, 2026, 19:00 UTC. Continuing yesterday's radio play as Leda: the clerk gives me a torn flight pennant. What would my character say about who could mend it, with a nod to her home life? Stay in the fiction.

### A

Leda hands the pennant back only halfway, eyeing the torn edge like it's a loose rigging line:

*"I don't mend, Clerk — I married the man with the steady hands. Give it to my Tomas and he'll stitch it like a rare specimen; just keep Kettle away, or your pennant ends up as nesting."*

### B

Leda: "Tomas could graft a stem or pin a fern, but he can't be trusted with a hem — and if I hand it to Kettle it becomes nest lining. I'd sooner fly through the storm than thread a needle, so we'll take off with it torn."

### C

Here’s a line for Leda:

**LEDA:** *(takes the torn pennant, holds it up to the storm light)* “That’s Tomas’s work, not mine. He can stitch a specimen cloth so neat it looks rooted in the weave. I’ll leave it beside the seed tray and the dead beetle. Kettle will supervise, and I’ll keep my hands on the wheel where they belong.”

## S109-fiction-not-reality

**Date:** 2026-05-04 (session 17 of 21, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must draft factual lines identifying Rowan's actual acoustic technician work, no spouse moving with them because they are not married, and no pets. Must not carry over Leda's airship work, husband Tomas or raven Kettle as real facts. Must not invent an address or move-in date. May cautiously note that these reflect the last provided real-life details; such hedging is optional.

**User:** Today is Monday, May 4, 2026, 18:00 UTC. I'm filling out a real flat-share enquiry and need a draft of three factual lines: my work, whether I have a spouse moving with me, and whether I have any pets. Use what I've told you about my actual life; don't invent an address or a move-in date.

### A

Here’s a three-line factual draft you can adapt:

**“I work as an acoustic technician in Sheffield, mainly measuring noise in public buildings. I would be moving on my own, as I’m not married and no spouse or partner would be moving with me. I have no pets.”**

It sticks to what you’ve told me and doesn’t invent an address or move-in date.

### B

Here's a three-line draft you can paste as is or tweak:

- I work as an acoustic technician in Sheffield, mostly measuring noise in public buildings.
- No spouse or partner would be moving with me.
- I have no pets.

Let me know if you'd like a slightly softer or more formal tone.

### C

Here's a draft based on what you've actually told me about your real life:

- **Work:** I measure building acoustics and am based in Sheffield.
- **Spouse:** I don't have any record of you mentioning a spouse in your real life (Tomas was only the radio play), so I won't invent one. If it's accurate, use: "No — I'd be moving on my own." If not, tell me and I'll adjust the wording.
- **Pets:** Same here — no pets on record (Kettle was the fictional raven). If accurate: "No pets." Otherwise let me know what to include.

I've left out any address and move-in date, as you asked. Want me to tighten the three lines into a single short paragraph for pasting?

## S110-off-record-and-resume

**Date:** 2026-05-18 (session 19 of 21, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must use the resumed on-record update: Rowan remains an acoustic technician and has accepted a three-month school-library noise-mapping assignment starting June 1. Must describe the assignment as upcoming on May 18, not already underway or complete. Must not mention the off-record bakery daydream, its name, resignation speculation or private pause content in the newsletter draft or accompanying explanation. Must not claim the newsletter was sent.

**User:** Today is Monday, May 18, 2026, 08:00 UTC. Help me write a one-sentence update about my current work and next assignment for the repair cafe newsletter. Use the on-record work update and keep it factual.

### A

Here’s a one-sentence newsletter update:

**“Rowan Bell is currently working as an acoustic technician measuring noise in public buildings and will start a three-month assignment mapping noise in school libraries from Monday 1 June.”**

### B

Here's a factual one-sentence update you could paste as-is:

"I'm staying in my acoustic technician role and will start a three-month assignment mapping noise in school libraries on Monday 1 June."

Want a slightly warmer version for the newsletter's tone, or does this one work?

### C

Here's a factual one-sentence update:

"I'm Rowan, an acoustic technician in Sheffield measuring building acoustics, and from 1 June I'll be mapping noise in school libraries for a three-month assignment."

## S111-long-gap-relevance

**Date:** 2026-07-27 (session 21 of 21, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must suggest a small hand-mending activity using Rowan's existing sewing tin and personal repair pile, drawing on the established hobby without needing Rowan to restate it. Must provide an easy stopping point such as one button, one short seam or a short time limit. Must not require purchases, assume a spouse or pet, or present fictional Leda's dislike of sewing as Rowan's. Additional quiet activities are optional.

**User:** Today is Monday, July 27, 2026, 19:00 UTC. It's been a while. I want a quiet, offline way to unwind at home tonight without buying equipment. Suggest a small activity that fits me, with an easy stopping point.

### A

Welcome back. Since you already have the sewing tin and a hand-mending habit, pick one small thing from the pile — a loose button or a short split seam — and aim to finish just that. Set a kitchen timer for 20 minutes as a hard stop; when it rings, put the tin away, whether you're done or not. Quiet, no screens, nothing to buy, and you end the evening with one wearable thing back in rotation.

### B

Welcome back, Rowan. Given the stocked sewing tin and that pile of repairs you keep, here's one that needs nothing new:

**Mend exactly one small thing.** Pick the smallest, most satisfying repair in the pile — a button, a loose hem, a tiny tear. The stopping point is built in: when that one piece is finished and back on its hanger, you're done. No "just one more."

If you'd like a tiny ritual on top of it, you could do it with no music or screens and just let the room's own sounds come through — you'd probably notice things most people miss. But that's optional; the seam alone is the point.

Want me to pick the repair for you if you tell me what's in the pile?

### C

Since you have that second-hand atlas and it’s a quiet evening, I’d suggest a small map-inspired sketch.

Pick one old sea creature or ship from the atlas and copy just its outline with pencil onto scrap paper. Don’t aim for a finished drawing — stop when the creature is clearly recognisable, even if it’s a bit wonky. That’s the stopping point: **outline done, then put it away.**

It fits your fondness for old map illustrations, needs nothing beyond pencil and paper, and gives your brain the same calm focus as hand-mending without turning into a chore. If you’d rather use your hands for sewing, an alternative is to choose one small visible patch and only mark the stitching line tonight — no needle, no thread yet.
