import pytest
from membrain import host
from membrain.adapters.chatbot import ChatMemory, Speaker

@pytest.mark.parametrize('prompt', [
    'Off the record: the rehearsal prop is a cobalt paper kite. Do not keep this in memory.',
    '请不要记录这一段：排练道具是一只钴蓝色纸风筝。只在这次聊天里说说，不要保存。',
])
def test_tool_free_adapter_must_not_store_explicit_off_record_request(tmp_path, monkeypatch, prompt):
    monkeypatch.setattr(host, 'ready_client', lambda *args, **kwargs: None)
    monkeypatch.setattr(host, 'start_in_background', lambda *args, **kwargs: None)
    memory = ChatMemory(tmp_path, tools=None)
    speaker = Speaker('public-recording-regression', 'synthetic-user')
    memory.context(speaker, prompt, session='synthetic-session', turn_id='private-turn')
    memory.record(speaker, 'We can discuss it without keeping it.', session='synthetic-session',
                  turn_id='private-turn', prompt=prompt)
    stored = [path for path in tmp_path.rglob('*') if path.is_file()
              and prompt in path.read_text(errors='replace')]
    assert not stored, 'An explicit off-record request reached local persistent storage.'
