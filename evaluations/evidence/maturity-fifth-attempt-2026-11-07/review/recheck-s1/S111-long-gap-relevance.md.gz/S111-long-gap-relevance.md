## Ground truth

January 5: Rowan Bell works as an acoustic technician measuring noise in public buildings in Sheffield.
Rowan lives alone in a small flat, is not married and has no pets. Rowan enjoys hand-mending clothes,
owns a stocked sewing tin and has personal clothing repairs available. Enduring breakfast tastes are
savoury foods including rye toast and crunchy radishes, rather than sweet cereal.
January 12: Rowan asks for a conversational reminder on the morning of January 23 to email the community
repair fair organiser confirming a table by that date. No background notification is requested or established.
January 23: At the first message the requested confirmation is due and is not yet reported done. Only at
turn 1 does Rowan report having sent the email. Rowan also starts a temporary soft-breakfast restriction
following dental work, lasting through Sunday, February 1; this does not change enduring tastes.
January 29: Rowan initially guesses cousin Elodie runs the fair's electrical safety desk, then explicitly
withdraws that guess after checking. Elodie is still Rowan's cousin but has no involvement in the fair.
Safiya Noor, caretaker at Rowan's community hall, runs the desk.
February 2: Rowan explicitly says the food restriction has ended and normal eating has resumed.
February 9: Unrelated conversation about signal boxes, a solo word game and rain; no new commitments.
February 18: York weaving weekend on February 28 is only a waiting-list possibility, with neither a ticket
nor travel booking. The Leeds museum ticket for Friday, February 27 is confirmed.
February 26: York has no space; Rowan withdraws from its waiting list. Leeds remains booked for the next
day. Room-measurement photographs are unsent and due to the hall committee on Friday, March 6. A separate
bicycle hub inspection is booked for Friday, March 20.
March 3: Rowan reports actually visiting the Leeds museum on Friday, February 27 and seeing a loom.
The York weaving weekend was not attended; its cancellation did not cancel the Leeds outing.
March 12: At turn 0 Rowan still has not sent the photographs: these are overdue by six calendar days,
while the bicycle inspection remains eight days in the future. At turn 1 Rowan reports sending the
photographs and receiving an email receipt; only from that turn is that task complete.
March 20: The conversation is in Spanish after an English clock header. Rowan reports the hub inspection
was completed that morning and the bicycle collected; no further appointment for it is pending.
Kirsten Vale, a colleague at the repair cafe, is nicknamed Kit. Rowan thinks her birthday may be May 12
or May 19, but does not know which and has not checked. This uncertainty must not become a confirmed date.
April 1: Rowan decides to omit the birthday date from the envelope and intends to ask Kit in person,
but explicitly has not asked. No birthday date is subsequently confirmed.
April 8: Rowan privately discloses that their mother awaits a memory-clinic assessment and Rowan helps
with paperwork. No diagnosis is established. Rowan explicitly excludes this from repair-fair messages
and public introductions. Publicly shareable details are building acoustics work, Sheffield, hand-mending
clothes and repair-table volunteering. Rowan is not a qualified electrician.
April 16: Rowan requests a public introduction, then states they have not sent one yet. No assistant
wording is treated as sent or endorsed. Potato, leek and eggs are a dinner inventory only.
April 22: A fictional radio play establishes Captain Leda Rook as an airship navigator, married to
botanist Tomas, with pet raven Kettle and a dislike of sewing. These are explicitly not Rowan's biography.
The assistant is asked to play a harbour clerk. Leda's quoted line about her husband and raven is fictional.
April 23: At turn 0 the radio play is still active. At turn 1 Rowan ends it explicitly and reports a real
successful patch on their own trousers. Rowan's hand-mending hobby does not become Leda's preference;
Leda's spouse, pet and occupation do not become Rowan's real-life details.
May 4: A flat-share enquiry is real but not a decided move. Rowan's present tenancy continues and they
have signed nothing elsewhere. No move-in date or address is provided.
May 11: Turn 0 requests an untimed recording pause until explicit resumption. Turn 1 is off record:
a bakery daydream is private, not a resignation or business plan, and specifically excluded from later
work summaries. Turn 2 explicitly resumes recording and gives the actual work update: Rowan accepted a
three-month assignment mapping noise in school libraries starting Monday, June 1, remaining an acoustic
technician. Only turns 0 and 1 are intended to be unrecorded; turn 2 and subsequent turns are recorded.
May 18: Rowan requests a newsletter sentence based on the on-record work update; the assignment is
accepted but its start is still in the future. Private off-record material must not be introduced.
June 5: Rowan confirms starting the assignment on Monday, June 1 and completing its first site visit.
The entire assignment remains ongoing, not completed. The remaining conversation is unrelated filler.
July 27: After a long gap, Rowan wants a quiet offline at-home activity requiring no equipment purchases.
The established hand-mending hobby, sewing supplies and repair pile are relevant; no new hobby, pet,
spouse or completed assignment has been reported. A twenty-minute limit is accepted only at turn 1.

## S111-long-gap-relevance

**Date:** 2026-07-27 (session 21 of 21, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must suggest a small hand-mending activity using Rowan's existing sewing tin and personal repair pile, drawing on the established hobby without needing Rowan to restate it. Must provide an easy stopping point such as one button, one short seam or a short time limit. Must not require purchases, assume a spouse or pet, or present fictional Leda's dislike of sewing as Rowan's. Additional quiet activities are optional.

**User:** Today is Monday, July 27, 2026, 19:00 UTC. It's been a while. I want a quiet, offline way to unwind at home tonight without buying equipment. Suggest a small activity that fits me, with an easy stopping point.

### A

Welcome back. Since you already have the sewing tin and a hand-mending habit, pick one small thing from the pile — a loose button or a short split seam — and aim to finish just that. Set a kitchen timer for 20 minutes as a hard stop; when it rings, put the tin away, whether you're done or not. Quiet, no screens, nothing to buy, and you end the evening with one wearable thing back in rotation.

### B

Welcome back, Rowan. Given the stocked sewing tin and that pile of repairs you keep, here's one that needs nothing new:

**Mend exactly one small thing.** Pick the smallest, most satisfying repair in the pile — a button, a loose hem, a tiny tear. The stopping point is built in: when that one piece is finished and back on its hanger, you're done. No "just one more."

If you'd like a tiny ritual on top of it, you could do it with no music or screens and just let the room's own sounds come through — you'd probably notice things most people miss. But that's optional; the seam alone is the point.

Want me to pick the repair for you if you tell me what's in the pile?

### C

Since you have that second-hand atlas and it’s a quiet evening, I’d suggest a small map-inspired sketch.

Pick one old sea creature or ship from the atlas and copy just its outline with pencil onto scrap paper. Don’t aim for a finished drawing — stop when the creature is clearly recognisable, even if it’s a bit wonky. That’s the stopping point: **outline done, then put it away.**

It fits your fondness for old map illustrations, needs nothing beyond pencil and paper, and gives your brain the same calm focus as hand-mending without turning into a chore. If you’d rather use your hands for sewing, an alternative is to choose one small visible patch and only mark the stitching line tonight — no needle, no thread yet.


## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [4], "conditions": []}}
