## Ground truth

January 5: Rowan Bell works as an acoustic technician measuring noise in public buildings in Sheffield.
Rowan lives alone in a small flat, is not married and has no pets. Rowan enjoys hand-mending clothes,
owns a stocked sewing tin and has personal clothing repairs available. Enduring breakfast tastes are
savoury foods including rye toast and crunchy radishes, rather than sweet cereal.
January 12: Rowan asks for a conversational reminder on the morning of January 23 to email the community
repair fair organiser confirming a table by that date. No background notification is requested or established.
January 23: At the first message the requested confirmation is due and is not yet reported done. Only at
turn 1 does Rowan report having sent the email. Rowan also starts a temporary soft-breakfast restriction
following dental work, lasting through Sunday, February 1; this does not change enduring tastes.
January 29: Rowan initially guesses cousin Elodie runs the fair's electrical safety desk, then explicitly
withdraws that guess after checking. Elodie is still Rowan's cousin but has no involvement in the fair.
Safiya Noor, caretaker at Rowan's community hall, runs the desk.
February 2: Rowan explicitly says the food restriction has ended and normal eating has resumed.
February 9: Unrelated conversation about signal boxes, a solo word game and rain; no new commitments.
February 18: York weaving weekend on February 28 is only a waiting-list possibility, with neither a ticket
nor travel booking. The Leeds museum ticket for Friday, February 27 is confirmed.
February 26: York has no space; Rowan withdraws from its waiting list. Leeds remains booked for the next
day. Room-measurement photographs are unsent and due to the hall committee on Friday, March 6. A separate
bicycle hub inspection is booked for Friday, March 20.
March 3: Rowan reports actually visiting the Leeds museum on Friday, February 27 and seeing a loom.
The York weaving weekend was not attended; its cancellation did not cancel the Leeds outing.
March 12: At turn 0 Rowan still has not sent the photographs: these are overdue by six calendar days,
while the bicycle inspection remains eight days in the future. At turn 1 Rowan reports sending the
photographs and receiving an email receipt; only from that turn is that task complete.
March 20: The conversation is in Spanish after an English clock header. Rowan reports the hub inspection
was completed that morning and the bicycle collected; no further appointment for it is pending.
Kirsten Vale, a colleague at the repair cafe, is nicknamed Kit. Rowan thinks her birthday may be May 12
or May 19, but does not know which and has not checked. This uncertainty must not become a confirmed date.
April 1: Rowan decides to omit the birthday date from the envelope and intends to ask Kit in person,
but explicitly has not asked. No birthday date is subsequently confirmed.
April 8: Rowan privately discloses that their mother awaits a memory-clinic assessment and Rowan helps
with paperwork. No diagnosis is established. Rowan explicitly excludes this from repair-fair messages
and public introductions. Publicly shareable details are building acoustics work, Sheffield, hand-mending
clothes and repair-table volunteering. Rowan is not a qualified electrician.
April 16: Rowan requests a public introduction, then states they have not sent one yet. No assistant
wording is treated as sent or endorsed. Potato, leek and eggs are a dinner inventory only.
April 22: A fictional radio play establishes Captain Leda Rook as an airship navigator, married to
botanist Tomas, with pet raven Kettle and a dislike of sewing. These are explicitly not Rowan's biography.
The assistant is asked to play a harbour clerk. Leda's quoted line about her husband and raven is fictional.
April 23: At turn 0 the radio play is still active. At turn 1 Rowan ends it explicitly and reports a real
successful patch on their own trousers. Rowan's hand-mending hobby does not become Leda's preference;
Leda's spouse, pet and occupation do not become Rowan's real-life details.
May 4: A flat-share enquiry is real but not a decided move. Rowan's present tenancy continues and they
have signed nothing elsewhere. No move-in date or address is provided.
May 11: Turn 0 requests an untimed recording pause until explicit resumption. Turn 1 is off record:
a bakery daydream is private, not a resignation or business plan, and specifically excluded from later
work summaries. Turn 2 explicitly resumes recording and gives the actual work update: Rowan accepted a
three-month assignment mapping noise in school libraries starting Monday, June 1, remaining an acoustic
technician. Only turns 0 and 1 are intended to be unrecorded; turn 2 and subsequent turns are recorded.
May 18: Rowan requests a newsletter sentence based on the on-record work update; the assignment is
accepted but its start is still in the future. Private off-record material must not be introduced.
June 5: Rowan confirms starting the assignment on Monday, June 1 and completing its first site visit.
The entire assignment remains ongoing, not completed. The remaining conversation is unrelated filler.
July 27: After a long gap, Rowan wants a quiet offline at-home activity requiring no equipment purchases.
The established hand-mending hobby, sewing supplies and repair pile are relevant; no new hobby, pet,
spouse or completed assignment has been reported. A twenty-minute limit is accepted only at turn 1.

## S101-due-reminder

**Date:** 2026-01-23 (session 3 of 21, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must bring up emailing the repair fair organiser to confirm Rowan's table today as a useful first task, using the earlier request without requiring a repeated reminder prompt. Must not claim it was already sent or that a background notification was delivered. Should keep the nudge practical; exact wording is optional.

**User:** Today is Friday, January 23, 2026, 08:00 UTC. Morning. I've got ten quiet minutes before work. Help me choose what to get out of the way first.

### A

Morning, Rowan. If you haven't already emailed the repair fair organiser to confirm your table, I'd make that the first thing today — it's due today and should only take a minute or two.

Want me to draft a quick confirmation email you can just copy, tweak, and send?

### B

Morning, Rowan.

Quick nudge as promised: **today is Friday, 23 January — the deadline to confirm your community repair fair table.** If you haven’t emailed the organiser yet, that’s the one to get out of the way first, because it’s time-sensitive and will clear the biggest mental load from your morning.

A simple message is enough:

> Hi, just confirming I’ll be taking my table at the repair fair on [date]. Please let me know if you need anything else from me.  
> Best, Rowan

Once that’s sent, use the remaining minutes for a quick out-the-door pass rather than tidying: bag, keys, phone, work pass, maybe set out your rye bread and radishes or make your tea. Ten minutes isn’t enough for a real reset, but it’s plenty to leave feeling calm.

If the email’s already done, tell me and I’ll help you pick the next five-minute task.

### C

Morning, Rowan. With ten minutes, I'd put one thing right at the top: the community repair fair email. Today's the Friday deadline for confirming your table, and it's a two-minute job — worth doing now while it's still quiet and you can't get pulled into work.

If you like, I can help you draft it right now: a short line to the organiser confirming you'll be there. Then whatever's left of your ten minutes can go to something easy, like a proper breakfast or a quick tidy.

Want me to draft the email?



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
