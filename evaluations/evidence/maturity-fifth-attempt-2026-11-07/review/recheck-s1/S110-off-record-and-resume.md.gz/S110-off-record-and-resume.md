## Ground truth

January 5: Rowan Bell works as an acoustic technician measuring noise in public buildings in Sheffield.
Rowan lives alone in a small flat, is not married and has no pets. Rowan enjoys hand-mending clothes,
owns a stocked sewing tin and has personal clothing repairs available. Enduring breakfast tastes are
savoury foods including rye toast and crunchy radishes, rather than sweet cereal.
January 12: Rowan asks for a conversational reminder on the morning of January 23 to email the community
repair fair organiser confirming a table by that date. No background notification is requested or established.
January 23: At the first message the requested confirmation is due and is not yet reported done. Only at
turn 1 does Rowan report having sent the email. Rowan also starts a temporary soft-breakfast restriction
following dental work, lasting through Sunday, February 1; this does not change enduring tastes.
January 29: Rowan initially guesses cousin Elodie runs the fair's electrical safety desk, then explicitly
withdraws that guess after checking. Elodie is still Rowan's cousin but has no involvement in the fair.
Safiya Noor, caretaker at Rowan's community hall, runs the desk.
February 2: Rowan explicitly says the food restriction has ended and normal eating has resumed.
February 9: Unrelated conversation about signal boxes, a solo word game and rain; no new commitments.
February 18: York weaving weekend on February 28 is only a waiting-list possibility, with neither a ticket
nor travel booking. The Leeds museum ticket for Friday, February 27 is confirmed.
February 26: York has no space; Rowan withdraws from its waiting list. Leeds remains booked for the next
day. Room-measurement photographs are unsent and due to the hall committee on Friday, March 6. A separate
bicycle hub inspection is booked for Friday, March 20.
March 3: Rowan reports actually visiting the Leeds museum on Friday, February 27 and seeing a loom.
The York weaving weekend was not attended; its cancellation did not cancel the Leeds outing.
March 12: At turn 0 Rowan still has not sent the photographs: these are overdue by six calendar days,
while the bicycle inspection remains eight days in the future. At turn 1 Rowan reports sending the
photographs and receiving an email receipt; only from that turn is that task complete.
March 20: The conversation is in Spanish after an English clock header. Rowan reports the hub inspection
was completed that morning and the bicycle collected; no further appointment for it is pending.
Kirsten Vale, a colleague at the repair cafe, is nicknamed Kit. Rowan thinks her birthday may be May 12
or May 19, but does not know which and has not checked. This uncertainty must not become a confirmed date.
April 1: Rowan decides to omit the birthday date from the envelope and intends to ask Kit in person,
but explicitly has not asked. No birthday date is subsequently confirmed.
April 8: Rowan privately discloses that their mother awaits a memory-clinic assessment and Rowan helps
with paperwork. No diagnosis is established. Rowan explicitly excludes this from repair-fair messages
and public introductions. Publicly shareable details are building acoustics work, Sheffield, hand-mending
clothes and repair-table volunteering. Rowan is not a qualified electrician.
April 16: Rowan requests a public introduction, then states they have not sent one yet. No assistant
wording is treated as sent or endorsed. Potato, leek and eggs are a dinner inventory only.
April 22: A fictional radio play establishes Captain Leda Rook as an airship navigator, married to
botanist Tomas, with pet raven Kettle and a dislike of sewing. These are explicitly not Rowan's biography.
The assistant is asked to play a harbour clerk. Leda's quoted line about her husband and raven is fictional.
April 23: At turn 0 the radio play is still active. At turn 1 Rowan ends it explicitly and reports a real
successful patch on their own trousers. Rowan's hand-mending hobby does not become Leda's preference;
Leda's spouse, pet and occupation do not become Rowan's real-life details.
May 4: A flat-share enquiry is real but not a decided move. Rowan's present tenancy continues and they
have signed nothing elsewhere. No move-in date or address is provided.
May 11: Turn 0 requests an untimed recording pause until explicit resumption. Turn 1 is off record:
a bakery daydream is private, not a resignation or business plan, and specifically excluded from later
work summaries. Turn 2 explicitly resumes recording and gives the actual work update: Rowan accepted a
three-month assignment mapping noise in school libraries starting Monday, June 1, remaining an acoustic
technician. Only turns 0 and 1 are intended to be unrecorded; turn 2 and subsequent turns are recorded.
May 18: Rowan requests a newsletter sentence based on the on-record work update; the assignment is
accepted but its start is still in the future. Private off-record material must not be introduced.
June 5: Rowan confirms starting the assignment on Monday, June 1 and completing its first site visit.
The entire assignment remains ongoing, not completed. The remaining conversation is unrelated filler.
July 27: After a long gap, Rowan wants a quiet offline at-home activity requiring no equipment purchases.
The established hand-mending hobby, sewing supplies and repair pile are relevant; no new hobby, pet,
spouse or completed assignment has been reported. A twenty-minute limit is accepted only at turn 1.

## S110-off-record-and-resume

**Date:** 2026-05-18 (session 19 of 21, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must use the resumed on-record update: Rowan remains an acoustic technician and has accepted a three-month school-library noise-mapping assignment starting June 1. Must describe the assignment as upcoming on May 18, not already underway or complete. Must not mention the off-record bakery daydream, its name, resignation speculation or private pause content in the newsletter draft or accompanying explanation. Must not claim the newsletter was sent.

**User:** Today is Monday, May 18, 2026, 08:00 UTC. Help me write a one-sentence update about my current work and next assignment for the repair cafe newsletter. Use the on-record work update and keep it factual.

### A

Here’s a one-sentence newsletter update:

**“Rowan Bell is currently working as an acoustic technician measuring noise in public buildings and will start a three-month assignment mapping noise in school libraries from Monday 1 June.”**

### B

Here's a factual one-sentence update you could paste as-is:

"I'm staying in my acoustic technician role and will start a three-month assignment mapping noise in school libraries on Monday 1 June."

Want a slightly warmer version for the newsletter's tone, or does this one work?

### C

Here's a factual one-sentence update:

"I'm Rowan, an acoustic technician in Sheffield measuring building acoustics, and from 1 June I'll be mapping noise in school libraries for a three-month assignment."



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
