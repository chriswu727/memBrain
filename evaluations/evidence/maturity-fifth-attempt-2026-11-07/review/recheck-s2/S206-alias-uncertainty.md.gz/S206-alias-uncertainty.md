## Ground truth

January 12, 2026: The user is Xu Shuangning (许霜宁), lives in Quanzhou, does packaging illustration for small shops, and sometimes volunteers at a community book-repair corner on Saturdays. Their enduring tea preference is unsweetened jasmine tea, hot or cold. Hot drinks only are a temporary consequence of lacking a refrigerator while moving art supplies, ending after January 25. The user asks for an in-chat reminder on the morning of January 20 to send the paper procurement list to Aunt Zhou (周姨), who will compile it at noon. No outbound sending or proactive notification outside a chat is authorized or reported.
January 16: Rain, an orange-candy packaging design, color choices, and reading preferences form an unrelated conversation. No completion of the paper task is reported here.
January 20: The first message opens morning planning, when the previously requested reminder is due. Only in turn 1 does the user report having personally sent the list and received acknowledgement; from then on that task is complete.
January 27: The refrigerator is back home. The user initially reads an old note as placing the spare cutting mat in locker six, then corrects this within the session: the administrator confirmed locker nine; locker six belongs to the neighboring florist. The user also withdraws an earlier assumption that Sister Liang (梁姐) had agreed to help on Saturday: she did not agree and must not be counted as confirmed help. No actual assistant action is asserted.
February 7: The drink request is after the temporary hot-drink restriction expired. The user asks for a volunteer note using the corrected locker and unconfirmed helper status. A February 15 printmaking workshop is only a tentative possibility: the user saved a registration page, has neither registered nor paid, and must first assess workload.
February 22: The user reports completing organization of the art-supply drawers on February 18. There has been no report of attending, booking, canceling, or missing the printmaking workshop; the past date alone cannot establish an outcome. Two tasks are explicitly still undone when introduced: material reimbursement submission due February 27 and mailing a postcard to a cousin due March 12.
March 3: The user explicitly says they have not provided further updates about those two tasks. The reimbursement's original deadline has passed; the postcard deadline remains in the future. Neither task's actual completion status can be inferred from silence. On March 3, the user reports having delivered the packaging illustration they worked on the previous day; the exact delivery date is not stated, and client feedback and acceptance remain outstanding.
March 18: This whole session is in English. Yao Yu (姚屿), called 阿屿, is the user's friend and the owner of the print shop they use. Old Harbor is the English nickname used for 塔下旧仓, a warehouse venue, not a boat terminal. A possible pop-up has two candidate dates, April 11 or April 18; the organizer has not chosen. Yao Yu is checking the venue. The user has neither booked a stall nor paid a deposit.
April 2: No new confirmation has arrived in the conversation before the progress-summary request. Venue alias resolution is known, while the event date and stall booking remain unconfirmed.
April 12: The user privately discloses owing a cousin 18,000 yuan for rent advanced for family the prior year. It may inform private conversation but must not be included or hinted at in drafts for clients, neighbors, or public introductions, including any insinuation of urgent financial need. Authorized public introduction material is packaging illustration, community book repair, and an interest in drawing plants in local streets.
April 28: A pastry-shop owner requests a forwardable introduction. The user subsequently says sketches are planned but pricing is not agreed; the new project is not signed. No later message confirms a contract.
May 5: A clearly fictional role-play character, Luan You (栾柚), lives at a mountain observatory, repairs clocks, loves sweet cocoa, and has a black cat named Rivet (铆钉). The assistant is invited to play a tool-delivery messenger. These attributes are explicitly not the user's real-life profile. The user exits role-play in turn 3. The user has not confirmed owning any cat in real life.
May 24: The request is for real-life facts: Quanzhou, packaging illustration, unsweetened jasmine tea with no permanent temperature restriction. Cat ownership remains unknown. Fictional mountain residence, clock repair, cocoa preference, and the cat must not become user facts.
June 7: The user explicitly resumes the earlier observatory role-play with the same fictional settings and asks for an in-character messenger scene without new background. The character's drink, location, and animal come from that story, not from the user's real tea, city, work, or private financial history. The user exits role-play in turn 2 and states that in real life they only went to the vegetable market that day.
June 21: Turn 0 requests an untimed recording pause until an explicit resume, and prohibits keeping or reusing the following private material. Turn 1 gives the off-record anonymous audio-writing alias 北极桃 and pilot title 《陶罐里的回声》; turn 2 remains explicitly off record and discusses the user's mixed feelings. These positions must not become material for later summaries or introductions. Turn 3 explicitly resumes normal recording and gives a distinct, public work arrangement: August 14 at 15:00 UTC, an online packaging-sketch review with the owner of 青篆纸店, requiring three botanical line drawings. This is a scheduled future meeting, not a completed event, and is not part of the off-record project. Turn 4 is ordinary recorded household conversation.
August 9: After the long gap, a portfolio introduction must use appropriate public information and omit the off-record project and private debt. Tentative or unsigned work must not become accomplishments. The later appointment question concerns the normally recorded post-resumption paper-shop meeting, still in the future. The user has provided no intervening update or cancellation. User gratitude or follow-up text must not be treated as evidence of any particular earlier assistant reply or successful tool action.

## S206-alias-uncertainty

**Date:** 2026-04-02 (session 9 of 16, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must resolve 阿屿 to 姚屿/Yao Yu and Old Harbor to 塔下旧仓, a warehouse venue. Must preserve April 11 versus April 18 as unresolved candidate event dates and the user's stall as not booked, with no deposit paid. Must not invent a final date, confirmed stall, or port/boat-terminal location. Should produce a usable progress note; bilingual formatting is optional.

**User:** Today is Thursday, April 2, 2026, 11:00 UTC. 阿屿让我给可能一起摆摊的朋友写个进度说明。Old Harbor到底是哪儿、活动日子定了没有、我是不是已经有摊位了？帮我按我们聊过的事实写，没确认的就直说。

### A

可以，先给你把“哪些算事实、哪些还没定”分清，再给你一段能直接发给朋友的进度说明。

**先对一下事实：**
- Old Harbor 就是**塔下旧仓**，是个**仓库**，不是码头/船运码头。阿屿用英文说“Old Harbor”时指的是它。
- 活动日期**还没定**：主办方提过 **4月11日或4月18日**，但没选具体哪天。
- 你**还没有订摊位、没付定金**；阿屿目前只是在看场地，场地本身也还没确认下来。

**可以这样写（发朋友）：**

> 进度同步一下：场地其实是“塔下旧仓”（阿屿说的 Old Harbor 就是这里，是个仓库，不是码头）。活动日期还没定，主办方提了4月11日和4月18日两个选项，暂时没确定。摊位我还没订、定金也没付，阿屿正在看场地。等有确切消息我再同步。

如果你想让语气更软一点，开头可以加一句“先跟你说下目前的实际进度”，把“其实”去掉也行。核心原则就是：**场地名、日期、摊位，这三样都别写成已确定**。

### B

可以这样写，按你们目前确认过的事实，没定的不替你打包票：

---

**摆摊进度说明（截至 4 月 2 日）**

1. **Old Harbor 是哪里**  
   阿屿说的 Old Harbor，实际中文名是“**塔下旧仓**”，是个**仓库**，不是码头或船运站。只是英文叫法，别被名字带偏。

2. **活动日期定了吗**  
   还没定。主办方之前提过 **4 月 11 日或 4 月 18 日**两个选项，但还没有最终确认。阿屿正在帮忙确认场地情况。

3. **我已经有摊位了吗**  
   还没有。我**没有报名、没有订摊位，也没有付定金**。要等日期和场地确认后，我再决定是否报名。

所以现在还没法确定一起摆摊的事。等有进一步消息，我会马上同步给你。

---

如果你想加上一句“如果你愿意，我们可以先商量货品怎么搭配”，也可以补在最后，但别写成“已经留了位置”。需要我帮你加吗？

### C

按我们聊过的事实，给你一段可以直接发的说明：

---

进度说明：

- 地点：大家说的 "Old Harbor"，实际是「塔下旧仓」，是一处仓库，不是码头。
- 日期：主办方提过 4 月 11 日和 4 月 18 日两个日子，但还没定下来。
- 摊位：我还没有订摊位，也没有付押金。
- 目前：阿屿（姚屿）在帮忙确认场地的情况。

简单说：场地和日期都还没敲定，摊位也还没订，现在还不能算确定参加。

---

要不要我把它改得更短，或者加一句"定下来我再同步你"？



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
