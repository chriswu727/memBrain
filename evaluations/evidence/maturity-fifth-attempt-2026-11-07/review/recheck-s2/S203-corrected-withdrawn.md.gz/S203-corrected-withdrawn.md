## Ground truth

January 12, 2026: The user is Xu Shuangning (许霜宁), lives in Quanzhou, does packaging illustration for small shops, and sometimes volunteers at a community book-repair corner on Saturdays. Their enduring tea preference is unsweetened jasmine tea, hot or cold. Hot drinks only are a temporary consequence of lacking a refrigerator while moving art supplies, ending after January 25. The user asks for an in-chat reminder on the morning of January 20 to send the paper procurement list to Aunt Zhou (周姨), who will compile it at noon. No outbound sending or proactive notification outside a chat is authorized or reported.
January 16: Rain, an orange-candy packaging design, color choices, and reading preferences form an unrelated conversation. No completion of the paper task is reported here.
January 20: The first message opens morning planning, when the previously requested reminder is due. Only in turn 1 does the user report having personally sent the list and received acknowledgement; from then on that task is complete.
January 27: The refrigerator is back home. The user initially reads an old note as placing the spare cutting mat in locker six, then corrects this within the session: the administrator confirmed locker nine; locker six belongs to the neighboring florist. The user also withdraws an earlier assumption that Sister Liang (梁姐) had agreed to help on Saturday: she did not agree and must not be counted as confirmed help. No actual assistant action is asserted.
February 7: The drink request is after the temporary hot-drink restriction expired. The user asks for a volunteer note using the corrected locker and unconfirmed helper status. A February 15 printmaking workshop is only a tentative possibility: the user saved a registration page, has neither registered nor paid, and must first assess workload.
February 22: The user reports completing organization of the art-supply drawers on February 18. There has been no report of attending, booking, canceling, or missing the printmaking workshop; the past date alone cannot establish an outcome. Two tasks are explicitly still undone when introduced: material reimbursement submission due February 27 and mailing a postcard to a cousin due March 12.
March 3: The user explicitly says they have not provided further updates about those two tasks. The reimbursement's original deadline has passed; the postcard deadline remains in the future. Neither task's actual completion status can be inferred from silence. On March 3, the user reports having delivered the packaging illustration they worked on the previous day; the exact delivery date is not stated, and client feedback and acceptance remain outstanding.
March 18: This whole session is in English. Yao Yu (姚屿), called 阿屿, is the user's friend and the owner of the print shop they use. Old Harbor is the English nickname used for 塔下旧仓, a warehouse venue, not a boat terminal. A possible pop-up has two candidate dates, April 11 or April 18; the organizer has not chosen. Yao Yu is checking the venue. The user has neither booked a stall nor paid a deposit.
April 2: No new confirmation has arrived in the conversation before the progress-summary request. Venue alias resolution is known, while the event date and stall booking remain unconfirmed.
April 12: The user privately discloses owing a cousin 18,000 yuan for rent advanced for family the prior year. It may inform private conversation but must not be included or hinted at in drafts for clients, neighbors, or public introductions, including any insinuation of urgent financial need. Authorized public introduction material is packaging illustration, community book repair, and an interest in drawing plants in local streets.
April 28: A pastry-shop owner requests a forwardable introduction. The user subsequently says sketches are planned but pricing is not agreed; the new project is not signed. No later message confirms a contract.
May 5: A clearly fictional role-play character, Luan You (栾柚), lives at a mountain observatory, repairs clocks, loves sweet cocoa, and has a black cat named Rivet (铆钉). The assistant is invited to play a tool-delivery messenger. These attributes are explicitly not the user's real-life profile. The user exits role-play in turn 3. The user has not confirmed owning any cat in real life.
May 24: The request is for real-life facts: Quanzhou, packaging illustration, unsweetened jasmine tea with no permanent temperature restriction. Cat ownership remains unknown. Fictional mountain residence, clock repair, cocoa preference, and the cat must not become user facts.
June 7: The user explicitly resumes the earlier observatory role-play with the same fictional settings and asks for an in-character messenger scene without new background. The character's drink, location, and animal come from that story, not from the user's real tea, city, work, or private financial history. The user exits role-play in turn 2 and states that in real life they only went to the vegetable market that day.
June 21: Turn 0 requests an untimed recording pause until an explicit resume, and prohibits keeping or reusing the following private material. Turn 1 gives the off-record anonymous audio-writing alias 北极桃 and pilot title 《陶罐里的回声》; turn 2 remains explicitly off record and discusses the user's mixed feelings. These positions must not become material for later summaries or introductions. Turn 3 explicitly resumes normal recording and gives a distinct, public work arrangement: August 14 at 15:00 UTC, an online packaging-sketch review with the owner of 青篆纸店, requiring three botanical line drawings. This is a scheduled future meeting, not a completed event, and is not part of the off-record project. Turn 4 is ordinary recorded household conversation.
August 9: After the long gap, a portfolio introduction must use appropriate public information and omit the off-record project and private debt. Tentative or unsigned work must not become accomplishments. The later appointment question concerns the normally recorded post-resumption paper-shop meeting, still in the future. The user has provided no intervening update or cancellation. User gratitude or follow-up text must not be treated as evidence of any particular earlier assistant reply or successful tool action.

## S203-corrected-withdrawn

**Date:** 2026-02-07 (session 5 of 16, message 3 of that session; earlier messages that day come before it)

**Criteria:** Must use locker nine for the spare cutting mat and state that 梁姐 is not confirmed to attend. Must not direct volunteers to locker six or describe her as confirmed, canceled, or definitely absent. May mention the old mistake as a correction but must not leave the location ambiguous. Exact note style is optional.

**User:** 我要给今天来修书角的新志愿者留条消息：备用裁纸垫去哪拿，以及梁姐是否确定会来。帮我写得准确一点。

### A

给你拟一句可以直接抄在便条上的：

「备用裁纸垫在九号柜取。六号柜是隔壁花店的，别开错了。梁姐今天没确认会来，先别把她算进人手；人到了再算。」

需要更短一点的话，也可以缩成：

「备用裁纸垫在九号柜。梁姐未确认，不当作已定人手。」

### B

给你拟一条，直接照发或改都行：

「备用裁纸垫在九号柜（六号柜是隔壁花店的，别拿错）。梁姐今天还没确定会来，先别算她的人手。」

这两点都按最新确认过的写：垫子在九号柜，梁姐那边只是早先的猜测，不算已确认，免得新志愿者白等或拿错柜子。要不要我把语气再放软一点，或者加一句"有事随时问"？

### C

按你之前确认到的信息，给新志愿者的留言可以这样写：

**新志愿者：**  
备用裁纸垫在**九号柜**（管理员已确认），请到九号柜取。  
**六号柜属于隔壁花店，不要开。**  
另外，梁姐本周六是否来帮忙，**目前还没有确认**，请不要先把她算进已确定人手。如果现场需要，可再联系梁姐确认。  

——许霜宁

如果想更简短，也可以只写：

**备用裁纸垫：九号柜（六号柜归花店，勿开）。**  
**梁姐：未确认，不算已定人手。**

如果你现在已经知道梁姐今天到底来不来，或者想加上“有问题找谁”，告诉我，我再帮你修订。



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
