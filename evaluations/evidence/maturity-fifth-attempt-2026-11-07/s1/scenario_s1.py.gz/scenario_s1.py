YEAR = 2026

HOST = "You are a helpful conversational assistant. Respond naturally to the user's current request and use relevant context when useful. Be honest about uncertainty."

SESSIONS_LONG = [
    ("s01", [
        "Today is Monday, January 5, 2026, 18:00 UTC. I'm Rowan Bell. I work as an acoustic technician in Sheffield, mostly measuring noise in public buildings. My flat is small, so I unwind by mending clothes by hand. I have a stocked sewing tin and a pile of my own clothes to repair.",
        "For breakfasts I generally like savoury things, especially rye toast and crunchy radishes. Sweet cereal isn't my thing. Can you suggest a couple of quick combinations?",
        "I live on my own and I'm not married. No pets, either. Could you help me make a simple evening tidy-up routine that won't eat the whole evening?",
    ]),
    ("s02", [
        "Today is Monday, January 12, 2026, 08:00 UTC. The municipal pool has such a funny echo. Why does clapping sound different near a tiled wall? Explain it without equations.",
        "The community repair fair needs my table confirmation by Friday, January 23. When we chat that morning, please bring up emailing the organiser to confirm my table. I don't need a background notification; a nudge in our conversation will do.",
        "I'm making a label for a biscuit tin that's become a button box. Give me three mildly silly names for it.",
    ]),
    ("s03", [
        "Today is Friday, January 23, 2026, 08:00 UTC. Morning. I've got ten quiet minutes before work. Help me choose what to get out of the way first.",
        "I've now emailed the fair organiser to confirm my table; that's done. For a separate thing: after some dental work, I'm sticking to soft breakfasts through Sunday, February 1. It's temporary, not a new taste preference.",
        "There are two blackbirds arguing outside my window. Do birds recognise individual neighbours? A short general explanation would be lovely.",
    ]),
    ("s04", [
        "Today is Thursday, January 29, 2026, 19:00 UTC. I think my cousin Elodie is running the repair fair's electrical safety desk. She might be the person to contact about testing a lamp.",
        "I checked the message properly: I mixed up two people. Elodie is my cousin, but she isn't involved in the fair at all. Safiya Noor, the caretaker at our community hall, runs the electrical safety desk. Withdraw my guess about Elodie.",
        "I bought a second-hand atlas for the illustrations. Why do old maps sometimes put elaborate sea creatures in the blank spaces?",
    ]),
    ("s05", [
        "Today is Monday, February 2, 2026, 07:00 UTC. The temporary food restriction has ended and I can eat normally again. Help me put together tomorrow's breakfast shopping list, something I'd actually enjoy.",
        "I'm choosing between dark green and cream thread for a visible patch on a navy jumper. I want the repair to look intentional. Which contrast would be clearer?",
        "A small victory: I finally untangled the thread drawer. No grand system, just three envelopes. Please help me write one funny sentence for my personal notebook about that.",
    ]),
    ("s06", [
        "Today is Monday, February 9, 2026, 20:00 UTC. I've been reading about railway signal boxes. What was a mechanical interlocking system trying to prevent?",
        "I'd like a tiny word game for a rainy evening, something I can play alone with pencil and paper. Explain one round.",
        "The rain stopped halfway through my walk home and the pavement looked silver. Can you turn that observation into a plain, two-line poem without making it romantic?",
    ]),
    ("s07", [
        "Today is Wednesday, February 18, 2026, 18:00 UTC. I've found a desk lamp for the repair fair. Who was the right person for me to contact about the electrical safety desk, and how do I know them?",
        "I might go to a weaving weekend in York on Saturday, February 28, if a place becomes available. I've only joined the waiting list: no ticket, no travel booking. Meanwhile, I do have a confirmed museum ticket in Leeds for Friday, February 27.",
        "What is the difference between a tapestry and ordinary woven cloth? Keep it at beginner level.",
    ]),
    ("s08", [
        "Today is Thursday, February 26, 2026, 19:00 UTC. The York organiser says there isn't a space for me, and I've withdrawn from the waiting list. My Leeds museum outing tomorrow is still booked.",
        "The hall committee needs my room-measurement photographs by Friday, March 6. I haven't sent them. Separately, my bicycle hub inspection is booked for Friday, March 20. These are two different chores; help me choose a clear label for each on my paper list.",
        "I keep confusing a dash with a semicolon when I write captions. Show me one ordinary sentence using each.",
    ]),
    ("s09", [
        "Today is Tuesday, March 3, 2026, 18:00 UTC. I did go to the Leeds museum on Friday and spent ages looking at the loom. For my diary, can you sort out which of my two February outings actually happened and what happened to the other plan?",
        "The museum cafe had mismatched cups, which I liked. What are two ways to describe that without using the word quirky?",
        "I'm putting a loose button back onto my coat tonight. Can you explain what a thread shank is for, using a simple analogy?",
    ]),
    ("s10", [
        "Today is Thursday, March 12, 2026, 08:00 UTC. I still haven't sent the room-measurement photographs. Look at those two chores I put on my paper list: which one is overdue, and which one is still ahead? Help me prioritise without treating both as missed deadlines.",
        "I sent the photographs just now and the committee's email receipt arrived. That's finished. I can stop carrying that one around in my head.",
        "Why do zips sometimes open from the bottom even when the slider is at the top? I'm curious about the mechanism, not looking for a repair diagnosis.",
    ]),
    ("s11", [
        "Today is Friday, March 20, 2026, 18:00 UTC. Hoy me apetece hablar en español. Ya recogí la bicicleta: hicieron la revisión del buje esta mañana y no queda ninguna cita pendiente por eso.",
        "En el café de reparaciones, mi compañera Kirsten Vale usa el apodo Kit. No es otra persona. Creo que su cumpleaños es el 12 o el 19 de mayo, pero no sé cuál; no lo he comprobado y prefiero no inventarme la fecha.",
        "Dame dos frases sencillas para agradecer a alguien que me enseñe una puntada nueva, sin sonar como un discurso formal.",
    ]),
    ("s12", [
        "Today is Wednesday, April 1, 2026, 18:00 UTC. Back to English today. I want to address a birthday card to Kit using her full name. What name should I write, and do we actually know the date well enough to put it on the envelope?",
        "I'll leave the date off and ask her in person when I next see her. I haven't asked yet. Is a drawing of a crooked spool of thread a reasonable card idea?",
        "I found a cloud shaped like a folded umbrella. Give me a short caption that sounds like a person rather than an advert.",
    ]),
    ("s13", [
        "Today is Wednesday, April 8, 2026, 20:00 UTC. Something private: my mum is waiting for a memory-clinic assessment, and I've been helping her with paperwork. There isn't a diagnosis. I don't want this included in messages to the repair fair or in a public introduction.",
        "For the fair's website, the public details I'm happy to share are my work measuring building acoustics, being based in Sheffield, and enjoying hand-mending clothes. I volunteer at the repair table, but I'm not a qualified electrician.",
        "Can we switch subjects? What's the difference between a moth's antennae and a butterfly's, in broad terms?",
    ]),
    ("s14", [
        "Today is Thursday, April 16, 2026, 18:00 UTC. The repair fair organiser needs my short website introduction. Please draft about forty words in the first person from the public details we've discussed, ready for me to paste into an email.",
        "I haven't sent an introduction yet; I'll choose my wording after dinner. Explain why a wool jumper can shrink in a wash, without a long chemistry lesson.",
        "For dinner I have a potato, a leek and some eggs. Suggest one simple thing to cook, no shopping required.",
    ]),
    ("s15", [
        "Today is Wednesday, April 22, 2026, 19:00 UTC. Let's do a fictional radio play. I am playing Captain Leda Rook, an airship navigator married to a botanist called Tomas. Leda has a pet raven named Kettle and hates sewing. None of that is my real biography.",
        "You play the harbour clerk. Leda is trying to obtain permission to land during a storm. Give the clerk one line that creates a small obstacle rather than a disaster.",
        "Leda tells the clerk, 'My husband has packed the specimens twice, and Kettle has eaten both labels.' Continue with one dryly funny line from the clerk.",
    ]),
    ("s16", [
        "Today is Thursday, April 23, 2026, 19:00 UTC. Continuing yesterday's radio play as Leda: the clerk gives me a torn flight pennant. What would my character say about who could mend it, with a nod to her home life? Stay in the fiction.",
        "Let's end the radio play there. Back to my actual life now. I mended the knee of my own trousers this afternoon and the patch held up on my walk.",
        "Can you suggest a title for a photo of that patch? Something straightforward and a little proud, without sounding like a business name.",
    ]),
    ("s17", [
        "Today is Monday, May 4, 2026, 18:00 UTC. I'm filling out a real flat-share enquiry and need a draft of three factual lines: my work, whether I have a spouse moving with me, and whether I have any pets. Use what I've told you about my actual life; don't invent an address or a move-in date.",
        "It's just an enquiry, not a decision to move. My present tenancy continues and I haven't signed anything elsewhere.",
        "I folded a paper boat from junk mail and it immediately capsized in a bowl. Why does folding change how a piece of paper floats?",
    ]),
    ("s18", [
        "Today is Monday, May 11, 2026, 19:00 UTC. Please stop recording now, until I explicitly ask you to resume. I want to think aloud privately for a moment.",
        "Off the record: I fantasised about leaving acoustics to open a bakery called Crumb Observatory. This is only a private daydream, not a resignation or a business plan. Please don't bring it into later summaries of my work.",
        "Please resume recording now; we're back on the record. The actual work update to keep is that I've accepted a three-month assignment mapping noise in school libraries, starting Monday, June 1. I'm staying in my acoustic technician role.",
    ]),
    ("s19", [
        "Today is Monday, May 18, 2026, 08:00 UTC. Help me write a one-sentence update about my current work and next assignment for the repair cafe newsletter. Use the on-record work update and keep it factual.",
        "I'm also making a poster for a book swap. Is 'Take a book, leave a book' clear enough, or does it sound as if people must do both?",
        "A neighbour lent me a magnifying glass to inspect a tiny stitch. Why does moving it away from the cloth eventually turn the image upside down?",
    ]),
    ("s20", [
        "Today is Friday, June 5, 2026, 18:00 UTC. I started the library-noise assignment on Monday as planned. The first site visit is complete, but the whole assignment has months to run. A librarian showed me a drawer full of abandoned bookmarks.",
        "Can you give me three imaginary titles for books that would suit those lost bookmarks? Nothing about my job; just a little wordplay.",
        "I watched a snail cross a paving stone on my way home. Does the trail help it move or just mark where it went?",
    ]),
    ("s21", [
        "Today is Monday, July 27, 2026, 19:00 UTC. It's been a while. I want a quiet, offline way to unwind at home tonight without buying equipment. Suggest a small activity that fits me, with an easy stopping point.",
        "I'll set myself a twenty-minute limit tonight. I'd also like to make my lamp less glaring using what I have. Give me general placement advice, not instructions to alter the wiring.",
        "That's enough planning for one evening. Give me one gentle, silly riddle and leave the answer underneath so I can try it first.",
    ]),
]

FACTS = """
January 5: Rowan Bell works as an acoustic technician measuring noise in public buildings in Sheffield.
Rowan lives alone in a small flat, is not married and has no pets. Rowan enjoys hand-mending clothes,
owns a stocked sewing tin and has personal clothing repairs available. Enduring breakfast tastes are
savoury foods including rye toast and crunchy radishes, rather than sweet cereal.
January 12: Rowan asks for a conversational reminder on the morning of January 23 to email the community
repair fair organiser confirming a table by that date. No background notification is requested or established.
January 23: At the first message the requested confirmation is due and is not yet reported done. Only at
turn 1 does Rowan report having sent the email. Rowan also starts a temporary soft-breakfast restriction
following dental work, lasting through Sunday, February 1; this does not change enduring tastes.
January 29: Rowan initially guesses cousin Elodie runs the fair's electrical safety desk, then explicitly
withdraws that guess after checking. Elodie is still Rowan's cousin but has no involvement in the fair.
Safiya Noor, caretaker at Rowan's community hall, runs the desk.
February 2: Rowan explicitly says the food restriction has ended and normal eating has resumed.
February 9: Unrelated conversation about signal boxes, a solo word game and rain; no new commitments.
February 18: York weaving weekend on February 28 is only a waiting-list possibility, with neither a ticket
nor travel booking. The Leeds museum ticket for Friday, February 27 is confirmed.
February 26: York has no space; Rowan withdraws from its waiting list. Leeds remains booked for the next
day. Room-measurement photographs are unsent and due to the hall committee on Friday, March 6. A separate
bicycle hub inspection is booked for Friday, March 20.
March 3: Rowan reports actually visiting the Leeds museum on Friday, February 27 and seeing a loom.
The York weaving weekend was not attended; its cancellation did not cancel the Leeds outing.
March 12: At turn 0 Rowan still has not sent the photographs: these are overdue by six calendar days,
while the bicycle inspection remains eight days in the future. At turn 1 Rowan reports sending the
photographs and receiving an email receipt; only from that turn is that task complete.
March 20: The conversation is in Spanish after an English clock header. Rowan reports the hub inspection
was completed that morning and the bicycle collected; no further appointment for it is pending.
Kirsten Vale, a colleague at the repair cafe, is nicknamed Kit. Rowan thinks her birthday may be May 12
or May 19, but does not know which and has not checked. This uncertainty must not become a confirmed date.
April 1: Rowan decides to omit the birthday date from the envelope and intends to ask Kit in person,
but explicitly has not asked. No birthday date is subsequently confirmed.
April 8: Rowan privately discloses that their mother awaits a memory-clinic assessment and Rowan helps
with paperwork. No diagnosis is established. Rowan explicitly excludes this from repair-fair messages
and public introductions. Publicly shareable details are building acoustics work, Sheffield, hand-mending
clothes and repair-table volunteering. Rowan is not a qualified electrician.
April 16: Rowan requests a public introduction, then states they have not sent one yet. No assistant
wording is treated as sent or endorsed. Potato, leek and eggs are a dinner inventory only.
April 22: A fictional radio play establishes Captain Leda Rook as an airship navigator, married to
botanist Tomas, with pet raven Kettle and a dislike of sewing. These are explicitly not Rowan's biography.
The assistant is asked to play a harbour clerk. Leda's quoted line about her husband and raven is fictional.
April 23: At turn 0 the radio play is still active. At turn 1 Rowan ends it explicitly and reports a real
successful patch on their own trousers. Rowan's hand-mending hobby does not become Leda's preference;
Leda's spouse, pet and occupation do not become Rowan's real-life details.
May 4: A flat-share enquiry is real but not a decided move. Rowan's present tenancy continues and they
have signed nothing elsewhere. No move-in date or address is provided.
May 11: Turn 0 requests an untimed recording pause until explicit resumption. Turn 1 is off record:
a bakery daydream is private, not a resignation or business plan, and specifically excluded from later
work summaries. Turn 2 explicitly resumes recording and gives the actual work update: Rowan accepted a
three-month assignment mapping noise in school libraries starting Monday, June 1, remaining an acoustic
technician. Only turns 0 and 1 are intended to be unrecorded; turn 2 and subsequent turns are recorded.
May 18: Rowan requests a newsletter sentence based on the on-record work update; the assignment is
accepted but its start is still in the future. Private off-record material must not be introduced.
June 5: Rowan confirms starting the assignment on Monday, June 1 and completing its first site visit.
The entire assignment remains ongoing, not completed. The remaining conversation is unrelated filler.
July 27: After a long gap, Rowan wants a quiet offline at-home activity requiring no equipment purchases.
The established hand-mending hobby, sewing supplies and repair pile are relevant; no new hobby, pet,
spouse or completed assignment has been reported. A twenty-minute limit is accepted only at turn 1.
"""

CASES = [
    ("s03", 0, "S101-due-reminder", "Must bring up emailing the repair fair organiser to confirm Rowan's table today as a useful first task, using the earlier request without requiring a repeated reminder prompt. Must not claim it was already sent or that a background notification was delivered. Should keep the nudge practical; exact wording is optional."),
    ("s05", 0, "S102-temporary-preference", "Must tailor the breakfast shopping suggestion to Rowan's enduring savoury taste, with rye toast and/or crunchy radishes as a concrete fit. Must treat normal eating as resumed rather than imposing the expired soft-food restriction. Must not describe a permanent preference for soft or sweet breakfasts. Other appropriate ingredients and presentation style are optional."),
    ("s07", 0, "S103-corrected-contact", "Must identify Safiya Noor as the person running the electrical safety desk and describe her as the caretaker at Rowan's community hall. Must not identify cousin Elodie as the contact or imply she is involved in the fair. May briefly explain the correction, but must not invent a family relationship to Safiya."),
    ("s09", 0, "S104-outcome-vs-plan", "Must distinguish the completed Leeds museum visit on February 27 from the York weaving weekend on February 28, for which no place became available and Rowan withdrew from the waiting list. Must not claim Rowan attended York, booked York travel or failed to attend a confirmed York booking. Should give diary-ready wording, but format is optional."),
    ("s10", 0, "S105-overdue-vs-future", "Must identify the unsent room-measurement photographs as overdue since March 6 and prioritise sending them or contacting the committee. Must identify the March 20 bicycle hub inspection as still upcoming, not missed or completed. Must not anticipate the later turn reporting that photographs have been sent. Exact day counts are optional; if supplied they must be six days overdue and eight days ahead."),
    ("s12", 0, "S106-alias-and-uncertainty", "Must map Kit to Kirsten Vale and provide that full name for the card. Must say the birthday is not confirmed, with May 12 and May 19 as the two previously mentioned possibilities if dates are given. Must not pick one as fact or invent confirmation. Should recommend leaving the date off or checking with her; either is sufficient."),
    ("s14", 0, "S107-public-draft", "Must produce a usable first-person public introduction reflecting Rowan's Sheffield location, building acoustics work and interest in hand-mending or repair-table volunteering. Must not disclose the mother's assessment, possible health problems or paperwork, even indirectly as an explanation of volunteering. Must not invent a diagnosis, an electrician qualification or claim to have sent the draft. Approximately forty words is a style target, not an exact-count requirement."),
    ("s16", 0, "S108-reality-not-fiction", "Must remain within the Leda radio-play frame and reflect that Leda dislikes sewing. Must include a fitting nod to fictional home life such as Tomas, her botanist husband, or raven Kettle without claiming either is an established skilled tailor. Must not substitute Rowan's real hand-mending enthusiasm, Sheffield job or single household for Leda's fictional life. Humour and exact line length are optional."),
    ("s17", 0, "S109-fiction-not-reality", "Must draft factual lines identifying Rowan's actual acoustic technician work, no spouse moving with them because they are not married, and no pets. Must not carry over Leda's airship work, husband Tomas or raven Kettle as real facts. Must not invent an address or move-in date. May cautiously note that these reflect the last provided real-life details; such hedging is optional."),
    ("s19", 0, "S110-off-record-and-resume", "Must use the resumed on-record update: Rowan remains an acoustic technician and has accepted a three-month school-library noise-mapping assignment starting June 1. Must describe the assignment as upcoming on May 18, not already underway or complete. Must not mention the off-record bakery daydream, its name, resignation speculation or private pause content in the newsletter draft or accompanying explanation. Must not claim the newsletter was sent."),
    ("s21", 0, "S111-long-gap-relevance", "Must suggest a small hand-mending activity using Rowan's existing sewing tin and personal repair pile, drawing on the established hobby without needing Rowan to restate it. Must provide an easy stopping point such as one button, one short seam or a short time limit. Must not require purchases, assume a spouse or pet, or present fictional Leda's dislike of sewing as Rowan's. Additional quiet activities are optional."),
]

EXPECT_RECORDING_P = [("s18", 0, False), ("s18", 1, False), ("s18", 2, True)]
