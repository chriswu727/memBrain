import hashlib
import json
import math
import os
import socket
import statistics
import psycopg
from membrain.local_embeddings import DOCUMENT_INDEX_VERSION
import time
from pathlib import Path

for key in list(os.environ):
    if key.startswith(('MEMORY_', 'MEMBRAIN_', 'C5_')) or key.endswith(('_API_KEY', '_API_TOKEN')):
        del os.environ[key]
os.environ.update(MEMBRAIN_SEMANTIC='0', PYTHON_DOTENV_DISABLED='1')

from membrain import desktop, host, embedded_database
from psycopg import sql
from membrain.build_identity import BUILD_ID
from membrain.client import MemoryClient
from membrain.local_profile import load_profile

root = Path(__file__).parent / 'semantic-host'
root.mkdir(exist_ok=True)
repository = Path('/Users/yichen/tmp/membrain-source-script-recall-20261107')
hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (repository / 'src').rglob('*')
          if p.is_file() and '__pycache__' not in p.parts}
report = {'runtime_pin': 'uncommitted-source-script-fix', 'build_id': BUILD_ID,
          'source_sha256': hashes, 'paid_provider_calls': 0, 'subscription_calls': 0, 'completed': False,
          'protocol': 'Actual host.recall_context over retained public 1000/10000 corpora. Same 20 original queries, one call each, no changed budgets, warmups, retries or generation. Record API target inclusion, host source selection, actual returned trace and final context inclusion separately. Each corpus starts and stops its own service; preserve every miss and cold latency.', 'phases': []}
assert BUILD_ID == '994d3e914c1702e1415adce090094d3969fbbfa87d0e16a7a62bd8eddc6cc7a2'

def save():
    (root / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')

class RecordingClient:
    def __init__(self, client):
        self.client = client
        self.response = None
        self.trace = None

    def __getattr__(self, name):
        return getattr(self.client, name)

    def recall(self, *args, **kwargs):
        self.response = self.client.recall(*args, **kwargs)
        return self.response

    def trace_recall(self, events):
        self.trace = list(events)
        return self.client.trace_recall(events)

def core_snapshot(profile):
    result = {}
    with psycopg.connect(profile.migration_database_url) as connection:
        connection.execute('SET TRANSACTION READ ONLY')
        for table in ('memory_events', 'memory_assertions', 'memory_embeddings', 'memory_embedding_passages'):
            rows = connection.execute(sql.SQL("SELECT to_jsonb(t)::text FROM {} t WHERE brain_id=%s ORDER BY to_jsonb(t)::text").format(sql.Identifier(table)), (profile.brain_id,)).fetchall()
            result[table] = {'rows': len(rows), 'sha256': hashlib.sha256(json.dumps(rows).encode()).hexdigest()}
    return result

save()
try:
    for count, directory in (
        (1000, Path('/Users/yichen/tmp/membrain-semantic-balance-1000-20261107')),
        (10000, Path('/Users/yichen/tmp/membrain-semantic-scale-20261107')),
    ):
        original = json.loads((directory / 'report.json').read_text())
        assert original['completed'] and original['all_ports_closed']
        samples = [s for p in original['phases'] if p['messages'] == count
                   for s in p['samples'] if s['mode'] == 'semantic']
        assert len(samples) == 20
        profile = load_profile(directory / 'installation')
        phase = {'messages': count, 'samples': [], 'completed': False}
        report['phases'].append(phase)
        try:
            for port in (profile.api_port, profile.database_port):
                with socket.socket() as sock:
                    assert sock.connect_ex(('127.0.0.1', port)) != 0
            try:
                embedded_database.start(profile)
                phase['core_before'] = core_snapshot(profile)
            finally:
                embedded_database.stop(profile)
            host.start(profile.directory)
            status = desktop.status(profile.directory)
            assert status['configuration_current'] and status['ready']
            with MemoryClient(profile.base_url, profile.api_key, profile.brain_id, timeout=120) as live:
                assert live._request('GET', 'v1/local/memory-status')['semantic_recall'] == 'ready'
                began_index = time.monotonic()
                phase['index_observations'] = []
                while True:
                    state = live.dashboard()['status']
                    with psycopg.connect(profile.migration_database_url) as conn:
                        conn.execute('SET TRANSACTION READ ONLY')
                        vectors = conn.execute('SELECT count(*) FROM memory_embeddings WHERE brain_id=%s AND document_index_version=%s', (profile.brain_id, DOCUMENT_INDEX_VERSION)).fetchone()[0]
                    snapshot = {'vectors': vectors, 'pending_jobs': state.get('pending_jobs'), 'index_lag': state.get('index_lag'), 'elapsed_seconds': round(time.monotonic()-began_index,3)}
                    phase['index_observations'].append(snapshot)
                    save()
                    if len(phase['index_observations'])%10 == 1:
                        print(json.dumps({'messages':count,'index':snapshot}),flush=True)
                    if vectors == count and not state.get('pending_jobs') and not state.get('index_lag'):
                        phase['settled'] = snapshot
                        break
                    if time.monotonic()-began_index > 1200:
                        raise TimeoutError('Passage coverage backfill did not settle within 1200 seconds.')
                    time.sleep(1)
                for sample in samples:
                    client = RecordingClient(live)
                    began = time.perf_counter()
                    context = host.recall_context(client, sample['query'], current_conversation='synthetic-query')
                    elapsed = round((time.perf_counter() - began) * 1000, 3)
                    target = sample['target_event']
                    items = client.response['result']['items']
                    api_hit = any(ref.get('event_id') == target for item in items
                                  for ref in item['memory'].get('evidence_refs', []))
                    source_ids = [event for event, _ in host._sources(client.response, 'synthetic-query')]
                    source_text = original['cases'][sample['case']]['source']
                    phase['samples'].append({'case': sample['case'], 'query': sample['query'], 'target_event': target,
                                              'api_hit': api_hit, 'source_filter_hit': target in source_ids,
                                              'trace_hit': target in (client.trace or []),
                                              'context_hit': source_text in (context or ''), 'ms': elapsed,
                                              'selected_source_ids': source_ids, 'trace': client.trace,
                                              'context': context, 'response': client.response})
                    save()
            values = sorted(sample['ms'] for sample in phase['samples'])
            phase['summary'] = {key: sum(s[key] for s in phase['samples'])
                                for key in ('api_hit', 'source_filter_hit', 'trace_hit', 'context_hit')}
            phase['summary'].update(queries=len(values), median_ms=statistics.median(values),
                                    p95_ms=values[math.ceil(len(values) * .95) - 1], max_ms=max(values))
            phase['core_after'] = core_snapshot(profile)
            phase['core_unchanged'] = phase['core_before'] == phase['core_after']
            assert phase['core_unchanged']
            phase['completed'] = True
        finally:
            desktop.stop(profile.directory)
            phase['ports'] = {}
            for port in (profile.api_port, profile.database_port):
                with socket.socket() as sock:
                    phase['ports'][str(port)] = sock.connect_ex(('127.0.0.1', port)) != 0
            phase['all_ports_closed'] = all(phase['ports'].values())
            save()
        print(json.dumps({'messages': count, 'summary': phase.get('summary'), 'all_ports_closed': phase['all_ports_closed']}), flush=True)
    report['completed'] = True
except Exception as error:
    report['failure'] = {'type': type(error).__name__, 'message': str(error)[:500]}
finally:
    report['source_unchanged'] = all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == value for p, value in hashes.items())
    save()
raise SystemExit(0 if report['completed'] and report['source_unchanged']
                 and all(p['all_ports_closed'] for p in report['phases']) else 1)
