import gzip,hashlib,json
from pathlib import Path
root=Path(__file__).parent
repo=Path('/Users/yichen/tmp/membrain-source-script-recall-20261107')
target=repo/'evaluations/evidence/maturity-source-script-2026-11-07'
files=[p for p in root.iterdir() if p.is_file() and p.suffix in {'.py','.log','.json'}]
for folder in ('semantic-host','semantic-host-query-time'):
    files.extend(p for p in (root/folder).rglob('*') if p.is_file() and p.suffix=='.json')
extra=Path('/Users/yichen/tmp/membrain-read-cache-delivery-20261107')
files.extend(extra/name for prefix in ('semantic-encoding-diagnostic','semantic-script-diagnostic') for name in (prefix+'.py',prefix+'.json',prefix+'.log'))
secrets=set()
for directory in ('membrain-semantic-balance-1000-20261107','membrain-semantic-scale-20261107'):
    profile=json.loads((Path('/Users/yichen/tmp')/directory/'installation/profile.json').read_text())
    for field in ('api_key','admin_password','app_password'):
        if profile.get(field):secrets.add(profile[field].encode())
manifest={'build_id':'16a9d16e5cd9b5d682cf6befb651e957d7d6cc76dc9ee2e83abe1a060abc21ce','schema_id':'478061ac77337fd25d87174df1185ab1d40ad4d4216290078fb26fd2f519fe39','status':'not promoted: public case3 regression at10000; whole host17/20 unchanged despite API19/20; remaining interference/context work','files':[]}
for p in sorted(files):
    data=p.read_bytes();assert not any(secret in data for secret in secrets),p.name
    name=str(p.relative_to(root)) if p.is_relative_to(root) else 'diagnosis/'+p.name
    out=target/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True)
    payload=gzip.compress(data,mtime=0);out.write_bytes(payload)
    assert gzip.decompress(out.read_bytes())==data
    manifest['files'].append({'path':str(out.relative_to(target)),'sha256':hashlib.sha256(payload).hexdigest(),'bytes':len(payload),'original_sha256':hashlib.sha256(data).hexdigest(),'original_bytes':len(data)})
manifest['privacy_scan']={'owned_credential_values':len(secrets),'matches':0,'private_profiles_dumps_excluded':True}
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print({'files':len(files),'compressed_bytes':sum(x['bytes'] for x in manifest['files']),'credential_matches':0})
