import ast
import hashlib
import json
import os
import time
from pathlib import Path

for name in list(os.environ):
    if name.startswith(("MEMORY_", "MEMBRAIN_", "C5_")) or name.endswith(("_API_KEY", "_API_TOKEN")):
        del os.environ[name]
os.environ["PYTHON_DOTENV_DISABLED"] = "1"
import numpy as np
from membrain.local_embeddings import LocalEmbeddingProvider, SPACE, FILES

root = Path(__file__).parent
fixture = Path("/Users/yichen/tmp/membrain-semantic-balance-1000-20261107")
original = json.loads((fixture / "report.json").read_text())
module = ast.parse((fixture / "probe.py").read_text())
nodes = [node for node in module.body if (isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) and node.targets[0].id in {"CASES", "TEMPLATES"}) or (isinstance(node, ast.FunctionDef) and node.name == "corpus")]
namespace = {}
exec(compile(ast.Module(body=nodes, type_ignores=[]), "public-corpus", "exec"), namespace)
assert hashlib.sha256(json.dumps(namespace["corpus"](10000), ensure_ascii=False).encode()).hexdigest() == original["corpus_sha256"]
rows = namespace["corpus"](1000)
model = Path("/Users/yichen/tmp/membrain-neural-evidence-20261103/perf-topology-9bc9893-installation/models/multilingual-e5-small-761b726dd34f")
for name, (sha, size) in FILES.items():
    data = (model/name).read_bytes()
    assert len(data) == size and hashlib.sha256(data).hexdigest() == sha
provider = LocalEmbeddingProvider(model)
queries = [provider.embed([case["query"]], purpose="query").vectors[0] for case in original["cases"]]
query_vectors = np.array(queries)
report = {"completed": False, "model": SPACE.descriptor(), "model_hashes_verified": True, "provider_calls": 0, "subscription_calls": 0, "rows": len(rows), "original_public_corpus_sha256": original["corpus_sha256"], "protocol": "Exploratory offline encoding comparison on unchanged public 1000-message corpus and twenty original questions. Same cached ONNX model and fixed document batches; compare role-wrapped direct-capture statement versus raw source text, without retrieval fusion or host filtering. One embedding per original query. Not a host acceptance run; no source database writes.", "arms": []}
for arm in ("current_role_wrapper", "raw_source_text"):
    began = time.monotonic()
    texts = [("user user (direct_statement): " + row["text"]) if arm == "current_role_wrapper" else row["text"] for row in rows]
    vectors = []
    for offset in range(0, len(texts), 64):
        vectors.extend(provider.embed(texts[offset:offset+64]).vectors)
    similarity = query_vectors @ np.array(vectors).T
    samples = []
    for case, expected in enumerate(original["cases"]):
        target = next(i for i,row in enumerate(rows) if row["case"] == case)
        order = sorted(range(len(rows)), key=lambda i: (-float(similarity[case,i]), i))
        samples.append({"case": case, "query": expected["query"], "target": expected["source"], "rank": order.index(target)+1, "similarity": float(similarity[case,target]), "top": [{"source": rows[i]["text"], "similarity": float(similarity[case,i])} for i in order[:5]]})
    report["arms"].append({"arm": arm, "seconds": time.monotonic()-began, "samples": samples, "top_12_hits": sum(s["rank"]<=12 for s in samples), "top_46_hits": sum(s["rank"]<=46 for s in samples)})
    (root/"semantic-encoding-diagnostic.json").write_text(json.dumps(report, indent=2, ensure_ascii=False)+"\n")
    print(json.dumps({"arm": arm, "top_12_hits": report["arms"][-1]["top_12_hits"], "ranks": [s["rank"] for s in samples]}), flush=True)
report["completed"] = True
(root/"semantic-encoding-diagnostic.json").write_text(json.dumps(report, indent=2, ensure_ascii=False)+"\n")
