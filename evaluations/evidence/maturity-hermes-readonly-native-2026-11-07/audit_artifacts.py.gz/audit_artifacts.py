from collections import Counter
import hashlib,json
from pathlib import Path
root=Path(__file__).parent
receipts=json.loads((root/'artifact-receipts.json').read_text())
assert len(receipts)==5, 'Wait for all five artifacts before final audit'
for receipt in receipts:
 for item in receipt['retained']:
  assert hashlib.sha256((root/item['path']).read_bytes()).hexdigest()==item['sha256']
summary=[];duplicates=0
for p in sorted((root/'artifacts').rglob('*.json')):
 data=json.loads(p.read_text())
 if not isinstance(data,dict) or 'completed' not in data:continue
 if p.name=='qualification.json' and p.parent.name=='native-artifacts':
  canonical=list(p.parent.parent.glob('native-check-*/qualification.json'))
  assert len(canonical)==1 and p.read_bytes()==canonical[0].read_bytes()
  duplicates+=1;continue
 if 'worker-result' in p.name:continue
 assert '42409792797' in str(p.relative_to(root/'artifacts')), p
 ports={}
 def visit(value,prefix=''):
  if isinstance(value,dict):
   for key,item in value.items():
    name=prefix+key
    if 'port' in key and 'closed' in key and isinstance(item,bool):ports[name]=item
    visit(item,name+'.')
  elif isinstance(value,list):
   for index,item in enumerate(value):visit(item,prefix+str(index)+'.')
 visit(data)
 assert data['completed'] is True,p
 assert data.get('model_calls')==0,p
 assert all(ports.values()),p
 summary.append({'path':str(p.relative_to(root/'artifacts')),'completed':True,'model_calls':0,'ports':ports})
result={'summaries':summary,'count':len(summary),'by_platform':dict(Counter(x['path'].split('/')[0] for x in summary)),'duplicate_qualification_copies_excluded':duplicates,'all_completed':True,'all_model_calls_zero':True,'all_recorded_port_closures_passed':True}
assert len(summary)==47 and duplicates==5,result['by_platform']
(root/'native-summary-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='summaries'}))
