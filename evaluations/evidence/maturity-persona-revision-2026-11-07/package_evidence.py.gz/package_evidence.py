import gzip
import hashlib
import json
from pathlib import Path

root = Path(__file__).parent
repo = Path('/Users/yichen/tmp/membrain-persona-feedback-revision-20261107')
target = repo / 'evaluations/evidence/maturity-persona-revision-2026-11-07'
files = [(p, p.name) for p in root.iterdir() if p.is_file() and p.suffix in {'.py', '.log', '.json'}]
files.extend((p, str(p.relative_to(root))) for p in (root / 'ci').rglob('*')
             if p.is_file() and p.suffix in {'.json', '.py', '.log'} and p.name != 'verify-collection.log')
prior = Path('/Users/yichen/tmp/membrain-diversity-delivery-20261107/ci')
for name in ('verify-pytest.log', 'verify-status-final.json', 'verify-log-receipt.json'):
    files.append((prior / name, 'predecessor-diversity/' + name))
secrets = set()
for name in ('membrain-semantic-balance-1000-20261107', 'membrain-semantic-scale-20261107'):
    profile = json.loads((Path('/Users/yichen/tmp') / name / 'installation/profile.json').read_text())
    for key in ('api_key', 'admin_password', 'app_password'):
        if profile.get(key):
            secrets.add(profile[key].encode())
identity = json.loads((root / 'installed-parity.json').read_text())
manifest = {'build_id': identity['build_id'], 'schema_id': identity['schema_id'],
            'status': 'Local source and installed checks complete; full Verify pending. Not R4/C5 acceptance.',
            'files': []}
for path, name in sorted(files):
    data = path.read_bytes()
    assert not any(secret in data for secret in secrets), name
    packed = gzip.compress(data, mtime=0)
    output = target / (name + '.gz')
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(packed)
    assert gzip.decompress(output.read_bytes()) == data
    manifest['files'].append({'path': name + '.gz', 'bytes': len(packed),
                              'sha256': hashlib.sha256(packed).hexdigest(), 'original_bytes': len(data),
                              'original_sha256': hashlib.sha256(data).hexdigest()})
manifest['privacy_scan'] = {'owned_credential_values': len(secrets), 'matches': 0,
                            'private_profiles_dumps_excluded': True}
(target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print({'payloads': len(files), 'credential_matches': 0})
