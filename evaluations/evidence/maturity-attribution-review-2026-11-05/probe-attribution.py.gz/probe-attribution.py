import contextlib,importlib.util,io,json,tempfile
from pathlib import Path
s=importlib.util.spec_from_file_location("review","evaluations/acceptance_review.py");m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
for answer in ({"cause":"host"},{"cause":"host","per_type":{"4":{"cause":"memory","evidence":"Synthetic memory supplied the false statement."}}}):
 with tempfile.TemporaryDirectory() as t:
  p=Path(t);rows=[{"case":"S01-practice","label":label,"arm":arm,"base":1,"resolved":[4] if arm in "PF" else []} for label,arm in zip("ABC","PEF")]
  (p/'tally-practice.json').write_text(json.dumps({"totals":{"resolved":{"P":0,"E":1,"F":0}},"rows":rows}))
  q=p/'attribution-practice';q.mkdir()
  for n in (1,2):(q/f'S01-A.{n}.json').write_text(json.dumps(answer))
  with contextlib.redirect_stdout(io.StringIO()):result=m.gate(p,['practice'])
  print(json.dumps({"attribution":answer,"R4":result['R4'],"memory_caused":result['arms']['P']['memory_caused'],"host_caused":result['arms']['P']['host_caused']}))
