import gzip,hashlib,json
from pathlib import Path
root=Path(__file__).parent
repo=Path('/Users/yichen/tmp/membrain-read-cache-retention-20261107')
target=repo/'evaluations/evidence/maturity-read-cache-2026-11-07'
files=[p for p in root.iterdir() if p.is_file() and p.suffix in ('.py','.json','.log')]
files.extend(p for p in (root/'ci').rglob('*') if p.is_file() and p.suffix in ('.py','.json','.log'))
manifest={'build_id':'0e0b3dc63848cfa5e14226f4009f683ec1b165f400c3ac73144d5ff449dc6b1c','schema_id':'91f417b8b5fe11514300d65d4e1982dd9170d1cfb9a498f804788d83c95820dd','scope':'Local cache/feedback/recovery regressions, all failed probes, actual same-corpus HTTP allocation and ordinary autovacuum, streamed backup recovery, failed predecessor CI. No paid or subscription calls. No private profiles or dumps.','files':[]}
for p in sorted(files):
    data=p.read_bytes()
    relative=str(p.relative_to(root))+'.gz'
    out=target/relative;out.parent.mkdir(parents=True,exist_ok=True)
    payload=gzip.compress(data,mtime=0);out.write_bytes(payload)
    assert gzip.decompress(out.read_bytes())==data
    manifest['files'].append({'path':relative,'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest(),'original_bytes':len(data),'original_sha256':hashlib.sha256(data).hexdigest()})
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print({'files':len(files),'compressed_bytes':sum(row['bytes'] for row in manifest['files'])})
