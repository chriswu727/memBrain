import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

root = Path(__file__).parent
run = '42365805952'
repo = 'chriswu727/memBrain'
status = json.loads(subprocess.check_output([
    'gh', 'run', 'view', run, '--repo', repo,
    '--json', 'status,conclusion,headSha,jobs',
]))
assert status['status'] == 'completed', status['status']
assert status['headSha'] == '99dadacf3a0b6094a3b4d7b9a3168e4f24534d1c'
(root / 'verify-status-final.json').write_text(json.dumps(status, indent=2) + '\n')
archive = root / 'verify-download.zip'
with archive.open('wb') as output:
    subprocess.run(['gh', 'api', f'repos/{repo}/actions/runs/{run}/logs'], stdout=output, check=True)
receipt = {'run': run, 'head': status['headSha'], 'conclusion': status['conclusion'],
           'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'files': []}
with zipfile.ZipFile(archive) as bundle:
    for name in bundle.namelist():
        if name == '0_runtime.txt':
            destination = 'verify-complete.log'
        elif name.startswith('runtime/') and 'Run uv run pytest -v' in name:
            destination = 'verify-pytest.log'
        else:
            continue
        data = bundle.read(name)
        (root / destination).write_bytes(data)
        receipt['files'].append({'archive_member': name, 'path': destination, 'bytes': len(data),
                                 'sha256': hashlib.sha256(data).hexdigest()})
assert len(receipt['files']) == 2, receipt
(root / 'verify-log-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
archive.unlink()
print(json.dumps(receipt, indent=2))
