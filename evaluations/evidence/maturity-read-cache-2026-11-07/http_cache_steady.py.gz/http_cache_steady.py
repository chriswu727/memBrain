import hashlib
import json
import math
import os
from pathlib import Path
import statistics
import sys
import time

for name in list(os.environ):
    if name.startswith(('MEMORY_', 'MEMBRAIN_', 'C5_')) or name.endswith(('_API_KEY', '_API_TOKEN')):
        del os.environ[name]
os.environ.update(MEMBRAIN_SEMANTIC='0', PYTHON_DOTENV_DISABLED='1')

import psycopg
from psycopg.rows import dict_row

import membrain
from membrain import desktop, host
from membrain.build_identity import BUILD_ID, SCHEMA_ID
from membrain.client import MemoryClient
from membrain.local_profile import ensure_profile, load_profile

root = Path(__file__).parent
arm = sys.argv[1]
assert arm in ('before', 'after')
label = sys.argv[2] if len(sys.argv) > 2 else arm
query_count = 6000
directory = root / 'http-installation'
source = Path(membrain.__file__).parent
hashes = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in source.rglob('*')
          if path.is_file() and '__pycache__' not in path.parts}
report = {'arm': arm, 'build_id': BUILD_ID, 'schema_id': SCHEMA_ID, 'completed': False,
          'label': label, 'prior_new_runtime_queries': 2250,
          'paid_or_subscription_calls': 0, 'source_hashes': hashes, 'samples': [], 'snapshots': [],
          'protocol': 'Same 32 original sources and IDs, 6000 additional real HTTP recalls after the completed new-runtime phase; zero embeddings or generation. Baseline first, then ordinary schema upgrade and bounded cleanup. No warmups, retries or corpus changes. This is an operational storage probe, not a recall-quality acceptance or statistically randomized latency comparison.'}


def save():
    (root / f'http-{label}.json').write_text(json.dumps(report, indent=2) + '\n')


def snapshot(profile):
    with psycopg.connect(profile.migration_database_url, row_factory=dict_row) as conn:
        conn.execute('SET TRANSACTION READ ONLY')
        conn.execute("SET statement_timeout='10000'")
        result = {}
        tables = ['memory_requests', 'memory_traces', 'memory_events', 'memory_assertions']
        if conn.execute("SELECT to_regclass('memory_read_cache') AS name").fetchone()['name']:
            tables.append('memory_read_cache')
        for table in tables:
            result[table] = dict(conn.execute(f'SELECT count(*) AS rows,coalesce(sum(pg_column_size(t)),0) AS live_row_bytes '
                                             f'FROM {table} t WHERE brain_id=%s', (profile.brain_id,)).fetchone())
            result[table]['relation_bytes_with_indexes'] = conn.execute('SELECT pg_total_relation_size(%s) AS n', (table,)).fetchone()['n']
        result['vacuum'] = [dict(row) for row in conn.execute("SELECT relname,n_dead_tup,n_live_tup,autovacuum_count,last_autovacuum::text FROM pg_stat_user_tables WHERE relname IN ('memory_read_cache','memory_requests')")]
        result['legacy_cached_reads'] = conn.execute("SELECT count(response) AS n FROM memory_requests WHERE brain_id=%s AND action IN ('recall','inspect')",
                                                    (profile.brain_id,)).fetchone()['n']
        if 'memory_read_cache' in tables:
            result['encoded_cache_bytes'] = int(conn.execute('SELECT coalesce(sum(response_bytes),0) AS n FROM memory_read_cache WHERE brain_id=%s',
                                                            (profile.brain_id,)).fetchone()['n'])
        for table in ('memory_events', 'memory_assertions'):
            rows = conn.execute(f'SELECT to_jsonb(t)::text AS data FROM {table} t WHERE brain_id=%s ORDER BY id,revision',
                                (profile.brain_id,)).fetchall()
            result[table]['content_sha256'] = hashlib.sha256('\n'.join(row['data'] for row in rows).encode()).hexdigest()
        return result


if arm == 'before':
    assert not directory.exists()
    profile = ensure_profile(directory, database_engine='embedded')
else:
    baseline = json.loads((root / 'http-before.json').read_text())
    assert baseline['completed'] and baseline['all_ports_closed']
    profile = load_profile(directory)
assert profile.cognition is None
assert not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
save()
try:
    assert desktop.start(directory)['ready']
    profile = load_profile(directory)
    with MemoryClient(profile.base_url, profile.api_key, profile.brain_id, timeout=30, trust_env=False) as client:
        if arm == 'before':
            for number in range(32):
                response = client.observe(f'The library appointment number {number} is beside the blue fountain.',
                                          source_event_key=f'library-{number}', conversation_id='source', branch_id='main')
                assert response['outcome'] == 'completed'
        deadline = time.monotonic() + 90
        while True:
            state = client.dashboard()['status']
            if not state.get('pending_jobs') and not state.get('index_lag'):
                break
            if time.monotonic() > deadline:
                raise TimeoutError('Source indexing did not finish.')
            time.sleep(.2)
        report['before'] = snapshot(profile)
        if arm == 'after':
            for table in ('memory_events', 'memory_assertions'):
                assert report['before'][table]['content_sha256'] == baseline['after'][table]['content_sha256']
        returned = []
        for number in range(query_count):
            began = time.perf_counter()
            response = client.recall('library appointment blue fountain', conversation_id='query', branch_id='main',
                                     budget=host.recall_budget(embeddings=0))
            elapsed = (time.perf_counter() - began) * 1000
            assert response['outcome'] == 'completed' and response['result']['items']
            assert response['result']['usage']['embedding_calls'] == 0
            returned.append(sorted(item['memory']['memory_id'] for item in response['result']['items']))
            report['samples'].append({'query': number, 'ms': elapsed, 'items': len(response['result']['items']),
                                      'diagnostics': len(response['result']['recall_traces'])})
            if (number + 1) % 250 == 0:
                current = snapshot(profile)
                if arm == 'after':
                    assert current['memory_read_cache']['rows'] <= 128 and current['encoded_cache_bytes'] <= 16*1024**2
                report['snapshots'].append({'queries': number + 1, 'state': current})
                save()
                print(json.dumps({'arm': arm, 'queries': number + 1, 'cached_rows': current.get('memory_read_cache', {}).get('rows'),
                                  'legacy_cached_reads': current['legacy_cached_reads']}), flush=True)
        report['after'] = snapshot(profile)
        for table in ('memory_events', 'memory_assertions'):
            assert report['before'][table]['content_sha256'] == report['after'][table]['content_sha256']
        report['returned_parent_ids_sha256'] = hashlib.sha256(json.dumps(returned).encode()).hexdigest()
        values = sorted(item['ms'] for item in report['samples'])
        report['timings'] = {'median_ms': statistics.median(values), 'p95_ms': values[math.ceil(.95*len(values))-1], 'maximum_ms': max(values)}
        report['completed'] = True
finally:
    desktop.stop(directory)
    report['all_ports_closed'] = not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
    report['source_unchanged'] = all(hashlib.sha256(Path(path).read_bytes()).hexdigest() == value for path, value in hashes.items())
    save()
    assert report['all_ports_closed'] and report['source_unchanged']
