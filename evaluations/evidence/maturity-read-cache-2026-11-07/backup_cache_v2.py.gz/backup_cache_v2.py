import json
import os
from pathlib import Path
import sys
import tempfile
import time

import httpx

os.environ.update(MEMBRAIN_SEMANTIC='0', PYTHON_DOTENV_DISABLED='1')
sys.path.insert(0, '/Users/yichen/tmp/membrain-read-cache-retention-20261107/tests')
from test_turns import Turns

from membrain import desktop, host
from membrain.build_identity import BUILD_ID, SCHEMA_ID
from membrain.client import MemoryActionError, MemoryClient
from membrain.desktop_backup import backup
from membrain.desktop_connection import open_client
from membrain.desktop_restore import activate, restore
from membrain.helpers import Principal, uid
from membrain.local_profile import ensure_profile, load_profile
from membrain.recovery_profile import authority_for
from membrain.service import MemoryService
from membrain.storage import Database

root = Path(__file__).parent
report = {'build_id': BUILD_ID, 'schema_id': SCHEMA_ID, 'completed': False, 'paid_or_subscription_calls': 0}


def harness(profile):
    turns = Turns.__new__(Turns)
    turns.database = Database(profile.database_url)
    turns.database.recovery_authority = authority_for(profile)
    turns.service = MemoryService(turns.database)
    turns.principal = Principal(profile.tenant_id, profile.principal_id)
    turns.brain = profile.brain_id
    turns.conversation, turns.branch = 'source', 'main'
    return turns


def events(turns):
    with turns.database.transaction(turns.principal) as conn:
        return conn.execute('SELECT id,revision,deleted,document FROM memory_events WHERE brain_id=%s ORDER BY id,revision',
                            (turns.brain,)).fetchall()


with tempfile.TemporaryDirectory(prefix='read-cache-recovery-', dir=root) as temporary:
    directory = Path(temporary)
    owned = []
    try:
        source = ensure_profile(directory / 'source', database_engine='embedded')
        owned.append(source.directory)
        with open_client(source.directory) as client:
            for number in range(2):
                client.observe(f'The library appointment number {number} is beside the blue fountain.',
                               source_event_key=f'library-{number}', conversation_id='source', branch_id='main')
            deadline = time.monotonic() + 60
            while client.dashboard()['status'].get('pending_jobs'):
                assert time.monotonic() < deadline
                time.sleep(.2)
            for _ in range(8):
                assert client.recall('library appointment blue fountain', conversation_id='query', branch_id='main',
                                     budget=host.recall_budget(embeddings=0))['outcome'] == 'completed'
        desktop.stop(source.directory)
        desktop._prepare_database(source)
        turns = harness(source)
        with turns.database.transaction(turns.principal) as conn:
            row = conn.execute('SELECT key FROM memory_read_cache WHERE brain_id=%s ORDER BY created_at DESC LIMIT 1',
                               (turns.brain,)).fetchone()
            assert row
            old_key = row['key']
            report['backed_up_cache_rows'] = conn.execute('SELECT count(*) AS n FROM memory_read_cache WHERE brain_id=%s',
                                                         (turns.brain,)).fetchone()['n']
            erased = conn.execute("SELECT id FROM memory_events WHERE brain_id=%s AND source_key='library-0' AND is_current",
                                  (turns.brain,)).fetchone()['id']
            generation = turns.service._brain(conn, turns.principal, turns.brain)['scope_generation']
        saved = backup(source.directory, output=directory / 'backup', request_id='read-cache-backup')
        turns.action('forget', {'idempotency_key': uid(), 'selector': {'kind': 'events', 'ids': [erased]},
                                'mode': 'erase_content', 'expected_scope_generation': generation})
        expected = events(turns)
        authority = authority_for(source)
        owned.append(directory / 'restored')
        result = restore(backup_path=directory / 'backup', directory=directory / 'restored',
                         registry_path=authority.registry.directory, request_id='read-cache-restore')
        assert result['state'] == 'quarantined'
        recovered = load_profile(directory / 'restored')
        restored = harness(recovered)
        with restored.database.transaction(restored.principal) as conn:
            for table in ('memory_read_cache', 'memory_cache_maintenance'):
                assert conn.execute(f'SELECT count(*) AS n FROM {table} WHERE brain_id=%s',
                                    (restored.brain,)).fetchone()['n'] == 0
        head = authority.registry.head()
        activated = activate(recovered.directory, recovery_epoch=result['recovery_epoch'], backup_id=saved['backup_id'],
                             checkpoint_at=result['checkpoint']['checkpoint_at'], retire_installation_id=source.installation_id,
                             expected_sequence=head['sequence'], expected_head_hash=head['head_hash'],
                             acknowledge_host_reconciliation=True)
        assert activated['state'] == 'active'
        assert events(restored) == expected
        assert desktop.start(recovered.directory)['ready']
        with MemoryClient(recovered.base_url, recovered.api_key, recovered.brain_id, trust_env=False) as unacknowledged:
            try:
                unacknowledged.recall('library appointment blue fountain')
            except httpx.HTTPStatusError as error:
                assert error.response.status_code == 409
                report['unacknowledged_error'] = error.response.json()['error']['code']
                assert report['unacknowledged_error'] == 'recovery_acknowledgement_required'
            else:
                raise AssertionError('The restored service accepted a client without its recovery epoch.')
        with open_client(recovered.directory, start_service=False) as client:
            try:
                client.recall('library appointment blue fountain', conversation_id='query', branch_id='main',
                              budget=host.recall_budget(embeddings=0), request_id=old_key)
            except MemoryActionError as error:
                assert error.code == 'version_conflict'
            else:
                raise AssertionError('A restored read receipt replayed its old payload.')
            response = client.recall('library appointment blue fountain', conversation_id='query', branch_id='main',
                                     budget=host.recall_budget(embeddings=0))
            assert response['outcome'] == 'completed' and response['result']['items']
            assert all(ref['event_id'] != erased for item in response['result']['items']
                       for ref in item['memory']['evidence_refs'])
        report.update(completed=True, private_streamed_backup=True, cache_cleared_in_quarantine=True,
                      cleanup_cursor_cleared=True, original_events_match_after_erasure=True,
                      old_read_replay_refused=True, fresh_http_recall_passed=True)
    finally:
        for path in reversed(owned):
            if (path / 'profile.json').is_file():
                profile = load_profile(path)
                desktop.stop(path)
                assert not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
        report['all_ports_closed'] = True
        (root / 'backup-cache-v2.json').write_text(json.dumps(report, indent=2) + '\n')
report['temporary_dump_and_restored_profile_removed'] = not directory.exists()
(root / 'backup-cache-v2.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
