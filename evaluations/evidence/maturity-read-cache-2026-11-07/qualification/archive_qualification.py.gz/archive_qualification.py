import gzip
import hashlib
import json
from pathlib import Path

root = Path(__file__).parent
repo = Path("/Users/yichen/tmp/membrain-read-cache-retention-20261107")
target = repo / "evaluations/evidence/maturity-read-cache-2026-11-07"
manifest = json.loads((target/"manifest.json").read_text())
files = [p for p in root.iterdir() if p.is_file() and p.suffix in {".py", ".json", ".log"} and p.name != "pr-body.md"]
for folder in ("visual", "ci"):
    files.extend(p for p in (root/folder).rglob("*") if p.is_file() and p.suffix in {".py", ".json", ".log", ".png", ".txt"} and p.name != "verify-collection.log")
files.append(root/"install-final/results.json")
profiles = list((root/"install-final").rglob("profile.json"))
profiles.append(Path("/Users/yichen/tmp/membrain-xml-integration-20261105/performance/perf-recall-cache-installation/profile.json"))
secrets = set()
for profile in profiles:
    data = json.loads(profile.read_text())
    for key in ("api_key", "admin_password", "app_password"):
        if data.get(key): secrets.add(data[key].encode())
entries = {entry["path"]: entry for entry in manifest["files"]}
for path in sorted(files):
    data = path.read_bytes()
    assert not any(secret in data for secret in secrets), path.name
    name = "qualification/" + str(path.relative_to(root)) + ("" if path.suffix == ".png" else ".gz")
    payload = data if path.suffix == ".png" else gzip.compress(data, mtime=0)
    destination = target/name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(payload)
    entries[name] = {"path": name, "bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest(), "original_bytes": len(data), "original_sha256": hashlib.sha256(data).hexdigest()}
for entry in entries.values():
    payload = (target/entry["path"]).read_bytes()
    raw = gzip.decompress(payload) if entry["path"].endswith(".gz") else payload
    assert hashlib.sha256(payload).hexdigest() == entry["sha256"]
    assert hashlib.sha256(raw).hexdigest() == entry["original_sha256"]
    assert not any(secret in raw for secret in secrets), entry["path"]
manifest["files"] = list(entries.values())
manifest["qualification_privacy_scan"] = {"owned_credential_values": len(secrets), "matches": 0, "private_profiles_dumps_excluded": True}
manifest["qualification_scope"] = "Exact installed runtime493: fresh49check installation,194runtime inputs in2homes,117installed regressions, full currentR5, five native platforms and47audited summaries, fullCI remains pending. Public encoding diagnosis is exploratory and does not alter runtime or establish recall improvements. No paid/subscription evaluation."
(target/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
print({"added_or_updated":len(files), "total":len(entries), "credential_values_checked":len(secrets), "matches":0})
