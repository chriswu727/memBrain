import subprocess,sys
from pathlib import Path
root=Path(__file__).parent
subprocess.run(["gh","run","watch","42368700922","--repo","chriswu727/memBrain","--interval","30","--exit-status"],check=False)
raise SystemExit(subprocess.run([sys.executable,str(root/"collect_verify.py")]).returncode)
