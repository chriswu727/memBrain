import hashlib,json,os,re,socket
from pathlib import Path
for name in list(os.environ):
    if name.startswith(("MEMORY_","MEMBRAIN_","C5_")) or name.endswith(("_API_KEY","_API_TOKEN")): del os.environ[name]
os.environ["PYTHON_DOTENV_DISABLED"]="1"
import numpy as np
import psycopg
from psycopg.rows import dict_row
from membrain import embedded_database
from membrain.local_embeddings import LocalEmbeddingProvider, model_directory
from membrain.local_profile import load_profile
root=Path(__file__).parent
fixture=Path("/Users/yichen/tmp/membrain-semantic-balance-1000-20261107")
original=json.loads((fixture/"report.json").read_text())
profile=load_profile(fixture/"installation")
report={"completed":False,"public_fixture":str(fixture),"provider_calls":0,"subscription_calls":0,"protocol":"Read-only stored vectors, unchanged original public queries; compare any-CJK membership to majority of alphabetic source characters after excluding the direct-capture envelope. Fixed global184/other16 pool, one-other-per-three primary interleave. Diagnostic vector ranks only, not full API/host results.","samples":[]}
cjk=re.compile("[\u3400-\u9fff]")
def content(doc):
    refs=doc.get("evidence_refs",[])
    if doc.get("derivation",{}).get("method")=="direct_capture" and len(refs)==1:
        span=refs[0].get("span",{})
        if span.get("unit")=="unicode_code_point" and type(span.get("start")) is int and type(span.get("end")) is int:
            count=span["end"]-span["start"]
            if 0<count<=len(doc["statement"]):return doc["statement"][-count:]
    return doc["statement"]
def majority(text):
    return len(cjk.findall(text))*2>sum(c.isalpha() for c in text)
assert all(not __import__('membrain.desktop',fromlist=['_port_open'])._port_open(port) for port in (profile.api_port,profile.database_port))
try:
    embedded_database.start(profile)
    with psycopg.connect(profile.migration_database_url,row_factory=dict_row) as conn:
        conn.execute("SET TRANSACTION READ ONLY")
        rows=conn.execute("SELECT a.id,a.document,v.embedding::text AS vector FROM memory_assertions a JOIN memory_embeddings v ON (a.tenant_id,a.owner_id,a.brain_id,a.id,a.revision)=(v.tenant_id,v.owner_id,v.brain_id,v.memory_id,v.memory_revision) WHERE a.brain_id=%s AND a.is_current AND NOT a.deleted ORDER BY a.id",(profile.brain_id,)).fetchall()
        assert len(rows)==1000,len(rows)
        report["corpus_sha256"]=hashlib.sha256(json.dumps(rows,sort_keys=True,default=str).encode()).hexdigest()
finally:
    embedded_database.stop(profile)
    report["all_ports_closed"]=all(not __import__('membrain.desktop',fromlist=['_port_open'])._port_open(port) for port in (profile.api_port,profile.database_port))
provider=LocalEmbeddingProvider(model_directory(profile.directory))
vectors=np.array([json.loads(r["vector"]) for r in rows])
for case in (6,12,16):
    example=original["cases"][case]
    q=np.array(provider.embed([example["query"]],purpose="query").vectors[0])
    order=sorted(range(len(rows)),key=lambda i:(-float(vectors[i]@q),rows[i]["id"]))
    target=next(i for i,row in enumerate(rows) if content(row["document"])==example["source"])
    result={"case":case,"query":example["query"],"source":example["source"],"global_rank":order.index(target)+1,"arms":[]}
    for mode in ("any_cjk","majority_source_script"):
        predicate=(lambda t:bool(cjk.search(t))) if mode=="any_cjk" else majority
        other=[i for i in order if predicate(rows[i]["document"]["statement"] if mode=="any_cjk" else content(rows[i]["document"]))!=predicate(example["query"])]
        primary=order[:184];extra=iter(other[:16]);seen=set();merged=[];n=0
        for i in primary:
            if i in seen:continue
            seen.add(i);merged.append(i);n+=1
            if n%3==0:
                for j in extra:
                    if j not in seen:seen.add(j);merged.append(j);break
        for j in extra:
            if j not in seen:seen.add(j);merged.append(j)
        result["arms"].append({"mode":mode,"other_rank":other.index(target)+1 if target in other else None,"merged_rank":merged.index(target)+1 if target in merged else None,"top_other_sources":[content(rows[i]["document"]) for i in other[:5]]})
    report["samples"].append(result)
report["completed"]=True
(root/"semantic-script-diagnostic.json").write_text(json.dumps(report,indent=2,ensure_ascii=False)+"\n")
print(json.dumps(report,ensure_ascii=False))
