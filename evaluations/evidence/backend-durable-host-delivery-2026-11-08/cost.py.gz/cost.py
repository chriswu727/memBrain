import json
import shutil
import statistics
import tempfile
import time
from pathlib import Path

from membrain import host


class Client:
    brain_id = 'synthetic-journal-cost'

    def __init__(self):
        self.observed = []

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def observe(self, **record):
        self.observed.append(record)

    def recall(self, *args, **kwargs):
        return {'result': {'items': []}}


root = Path(tempfile.mkdtemp(prefix='membrain-durable-host-cost-')).resolve()
client = Client()
host.ready_client = lambda *args: client
host.start_in_background = lambda *args: None
samples = []
try:
    for i in range(44):
        host.prompt_context(root, 's', 'Synthetic public appointment ' + str(i), turn_id=str(i))
        started = time.perf_counter_ns()
        result = host.finish_turn(root, 's', 'Recorded synthetic appointment ' + str(i), turn_id=str(i))
        elapsed = (time.perf_counter_ns() - started) / 1e6
        assert len(result) == 2
        if i >= 4:
            samples.append(elapsed)
    assert len(client.observed) == 88
    print(json.dumps({'package': str(Path(host.__file__).resolve()), 'samples_ms': samples,
                      'median_ms': statistics.median(samples), 'p95_ms': sorted(samples)[37],
                      'scope': 'Local finish callback with synchronous filesystem writes and a fake transport; no database, model or end-to-end recall timing.'}))
finally:
    shutil.rmtree(root)
