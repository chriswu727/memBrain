import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

prefix = Path('/private/tmp')
owned = [prefix / ('membrain-durable-host-' + suffix) for suffix in (
    'baseline-package', 'baseline', 'focused', 'corrupt', 'concurrency',
)]
receipts = []
for path in owned:
    if not path.exists():
        continue
    assert not path.is_symlink(), path
    assert not list(path.rglob('postmaster.pid')), path
    processes = subprocess.check_output(['ps', '-eo', 'pid,command'], text=True).splitlines()
    assert not any(str(path) in line for line in processes if line.split()[0] != str(os.getpid())), path
    size = sum(p.stat().st_size for p in path.rglob('*') if p.is_file() and not p.is_symlink())
    shutil.rmtree(path)
    receipts.append({'path': str(path), 'logical_bytes_removed': size})
receipt = {'removed': receipts, 'free_bytes_after': shutil.disk_usage(prefix).free,
           'scope': 'Task-owned stopped probe fixtures and baseline package only; no real profiles, models, backups or source worktrees.'}
(prefix / 'membrain-durable-host-cleanup.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
