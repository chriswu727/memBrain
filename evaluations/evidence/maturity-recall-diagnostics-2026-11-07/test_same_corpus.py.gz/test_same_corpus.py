import importlib.util,json
from pathlib import Path
from test_recall_executor import canonical
from test_response_validation import recall_request
from test_turns import turns as turns
from test_vector_jobs import drain
from membrain.helpers import now


def test_same_corpus(turns):
    path=Path('/Users/yichen/tmp/membrain-passage-index-delivery-20261107/install-final/uv-tools/membrain-ai/lib/python3.12/site-packages/membrain/service.py')
    assert path.is_file()
    spec=importlib.util.spec_from_file_location('membrain._trace_storage_baseline',path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    for number in range(32):
        turns.observe(f'The library appointment number {number} is beside the blue fountain.')
        drain(turns)
    baseline=module.MemoryService(turns.database)
    stamp=now()
    baseline.access_time_provider=lambda:stamp
    turns.service.access_time_provider=lambda:stamp
    def rows():
        with turns.database.transaction(turns.principal) as conn:
            return conn.execute('SELECT count(*) AS n FROM memory_traces WHERE brain_id=%s',(turns.brain,)).fetchone()['n']
    samples=[]
    for number in range(20):
        before=rows()
        old=baseline.handle(turns.principal,recall_request(turns.brain,query=f'library appointment {number} blue fountain'))
        assert old['outcome']=='completed' and old['result']['items']
        after_old=rows()
        new=turns.service.handle(turns.principal,recall_request(turns.brain,query=f'library appointment {number} blue fountain'))
        assert new['outcome']=='completed' and new['result']['items']
        assert canonical(old['result'])==canonical(new['result'])
        assert rows()==after_old
        assert after_old-before==len(old['result']['recall_traces'])
        samples.append({'case':number,'canonical_results_equal':True,'baseline_extra_rows':after_old-before,'fixed_extra_rows':0})
    Path(__file__).with_name('same-corpus.json').write_text(json.dumps({'completed':True,'cases':samples,'normalization':'Only recall/snapshot/trace identities, timestamps and elapsed_ms; same original source IDs, database, clock, query and result budget. Original installed service module versus current service; all other modules identical.','paid_calls':0},indent=2)+'\n')
