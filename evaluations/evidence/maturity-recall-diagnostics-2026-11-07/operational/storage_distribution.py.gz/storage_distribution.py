import json,time
from pathlib import Path
import psycopg
from membrain import desktop,embedded_database
from membrain.local_profile import load_profile
root=Path(__file__).parent
profile=load_profile(Path('/Users/yichen/tmp/membrain-xml-integration-20261105/performance/perf-recall-cache-installation'))
report={'completed':False,'read_only':True}
assert not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
try:
    embedded_database.start(profile)
    with psycopg.connect(profile.migration_database_url) as conn:
        conn.execute('SET TRANSACTION READ ONLY')
        conn.execute("SET statement_timeout='120s'")
        conn.execute("SET work_mem='8MB'")
        started=time.monotonic()
        report['traces']=[{'kind':r[0],'count':r[1]} for r in conn.execute("SELECT document->>'kind',count(*) FROM memory_traces GROUP BY 1")]
        report['requests']=[{'action':r[0],'count':r[1],'cached':r[2],'live_response_bytes':r[3]} for r in conn.execute("SELECT action,count(*),count(response),coalesce(sum(pg_column_size(response)),0) FROM memory_requests GROUP BY action")]
        report['query_seconds']=time.monotonic()-started
        report['relations']=[{'name':r[0],'bytes_including_indexes':r[1]} for r in conn.execute("SELECT relname,pg_total_relation_size(relid) FROM pg_stat_user_tables WHERE relname IN ('memory_requests','memory_traces','memory_events','memory_assertions')")]
        report['completed']=True
finally:
    embedded_database.stop(load_profile(profile.directory))
    report['all_ports_closed']=not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
    (root/'storage-distribution.json').write_text(json.dumps(report,indent=2)+'\n')
    assert report['all_ports_closed']
print(json.dumps(report,indent=2))
