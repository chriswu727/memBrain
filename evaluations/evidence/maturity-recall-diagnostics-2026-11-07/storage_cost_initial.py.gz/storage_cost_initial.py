import json,os,time
from pathlib import Path
import pytest
from test_response_validation import recall_request
from test_turns import turns as turns
from test_vector_jobs import drain
from membrain.build_identity import BUILD_ID

@pytest.mark.integration
def test_storage_cost(turns):
    for number in range(32):
        turns.observe(f'The library appointment number {number} is beside the blue fountain.')
    drain(turns)
    def size():
        with turns.database.transaction(turns.principal) as conn:
            return {table:dict(conn.execute(f"SELECT count(*) AS rows,coalesce(sum(pg_column_size(t)),0) AS live_row_bytes FROM {table} t WHERE brain_id=%s",(turns.brain,)).fetchone()) for table in ('memory_traces','memory_requests','memory_events','memory_assertions')}
    before=size()
    started=time.perf_counter()
    traces=0
    responses=[]
    for _ in range(200):
        result=turns.service.handle(turns.principal,recall_request(turns.brain))
        assert result['outcome']=='completed' and result['result']['items']
        traces+=len(result['result']['recall_traces'])
        responses.append(sorted(item['memory']['statement'] for item in result['result']['items']))
    report={'build_id':BUILD_ID,'queries':200,'candidate_traces_returned':traces,'elapsed_seconds':time.perf_counter()-started,'before':before,'after':size(),'returned_statements':responses,'paid_calls':0}
    Path(__file__).with_name(os.environ['STORAGE_ARM']+'-cost.json').write_text(json.dumps(report,indent=2)+'\n')
