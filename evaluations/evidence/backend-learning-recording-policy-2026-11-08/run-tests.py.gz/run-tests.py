import os,subprocess,sys
from pathlib import Path
from membrain.local_profile import ensure_profile
from membrain import embedded_database
from membrain.cli import bootstrap
from membrain.config import Settings
os.environ['PYTHON_DOTENV_DISABLED']='1'
os.environ['MEMBRAIN_SEMANTIC']='0'
profile=ensure_profile(Path('/private/tmp/membrain-learning-fence-tests-db'),database_engine='embedded')
try:
    embedded_database.start(profile)
    bootstrap(Settings(database_url=profile.database_url, migration_database_url=profile.migration_database_url), app_password=profile.app_password)
    os.environ['MEMORY_DATABASE_URL']=profile.database_url
    os.environ['MEMORY_MIGRATION_DATABASE_URL']=profile.migration_database_url
    result=subprocess.run([sys.executable,'-m','pytest',*sys.argv[1:]])
    raise SystemExit(result.returncode)
finally:
    embedded_database.stop(profile)
