import hashlib,json,math,os,socket,statistics,time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
acceptance_state = Path("/Users/yichen/tmp/membrain-acceptance-20261107b/evaluations/.maturity-heldout-20261107b/runs/attempt-state.json")
assert acceptance_state.exists() and json.loads(acceptance_state.read_text())["result"] in {"complete", "stopped", "interrupted"}, "Wait for the authorized acceptance workload to finish."
for name in list(os.environ):
    if name.startswith(("MEMORY_","MEMBRAIN_","C5_")) or name.endswith(("_API_KEY","_API_TOKEN")):del os.environ[name]
os.environ.update(MEMBRAIN_SEMANTIC="0",PYTHON_DOTENV_DISABLED="1")
import psycopg
from psycopg import sql
from membrain import desktop,host
from membrain.build_identity import BUILD_ID
from membrain.client import MemoryClient
from membrain.local_profile import load_profile
root=Path(__file__).parent
repo=Path('/Users/yichen/tmp/membrain-review-20261029')
profile=load_profile(Path('/Users/yichen/tmp/membrain-semantic-scale-20261107/installation'))
original=json.loads(Path('/Users/yichen/tmp/membrain-semantic-scale-20261107/report.json').read_text())
cases=original['cases']
assert len(cases)==20
assert BUILD_ID=='483d6508d9e4b873e88a6aac413b49115ba134588d962b431e9c4b72235ea6a3'
hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (repo/'src').rglob('*') if p.is_file() and '__pycache__' not in p.parts}
report={'completed':False,'build_id':BUILD_ID,'protocol':'Instrumented action-stage diagnosis, timing wrappers only in a separate Python environment; production installed files unchanged. The wrappers add observability overhead, so timings are diagnostic, not acceptance. Endpoint timing diagnostic for the observed concurrent host latency. Same questions and budgets; each HTTP request is timed without changing requests. Not a new acceptance run. Actual cached ONNX semantics and full host context on unchanged public10000-source corpus. Fresh service. Serial then eight concurrent clients of one brain. Each client records one explicit warmup followed by all20 original questions, rotated by worker index. Original5000ms host budget unchanged. Report every fallback/error/miss including warmups. No generation or paid/subscription calls; descriptive capacity probe, not R4/C5 or R5 acceptance.','paid_provider_calls':0,'subscription_calls':0,'phases':[]}
def save():
    (root/'action-profile.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+"\n")
def snapshot():
    result={}
    with psycopg.connect(profile.migration_database_url) as conn:
        conn.execute('SET TRANSACTION READ ONLY')
        for name in ('memory_events','memory_assertions','memory_embeddings','memory_embedding_passages'):
            rows=conn.execute(sql.SQL("SELECT to_jsonb(t)::text FROM {} t WHERE brain_id=%s ORDER BY to_jsonb(t)::text").format(sql.Identifier(name)),(profile.brain_id,)).fetchall()
            result[name]={'rows':len(rows),'sha256':hashlib.sha256(json.dumps(rows).encode()).hexdigest()}
    return result
BaseMemoryClient = MemoryClient
class MemoryClient(BaseMemoryClient):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.endpoint_timings=[]
    def _request(self,method,path,**kwargs):
        began=time.perf_counter()
        item={'method':method,'path':path,'request_id':(kwargs.get('json') or {}).get('request_id')}
        try:
            result=super()._request(method,path,**kwargs)
            item['completed']=True
            return result
        except Exception as error:
            item['error']=type(error).__name__
            raise
        finally:
            item['ms']=round((time.perf_counter()-began)*1000,3)
            self.endpoint_timings.append(item)

class RecordingClient:
    def __init__(self,client):self.client=client;self.calls=[]
    def __getattr__(self,name):return getattr(self.client,name)
    def recall(self,*args,**kwargs):
        try:
            response=self.client.recall(*args,**kwargs)
            self.calls.append({'outcome':response.get('outcome'),'usage':response.get('result',{}).get('usage')})
            return response
        except Exception as error:
            self.calls.append({'error':type(error).__name__})
            raise

def worker(index):
    records=[]
    with MemoryClient(profile.base_url,profile.api_key,profile.brain_id,timeout=30) as client:
        for offset in range(21):
            case=(index+max(0,offset-1))%20
            client.endpoint_timings=[];wrapped=RecordingClient(client);start=time.perf_counter()
            entry={'worker':index,'case':case,'warmup':offset==0}
            try:
                context=host.recall_context(wrapped,cases[case]['query'],current_conversation='synthetic-query')
                entry.update(nonempty=bool(context),hit=cases[case]['source'] in (context or ''))
            except Exception as error:
                entry.update(error=type(error).__name__,nonempty=False,hit=False)
            entry.update(ms=round((time.perf_counter()-start)*1000,3),recall_calls=wrapped.calls,endpoint_timings=client.endpoint_timings)
            entry['semantic_without_fallback']=len(wrapped.calls)==1 and wrapped.calls[0].get('usage',{}).get('embedding_calls')==1
            records.append(entry)
    return records

save()
assert not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
try:
    host.start(profile.directory)
    assert desktop.status(profile.directory)['ready']
    with MemoryClient(profile.base_url,profile.api_key,profile.brain_id) as client:
        assert client._request('GET','v1/local/memory-status')['semantic_recall']=='ready'
    report['core_before']=snapshot()
    for workers in (1,8):
        began=time.monotonic()
        with ThreadPoolExecutor(max_workers=workers) as pool:
            samples=[sample for result in pool.map(worker,range(workers)) for sample in result]
        measured=[s for s in samples if not s['warmup']];values=sorted(s['ms'] for s in measured)
        phase={'workers':workers,'seconds':time.monotonic()-began,'samples':samples,'summary':{'queries':len(values),'median_ms':statistics.median(values),'p95_ms':values[math.ceil(len(values)*.95)-1],'max_ms':max(values),'hits':sum(s['hit'] for s in measured),'semantic_without_fallback':sum(s['semantic_without_fallback'] for s in measured),'warmup_errors':sum('error' in s for s in samples if s['warmup'])}}
        report['phases'].append(phase);save();print(json.dumps({'workers':workers,'summary':phase['summary']}),flush=True)
    report['core_after']=snapshot();report['core_unchanged']=report['core_before']==report['core_after']
    report['completed']=True
finally:
    desktop.stop(profile.directory)
    report['all_ports_closed']=not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
    report['source_unchanged']=all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in hashes.items())
    save()
raise SystemExit(0 if report['completed'] and report['core_unchanged'] and report['all_ports_closed'] and report['source_unchanged'] and all(s['semantic_without_fallback'] and s['hit'] for p in report['phases'] for s in p['samples']) else 1)
