import os,sys,runpy
from pathlib import Path
for name in list(os.environ):
    if name.startswith(('MEMORY_','MEMBRAIN_','C5_')) or name.endswith(('_API_KEY','_API_TOKEN')):del os.environ[name]
sys.path.append('/Users/yichen/tmp/membrain-review-20261029/.venv/lib/python3.12/site-packages')
import membrain
from membrain.build_identity import BUILD_ID
assert Path(membrain.__file__).is_relative_to(Path(sys.executable).parent.parent)
assert BUILD_ID=='5f8ad59f4ef931f000b1c2531eb0f735262823e550fd825bffb206d9336fc11e'
print({'package':membrain.__file__,'build_id':BUILD_ID},flush=True)
sys.argv=[str(Path(__file__).parent/'run_tests.py'),'wheel-fixed','-q','-c','pytest.ini','test_candidates.py','test_cross_script_candidates.py','test_source_candidates.py','test_source_passages.py','test_passage_index.py','test_candidate_speech_budget.py','test_recall_diversity.py','test_semantic_pools.py']
runpy.run_path(sys.argv[0],run_name='__main__')
