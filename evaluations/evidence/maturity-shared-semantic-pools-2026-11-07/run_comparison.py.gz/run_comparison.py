import json
from pathlib import Path
import subprocess
root=Path(__file__).parent
baseline=Path('/Users/yichen/tmp/membrain-review-20261029')
candidate=Path('/Users/yichen/tmp/membrain-recall-query-plan-20261107')
builds={'baseline':'483d6508d9e4b873e88a6aac413b49115ba134588d962b431e9c4b72235ea6a3','candidate':'5f8ad59f4ef931f000b1c2531eb0f735262823e550fd825bffb206d9336fc11e'}
for name in ['baseline1','candidate1','candidate2','baseline2']:
    variant='baseline' if name.startswith('baseline') else 'candidate'
    repo=baseline if variant=='baseline' else candidate
    with (root/(name+'.log')).open('x') as log:
        result=subprocess.run([str(repo/'.venv/bin/python'),str(root/'compare_profile.py'),name,str(repo),builds[variant]],cwd=repo,stdout=log,stderr=log)
    print(json.dumps({'phase':name,'exit':result.returncode}),flush=True)
    if result.returncode:raise SystemExit(result.returncode)
