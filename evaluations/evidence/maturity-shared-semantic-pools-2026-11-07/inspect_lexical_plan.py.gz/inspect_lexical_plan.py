import json,os
from pathlib import Path
for name in list(os.environ):
    if name.startswith(('MEMORY_','MEMBRAIN_','C5_')) or name.endswith(('_API_KEY','_API_TOKEN')):del os.environ[name]
os.environ.update(MEMBRAIN_SEMANTIC='0',PYTHON_DOTENV_DISABLED='1')
import psycopg
from psycopg.rows import dict_row
from membrain import desktop,embedded_database
from membrain.lexical_candidates import lexical_rows
from membrain.local_profile import load_profile
root=Path(__file__).parent
profile=load_profile(Path('/Users/yichen/tmp/membrain-semantic-scale-20261107/installation'))
cases=json.loads(Path('/Users/yichen/tmp/membrain-semantic-scale-20261107/report.json').read_text())['cases']
report={'completed':False,'scope':'Two existing public queries, read-only EXPLAIN ANALYZE of lexical candidate SQL on the unchanged 10000-memory corpus; diagnostic only, no provider calls.','queries':[]}
class Capture:
    def __init__(self,conn):self.conn=conn;self.captured=[]
    def execute(self,query,params):
        self.captured.append((query,params))
        return self.conn.execute(query,params)
assert not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
try:
    embedded_database.start(profile)
    with psycopg.connect(profile.database_url,row_factory=dict_row) as conn:
        conn.execute('SET TRANSACTION READ ONLY')
        conn.execute("SELECT set_config('app.tenant_id',%s,true),set_config('app.principal_id',%s,true)",(profile.tenant_id,profile.principal_id))
        for index in (0,10):
            capture=Capture(conn)
            lexical_rows(capture,(profile.tenant_id,profile.principal_id,profile.brain_id),{'brain_ref':profile.brain_id,'conversation_ref':'synthetic-query','branch_ref':'main'},cases[index]['query'],limit=128,include_speech=False)
            for query,params in capture.captured:
                plan=conn.execute('EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) '+query,params).fetchone()['QUERY PLAN'][0]
                nodes=[]
                def visit(node):
                    nodes.append(node)
                    for child in node.get('Plans',[]):visit(child)
                visit(plan['Plan'])
                report['queries'].append({'case_index':index,'sql':query,'execution_ms':plan['Execution Time'],'indexes':sorted({node['Index Name'] for node in nodes if 'Index Name' in node}),'lexical_gin_used':any(node.get('Index Name')=='memory_assertions_search' for node in nodes),'plan':plan})
    report['completed']=True
finally:
    embedded_database.stop(profile)
    report['ports_closed']=not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
    (root/'lexical-plan.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'completed':report['completed'],'ports_closed':report['ports_closed'],'queries':[{key:row[key] for key in ['case_index','execution_ms','indexes','lexical_gin_used']} for row in report['queries']]}))
