import hashlib,json,os,statistics,time
from pathlib import Path
for name in list(os.environ):
    if name.startswith(('MEMORY_','MEMBRAIN_','C5_')) or name.endswith(('_API_KEY','_API_TOKEN')):del os.environ[name]
os.environ.update(MEMBRAIN_SEMANTIC='0',PYTHON_DOTENV_DISABLED='1')
import psycopg
from psycopg.rows import dict_row
from membrain import desktop,embedded_database
from membrain.lexical_candidates import lexical_rows
from membrain.local_profile import load_profile
root=Path(__file__).parent
profile=load_profile(Path('/Users/yichen/tmp/membrain-semantic-scale-20261107/installation'))
cases=json.loads(Path('/Users/yichen/tmp/membrain-semantic-scale-20261107/report.json').read_text())['cases']
report={'completed':False,'scope':'Public read-only SQL prototype only. Same lexical_rows code; intercept only the lexical term SQL to join the stored indexed relation. No runtime source edit, no provider calls. 20 queries x 2 limits x baseline/candidate/candidate/baseline. Not an end-to-end host benchmark or acceptance.','samples':[]}
class Rewrite:
    def __init__(self,conn,variant):self.conn=conn;self.variant=variant;self.modified=False
    def execute(self,query,params):
        if self.variant=='candidate' and query.startswith('WITH eligible'):
            old="a.embedding <=> %s::vector AS distance,to_tsvector('simple',a.search_text) AS lexemes "
            new="a.embedding <=> %s::vector AS distance "
            assert query.count(old)==1
            query=query.replace(old,new)
            old="FROM eligible WHERE lexemes @@ term.query "
            new="FROM eligible JOIN memory_assertions indexed USING (tenant_id,owner_id,brain_id,id,revision) WHERE to_tsvector('simple',indexed.search_text) @@ term.query "
            assert query.count(old)==1
            query=query.replace(old,new);self.modified=True
        return self.conn.execute(query,params)
def save(): (root/'lexical-index-probe.json').write_text(json.dumps(report,indent=2)+'\n')
assert not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
try:
    embedded_database.start(profile)
    with psycopg.connect(profile.database_url,row_factory=dict_row) as conn:
        conn.execute('SET TRANSACTION READ ONLY')
        conn.execute("SELECT set_config('app.tenant_id',%s,true),set_config('app.principal_id',%s,true)",(profile.tenant_id,profile.principal_id))
        for index,case in enumerate(cases):
            for limit in (128,512):
                expected=None
                for position,variant in enumerate(('baseline','candidate','candidate','baseline')):
                    wrapped=Rewrite(conn,variant);began=time.perf_counter()
                    output=lexical_rows(wrapped,(profile.tenant_id,profile.principal_id,profile.brain_id),{'brain_ref':profile.brain_id,'conversation_ref':'synthetic-query','branch_ref':'main'},case['query'],limit=limit,include_speech=False)
                    elapsed=1000*(time.perf_counter()-began)
                    if expected is None:expected=output
                    equal=expected==output
                    report['samples'].append({'case_index':index,'limit':limit,'variant':variant,'position':position,'ms':elapsed,'modified':wrapped.modified,'equal':equal})
                    save()
                    if not equal:raise AssertionError('Prototype changed lexical output; do not use it.')
            print(json.dumps({'case_index':index,'samples':len(report['samples'])}),flush=True)
    report['completed']=True
finally:
    embedded_database.stop(profile)
    report['ports_closed']=not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
    save()
for limit in (128,512):
    for variant in ('baseline','candidate'):
        selected=[s['ms'] for s in report['samples'] if s['limit']==limit and s['variant']==variant and s['case_index']>=10]
        print(json.dumps({'limit':limit,'variant':variant,'word_channel_queries':len(selected),'median_ms':statistics.median(selected)}))
