import json, subprocess
from pathlib import Path

root = Path(__file__).parent
source = '422fac168babd21581889ccedb192f3e652b48b0'
runs = [42673189368, 42673909552, 42673913787, 42673918492, 42673923840]
states = []
for run in runs:
    state = json.loads(subprocess.check_output(['gh', 'run', 'view', str(run), '--json', 'databaseId,headSha,status,conclusion,jobs,url,attempt']))
    assert state['headSha'] == source and state['status'] == 'completed'
    jobs = [j for j in state['jobs'] if j['name'].startswith('native (')]
    assert len(jobs) == 1 and jobs[0]['conclusion'] == 'success'
    steps = {s['name']: s['conclusion'] for s in jobs[0]['steps']}
    assert steps['Download an existing owned candidate for isolated verification'] == 'success'
    assert all(v == 'skipped' for k, v in steps.items() if k.startswith('Build portable'))
    assert state['conclusion'] == ('failure' if run == 42673189368 else 'success')
    if run in runs[1:4]:
        assert state['attempt'] == 2
    states.append(state)
(root / 'completed-native-status.json').write_text(json.dumps(states, indent=2) + '\n')
subprocess.run(['python3', str(root / 'audit-native.py')], check=True)
audit = json.loads((root / 'native-audit/native-summary-audit.json').read_text())
assert audit['count'] == 47 and len(audit['temporary_chat_checks']) == 15
assert audit['duplicate_qualification_copies_excluded'] == 5
assert len(audit['by_platform']) == 5
paths = ['scripts/build_native_bundle.py', 'src/membrain/resources/native', 'pyproject.toml', 'uv.lock', '.github/workflows/native-engine.yml']
subprocess.run(['git', 'diff', '--exit-code', '27a61078039606563e1effeaca0e2cd1a63038ac', source, '--', *paths], check=True)
subprocess.run(['git', 'diff', '--exit-code', source, '50936ca68a3fa36cfe8bbb736ea9e65f40d7f170', '--', 'src', 'migrations', 'tests', 'scripts', 'pyproject.toml', 'uv.lock', 'plugins', 'integrations'], check=True)
result = {'qualification_source': source, 'runtime_commit': '978312c3140bc7745f619014b9c3ead12fece0ed', 'all_selected_jobs_passed': True, 'all_workflows_passed': False, 'historical_workflow_failure': 42673189368, 'failure_reason': 'GitHub internal server error prevented other matrix jobs from being created; the selected Intel job passed.', 'supplier_run': 42574397718, 'supplier_inputs_unchanged': paths, 'logical_summaries': 47, 'duplicate_copies_excluded': 5, 'temporary_chat_journeys': 15, 'platforms': audit['by_platform'], 'model_calls': 0}
(root / 'qualification-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
