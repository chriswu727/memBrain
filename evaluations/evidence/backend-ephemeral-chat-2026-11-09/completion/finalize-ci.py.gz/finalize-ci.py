import json,re,subprocess
from pathlib import Path
run='42673202623'
status=json.loads(subprocess.check_output(['gh','run','view',run,'--json','databaseId,headSha,status,conclusion,jobs,url']))
Path('/private/tmp/membrain-ephemeral-closeout/verify-status.json').write_text(json.dumps(status,indent=2)+'\n')
assert status['headSha']=='422fac168babd21581889ccedb192f3e652b48b0'
if status['status']!='completed':
    print(json.dumps({'status':status['status']}))
    raise SystemExit(0)
job=next(j for j in status['jobs'] if j['name']=='runtime')
log=Path('/private/tmp/membrain-ephemeral-closeout/verify-job.log')
with log.open('wb') as out:
    subprocess.run(['gh','api',f'repos/chriswu727/memBrain/actions/jobs/{job["databaseId"]}/logs'],stdout=out,check=True)
content=log.read_text()
lines=[line for line in content.splitlines() if re.search(r'\d+ passed.* in |# (tests|pass|fail|skipped) |Successfully built|error TS|FAILED tests/|short test summary',line)]
result={'run_id':int(run),'job_id':job['databaseId'],'conclusion':status['conclusion'],'source_commit':status['headSha'],'direct_job_log':log.name,'lines':lines}
Path('/private/tmp/membrain-ephemeral-closeout/verify-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
assert status['conclusion']=='success', 'The full Verify workflow did not pass.'
assert re.search(r'8256 passed[^\n]* in ',content), 'Full Python result missing or unexpected.'
assert re.search(r'# tests 56\b',content) and re.search(r'# pass 56\b',content)
assert re.search(r'# fail 0\b',content) and re.search(r'# skipped 0\b',content)
