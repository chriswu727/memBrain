import json,subprocess,time
from pathlib import Path
root=Path(__file__).parent
runs=[42673909552,42673913787,42673918492]
previous={}
while runs:
    for run in list(runs):
        raw=subprocess.check_output(['gh','run','view',str(run),'--json','databaseId,headSha,status,conclusion,jobs,url'],text=True)
        data=json.loads(raw)
        assert data['headSha']=='422fac168babd21581889ccedb192f3e652b48b0'
        summary={'run':run,'status':data['status'],'conclusion':data['conclusion'],'active':[s['name'] for j in data['jobs'] for s in j.get('steps',[]) if s['status']=='in_progress']}
        if previous.get(run)!=summary:print(json.dumps(summary),flush=True);previous[run]=summary
        if data['status']=='completed':
            (root/f'run-{run}-attempt-2.json').write_text(raw+'\n');runs.remove(run)
    if runs:time.sleep(40)
