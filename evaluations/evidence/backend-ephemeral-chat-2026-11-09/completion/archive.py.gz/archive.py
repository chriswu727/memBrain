import gzip, hashlib, json, re, sys
from pathlib import Path

root = Path(__file__).parent
repo = Path('/Users/yichen/tmp/membrain-review-20261029')
sys.path.insert(0, str(repo / 'src'))
from membrain.privacy import scrub

target = repo / 'evaluations/evidence/backend-ephemeral-chat-2026-11-09/completion'
target.mkdir(exist_ok=True)
entries = []
for source in sorted(root.rglob('*')):
    if not source.is_file() or source.suffix not in {'.py', '.json', '.log'}:
        continue
    relative = source.relative_to(root)
    raw = source.read_bytes()
    stored = raw
    if source.suffix == '.log':
        content = raw.decode()
        identifiers = sorted(set(re.findall(r'\b[0-9a-f]{40,64}\b', content)))
        for index, identifier in enumerate(identifiers):
            content = content.replace(identifier, f'PUBLICHASHPLACEHOLDER{index}END')
        content = scrub(content)
        for index, identifier in enumerate(identifiers):
            content = content.replace(f'PUBLICHASHPLACEHOLDER{index}END', identifier)
        stored = content.encode()
    destination = target / (str(relative) + '.gz')
    destination.parent.mkdir(parents=True, exist_ok=True)
    compressed = gzip.compress(stored, mtime=0)
    destination.write_bytes(compressed)
    assert gzip.decompress(destination.read_bytes()) == stored
    entries.append({'path': str(destination.relative_to(target)), 'raw_sha256': hashlib.sha256(raw).hexdigest(), 'stored_sha256': hashlib.sha256(stored).hexdigest(), 'compressed_sha256': hashlib.sha256(compressed).hexdigest(), 'redacted': stored != raw, 'compressed_bytes': len(compressed)})
manifest = {'qualification_source': '422fac168babd21581889ccedb192f3e652b48b0', 'fully_qualified_platform_checks': True, 'historical_workflow_failures_preserved': True, 'files': entries, 'total_compressed_bytes': sum(x['compressed_bytes'] for x in entries)}
(target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'files': len(entries), 'compressed_bytes': manifest['total_compressed_bytes']}))
