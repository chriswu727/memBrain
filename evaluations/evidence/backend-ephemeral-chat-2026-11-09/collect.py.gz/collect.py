import gzip
import hashlib
import json
from pathlib import Path
from membrain.privacy import scrub

prefix = 'membrain-ephemeral-'
root = Path('/private/tmp')
dest = Path('evaluations/evidence/backend-ephemeral-chat-2026-11-09')
dest.mkdir(parents=True, exist_ok=True)
identity = json.loads((root / (prefix + 'package/identity.json')).read_text())
previous = json.loads((root / (prefix + 'package-before-index-identity.json')).read_text())
previous_scope = json.loads((root / (prefix + 'package-before-scope-identity.json')).read_text())
public_ids = [v for doc in (identity, previous, previous_scope) for v in doc.values() if isinstance(v, str)] + [
    '27a61078039606563e1effeaca0e2cd1a63038ac',
    'd6fa9e36222d4c1c9005a9ec6cee8a8c5cf6f393',
]
files = []
for p in sorted(root.glob(prefix + '*')):
    if not p.is_file() or p.suffix not in {'.log', '.json', '.py', '.gz'}:
        continue
    raw = p.read_bytes()
    content = gzip.decompress(raw).decode() if p.suffix == '.gz' else raw.decode()
    if p.suffix in {'.log', '.gz'}:
        for i, value in enumerate(public_ids):
            content = content.replace(value, f'PUBLICIDENTITYPLACEHOLDER{i}X')
        content = scrub(content)
        for i, value in enumerate(public_ids):
            content = content.replace(f'PUBLICIDENTITYPLACEHOLDER{i}X', value)
    output = content.encode()
    target = dest / (p.name.removeprefix(prefix) + '.gz')
    target.write_bytes(gzip.compress(output, mtime=0))
    assert gzip.decompress(target.read_bytes()) == output
    files.append({'path': target.name, 'raw_sha256': hashlib.sha256(raw).hexdigest(),
                  'stored_sha256': hashlib.sha256(output).hexdigest(), 'redacted': output != raw})
(dest / 'package-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
(dest / 'manifest.json').write_text(json.dumps({'identity': identity, 'files': files}, indent=2) + '\n')
print(json.dumps({'files': len(files), 'compressed_bytes': sum(p.stat().st_size for p in dest.glob('*.gz'))}))
