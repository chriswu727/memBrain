import gzip
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

from membrain import embedded_database
from membrain.cli import bootstrap
from membrain.build_identity import BUILD_ID, package_manifest, manifest_digest
import membrain
from membrain.config import Settings
from membrain.local_profile import ensure_profile

os.environ['PYTHON_DOTENV_DISABLED'] = '1'
os.environ['MEMBRAIN_SEMANTIC'] = '0'
os.environ['MEMBRAIN_REQUIRE_BROWSER'] = '1'
root = Path('/private/tmp/membrain-ephemeral-tests-db')
temporary = Path('/private/tmp/membrain-ephemeral-pytest')

def clean(path):
    if not path.exists():
        return 0
    assert not path.is_symlink()
    assert not list(path.rglob('postmaster.pid')), f'A database remains at {path}'
    processes = subprocess.check_output(['ps', '-eo', 'pid,command'], text=True).splitlines()
    assert not any(str(path) in p for p in processes if p.split()[0] != str(os.getpid())), f'Active process at {path}'
    size = sum(p.stat().st_size for p in path.rglob('*') if p.is_file() and not p.is_symlink())
    shutil.rmtree(path)
    return size

assert shutil.disk_usage(root.parent).free > 2 * 1024**3, 'At least 2 GiB is required before starting a test batch.'
profile = ensure_profile(root, database_engine='embedded')
results = []
started = time.time()
try:
    embedded_database.start(profile)
    bootstrap(Settings(database_url=profile.database_url, migration_database_url=profile.migration_database_url), app_password=profile.app_password)
    os.environ['MEMORY_DATABASE_URL'] = profile.database_url
    os.environ['MEMORY_MIGRATION_DATABASE_URL'] = profile.migration_database_url
    for target in sys.argv[1:]:
        clean(temporary)
        package = Path(membrain.__file__).parent
        assert manifest_digest(package_manifest(package, package.parents[1])) == BUILD_ID, 'Runtime changed during verification.'
        result = subprocess.run([sys.executable, '-m', 'pytest', '-q', '-o', 'tmp_path_retention_policy=failed', '--basetemp', str(temporary), target], capture_output=True, text=True)
        print(f'CHECK {target}', flush=True)
        print(result.stdout, end='', flush=True)
        print(result.stderr, end='', flush=True)
        if result.returncode:
            logs = {str(path.relative_to(temporary)): path.read_text(errors='replace') for path in temporary.rglob('*.log') if path.stat().st_size < 2000000}
            name = target.replace('/', '_').replace(':', '_')
            (temporary.parent / ('membrain-ephemeral-failure-' + name + '.json.gz')).write_bytes(gzip.compress(json.dumps(logs).encode()))
        assert manifest_digest(package_manifest(package, package.parents[1])) == BUILD_ID, 'Runtime changed during verification.'
        removed = clean(temporary)
        results.append({'target': target, 'returncode': result.returncode, 'temporary_bytes_removed': removed})
        print(f'Temporary cleanup: {removed} bytes', flush=True)
finally:
    embedded_database.stop(profile)
    removed = clean(root)
    print(json.dumps({'checks': results, 'database_bytes_removed': removed, 'seconds': time.time() - started}), flush=True)
raise SystemExit(int(any(r['returncode'] for r in results)))
