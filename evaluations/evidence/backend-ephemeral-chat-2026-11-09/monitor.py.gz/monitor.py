import json,subprocess,time
from pathlib import Path
runs=[42673202623,42673189368]
previous={}
while runs:
    for run in list(runs):
        response=subprocess.run(['gh','run','view',str(run),'--json','databaseId,headSha,status,conclusion,jobs,url'],capture_output=True,text=True)
        if response.returncode:
            print(json.dumps({'run':run,'status_lookup_failed':True}),flush=True)
            continue
        value=json.loads(response.stdout)
        assert value['headSha']=='422fac168babd21581889ccedb192f3e652b48b0'
        state={'run':run,'status':value['status'],'conclusion':value['conclusion'],'jobs':[{'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],'active_steps':[s['name'] for s in j.get('steps',[]) if s['status']=='in_progress']} for j in value['jobs'] if j['conclusion']!='skipped']}
        if state!=previous.get(run):
            print(json.dumps(state),flush=True)
            previous[run]=state
        if value['status']=='completed':
            Path('/private/tmp/membrain-ephemeral-run-'+str(run)+'.json').write_text(json.dumps(value,indent=2)+'\n')
            runs.remove(run)
    if runs:time.sleep(45)
