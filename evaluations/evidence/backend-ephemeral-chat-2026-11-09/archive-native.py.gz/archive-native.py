import gzip,hashlib,json,subprocess
from pathlib import Path
root=Path('/private/tmp/membrain-ephemeral-native-audit')
dest=Path('evaluations/evidence/backend-ephemeral-chat-2026-11-09/native')
selection={42673189368:'macos-x86_64',42673909552:'macos-arm64',42673913787:'linux-x86_64',42673918492:'linux-aarch64',42673923840:'windows-x86_64'}
source='422fac168babd21581889ccedb192f3e652b48b0'
statuses=[]
for run,target in selection.items():
    status=json.loads(subprocess.check_output(['gh','run','view',str(run),'--json','databaseId,headSha,status,conclusion,jobs,url']))
    assert status['status']=='completed' and status['conclusion']=='success' and status['headSha']==source
    jobs=[j for j in status['jobs'] if j['name'].startswith('native (')]
    assert len(jobs)==1 and jobs[0]['name']=='native ('+target+')'
    for job in jobs:
        assert job['conclusion']=='success'
        reuse=[s for s in job['steps'] if s['name']=='Download an existing owned candidate for isolated verification']
        assert len(reuse)==1 and reuse[0]['conclusion']=='success'
        assert all(s['conclusion']=='skipped' for s in job['steps'] if s['name'].startswith('Build portable'))
    statuses.append(status)
inputs=['scripts/build_native_bundle.py','src/membrain/resources/native','pyproject.toml','uv.lock','.github/workflows/native-engine.yml']
subprocess.run(['git','diff','--exit-code','27a61078039606563e1effeaca0e2cd1a63038ac',source,'--',*inputs],check=True)
audit=json.loads((root/'native-summary-audit.json').read_text())
assert audit['count']==47 and audit['complete_five_platform_qualification']
assert len(audit['temporary_chat_checks'])==15 and all(x['restart_replay'] and x['restore_replay'] for x in audit['temporary_chat_checks'])
(root/'workflow-status.json').write_text(json.dumps(statuses,indent=2)+'\n')
files=[]
for p in sorted(root.rglob('*.json')):
    raw=p.read_bytes();target=dest/(str(p.relative_to(root))+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(target.read_bytes())==raw
    files.append({'path':str(target.relative_to(dest)),'sha256':hashlib.sha256(raw).hexdigest()})
manifest={'source_commit':source,'workflow_runs':selection,'conclusion':'success','reused_native_run':42574397718,'unchanged_supplier_inputs':inputs,'logical_summaries':47,'temporary_chat_journeys':15,'duplicate_qualification_copies_excluded':5,'files':files}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='files'}))
