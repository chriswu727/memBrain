import hashlib,json,os,shutil,statistics,subprocess,time
from pathlib import Path
from psycopg import sql
from membrain import embedded_database
from membrain.build_identity import BUILD_ID,package_manifest,manifest_digest
from membrain.cli import bootstrap
from membrain.client import MemoryClient
from membrain.config import Settings
from membrain.helpers import Principal
from membrain.local_profile import ensure_profile
from membrain.runtime import BrainRuntime
from membrain.api import create_app
from membrain.service import MemoryService
from membrain.storage import Database
from examples.evaluation_host import loopback_server

root=Path('/private/tmp/membrain-ephemeral-storage-db')
assert not root.exists() and shutil.disk_usage(root.parent).free>2*1024**3
os.environ['MEMBRAIN_SEMANTIC']='0'
profile=ensure_profile(root,database_engine='embedded')
principal=Principal(profile.tenant_id,profile.principal_id)
service=None
samples=[]
result={'build_id':BUILD_ID,'provider_calls':0,'synthetic_generator_calls':0,'transport':'real loopback HTTP','database_pool':True,'scope_count':1,'observations':[]}
try:
    embedded_database.start(profile)
    bootstrap(Settings(database_url=profile.database_url,migration_database_url=profile.migration_database_url),app_password=profile.app_password)
    database=Database(profile.database_url,pool=True)
    service=MemoryService(database)
    settings=Settings(database_url=profile.database_url,api_keys={hashlib.sha256(profile.api_key.encode()).hexdigest():principal})
    def storage():
        rows={}
        with database.transaction(principal) as conn:
            for name in ['memory_events','memory_jobs','memory_runtime_turns','memory_runtime_turn_transitions']:
                row=conn.execute(sql.SQL('SELECT count(*) AS rows,coalesce(sum(pg_column_size(t)),0) AS row_bytes FROM {} t').format(sql.Identifier(name))).fetchone()
                row['allocated_bytes']=conn.execute('SELECT pg_total_relation_size(%s::regclass) AS bytes',(name,)).fetchone()['bytes']
                rows[name]={k:int(v) for k,v in row.items()}
        return rows
    def generate(request):
        result['synthetic_generator_calls']+=1
        return 'Synthetic temporary reply. '+('R'*100)
    with loopback_server(create_app(settings,service=service)) as url:
        with MemoryClient(url,profile.api_key,profile.brain_id,trust_env=False) as memory:
            memory.brain_id=memory.create_brain('Synthetic temporary storage probe')['id']
            policy=memory.recording_status();memory.set_recording(paused=True,expected_revision=policy['revision'])
            runtime=BrainRuntime(memory,generate)
            result['baseline']=storage()
            for index in range(1000):
                started=time.perf_counter()
                turn=runtime.respond('Synthetic temporary input '+str(index)+' '+('X'*1000),message_id='storage-'+str(index),conversation_id='storage-probe')
                samples.append(1000*(time.perf_counter()-started))
                assert turn.ephemeral and turn.stage=='completed'
                if index+1 in (10,100,500,1000):
                    buffer=list(runtime.temporary.history.values())
                    record={'turns':index+1,'storage':storage(),'buffer_scopes':len(buffer),'buffer_messages':sum(len(items) for _,items in buffer),'buffer_content_bytes':sum(len(item['content'].encode()) for _,items in buffer for item in items),'median_ms':statistics.median(samples),'p95_ms':sorted(samples)[int(.95*(len(samples)-1))]}
                    assert record['buffer_scopes']==1 and record['buffer_messages']<=6 and record['buffer_content_bytes']<=4000
                    assert record['storage']['memory_events']['rows']==record['storage']['memory_jobs']['rows']==0
                    assert record['storage']['memory_runtime_turns']['rows']==index+1
                    result['observations'].append(record);print(json.dumps(record),flush=True)
            runtime.temporary.clear();assert not runtime.temporary.history
    result['completed']=True
finally:
    if service is not None:service.database.close()
    embedded_database.stop(profile)
    assert not list(root.rglob('postmaster.pid'))
    processes=subprocess.check_output(['ps','-eo','pid,command'],text=True).splitlines()
    assert not any(str(root) in line for line in processes if line.split()[0]!=str(os.getpid()))
    size=sum(p.stat().st_size for p in root.rglob('*') if p.is_file() and not p.is_symlink())
    shutil.rmtree(root)
    result['stopped_database_bytes_removed']=size
    assert manifest_digest(package_manifest(Path('src/membrain'),Path.cwd()))==BUILD_ID
    Path('/private/tmp/membrain-ephemeral-storage-probe.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'completed':result.get('completed',False),'provider_calls':0,'synthetic_generator_calls':result['synthetic_generator_calls'],'stopped_database_bytes_removed':size}),flush=True)
