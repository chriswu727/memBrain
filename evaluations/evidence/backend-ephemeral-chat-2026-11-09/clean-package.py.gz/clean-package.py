import hashlib,json,os,shutil,subprocess
from pathlib import Path
root=Path('/private/tmp/membrain-ephemeral-package')
identity=json.loads((root/'identity.json').read_text())
log=Path('/private/tmp/membrain-ephemeral-installed.log').read_text()
receipt=json.loads(log.strip().splitlines()[-1])
assert len(receipt['checks'])==27 and all(x['returncode']==0 for x in receipt['checks'])
import re
assert sum(map(int,re.findall(r'^(\d+) passed', log, re.M)))==570
from membrain.build_identity import BUILD_ID,package_manifest,manifest_digest
source=Path('src/membrain').resolve();wheel=root/'wheel/membrain'
assert manifest_digest(package_manifest(source,Path.cwd()))==identity['build_id']==BUILD_ID
if wheel.exists():
    assert manifest_digest(package_manifest(wheel,root/'wheel'))==BUILD_ID
removed=[]
for path in [root/'wheel',Path('dist').resolve()]:
    if not path.exists():continue
    assert not path.is_symlink() and not list(path.rglob('postmaster.pid'))
    processes=subprocess.check_output(['ps','-eo','pid,command'],text=True).splitlines()
    assert not any(str(path) in p for p in processes if p.split()[0]!=str(os.getpid()))
    if path.name=='dist':
        for p in path.iterdir():
            if p.name=='.gitignore':
                assert p.read_text()=='*'
                continue
            assert p.name in {'membrain_ai-0.1.0-py3-none-any.whl','membrain_ai-0.1.0.tar.gz'}
            kind='wheel_sha256' if p.suffix=='.whl' else 'sdist_sha256'
            assert hashlib.sha256(p.read_bytes()).hexdigest()==identity[kind]
    size=sum(p.stat().st_size for p in path.rglob('*') if p.is_file() and not p.is_symlink())
    shutil.rmtree(path);removed.append({'path':str(path),'bytes':size})
    Path('/private/tmp/membrain-ephemeral-package-cleanup-progress.json').write_text(json.dumps(removed,indent=2)+'\n')
result={'installed_tests':570,'runtime_inputs':212,'build_id':BUILD_ID,'removed':removed,'database_bytes_removed':receipt['database_bytes_removed']}
Path('/private/tmp/membrain-ephemeral-package-cleanup.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
