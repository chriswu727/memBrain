import json
from pathlib import Path
root=Path('/private/tmp')
old=json.loads((root/'membrain-http-recovery-pr43.json').read_text())['body']
performance=next(line for line in old.splitlines() if line.startswith('- Previous [stored recall eligibility'))
remaining=old.split('Latest behavioral acceptance is',1)[1]
report='https://github.com/chriswu727/memBrain/blob/integration/maturity-candidate/evaluations/backend-http-read-recovery-2026-11-09.md'
body58=f'''User deletion now invalidates versioned delayed observations, notes, learning and durable turns under the brain lock. Independent deletion intents preserve a revision floor across older backup restoration. Already-dispatched delivery retains factual metadata while withholding stale returned content. Internal note replacement preserves ongoing extraction authority and independently replayable suppression.

The Python memory client recovers a bodyless GET once after RemoteProtocolError or ReadError, preserving authentication and recovery epoch and logging a content-free warning. Writes, requests carrying bodies, timeouts, connect errors, HTTP errors and malformed JSON are not replayed. Real-TCP fault injection reproduces a keepalive closure after the pool reuse check; the exact server-side cause of the historical CI disconnect remains unproven.

Merged into integration as f0b9b3040544300d5914a1921c63675dc1f592ee; its complete tree equals qualified source 8fa22d81b73e8e0108a9edafff335b22f6af3f1a. Runtime b4d39b4c6ca6ce0ab1816fe620702b637e2bb6ec. Documentation/evidence follow-ups do not change runtime inputs.

Validation:
- Verify 42641634827: 8,228 Python tests, zero skips, three existing fork warnings, 1,969.28 seconds; 56 TypeScript tests, zero skips, types, Ruff and package builds. The formerly failing real-loopback scenario passes in this complete run.
- Current related source and extracted-wheel checks each pass 161 tests; all 209 runtime inputs match. Wheel checks use existing development dependencies.
- Native 42641749935: five platforms and 47 audited logical summaries pass, five duplicate copies excluded, zero model calls and all recorded port closures passing. It reuses checked binaries from 42574397718 with unchanged supplier inputs. Duplicate automatic run 42641634923 was cancelled, not passed; that cancellation remains visible in the PR checks.
- Prior erasure results and all three failed CI runs remain retained for their original candidates. This change makes no new recall-speed or behavioral-quality claim.

[Detailed current report and checksummed evidence]({report}). Stopped synthetic databases and rebuildable installation copies were cleaned; raw task files are removed after evidence verification. Real profiles, models, backups and the shared development environment remain.

Integration only. R4 remains failed, C5 invalid/unscored, and final review remains open. Main merge, tags and publication remain blocked. No new paid or subscription-backed evaluation ran.'''
intro=old.split('\n\n',1)[0]
body43=f'''{intro}

All nine launchers pin runtime b4d39b4c6ca6ce0ab1816fe620702b637e2bb6ec. PR #58 integrates erasure fences and bounded HTTP read recovery as f0b9b3040544300d5914a1921c63675dc1f592ee, whose complete tree equals qualified source 8fa22d81b73e8e0108a9edafff335b22f6af3f1a. Documentation/evidence follow-ups change no runtime inputs. Main merge, tags and publication remain blocked; this PR is not release-ready.

Current engineering qualification:
- [Verify 42641634827](https://github.com/chriswu727/memBrain/actions/runs/42641634827) passes 8,228 Python/56 TypeScript tests with zero skips, types, Ruff and builds. Three Python fork warnings remain; Python test time is 1,969.28 seconds. [Native 42641749935](https://github.com/chriswu727/memBrain/actions/runs/42641749935) passes five platforms and 47 audited logical summaries using the unchanged, previously qualified supplier binaries from 42574397718. The duplicate automatic native build was cancelled, not counted as a pass.
- Explicit erasure/suppression revokes old capture authority, including delayed observations, queued learning and durable turns. Independent intent revision floors survive older backup restoration. Internal note replacement preserves ongoing authority without losing suppression records. In-flight delivery can settle factual metadata while stale returned content is withheld.
- A bodyless GET can recover once after a reset or closed read connection. Writes and other failure classes are not automatically retried. Real-TCP regressions and the full previously failing loopback scenario pass; the historical disconnect's exact cause remains unproven. Related source and extracted-wheel checks each pass 161 tests, with equality of all 209 runtime inputs. Wheel tests use existing development dependencies. [Current report and retained failures]({report}).
{performance}
- Preceding control, concurrency, 3D, local erasure timing and broader installation evidence retains its original runtime scope. These engineering results do not establish better personality, emotion or general memory quality.

Remaining backend work: local timed/conversation capture and the server's whole-brain gate remain different scopes; automatic cross-device synchronization is not implemented. Ephemeral durable chat and receipt normalization across the independent AgentRuntime remain open. Host delivery uses a local journal plus idempotent server replay, not one distributed transaction; already-dispatched external operations cannot be recalled. Tools-only/direct clients that omit capture metadata retain their current-policy contract. The previously reproduced delayed observation after explicit erasure is now fenced for versioned captures. Historical deletion intents cannot reconstruct a revision floor never recorded. Disconnected hosts and external transcripts retain their separate limits. Source tests do not establish general multilingual privacy-intent understanding. https://github.com/chriswu727/memBrain/blob/integration/maturity-candidate/architecture/backend-control-flow-2026-11-07.md

Latest behavioral acceptance is{remaining}'''
for n,body in [(58,body58),(43,body43)]:
    (root/f'membrain-http-recovery-pr{n}-final.json').write_text(json.dumps({'body':body},indent=2)+'\n')
