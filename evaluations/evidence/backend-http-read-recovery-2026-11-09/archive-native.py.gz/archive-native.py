import gzip,hashlib,json,subprocess
from pathlib import Path
root=Path('/private/tmp/membrain-http-recovery-native-audit')
dest=Path('evaluations/evidence/backend-http-read-recovery-2026-11-09/native')
run=42641749935;source='8fa22d81b73e8e0108a9edafff335b22f6af3f1a'
status=json.loads(subprocess.check_output(['gh','run','view',str(run),'--json','databaseId,headSha,status,conclusion,jobs,url']))
assert status['status']=='completed' and status['conclusion']=='success' and status['headSha']==source
jobs=[j for j in status['jobs'] if j['name'].startswith('native (')];assert len(jobs)==5
for job in jobs:
    assert job['conclusion']=='success'
    reuse=[s for s in job['steps'] if s['name']=='Download an existing owned candidate for isolated verification']
    assert len(reuse)==1 and reuse[0]['conclusion']=='success'
    assert all(s['conclusion']=='skipped' for s in job['steps'] if s['name'].startswith('Build portable'))
inputs=['scripts/build_native_bundle.py','src/membrain/resources/native','pyproject.toml','uv.lock','.github/workflows/native-engine.yml']
subprocess.run(['git','diff','--exit-code','27a61078039606563e1effeaca0e2cd1a63038ac',source,'--',*inputs],check=True)
audit=json.loads((root/'native-summary-audit.json').read_text());assert audit['count']==47 and audit['complete_five_platform_qualification']
(root/'workflow-status.json').write_text(json.dumps(status,indent=2)+'\n')
files=[]
for p in sorted(root.rglob('*.json')):
    raw=p.read_bytes();target=dest/(str(p.relative_to(root))+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(target.read_bytes())==raw
    files.append({'path':str(target.relative_to(dest)),'sha256':hashlib.sha256(raw).hexdigest()})
manifest={'source_commit':source,'workflow_run':run,'conclusion':'success','reused_native_run':42574397718,'unchanged_supplier_inputs':inputs,'logical_summaries':47,'duplicate_qualification_copies_excluded':5,'files':files}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='files'}))
