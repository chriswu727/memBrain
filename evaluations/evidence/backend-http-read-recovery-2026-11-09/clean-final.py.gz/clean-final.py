import gzip,hashlib,json,os,shutil,subprocess
from pathlib import Path
root=Path('/private/tmp');prefix='membrain-http-recovery-'
dest=Path('evaluations/evidence/backend-http-read-recovery-2026-11-09')
manifest=json.loads((dest/'manifest.json').read_text())
indexed={x['path']:x for x in manifest['files']}
for entry in indexed.values():
    assert hashlib.sha256(gzip.decompress((dest/entry['path']).read_bytes())).hexdigest()==entry['stored_sha256']
native_manifest=json.loads((dest/'native/manifest.json').read_text())
for entry in native_manifest['files']:
    assert hashlib.sha256(gzip.decompress((dest/'native'/entry['path']).read_bytes())).hexdigest()==entry['sha256']
paths=sorted(root.glob(prefix+'*'));removed=[]
processes=subprocess.check_output(['ps','-eo','pid,command'],text=True).splitlines()
for p in paths:
    assert not p.is_symlink()
    if p.is_dir():
        assert p.name in {prefix+'native-audit',prefix+'package'},p
        assert not any(str(p) in line for line in processes if line.split()[0]!=str(os.getpid())),p
        assert not list(p.rglob('postmaster.pid'))
        for f in p.rglob('*'):
            if not f.is_file():continue
            if p.name.endswith('package'):
                assert f==p/'identity.json'
                assert f.read_bytes()==(dest/'package-identity.json').read_bytes()
            else:
                archived=dest/'native'/(str(f.relative_to(p))+'.gz')
                assert gzip.decompress(archived.read_bytes())==f.read_bytes()
    else:
        entry=indexed[p.name.removeprefix(prefix)+'.gz']
        assert hashlib.sha256(p.read_bytes()).hexdigest()==entry['raw_sha256'],p
for p in paths:
    size=sum(f.stat().st_size for f in p.rglob('*') if f.is_file()) if p.is_dir() else p.stat().st_size
    if p.is_dir():shutil.rmtree(p)
    else:p.unlink()
    removed.append({'path':str(p),'bytes':size})
receipt={'removed':removed,'bytes_removed':sum(x['bytes'] for x in removed),'raw_prefix_absent':not list(root.glob(prefix+'*')),'free_bytes':shutil.disk_usage(root).free}
(dest/'final-cleanup.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='removed'}))
