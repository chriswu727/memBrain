import json,re,subprocess
from pathlib import Path
run='42641634827'
prefix=Path('/private/tmp/membrain-http-recovery-verify-status.json')
status=json.loads(subprocess.check_output(['gh','run','view',run,'--json','databaseId,headSha,status,conclusion,jobs,url']))
prefix.write_text(json.dumps(status,indent=2)+'\n')
assert status['headSha']=='8fa22d81b73e8e0108a9edafff335b22f6af3f1a'
if status['status']!='completed':
    print(json.dumps({'status':status['status']}))
    raise SystemExit(0)
log=Path('/private/tmp/membrain-http-recovery-verify.log')
with log.open('wb') as out:
    subprocess.run(['gh','run','view',run,'--log'],stdout=out,check=True)
content=log.read_text()
lines=[line for line in content.splitlines() if re.search(r'\d+ passed.* in |# (tests|pass|fail|skipped) |Successfully built|error TS',line)]
Path('/private/tmp/membrain-http-recovery-verify-summary.json').write_text(json.dumps({'conclusion':status['conclusion'],'lines':lines},indent=2)+'\n')
print(json.dumps({'conclusion':status['conclusion'],'lines':lines}))
