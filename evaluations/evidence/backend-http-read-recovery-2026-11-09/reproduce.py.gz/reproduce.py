import json,threading
from unittest.mock import patch
from fastapi import FastAPI
from httpcore._sync.http11 import HTTP11Connection
from uvicorn.protocols.http.h11_impl import H11Protocol
from examples.evaluation_host import loopback_server
from membrain.client import MemoryClient
from membrain.runtime_client import RuntimeClient
app=FastAPI();calls=[];protocols=[];closed=threading.Event();armed=False
@app.get('/v1/brains/brain/runtime/cognitive-usage')
def usage():
    calls.append('GET');return {'requests_seen':len(calls)}
original_complete=H11Protocol.on_response_complete
original_expired=HTTP11Connection.has_expired
original_timeout=H11Protocol.timeout_keep_alive_handler
def complete(self):
    protocols.append(self);original_complete(self)
def timeout(self):
    original_timeout(self);closed.set()
def has_expired(self):
    global armed
    result=original_expired(self)
    if armed and not result:
        armed=False
        protocol=protocols[-1]
        protocol.loop.call_soon_threadsafe(protocol.timeout_keep_alive_handler)
        assert closed.wait(3)
    return result
with patch.object(H11Protocol,'on_response_complete',complete),patch.object(H11Protocol,'timeout_keep_alive_handler',timeout),patch.object(HTTP11Connection,'has_expired',has_expired):
    with loopback_server(app) as url:
        with MemoryClient(url,'synthetic','brain',trust_env=False) as memory:
            assert RuntimeClient(memory).cognitive_usage()=={'requests_seen':1}
            armed=True
            try:
                result=RuntimeClient(memory).cognitive_usage()
            except Exception as error:
                result={'error_type':type(error).__name__,'error':str(error)}
            with MemoryClient(url,'synthetic','brain',trust_env=False) as fresh:
                recovered=RuntimeClient(fresh).cognitive_usage()
print(json.dumps({'second_read':result,'keepalive_close_observed':closed.is_set(),'fresh_connection_result':recovered,'server_requests':calls,'model_calls':0}))
