import json,collections
from pathlib import Path
root=Path(__file__).parent
rows=[json.loads(x) for x in (root/'stages.jsonl').read_text().splitlines()]
report=json.loads((root/'results/serial/action-profile.json').read_text())
requests={e['request_id']:s for phase in report['phases'] for s in phase['samples'] for e in s['endpoint_timings'] if e['path']=='v1/actions'}
parents={r['pid'] for r in rows if r['stage']=='worker_roundtrip'}
seen=collections.Counter();result=[]
for r in rows:
 if r['stage']!='respond' or r['pid'] in parents:continue
 s=requests[r['request_id']];seen[r['pid']]+=1
 nested={x['stage']:x['ms'] for x in rows if x['pid']==r['pid'] and x['request_id']==r['request_id'] and x['stage'] in ('candidate_collection','retrieval','cache_store')}
 result.append({'case':s['case'],'warmup':s['warmup'],'pid':r['pid'],'worker_request_number':seen[r['pid']],'http_context_ms':s['ms'],'worker_respond_ms':r['ms'],**nested})
(root/'first-use.json').write_text(json.dumps({'protocol':'Correlates existing diagnostic samples only; does not isolate cause or add requests. Nested stages overlap.','samples':result},indent=2)+'\n')
print(json.dumps(result,indent=2))
