import collections,json,math,statistics
from pathlib import Path
root=Path(__file__).parent
rows=[json.loads(line) for line in (root/'stages.jsonl').read_text().splitlines()]
shapes={row['sha256']:row['sql'] for row in map(json.loads,(root/'sql-shapes.jsonl').read_text().splitlines())}
def summary(values):
 values=sorted(values)
 return {'n':len(values),'median_ms':round(statistics.median(values),3),'p95_ms':round(values[math.ceil(len(values)*.95)-1],3),'total_ms':round(sum(values),3)}
groups=collections.defaultdict(list);queries=collections.defaultdict(list)
for row in rows:
 assert not row['failed'],row
 groups[row['stage']].append(row['ms'])
 if row['stage']=='sql_execute':queries[row['sql_sha256']].append(row['ms'])
result={'protocol':'Instrumented serial diagnostic; wrappers add overhead. Includes one warmup and twenty measured questions. Stages nest; do not sum their totals. Not a latency benchmark or acceptance run.','stages':{k:summary(v) for k,v in groups.items()},'queries':sorted([{'sha256':k,'sql':shapes[k],**summary(v)} for k,v in queries.items()],key=lambda x:x['total_ms'],reverse=True)}
(root/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'stages':result['stages'],'top_sql':[{'prefix':q['sql'][:100],**{k:q[k] for k in ('n','median_ms','total_ms')}} for q in result['queries'][:6]]},indent=2))
