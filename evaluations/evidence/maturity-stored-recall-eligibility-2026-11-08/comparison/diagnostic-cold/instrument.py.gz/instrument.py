import contextvars
import functools
import hashlib
import json
import os
import time
from pathlib import Path

import psycopg
from membrain import candidates, cognition, lexical_candidates, read_cache, service, source_candidates
from membrain.local_embeddings import LocalEmbeddingProvider
from membrain.recall_service_executor import RecallServiceExecutor

OUTPUT = Path(__file__).with_name("stages.jsonl")
QUERIES = Path(__file__).with_name("sql-shapes.jsonl")
REQUEST = contextvars.ContextVar("diagnostic_request", default=None)
SEEN = set()


def append(path, value):
    descriptor = os.open(path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
    try:
        os.write(descriptor, (json.dumps(value) + "\n").encode())
    finally:
        os.close(descriptor)


def emit(stage, started, failed, **extra):
    request = REQUEST.get()
    if request is not None:
        append(OUTPUT, {"request_id": request, "pid": os.getpid(), "stage": stage,
                       "ms": (time.perf_counter() - started) * 1000, "failed": failed, **extra})


def wrap(owner, name, label, request=False):
    original = getattr(owner, name)
    @functools.wraps(original)
    def measured(*args, **kwargs):
        token = REQUEST.set(args[2].get("request_id")) if request else None
        started, failed = time.perf_counter(), False
        try:
            return original(*args, **kwargs)
        except BaseException:
            failed = True
            raise
        finally:
            emit(label, started, failed)
            if token is not None:
                REQUEST.reset(token)
    setattr(owner, name, measured)


wrap(service.MemoryService, "_respond", "respond", request=True)
wrap(service.MemoryService, "_retrieval", "retrieval")
wrap(candidates, "collect_candidates", "candidate_collection")
wrap(lexical_candidates, "lexical_rows", "lexical_route")
wrap(source_candidates, "source_candidates", "source_route")
wrap(cognition, "recall", "cognition")
wrap(LocalEmbeddingProvider, "__call__", "onnx")
wrap(read_cache, "store", "cache_store")
wrap(RecallServiceExecutor, "respond", "worker_roundtrip")

ORIGINAL_EXECUTE = psycopg.Connection.execute


def execute(self, query, *args, **kwargs):
    if REQUEST.get() is None or not isinstance(query, str):
        return ORIGINAL_EXECUTE(self, query, *args, **kwargs)
    shape = hashlib.sha256(query.encode()).hexdigest()
    if shape not in SEEN:
        SEEN.add(shape)
        append(QUERIES, {"sha256": shape, "sql": query})
    started, failed = time.perf_counter(), False
    try:
        return ORIGINAL_EXECUTE(self, query, *args, **kwargs)
    except BaseException:
        failed = True
        raise
    finally:
        emit("sql_execute", started, failed, sql_sha256=shape)


psycopg.Connection.execute = execute
ORIGINAL_FETCHALL = psycopg.Cursor.fetchall


def fetchall(self):
    started, failed = time.perf_counter(), False
    try:
        return ORIGINAL_FETCHALL(self)
    except BaseException:
        failed = True
        raise
    finally:
        emit("sql_fetchall", started, failed)


psycopg.Cursor.fetchall = fetchall

from membrain import native_contracts
wrap(native_contracts, "_compiled", "native_contract_compile_lookup")
wrap(native_contracts, "accepts_response", "native_response_validation")
