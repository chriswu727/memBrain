import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import time

for name in list(os.environ):
    if name.startswith(('MEMORY_', 'MEMBRAIN_', 'C5_')) or name.endswith(('_API_KEY', '_API_TOKEN')):
        del os.environ[name]
os.environ.update(MEMBRAIN_SEMANTIC='0', PYTHON_DOTENV_DISABLED='1')
import psycopg
from psycopg import sql
from membrain import candidates, desktop, embedded_database
from membrain.client import default_budget, default_read_fence
from membrain.config import configured_service
from membrain.helpers import Principal, now
from membrain.local_profile import load_profile
from membrain.service import reading

root = Path(__file__).parent
baseline = root/'baseline/membrain/candidates.py'
spec = importlib.util.spec_from_file_location('membrain.candidates_baseline', baseline)
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
profile = load_profile(Path('/Users/yichen/tmp/membrain-semantic-scale-20261107/installation'))
cases = json.loads(Path('/Users/yichen/tmp/membrain-semantic-scale-20261107/report.json').read_text())['cases']
settings = profile.settings()
assert settings.cognition_base_url is None and settings.embedding_base_url is None
assert settings.embedding_local_directory is not None
report = {'completed': False, 'pairs': [], 'baseline_sha256': hashlib.sha256(baseline.read_bytes()).hexdigest(), 'candidate_sha256': hashlib.sha256(Path(candidates.__file__).read_bytes()).hexdigest(), 'protocol': 'Strict Python equality of full ordered candidate documents and complete candidate state; same transaction, embedding, fixed access time, and public 10000-memory corpus. 20 queries x 3 token budgets x 2 intents. No paid or subscription calls.'}
def save():
    (root/'candidate-parity.json').write_text(json.dumps(report, indent=2)+'\n')
def snapshot():
    result = {}
    with psycopg.connect(profile.migration_database_url) as conn:
        conn.execute('SET TRANSACTION READ ONLY')
        for name in ('memory_events', 'memory_assertions', 'memory_embeddings', 'memory_embedding_passages'):
            rows = conn.execute(sql.SQL('SELECT to_jsonb(t)::text FROM {} t WHERE brain_id=%s ORDER BY to_jsonb(t)::text').format(sql.Identifier(name)), (profile.brain_id,)).fetchall()
            result[name] = {'rows': len(rows), 'sha256': hashlib.sha256(json.dumps(rows).encode()).hexdigest()}
    return result
assert not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
save()
try:
    embedded_database.start(profile)
    report['before'] = snapshot()
    principal = Principal(profile.tenant_id, profile.principal_id)
    target = {'brain_ref': profile.brain_id, 'conversation_ref': 'synthetic-query', 'branch_ref': 'main'}
    access_at = now()
    with configured_service(settings) as service:
        assert service.embedding_provider is not None
        for index, case in enumerate(cases):
            embedding = service.embedding_provider.embed([case['query']], purpose='query')
            for budget in (2048, 12000, 64000):
                for intent in ('explore', 'exact_quote'):
                    query = {'query': case['query'], 'intent': intent, 'budget': default_budget(budget), 'read_fence': default_read_fence(), 'cue_event_ids': [], 'additional_cues': []}
                    with service.database.transaction(principal) as conn, reading():
                        brain = service._brain(conn, principal, profile.brain_id)
                        outputs = []
                        original_eligible = candidates._eligible
                        try:
                            for function in (old._eligible, original_eligible):
                                candidates._eligible = function
                                outputs.append(candidates.collect_candidates(conn, service, principal, copy.deepcopy(brain), copy.deepcopy(target), copy.deepcopy(query), query_embedding=embedding, access_at=access_at))
                        finally:
                            candidates._eligible = original_eligible
                    same = outputs[0] == outputs[1]
                    report['pairs'].append({'case_index': index, 'budget': budget, 'intent': intent, 'equal': same, 'baseline_count': len(outputs[0][0]), 'candidate_count': len(outputs[1][0]), 'documents_equal': outputs[0][0] == outputs[1][0], 'state_equal': outputs[0][1] == outputs[1][1]})
                    save()
                    if not same:
                        (root/'parity-failure.txt').write_text(repr(outputs))
                        raise AssertionError('Candidate output mismatch; preserved in parity-failure.txt')
            print(json.dumps({'case_index': index, 'pairs_completed': len(report['pairs'])}), flush=True)
    report['after'] = snapshot()
    report['core_unchanged'] = report['before'] == report['after']
    report['completed'] = True
finally:
    embedded_database.stop(profile)
    report['all_ports_closed'] = not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
    save()
assert report['completed'] and report['core_unchanged'] and report['all_ports_closed']
print(json.dumps({'completed': True, 'equal_pairs': len(report['pairs']), 'core_unchanged': report['core_unchanged'], 'all_ports_closed': report['all_ports_closed']}), flush=True)
