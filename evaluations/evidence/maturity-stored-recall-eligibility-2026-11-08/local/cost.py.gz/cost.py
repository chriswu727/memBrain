import hashlib,json,os,socket,time
from pathlib import Path
for k in list(os.environ):
    if k.startswith(('MEMORY_','MEMBRAIN_','C5_')) or k.endswith(('_API_KEY','_API_TOKEN')):del os.environ[k]
os.environ.update(PYTHON_DOTENV_DISABLED='1',MEMBRAIN_SEMANTIC='0')
import psycopg
from psycopg import sql
from psycopg.rows import dict_row
from membrain import embedded_database,storage
from membrain.local_profile import load_profile
from membrain.build_identity import MIGRATIONS
p=load_profile(Path('/Users/yichen/tmp/membrain-semantic-scale-20261107/installation'))
r={'completed':False,'paid_provider_calls':0,'subscription_calls':0,'costs':[],'protocol':'Public synthetic corpus only. Ordinary logged clones retain all indexes/defaults/generated columns, not RLS/FKs. REINDEX both after loading. Five alternating 1000-row insert/update transactions rolled back. Updates change both document.statement and search_text. No application/network/consolidation or commit fsync. 10000/50000 rows. Temporary clones rolled back before actual profile upgrade.'}
ddl=dict(MIGRATIONS)['031_recall_eligibility.sql'].decode()
def save():Path('/private/tmp/membrain-eligibility-cost.json').write_text(json.dumps(r,indent=2)+'\n')
def sizes(c,name):
    return c.execute('SELECT pg_relation_size(%s::regclass) AS heap,pg_indexes_size(%s::regclass) AS indexes,pg_total_relation_size(%s::regclass) AS total',(name,name,name)).fetchone()
def snap(c):
    return {name:hashlib.sha256(json.dumps(c.execute(sql.SQL('SELECT (to_jsonb(t)-\'recall_non_speech\')::text AS row FROM {} t ORDER BY (to_jsonb(t)-\'recall_non_speech\')::text').format(sql.Identifier(name))).fetchall()).encode()).hexdigest() for name in ('memory_events','memory_assertions','memory_embeddings','memory_embedding_passages')}
for port in (p.api_port,p.database_port):
    with socket.socket() as s:assert s.connect_ex(('127.0.0.1',port))!=0
try:
    embedded_database.start(p)
    with psycopg.connect(p.migration_database_url,row_factory=dict_row) as c:
        assert not c.execute("SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='memory_assertions' AND column_name='recall_non_speech'").fetchone()
        before=snap(c)
        cols=[x['attname'] for x in c.execute("SELECT attname FROM pg_attribute WHERE attrelid='memory_assertions'::regclass AND attnum>0 AND NOT attisdropped AND attgenerated='' ORDER BY attnum")]
        names=sql.SQL(',').join(map(sql.Identifier,cols))
        for count in (10000,50000):
            with c.transaction(force_rollback=True):
                c.execute('CREATE SCHEMA eligibility_cost_probe')
                for name in ('baseline','candidate'):
                    c.execute(sql.SQL('CREATE TABLE eligibility_cost_probe.{} (LIKE public.memory_assertions INCLUDING ALL)').format(sql.Identifier(name)))
                    expressions=sql.SQL(',').join(sql.SQL("a.id || '-' || n::text") if x=='id' else sql.SQL('a.{}').format(sql.Identifier(x)) for x in cols)
                    c.execute(sql.SQL('INSERT INTO eligibility_cost_probe.{} ({}) SELECT {} FROM public.memory_assertions a CROSS JOIN generate_series(1,%s) n').format(sql.Identifier(name),names,expressions),(count//10000,))
                    c.execute(sql.SQL('REINDEX TABLE eligibility_cost_probe.{}').format(sql.Identifier(name)))
                item={'rows':count,'baseline':sizes(c,'eligibility_cost_probe.baseline')}
                start=time.perf_counter();c.execute(ddl.replace('memory_assertions','eligibility_cost_probe.candidate'))
                item.update(migration_seconds=time.perf_counter()-start,candidate=sizes(c,'eligibility_cost_probe.candidate'),projection_bytes=c.execute('SELECT sum(pg_column_size(recall_non_speech)) AS n FROM eligibility_cost_probe.candidate').fetchone()['n'])
                if count==10000:
                    item['writes']=[]
                    for iteration in range(5):
                        for name in (('baseline','candidate') if iteration%2==0 else ('candidate','baseline')):
                            for operation in ('insert','update'):
                                with c.transaction(force_rollback=True):
                                    start=time.perf_counter()
                                    if operation=='insert':
                                        expressions=sql.SQL(',').join(sql.SQL("a.id || '-write'") if x=='id' else sql.SQL('a.{}').format(sql.Identifier(x)) for x in cols)
                                        c.execute(sql.SQL('INSERT INTO eligibility_cost_probe.{} ({}) SELECT {} FROM public.memory_assertions a ORDER BY id LIMIT 1000').format(sql.Identifier(name),names,expressions))
                                    else:
                                        c.execute(sql.SQL("UPDATE eligibility_cost_probe.{} SET search_text=search_text||' amberchanged', document=jsonb_set(document,'{{statement}}',to_jsonb((document->>'statement')||' amberchanged')) WHERE id IN (SELECT id FROM eligibility_cost_probe.{} ORDER BY id LIMIT 1000)").format(sql.Identifier(name),sql.Identifier(name)))
                                    item['writes'].append({'iteration':iteration,'variant':name,'operation':operation,'rows':1000,'ms':(time.perf_counter()-start)*1000})
                r['costs'].append(item);save();print(json.dumps({k:v for k,v in item.items() if k!='writes'}),flush=True)
        assert snap(c)==before
    start=time.perf_counter();storage.Database(p.migration_database_url).migrate()
    r['actual_profile_upgrade_seconds']=time.perf_counter()-start
    with psycopg.connect(p.migration_database_url,row_factory=dict_row) as c:
        r['core_unchanged']=before==snap(c);assert r['core_unchanged']
    r['completed']=True
finally:
    embedded_database.stop(p);r['ports_closed']={}
    for name,port in [('api',p.api_port),('database',p.database_port)]:
        with socket.socket() as s:r['ports_closed'][name]=s.connect_ex(('127.0.0.1',port))!=0
    save()
