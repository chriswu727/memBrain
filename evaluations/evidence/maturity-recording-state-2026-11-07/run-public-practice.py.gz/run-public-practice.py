import hashlib,json,os,socket,subprocess,sys,time
from pathlib import Path
from membrain.build_identity import BUILD_ID,SCHEMA_ID,package_manifest
root=Path(__file__).parent
repo=Path('/Users/yichen/tmp/membrain-recording-state-20261107')
out=root/'public-practice';out.mkdir(exist_ok=False)
files=subprocess.check_output(['git','ls-files','src','plugins','migrations','architecture','evaluations/c5-harness.py','evaluations/c5-practice-scenario.py','evaluations/c5-dry-run-check.py','evaluations/acceptance_review.py','evaluations/acceptance_pipeline','evaluations/acceptance-review','evaluations/evaluation_budget.py','evaluations/acceptance_attempt.py','evaluations/maturity-provider-policy-draft.json','pyproject.toml','uv.lock'],cwd=repo,text=True).splitlines()
files=[repo/f for f in files]+[Path(__file__)]
hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
env={k:v for k,v in os.environ.items() if not k.startswith(('MEMORY_','MEMBRAIN_','C5_')) and not k.endswith(('_API_KEY','_API_TOKEN')) and k not in ('PYTHONPATH','VIRTUAL_ENV')}
env.update(C5_STUB='1',MEMBRAIN_SEMANTIC='0',PYTHON_DOTENV_DISABLED='1')
report={'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'runtime_pin':subprocess.check_output(['git','rev-parse','HEAD^'],cwd=repo,text=True).strip(),'build_id':BUILD_ID,'schema_id':SCHEMA_ID,'runtime_inputs':len(package_manifest(repo/'src/membrain',repo)),'scope':'Current source runtime; deterministic public stubs; keyword recall; direct parallel harness (not shell supervisor); external sockets refused by harness; no provider credentials or model calls. Fresh installed qualification recorded separately.','input_sha256':hashes,'completed':False,'arms':{}}
result=root/'public-practice-result.json';result.write_text(json.dumps(report,indent=2)+'\n')
processes={};logs=[];ports=[]
try:
 for arm in 'PEF':
  directory=out/f'practice-{arm}';directory.mkdir();selected=dict(env)
  if arm!='F':
   sockets=[socket.socket(),socket.socket()]
   for s in sockets:s.bind(('127.0.0.1',0))
   arm_ports=[s.getsockname()[1] for s in sockets];ports+=arm_ports
   for s in sockets:s.close()
   selected['MEMBRAIN_PORTS']=','.join(map(str,arm_ports))
  log=(directory/'run.log').open('w');logs.append(log)
  command=[sys.executable,'-u',str(repo/'evaluations/c5-harness.py'),arm,str(repo/'evaluations/c5-practice-scenario.py'),str(directory)]
  processes[arm]=subprocess.Popen(command,cwd=repo,env=selected,stdout=log,stderr=subprocess.STDOUT)
 deadline=time.monotonic()+600
 while any(p.poll() is None for p in processes.values()):
  if any(p.poll() not in (None,0) for p in processes.values()):raise RuntimeError('Public practice arm failed; stop siblings')
  if time.monotonic()>deadline:raise RuntimeError('Public practice timeout')
  time.sleep(.2)
 assert all(p.returncode==0 for p in processes.values())
 report['completed']=True
finally:
 for arm,p in processes.items():
  if p.poll() is None:
   p.terminate()
   try:p.wait(timeout=15)
   except subprocess.TimeoutExpired:p.kill();p.wait()
  report['arms'][arm]={'exit_code':p.returncode}
 for f in logs:f.close()
 report['inputs_unchanged']=all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in hashes.items())
 report['ports']=[]
 for port in ports:
  with socket.socket() as s:
   s.settimeout(1);report['ports'].append({'port':port,'closed':s.connect_ex(('127.0.0.1',port))!=0})
 result.write_text(json.dumps(report,indent=2)+'\n')
print({k:v for k,v in report.items() if k!='input_sha256'})
assert report['completed'] and report['inputs_unchanged'] and all(p['closed'] for p in report['ports'])
