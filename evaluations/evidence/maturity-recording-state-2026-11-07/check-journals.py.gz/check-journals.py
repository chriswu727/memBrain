import json
from pathlib import Path
root=Path(__file__).parent
report={}
for arm,n in [('P',24),('E',18),('F',18)]:
 p=root/'public-practice'/f'practice-{arm}'
 rows=[json.loads(s) for s in (p/'host-rounds.jsonl').read_text().splitlines()]
 turns=[json.loads(s) for s in next(p.glob('results_*.jsonl')).read_text().splitlines()]
 assert len(rows)==n and len(turns)==18
 assert {(r['session'],r['turn']) for r in rows}=={(r['session'],r['turn']) for r in turns}
 assert all('reasoning_content' not in r['message'] for r in rows)
 report[arm]={'turns':len(turns),'journal_rows':len(rows),'positions_match':True,'reasoning_content_present':False}
(root/'journal-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
