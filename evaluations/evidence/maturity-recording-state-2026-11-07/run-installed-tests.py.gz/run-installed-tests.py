import json,os,subprocess
from pathlib import Path
root=Path(__file__).parent
python=root/'install-final/uv-tools/membrain-ai/bin/python'
env={k:v for k,v in os.environ.items() if not k.startswith(('MEMORY_', 'MEMBRAIN_', 'C5_')) and not k.endswith(('_API_KEY', '_API_TOKEN')) and k not in ('PYTHONPATH', 'VIRTUAL_ENV')}
env.update(PYTHON_DOTENV_DISABLED='1',MEMBRAIN_SEMANTIC='0')
code="""import sys
from pathlib import Path
sys.path.append('/Users/yichen/tmp/membrain-review-20261029/.venv/lib/python3.12/site-packages')
import membrain
from membrain.build_identity import BUILD_ID
assert Path(membrain.__file__).resolve().is_relative_to(Path(sys.executable).parent.parent)
assert BUILD_ID=='44c034fefd9278d180578307e2169d6ed630f101ff2736a4c6ba7e8e1462a319'
print({'package':membrain.__file__,'build_id':BUILD_ID},flush=True)
import pytest
raise SystemExit(pytest.main(['-c','pytest.ini','test_recording_context.py','-q','--basetemp=../installed-tests-temp']))
"""
with (root/'installed-tests.log').open('w') as log:
 result=subprocess.run([str(python),'-I','-c',code],cwd=root/'installed-tests',env=env,stdout=log,stderr=subprocess.STDOUT)
(root/'installed-tests-summary.json').write_text(json.dumps({'exit_code':result.returncode,'provider_calls':0},indent=2)+'\n')
print((root/'installed-tests.log').read_text())
raise SystemExit(result.returncode)
