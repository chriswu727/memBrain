import json
from pathlib import Path

root = Path(__file__).parent
artifacts = root / 'artifacts'
audit = json.loads((root / 'native-summary-audit.json').read_text())
fields = {
    'native-adoption': ('loader_failure_preserves_live_service', 'rejected_restart_documents_unchanged',
                       'verified_restart_changes_instance', 'http_memory_after_restart', 'default_native_selector',
                       'credentials_preserved', 'original_cluster_preserved', 'admission_before_api',
                       'http_memory_after_cold_restart', 'private_backup_restore', 'quarantine_blocks_api',
                       'restored_memory_recalled', 'restored_credentials_rotated'),
    'native-maintenance': ('interrupted_opening_blocks_ordinary_role', 'flags_restored_before_backup_rejection',
                          'closed_flags_limits_and_acls_preserved', 'resumed_all_database_catalog_repair',
                          'public_and_custom_schema_vector_upgraded', 'complete_vector_rows_and_nearest_results_preserved',
                          'nonowner_statistics_hidden_after_repair', 'repeat_and_restart_verified'),
    'native-transition': ('original_rows_roles_vector_indexes_and_nearest_restored', 'original_backup_immutable_during_resume',
                         'failed_target_preserved_or_privately_archived', 'target_sql_journal_archived',
                         'original_data_location_and_account_retained', 'new_operation_uses_fresh_snapshot',
                         'independent_authority_blocks_rollback', 'application_schema_and_authority_reconciled',
                         'admission_durable_before_api_launch', 'post_admission_write_preserved'),
    'native-snapshot': ('original_unchanged_during_snapshot', 'upgraded_original_preserved_during_restore',
                       'restored_complete_bytes_modes_owners_timestamps',
                       'roles_second_database_vector_indexes_and_rows_restored', 'original_engine_and_vector_restored',
                       'custom_configuration_preserved'),
    'packaged-native': ('restart_preserves_rows', 'host_native_environment_isolated',
                       'cached_client_dump_preserves_row', 'supplier_unchanged'),
}
checks = []
hosts = {}
for row in audit['summaries']:
    path = artifacts / row['path']
    data = json.loads(path.read_text())
    if path.name == 'qualification.json':
        assert all('16.15' in version for version in data['tools'].values())
        before, after = data['stages']
        assert before['rows'] == after['rows'] == 1000
        assert before['sha256'] == after['sha256'] and after['extension'] == '0.8.6'
        assert data['restart_preserves_rows'] and data['backup_restore_preserves_rows']
        hosts[row['path'].split('/')[0]] = {'host': data['host'], 'os_release': data['os_release'],
                                          'previous_vector': before['extension'], 'current_vector': after['extension']}
        checks.append({'path': row['path'], 'stage_hashes_equal': True})
        continue
    category = next(name for name in fields if name in row['path'])
    for field in fields[category]:
        assert data[field] is True, (row['path'], field)
    if category == 'native-adoption' and data['legacy_upgrade']:
        assert data['legacy_vector_rows_preserved'] is True, row['path']
    if category == 'packaged-native':
        assert data['supplier_python_executed'] is False and data['verified_files'] > 0
    checks.append({'path': row['path'], 'checked_fields': list(fields[category]), 'scope': data.get('scope', 'installed adoption')})
assert len(checks) == 47 and len(hosts) == 5
result = {'run': 42400657384, 'head': '62e17adc2c45c072001ca0cbb4e6756e585bc3a7',
          'hosts': hosts, 'checks': checks, 'completed': True}
(root / 'native-stage-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'checked_summaries': len(checks), 'platforms': len(hosts), 'completed': True}))
