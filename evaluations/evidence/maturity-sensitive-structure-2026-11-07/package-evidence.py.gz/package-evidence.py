import gzip,hashlib,json,shutil
from pathlib import Path
root=Path(__file__).parent
repo=Path('/Users/yichen/tmp/membrain-sensitive-structure-20261107')
target=repo/'evaluations/evidence/maturity-sensitive-structure-2026-11-07'
original=Path('/Users/yichen/tmp/membrain-acceptance-20261107/evaluations/.maturity-heldout-20261107/control/release-source-review.json')
shutil.copyfile(original,root/'original-source-review.json')
files=[p for p in root.iterdir() if p.is_file() and p.suffix in {'.py','.json','.log'} and not p.name.startswith('pr43-')]
files.append(root/'install-final/results.json')
for arm in 'PEF':
 files += [p for p in (root/'public-practice'/f'practice-{arm}').iterdir() if p.is_file() and p.suffix in {'.json','.jsonl','.log'}]
secrets=set();profiles=[]
for parent in ['before-temp','after-temp','related-installation','related-temp','install-final','public-practice','installed-tests-temp','graph-cost-installation']:
 for p in (root/parent).rglob('profile.json'):
  d=json.loads(p.read_text());profiles.append(p)
  for k in ('api_key','admin_password','app_password'):
   v=d.get(k)
   if isinstance(v,str) and len(v)>16:secrets.add(v.encode())
assert len(profiles)>=10 and len(secrets)>=24
manifest={'source_head':'62e17adc2c45c072001ca0cbb4e6756e585bc3a7','runtime_pin':'86e7f1fed2ba00d08b3cb9509beb50e4cf811f4b','build_id':'eb152d9724f67904fb1bafb38896b2ea03c5495f78a7b1470a4e729b5ca399ef','scope':'Public synthetic checks and source-review reports only. No hidden scenarios, private scenario findings, provider credentials, profile contents, database contents or archives. Initial installed demo fixture failure retained. CI still pending.','privacy':{'profiles_checked':len(profiles),'known_credentials_checked':len(secrets),'all_absent':True},'files':[]}
for p in sorted(set(files)):
 data=p.read_bytes();assert not any(s in data for s in secrets),f'Credential detected in {p.name}; refuse publication'
 name=p.relative_to(root).as_posix()+'.gz';packed=gzip.compress(data,mtime=0);dst=target/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(packed)
 assert gzip.decompress(dst.read_bytes())==data
 manifest['files'].append({'path':name,'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'original_sha256':hashlib.sha256(data).hexdigest()})
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print({'payloads':len(manifest['files']),**manifest['privacy']})
