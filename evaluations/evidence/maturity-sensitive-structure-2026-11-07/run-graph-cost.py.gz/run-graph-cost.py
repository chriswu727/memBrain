import hashlib, importlib.util, json, os, socket, statistics, subprocess, sys, time
from pathlib import Path
root=Path(__file__).parent
repo=Path('/Users/yichen/tmp/membrain-sensitive-structure-20261107')
for key in list(os.environ):
 if key.startswith(('MEMORY_','MEMBRAIN_','C5_')) or key.endswith(('_API_KEY','_API_TOKEN')):os.environ.pop(key)
os.environ.update(MEMBRAIN_SEMANTIC='0',PYTHON_DOTENV_DISABLED='1')
from membrain import host,desktop
from membrain.config import configured_service
from membrain.local_profile import load_profile
from membrain.build_identity import BUILD_ID
from membrain.structure_map import structure_map
spec=importlib.util.spec_from_file_location('graph_public_helpers',root/'installed-tests/test_memory_map.py')
helpers=importlib.util.module_from_spec(spec);spec.loader.exec_module(helpers)
old_bytes=subprocess.check_output(['git','show','86dfcb24ed081f7ecf925001ba65de68f46e41d3:src/membrain/structure_map.py'],cwd=repo)
old={'__name__':'membrain._graph_cost_previous','__package__':'membrain'}
exec(compile(old_bytes,'previous-structure-map.py','exec'),old)
profile_root=root/'graph-cost-installation';assert not profile_root.exists()
report={'completed':False,'build_id':BUILD_ID,'provider_calls':0,'old_structure_sha256':hashlib.sha256(old_bytes).hexdigest(),'new_structure_sha256':hashlib.sha256((repo/'src/membrain/structure_map.py').read_bytes()).hexdigest(),'scope':'Source-service graph endpoint projection, synthetic mixed-sensitivity notes, same stored data. No browser or recall benchmark; previous implementation loaded separately for comparison. Four ABBA phases per graph bound, 20 timed calls after 2 explicit warmups per phase. All samples retained.','phases':[]}
try:
 host.start(profile_root);profile=load_profile(profile_root)
 with configured_service(profile.settings()) as service:
  principal=next(iter(profile.settings().principals().values()));ident=service.create_brain(principal,'Graph privacy cost fixture')['id'];brain=(service,principal,ident)
  for i in range(200):
   source=helpers.say(brain,f'Public synthetic source {i:04d}.')
   helpers.note(brain,f'Synthetic shared private marker {i:04d}.',role='user',source_event_ids=[source])
   helpers.note(brain,f'Synthetic direct private marker {i:04d}.',role='user',sensitive=True,source_event_ids=[source])
   helpers.note(brain,f'Synthetic public hobby {i:04d}.',role='user')
  jobs=0
  while service.work_once(principal,ident):
   jobs+=1
   assert jobs<10000,'Fixture indexing exceeded bound'
  with service.database.transaction(principal) as conn:
   report['fixture']={table:conn.execute('SELECT count(*) AS n FROM '+table+' WHERE tenant_id=%s AND owner_id=%s AND brain_id=%s',service._params(principal,ident)).fetchone()['n'] for table in ('memory_events','memory_assertions','memory_event_dependencies')}
  report['jobs_drained']=jobs
  for bound in (200,500):
   for phase,implementation in enumerate(('previous','repaired','repaired','previous')):
    function=structure_map if implementation=='repaired' else old['structure_map']
    samples=[]
    for index in range(22):
     start=time.perf_counter();graph=function(*brain,max_nodes=bound,max_edges=bound*2);elapsed=(time.perf_counter()-start)*1000
     if implementation=='repaired':
      serialized=json.dumps(graph)
      assert 'Synthetic shared private marker' not in serialized and 'Synthetic direct private marker' not in serialized
      assert any(n['kind']=='assertion' and n['masked'] for n in graph['nodes'])
      assert any(n['kind']=='assertion' and not n['masked'] for n in graph['nodes'])
     if index>=2:samples.append(elapsed)
    ordered=sorted(samples)
    item={'bound':bound,'phase':phase,'implementation':implementation,'nodes':len(graph['nodes']),'edges':len(graph['edges']),'median_ms':statistics.median(samples),'p95_ms':ordered[int(.95*(len(ordered)-1))],'raw_ms':samples}
    report['phases'].append(item);print({k:v for k,v in item.items() if k!='raw_ms'},flush=True)
  report['completed']=True
finally:
 desktop.stop(profile_root)
 if (profile_root/'profile.json').exists():
  profile=load_profile(profile_root);report['ports']=[]
  for port in (profile.api_port,profile.database_port):
   with socket.socket() as sock:report['ports'].append({'port':port,'closed':sock.connect_ex(('127.0.0.1',port))!=0})
 (root/'graph-cost.json').write_text(json.dumps(report,indent=2)+'\n')
assert report['completed'] and all(p['closed'] for p in report['ports'])
