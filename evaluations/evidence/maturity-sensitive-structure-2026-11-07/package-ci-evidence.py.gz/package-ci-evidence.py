import gzip,hashlib,json,re,subprocess
from pathlib import Path
root=Path(__file__).parent
repo=Path('/Users/yichen/tmp/membrain-sensitive-structure-20261107')
ci=root/'ci'
target=repo/'evaluations/evidence/maturity-sensitive-structure-2026-11-07'
qualified='62e17adc2c45c072001ca0cbb4e6756e585bc3a7'
statuses={key:json.loads((ci/(key+'-status-final.json')).read_text()) for key in ('verify','native')}
for key,state in statuses.items():
 assert state['status']=='completed' and state['conclusion']=='success' and state['headSha']==qualified,key
steps={s['name']:s['conclusion'] for j in statuses['verify']['jobs'] for s in j['steps']}
for name in ('Run uv run ruff check src tests examples','Run uv run pytest -v --durations=15','Run npm ci && npm test && npm run typecheck','Run uv build'):
 assert steps[name]=='success',name
pytest=(ci/'verify-pytest.log').read_text();matches=re.findall(r'=+ (\d+) passed([^\n]*?) in ([0-9.]+)s',pytest)
assert len(matches)==1 and not any(word in matches[0][1] for word in ('failed','skipped','error')),matches
full=(ci/'verify-complete.log').read_text()
ts={name:int(re.findall(r'# '+name+r' (\d+)',full)[-1]) for name in ('tests','pass','fail','skipped')}
assert ts['tests']==ts['pass'] and ts['fail']==ts['skipped']==0
native=json.loads((ci/'native-summary-audit.json').read_text());stages=json.loads((ci/'native-stage-audit.json').read_text())
assert native['count']==47 and native['all_completed'] and native['all_model_calls_zero'] and native['all_recorded_port_closures_passed']
assert stages['completed'] and len(stages['hosts'])==5 and stages['head']==qualified
assert not subprocess.check_output(['git','diff',qualified,'--','src','tests','plugins','integrations','scripts','migrations','architecture','sdk','.github','pyproject.toml','uv.lock'],cwd=repo)
summary={'qualified_source':qualified,'verify_run':42400657368,'native_run':42400657384,'python_passed':int(matches[0][0]),'python_summary_suffix':matches[0][1],'python_seconds':float(matches[0][2]),'typescript':ts,'native_platforms':5,'native_unique_summaries':47,'source_equivalent_to_current':True,'completed':True}
(root/'ci-qualification-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
secrets=set();profiles=[]
for parent in ['before-temp','after-temp','related-installation','related-temp','install-final','public-practice','installed-tests-temp','graph-cost-installation']:
 for p in (root/parent).rglob('profile.json'):
  d=json.loads(p.read_text());profiles.append(p)
  for k in ('api_key','admin_password','app_password'):
   v=d.get(k)
   if isinstance(v,str) and len(v)>16:secrets.add(v.encode())
assert len(profiles)==12 and len(secrets)==36
manifest=json.loads((target/'manifest.json').read_text());known={f['path'] for f in manifest['files']}
for f in manifest['files']:
 packed=(target/f['path']).read_bytes();assert hashlib.sha256(packed).hexdigest()==f['sha256']
 assert hashlib.sha256(gzip.decompress(packed)).hexdigest()==f['original_sha256']
files=[p for p in ci.rglob('*') if p.is_file() and p.suffix in {'.py','.json','.log'} and not p.name.endswith('-watch.log')]
files += [Path(__file__),root/'ci-qualification-summary.json']
for p in sorted(files):
 data=p.read_bytes();assert not any(s in data for s in secrets),f'Credential detected in {p.name}'
 name=p.relative_to(root).as_posix()+'.gz';assert name not in known,'Refuse replacing archived payload'
 packed=gzip.compress(data,mtime=0);dst=target/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(packed)
 assert gzip.decompress(dst.read_bytes())==data
 manifest['files'].append({'path':name,'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'original_sha256':hashlib.sha256(data).hexdigest()})
manifest['scope']='Public synthetic checks, independent source reviews and completed exact-source CI evidence. Original source regressions and installed demo fixture failure retained. Hidden scenarios, private scenario findings, provider credentials, profiles, databases and archives excluded.'
manifest['ci']=summary
manifest['privacy']['ci_export_scope']='Workflow-exported qualification JSON/log files and raw Verify logs; local 36-value credential scan is not a claim to possess CI profile credentials.'
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print({'payloads':len(manifest['files']),**summary})
