import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path(__file__).parent
repo=Path('/Users/yichen/tmp/membrain-sensitive-structure-20261107')
python=root/'install-final/uv-tools/membrain-ai/bin/python'
for n in ('test_memory_map.py','conftest.py'):
 assert (root/'installed-tests'/n).read_bytes()==(repo/'tests'/n).read_bytes()
env={k:v for k,v in os.environ.items() if not k.startswith(('MEMORY_','MEMBRAIN_','C5_')) and not k.endswith(('_API_KEY','_API_TOKEN')) and k not in ('PYTHONPATH','VIRTUAL_ENV')}
env.update(PYTHON_DOTENV_DISABLED='1',MEMBRAIN_SEMANTIC='0')
code="""import json,sys
from pathlib import Path
sys.path.append('/Users/yichen/tmp/membrain-review-20261029/.venv/lib/python3.12/site-packages')
import membrain
from membrain.build_identity import BUILD_ID
assert Path(membrain.__file__).resolve().is_relative_to(Path(sys.executable).parent.parent)
assert BUILD_ID=='eb152d9724f67904fb1bafb38896b2ea03c5495f78a7b1470a4e729b5ca399ef'
print(json.dumps({'package':membrain.__file__,'build_id':BUILD_ID}),flush=True)
import pytest
raise SystemExit(pytest.main(['-c','pytest.ini','test_memory_map.py::test_demo_has_only_fictional_nodes_and_all_edges_have_existing_endpoints','-q','--basetemp=../installed-demo-followup-temp']))
"""
with (root/'installed-demo-followup.log').open('w') as log:
 result=subprocess.run([str(python),'-c',code],cwd=root/'installed-tests',env=env,stdout=log,stderr=subprocess.STDOUT)
(root/'installed-demo-followup-summary.json').write_text(json.dumps({'exit_code':result.returncode,'tests_match_source':True,'wrapper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n')
raise SystemExit(result.returncode)
