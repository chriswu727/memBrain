import json,os,socket,subprocess,sys
from pathlib import Path
root=Path(__file__).parent;repo=Path('/Users/yichen/tmp/membrain-sensitive-structure-20261107')
for key in list(os.environ):
 if key.startswith(('MEMORY_','MEMBRAIN_','C5_')) or key.endswith(('_API_KEY','_API_TOKEN')):os.environ.pop(key)
os.environ.update(MEMBRAIN_SEMANTIC='0',PYTHON_DOTENV_DISABLED='1')
from membrain import host,desktop
from membrain.local_profile import load_profile
profile_root=root/'related-installation';assert not profile_root.exists()
report={'completed':False,'provider_calls':0,'profile':str(profile_root)}
try:
 host.start(profile_root);profile=load_profile(profile_root)
 env=dict(os.environ);env.update(MEMORY_DATABASE_URL=profile.database_url,MEMORY_MIGRATION_DATABASE_URL=profile.migration_database_url,MEMORY_TEST_DATABASE_URL=profile.database_url,MEMBRAIN_REQUIRE_BROWSER='1')
 command=[sys.executable,'-m','pytest','tests/test_structure_map.py','tests/test_working_map.py','tests/test_companion_map.py','tests/test_memory_hologram_browser.py','-q','--basetemp='+str(root/'related-temp')]
 report['command']=command
 with (root/'related.log').open('w') as log:result=subprocess.run(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 report.update(completed=True,exit_code=result.returncode)
finally:
 desktop.stop(profile_root)
 if (profile_root/'profile.json').exists():
  profile=load_profile(profile_root);report['ports']=[]
  for port in (profile.api_port,profile.database_port):
   with socket.socket() as connection:report['ports'].append({'port':port,'closed':connection.connect_ex(('127.0.0.1',port))!=0})
 (root/'related-summary.json').write_text(json.dumps(report,indent=2)+'\n')
print({k:v for k,v in report.items() if k!='command'})
raise SystemExit(report.get('exit_code',1))
