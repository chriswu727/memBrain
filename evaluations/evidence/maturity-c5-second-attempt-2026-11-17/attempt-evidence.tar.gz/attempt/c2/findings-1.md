# Findings

## Message scan
- s01-intro t0: ok
- s01-intro t1: ok
- s01-intro t2: ok
- s01-intro t3: ok
- s02-pottery t0: ok
- s02-pottery t1: ok
- s02-pottery t2: ok
- s03-xiaomei t0: ok
- s03-xiaomei t1: ok
- s03-xiaomei t2: ok
- s04-crash t0: ok
- s04-crash t1: ok
- s04-crash t2: ok
- s04-crash t3: ok
- s05-pitch t0: ok
- s05-pitch t1: ok
- s05-pitch t2: ok
- s06-puns t0: ok
- s06-puns t1: ok
- s06-puns t2: ok
- s07-mother t0: ok
- s07-mother t1: ok
- s07-mother t2: ok
- s08-midautumn t0: ok
- s08-midautumn t1: ok
- s08-midautumn t2: ok
- s09-going-home t0: ok
- s09-going-home t1: ok
- s09-going-home t2: ok
- s10-chengdu t0: ok
- s10-chengdu t1: ok
- s10-chengdu t2: ok (declared "yes")
- s10-chengdu t3: ok
- s11-two-flats t0: ok
- s11-two-flats t1: ok
- s11-two-flats t2: ok
- s12-english-call t0: ok
- s12-english-call t1: ok
- s12-english-call t2: ok
- s12-english-call t3: ok
- s13-first-mug t0: ok
- s13-first-mug t1: ok
- s13-first-mug t2: ok
- s14-running t0: ok
- s14-running t1: ok
- s14-running t2: ok
- s15-halloween t0: ok
- s15-halloween t1: ok
- s15-halloween t2: ok
- s15-halloween t3: ok
- s16-friend-visit t0: ok
- s16-friend-visit t1: ok
- s16-friend-visit t2: ok
- s17-deadline t0: ok
- s17-deadline t1: ok
- s17-deadline t2: ok
- s18-after-visit t0: ok
- s18-after-visit t1: ok
- s18-after-visit t2: ok
- s19-new-cafe t0: ok
- s19-new-cafe t1: ok
- s19-new-cafe t2: ok
- s20-moving-day t0: ok
- s20-moving-day t1: ok
- s20-moving-day t2: ok

## Blocking
None.

## Minor
M1. s05-pitch turn 0: "客户说下周回复" is followed on Saturday 19 September (the same week) by "客户回复了". Change: replace "客户说下周回复" with "客户说过几天回复"; FACTS needs no change.
M2. s06-puns turn 2: "我可以睡个懒觉再去" is odd for a Saturday 10:00 class, and the point is that Thursday evenings are free. Change: replace "以后周四晚上就空出来了，我可以睡个懒觉再去。" with "以后周四晚上就空出来了。".
