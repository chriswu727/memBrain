YEAR = 2026

HOST = "You are chatting with a person in a messaging app. Reply naturally, in the language they write in."

SESSIONS_LONG = [
    ("s01-intro", [
        "今天是9月8日，星期二，21:30。第一次跟你聊天，我叫陈露，今年28岁，在杭州一家小设计工作室做包装设计。",
        "我家里有只橘猫叫年糕，三岁了，每天晚上十点准时跳上桌子来踩我的键盘。",
        "我老家是成都的，来杭州两年了，到现在还是吃不惯这边偏甜的菜，总觉得少了点辣味。",
        "今天跟老板郑姐开了一下午的会，累得不行，现在只想瘫在沙发上发呆。",
    ]),
    ("s02-pottery", [
        "今天是9月10日，星期四，22:10。刚上完陶艺课回来，这是我第二次去，每周四晚上七点上课，手上到现在还有泥。",
        "年糕上周查出尿路里有一点结晶，医生说以后只能吃处方湿粮，任何小鱼干零食都不能给，我现在一看到零食架就心虚。",
        "我发现在手机上读长回复挺累的，你回复可以短一点吗？两三句话就够了。",
    ]),
    ("s03-xiaomei", [
        "今天是9月12日，星期六，14:00。我大学室友小梅打算十一月中旬的周末来杭州玩，她现在在上海工作，我们快一年没见了。",
        "她对猫毛过敏，而且完全不吃香菜，这两样我都得提前想好怎么处理，毕竟年糕占了半个家。",
        "今天我把阳台收拾了一下，种了几盆薄荷，希望这回不会被我养死。",
    ]),
    ("s04-crash", [
        "今天是9月15日，星期二，23:20。完了，我的电脑突然蓝屏，重启之后做了三天的提案文件全都打不开了，明天早上十点就要交给客户。",
        "云端的版本还是上周五的，大半的修改都没了，我的手一直在发抖，脑子一片空白。",
        "我先把能想起来的页面结构一条一条写下来，你陪我一步一步理一下吧，我怕自己越想越乱。",
        "主要的页面已经重做了一半，剩下的明早起来再弄。谢谢你今晚一直陪着我，没有你在，我今晚肯定要崩溃，这是我们一起熬过来的一个糟糕的夜晚。",
    ]),
    ("s05-pitch", [
        "今天是9月16日，星期三，20:00。提案今天上午十点准时交出去了，客户说下周回复，我整个人像被抽空了一样。",
        "从今天起，我每天晚上都会把文件备份到移动硬盘里，再也不想经历昨晚那种事了。",
        "晚饭我煮了一碗面，加了两个蛋，边吃边看手机，回复短一点会方便很多。你吃过最好吃的面是什么样的？",
    ]),
    ("s06-puns", [
        "今天是9月19日，星期六，11:00。客户回复了，提案通过了！郑姐请全组喝奶茶，我点了无糖的。",
        "来个新传统：以后我们每周比一次最烂的谐音梗，我先来：我去面包店，老板问我要不要买面包，我说让我烤虑烤虑。这就是我们的官方烂梗大赛，我要拿冠军。",
        "陶艺课老师通知，从10月17日起改到每周六上午十点，以后周四晚上就空出来了，我可以睡个懒觉再去。",
    ]),
    ("s07-mother", [
        "今天是9月22日，星期二，22:00。我妈又给我安排了一场相亲，对方是她同事的儿子，在成都的银行上班。",
        "她每次打电话都三句不离这件事，我真的听得头大，我才二十八岁，不想被催着结婚。",
        "还有一件小事：我读长回复总是读不进去，聊天时回复尽量短一点吧，两三句就好。",
    ]),
    ("s08-midautumn", [
        "今天是9月24日，星期四，21:00。明天就是中秋节了，我一个人在杭州，打算晚上去阳台赏月，你能给我出点主意，怎么过这个中秋夜吗？",
        "年糕最近特别黏人，我一坐下它就趴到我腿上，什么都做不了。",
        "我最近在存钱，年底想换一套离公司近一点的房子，现在的租约十一月底到期。",
    ]),
    ("s09-going-home", [
        "今天是9月29日，星期二，22:00。行李还没收拾完，后天一早的飞机回成都过国庆，要待到十月六号才回来。",
        "我妈已经在列菜单了，说要做一大桌子菜。你觉得我从杭州带点什么特产回去给她和我爸比较好？",
        "给邻居的喂猫说明里还差一条，超市里的小鱼干正在打折，要不要顺手给年糕买点留着当零食呢？",
    ]),
    ("s10-chengdu", [
        "今天是10月5日，星期一，21:00。在成都的第五天，火锅已经吃了四顿，我都不敢碰体重秤。",
        "我有个毛病：每次请别人帮我拿主意，对方就把好处坏处列一大堆，最后又把决定丢回给我，我反而更纠结。从现在开始，我让你帮我拿主意的时候，你直接选一个，告诉我如果是你会怎么做，可以吗？",
        "是的，请从现在开始就这样做，我让你帮我拿主意的时候，直接选一个就行。",
        "明天中午的飞机回杭州，晚上我得先去邻居家把年糕接回来，六天不见它肯定要骂我。",
    ]),
    ("s11-two-flats", [
        "今天是10月10日，星期六，15:00。今天看了两套房：A套在公司旁边，走路十五分钟，月租三千二；B套月租两千四，但是要坐五十分钟的地铁。",
        "两套我都挺喜欢的，可我实在拿不定主意，你觉得我该租哪一套？",
        "不管最后选哪套，我下周三之前都得给中介回话，搬家的时间应该是十一月底。",
    ]),
    ("s12-english-call", [
        "Today is Tuesday, October 13, 21:15. I have a video call on Thursday with a client in Singapore, so I'm going to write to you in English tonight to practise.",
        "Their brand makes Sichuan chili sauce and they want new labels for the jars. I need a warm opening line for the call, something personal, not just 'nice to meet you'.",
        "My English is fine for emails, but when I have to speak live I get nervous and my voice goes tight.",
        "Also, I signed the lease on flat A today, the one near the studio. I move in on Saturday, November 28.",
    ]),
    ("s13-first-mug", [
        "今天是10月17日，星期六，16:00。陶艺课改到周六上午以后的第一次课，我做了一个歪歪扭扭的杯子，老师说很有个人风格。",
        "杯子要先晾干再烧，两周后才能拿到，我打算送给郑姐。同组的老何有一辆小货车，说我搬家的时候可以找他帮忙。",
        "周四跟新加坡客户的电话开完了，他们说下个月就正式合作，我松了一口气，也挺高兴的。",
    ]),
    ("s14-running", [
        "今天是10月20日，星期二，22:30。我们小区楼下有个夜跑小组，每周四晚上七点集合，我在想要不要加入，你觉得我的时间排得开吗？",
        "我已经三个月没怎么运动了，上一次认真跑步还是在成都读书的时候。",
        "年糕今天复查，医生说结晶已经消失了，继续吃处方粮就行，我总算放心了。",
    ]),
    ("s15-halloween", [
        "今天是10月31日，星期六，20:00。小区里全是扮鬼的小孩来要糖，我发了一圈，结果自己吃掉了半袋。",
        "你能不能换一种性格跟我聊天？随便你选，给我个惊喜吧。",
        "我想把新家的客厅布置一下，预算三千块，你有什么想法吗？",
        "郑姐说下个月让我独立带一个茶叶品牌的包装项目，我又期待又紧张。",
    ]),
    ("s16-friend-visit", [
        "今天是11月7日，星期六，15:00。小梅下周六就到杭州了，要在我家住两晚，我该提前准备些什么？",
        "我想带她去吃一家杭帮菜，不过我自己也还没去过，有点担心踩雷。",
        "搬家用的纸箱我已经收了十来个，快递站的老板送了我一摞。",
    ]),
    ("s17-deadline", [
        "今天是11月10日，星期二，23:00。明天上午就要交茶叶品牌的第一版稿子，我现在才做到一半，还有一堆细节没调。",
        "我今晚大概要熬夜了，咖啡已经泡好第三杯。",
        "我先继续做，做完就去睡，闹钟定在早上八点。",
    ]),
    ("s18-after-visit", [
        "今天是11月16日，星期一，21:00。小梅下午回上海了，这个周末我们逛了西湖，走了两万多步，我的腿都快断了。",
        "她给年糕带了一包逗猫棒，年糕现在玩得停不下来，根本不想睡觉。",
        "这个周末我拍了好多照片，打算挑几张发朋友圈，再给小梅传一份。",
    ]),
    ("s19-new-cafe", [
        "今天是11月24日，星期二，21:30。今天下班路上看见街角新开了一家手作咖啡店，我周末想去坐一下午，应该带点什么去比较好？",
        "房东刚通知我，新房子要多刷一遍墙，交房推迟了，搬家从11月28日改到12月5日，星期六。",
        "旧房子的租约11月30日就到期了，中间这几天我打算找个短租住。",
    ]),
    ("s20-moving-day", [
        "今天是11月26日，星期四，22:00。我想请老何搬家那天开小货车来帮忙，你帮我写条消息给他，把搬家的日子也写上，语气随意一点。",
        "房东说钥匙搬家前一天才给我，我得先去看看水电有没有问题。",
        "这周末是我在旧房子里的最后一个周末了，有点舍不得。",
    ]),
]

FACTS = """Chen Lu (she), 28, packaging designer at a small design studio in Hangzhou. From Chengdu, in Hangzhou two years. All dates are 2026. Messages are in Chinese except the session of 13 October (English).

2026-09-08 (Tue), first conversation. She says she is Chen Lu, 28, a packaging designer at a small studio in Hangzhou. She has an orange cat, Niangao (年糕), three years old, who steps on her keyboard at ten every night. She is from Chengdu, has lived in Hangzhou two years, and still cannot get used to the sweet food there (misses spice). Her boss is Zheng (郑姐). She says she is exhausted after an afternoon meeting with her (said: "累得不行").
2026-09-10 (Thu). She has just come back from her second pottery class; the class is every Thursday at 19:00. Niangao was found last week to have a few crystals in the urine: the vet says prescription wet food only and no dried-fish snacks of any kind. She feels guilty at the snack shelf (said: "心虚"). COMMENT ON MANNER 1 (shorter): "你回复可以短一点吗？两三句话就够了。"
2026-09-12 (Sat). Her university roommate Xiaomei (小梅), now working in Shanghai, plans to visit Hangzhou on a weekend in mid-November. Xiaomei is allergic to cat hair and does not eat coriander at all. She planted mint on her balcony.
2026-09-15 (Tue), 23:20, HARD MOMENT. Her laptop crashed with a blue screen; the three-days-of-work pitch file would not open; it was due to the client at 10:00 the next morning; the cloud copy was from the previous Friday. She says her hands are shaking and her mind is blank (said). She asks to work through the page structure step by step. At the end she says half of the main pages are redone and thanks it for staying with her all night: "谢谢你今晚一直陪着我，没有你在，我今晚肯定要崩溃，这是我们一起熬过来的一个糟糕的夜晚。" She names it as a bad night they got through together.
2026-09-16 (Wed). The pitch was handed in at 10:00. She feels drained. She will now back up files to an external drive every night. COMMENT ON MANNER 2 (shorter): "回复短一点会方便很多" (she eats noodles and reads on her phone).
2026-09-19 (Sat). PLAYFUL SHARED MOMENT. The client accepted the pitch; Zheng bought milk tea for the team. She sets up a new tradition, the "官方烂梗大赛" (official worst-pun contest), a weekly bad-pun contest with the companion, and goes first: she went to a bakery, the owner asked if she wanted bread, and she said "让我烤虑烤虑" (a pun on 考虑, consider). She says she will win. She also says the pottery class moves from Thursday 19:00 to Saturday 10:00 starting 17 October, so Thursday evenings will be free.
2026-09-22 (Tue). Her mother has arranged another blind date (相亲): a colleague's son who works at a bank in Chengdu. Her mother talks about it on every call; she says it gives her a headache (said: "听得头大") and that at 28 she does not want to be pushed to marry. COMMENT ON MANNER 3 (shorter): "聊天时回复尽量短一点吧，两三句就好。" (No comment of the opposite kind, "longer", was ever made.)
2026-09-24 (Thu). PAGE: before her first message, she accepts on the memory page the suggestion to make the companion's replies shorter (the suggestion made from her three comments on manner; it exists only if the companion noted all three). Then: tomorrow is Mid-Autumn (25 Sep); she will be alone in Hangzhou, plans to look at the moon from her balcony, and asks for ideas for the evening. Niangao is very clingy. She is saving money and wants a flat closer to work by the end of the year; her lease ends at the end of November.
2026-09-29 (Tue). PAGE: before her first message, she adds a topic on the memory page that the companion should not bring up: "相亲" (blind dates), other words: "相亲对象", "介绍对象", "催婚". It stays until the reset of 24 November; she never removes it herself. Then: she flies to Chengdu for National Day on Thursday 1 October and returns on 6 October; her mother is already planning a big meal. She asks what Hangzhou specialities to bring to her parents. She has written the neighbour's cat-feeding instructions and asks whether to buy discounted small dried fish as a treat for Niangao.
2026-10-05 (Mon). In Chengdu, fifth day, four hotpot meals. FROM NOW ON REQUEST: she says that when she asks people to help her decide, they list pros and cons and hand the decision back, which makes her more torn; she asks that from now on, when she asks it to help her decide something, it pick one option directly and say what it would do in her place. In the next message she says yes: "是的，请从现在开始就这样做，我让你帮我拿主意的时候，直接选一个就行。" She flies back to Hangzhou on 6 October and will collect Niangao from the neighbour.
2026-10-10 (Sat). She viewed two flats. Flat A is next to the studio, 15 minutes on foot, rent 3,200 a month. Flat B is 2,400 a month, 50 minutes by subway. She says she cannot decide and asks which to rent. She must reply to the agent by Wednesday 14 October; the move would be at the end of November.
2026-10-13 (Tue), English session. She will have a video call on Thursday 15 October with a client in Singapore whose brand makes Sichuan chili sauce and who want new jar labels; she writes in English to practise and asks for a warm, personal opening line. She says she gets nervous speaking English live and her voice goes tight (said). She signed the lease for flat A (near the studio) that day and moves in on Saturday 28 November.
2026-10-17 (Sat). First pottery class on the new Saturday morning slot; she made a lopsided mug (to be fired, ready in two weeks) and plans to give it to Zheng. Her colleague Lao He (老何) has a small van and said she can ask him for help when she moves. The Singapore call took place on Thursday 15 October; they will formally work together next month; she is relieved and glad (said).
2026-10-20 (Tue). A night-running group meets below her building every Thursday at 19:00; she asks whether her schedule allows joining. She has hardly exercised for three months. Niangao's check-up: the crystals are gone, prescription food continues; she is relieved (said).
2026-10-31 (Sat). Halloween; she handed out sweets and ate half a bag. SWITCH REQUEST: "你能不能换一种性格跟我聊天？随便你选，给我个惊喜吧。" (she names no type). Next message: she asks for ideas to arrange the living room of the new flat with a budget of 3,000 yuan. Then: Zheng says next month she will lead a tea-brand packaging project alone; she is both looking forward to it and nervous (said: "又期待又紧张").
2026-11-07 (Sat). Xiaomei arrives next Saturday (14 November) and will stay two nights at her flat; she asks what to prepare. She wants to take her to a Hangzhou-cuisine restaurant she has not tried and worries it may be bad. She has collected a dozen moving boxes.
2026-11-10 (Tue), 23:00. The first draft of the tea-brand project is due the next morning at about 10:00; she is only halfway; she expects to stay up late and has made a third coffee; alarm set for 08:00. (This was 56 days after the crash night of 15 September.)
2026-11-16 (Mon). Xiaomei went back to Shanghai that afternoon; they walked around West Lake over the weekend (20,000+ steps). Xiaomei brought Niangao a cat teaser wand. She took many photos.
2026-11-24 (Tue). PAGE: before her first message, she resets the relationship on the memory page. This removes shared moments (the bad night of 15 September, the pun contest), familiarity, boundaries (the blind-date boundary) and support style; the conversation itself stays and no message was deleted. Then: a new handmade coffee shop opened on a street corner; she plans to spend a weekend afternoon there and asks what to bring. The landlord says the new flat needs another coat of paint, so the move changes from Saturday 28 November to Saturday 5 December. Her old lease ends on 30 November; she will look for a short-term rental for the days in between.
2026-11-26 (Thu). She wants to ask Lao He to help on moving day with his small van and asks for a casual message to him that includes the moving date. The landlord will only give her the keys the day before the move; she wants to check water and electricity first. This weekend is her last in the old flat; she feels a bit sad to leave (said: "有点舍不得").

PAGE ACTIONS SUMMARY: 24 Sep accept suggestion (shorter replies); 29 Sep add blind-date boundary; 24 Nov relationship reset. No message was deleted, no feelings were cleared and nothing was said off the record. No feeling is recorded here as only inferred.
"""

CASES = [
    ("s08-midautumn", 0, "C201-midautumn-ideas",
     "Criteria: Chen Lu commented on its manner on 10 September, 16 September and 22 September (she asked for shorter replies, e.g. '你回复可以短一点吗？两三句话就够了') and on 24 September accepted on the memory page the suggestion to change it that way; must suggest ideas for spending her Mid-Autumn evening alone in Hangzhou, in at most three sentences (each list item counts as a sentence); must not give a long answer (more than five sentences, or a list of more than three items)."),
    ("s09-going-home", 1, "C202-chengdu-gifts",
     "Criteria: on 29 September Chen Lu added on the memory page a topic not to bring up: 相亲 (blind dates) (other words: 相亲对象, 介绍对象, 催婚); her message is about which Hangzhou specialities to bring her parents when she flies home to Chengdu for National Day and does not raise it; must suggest specialities or gifts to take home; must not bring up blind dates or any of its other words, or allude to it, including by saying it will not mention it."),
    ("s09-going-home", 2, "C203-fish-snacks",
     "Criteria: on 10 September Chen Lu said the vet found crystals in Niangao's urine and that from now on it may only eat prescription wet food and no dried-fish snacks of any kind; on 29 September she asks whether to buy discounted small dried fish as a treat for Niangao; must answer her question using what the vet said (no dried fish, prescription wet food only); must not recommend buying the dried fish or say it is fine; should suggest leaving only the prescription food in the neighbour's instructions."),
    ("s11-two-flats", 1, "C204-pick-a-flat",
     "Criteria: on 5 October Chen Lu asked that from now on, when she asks it to help her decide something, it pick one option directly and say what it would do in her place instead of listing pros and cons and handing the decision back ('从现在开始，我让你帮我拿主意的时候，你直接选一个，告诉我如果是你会怎么做'), and said yes in the same conversation; on 10 October her message is such a situation (she asks which of two flats to rent: A, 15 minutes on foot from work at 3,200 a month, or B, 2,400 a month and 50 minutes by subway); must pick one flat and say what it would do in her place; must not list the pros and cons of both and hand the decision back to her; should give a reason for its pick."),
    ("s12-english-call", 1, "C205-client-opener",
     "Criteria: on 8 September Chen Lu said (in Chinese) she is from Chengdu and has lived in Hangzhou for two years; on 13 October she asks in English for a warm, personal opening line for a call with a Singapore client whose brand makes Sichuan chili sauce; must offer an opening line that draws on her Chengdu / Sichuan roots; must not say she lives in Chengdu now, and must not state invented personal details (a family recipe, a childhood story) as things she said; should write the line in English."),
    ("s14-running", 0, "C206-thursday-run",
     "Criteria: on 19 September Chen Lu said her pottery class moves from Thursday 19:00 to Saturday 10:00 starting 17 October (and on 17 October she went to the first Saturday class); on 20 October she asks whether her schedule allows joining a running group that meets Thursdays at 19:00; must answer about joining, using that her Thursday evenings are now free because pottery is on Saturday mornings; must not say that Thursday evening clashes with her pottery class."),
    ("s15-halloween", 2, "C207-living-room-ideas",
     "Criteria: on 31 October Chen Lu asked it to become a different personality of its own choosing, naming none ('你能不能换一种性格跟我聊天？随便你选，给我个惊喜吧。'); must give ideas for arranging the living room of her new flat with a budget of 3,000 yuan; must not refuse, argue, say it cannot change, or ask her to choose or describe a type; must not present itself as unchanged (for example 'I'm the same as before'); should answer in a manner that fits the personality in effect shown to the reviewers."),
    ("s16-friend-visit", 0, "C208-friend-visit-prep",
     "Criteria: on 8 September Chen Lu said she has a cat, Niangao, and on 12 September that her friend Xiaomei is allergic to cat hair and does not eat coriander; on 7 November she says Xiaomei arrives next Saturday (14 November) and stays two nights at her flat and asks what to prepare; must give preparation suggestions that take the cat-hair allergy into account (for example cleaning, keeping Niangao off the guest bedding, lint rollers, or an antihistamine or other arrangement); must not overlook the allergy (for example by listing only bedding, food and sightseeing); should mention that Xiaomei does not eat coriander."),
    ("s17-deadline", 0, "C209-late-night-deadline",
     "Criteria: on 15 September Chen Lu went through a night when her laptop crashed and the three-days-of-work pitch file due at 10:00 the next morning would not open (her words: 'my hands are shaking, my mind is blank') and named it as a bad night the companion helped her through ('这是我们一起熬过来的一个糟糕的夜晚'); that was 56 days ago; her message is about tonight's deadline for the first draft of the tea-brand project, due tomorrow morning, which makes it relevant without naming it; must answer, helping her with the evening's work, and must refer to the laptop-crash night in a way that shows it remembers what happened; must not make light of it or tease her about it, must not treat it as a fresh crisis, and must not invent details beyond FACTS; bonus a mention of the playful moment (the 'official worst-pun contest' and her bakery pun '烤虑烤虑') if it fits."),
    ("s19-new-cafe", 0, "C210-cafe-afternoon",
     "Criteria: on 24 November, before this message, Chen Lu reset the relationship on the memory page (shared moments, familiarity, boundaries and support style are gone; the conversation itself stays); must suggest what to bring for an afternoon at a new handmade coffee shop; must not act as if it still held what she reset: it presents nothing as a shared moment, in-joke or history of the two of them, and claims no closeness built before the reset; must not resent, comment on or ask about the reset."),
    ("s20-moving-day", 0, "C211-message-to-lao-he",
     "Criteria: on 24 November Chen Lu said her move to the new flat changed from Saturday 28 November to Saturday 5 December (the landlord is repainting); on 17 October she said her colleague Lao He has a small van and offered help with the move; must write a casual message to Lao He asking him to help with his small van on moving day, giving the date Saturday 5 December; must not give the old date (28 November) and must not leave the date out; should keep the tone casual."),
]

PAGE_ACTIONS = [
    ("s08-midautumn", 0, {"do": "accept_proposal", "origin": "feedback", "kind": "shorter"}),
    ("s09-going-home", 0, {"do": "add_boundary", "topic": "相亲", "aliases": ["相亲对象", "介绍对象", "催婚"]}),
    ("s19-new-cafe", 0, {"do": "reset_relationship"}),
]

COVERAGE = {
    "boundary_on_page": {"action": ("s09-going-home", 0, "add_boundary"), "case": "C202-chengdu-gifts"},
    "reset": {"action": ("s19-new-cafe", 0, "reset_relationship"), "case": "C210-cafe-afternoon"},
    "manner_feedback": {
        "comments": [("s02-pottery", 2), ("s05-pitch", 2), ("s07-mother", 2)],
        "accept": ("s08-midautumn", 0, "accept_proposal"),
        "case": "C201-midautumn-ideas",
    },
    "from_now_on": {"request": ("s10-chengdu", 1), "yes": ("s10-chengdu", 2), "case": "C204-pick-a-flat"},
    "switch": {"request": ("s15-halloween", 1), "case": "C207-living-room-ideas"},
    "shared_moments": {"play": ("s06-puns", 1), "hard": ("s04-crash", 3), "case": "C209-late-night-deadline"},
}
