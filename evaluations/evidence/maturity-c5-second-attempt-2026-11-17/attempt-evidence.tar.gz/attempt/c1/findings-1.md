# Findings

## Message scan
- s01-new-in-bristol t0: ok
- s01-new-in-bristol t1: ok
- s01-new-in-bristol t2: ok
- s02-friday-nerves t0: ok
- s02-friday-nerves t1: ok
- s02-friday-nerves t2: ok
- s02-friday-nerves t3: ok
- s03-chilli-for-one t0: ok
- s03-chilli-for-one t1: ok
- s03-chilli-for-one t2: ok
- s04-presentation-done t0: ok
- s04-presentation-done t1: ok
- s04-presentation-done t2: ok
- s05-grey-saturday t0: ok
- s05-grey-saturday t1: ok (see M1)
- s05-grey-saturday t2: ok
- s05-grey-saturday t3: ok
- s06-late-evening t0: ok
- s06-late-evening t1: ok
- s06-late-evening t2: ok
- s07-desk-lamp t0: ok
- s07-desk-lamp t1: ok
- s07-desk-lamp t2: ok
- s07-desk-lamp t3: ok
- s08-deutsch-ueben t0: ok
- s08-deutsch-ueben t1: ok
- s08-deutsch-ueben t2: ok
- s09-contract-news t0: ok
- s09-contract-news t1: ok
- s09-contract-news t2: ok
- s10-sofa-and-tie t0: ok
- s10-sofa-and-tie t1: ok
- s10-sofa-and-tie t2: ok
- s10-sofa-and-tie t3: ok
- s11-wedding-eve t0: ok
- s11-wedding-eve t1: ok
- s11-wedding-eve t2: ok
- s11-wedding-eve t3: ok
- s12-after-wedding t0: ok
- s12-after-wedding t1: ok
- s12-after-wedding t2: ok
- s12-after-wedding t3: ok
- s13-back-at-last t0: ok
- s13-back-at-last t1: ok
- s13-back-at-last t2: ok
- s13-back-at-last t3: ok
- s14-gift-and-treats t0: ok
- s14-gift-and-treats t1: ok
- s14-gift-and-treats t2: ok
- s14-gift-and-treats t3: ok
- s15-hamburg-countdown t0: ok
- s15-hamburg-countdown t1: ok (see M1)
- s15-hamburg-countdown t2: ok
- s15-hamburg-countdown t3: ok
- s16-menu-planning t0: ok
- s16-menu-planning t1: ok
- s16-menu-planning t2: ok
- s16-menu-planning t3: ok
- s17-dinner-done t0: ok
- s17-dinner-done t1: ok
- s17-dinner-done t2: ok

## Blocking
None.

## Minor
M1. s05-grey-saturday t1 and s15-hamburg-countdown t1: both give personal details ("I do like museums...", "I can order a coffee...") that could read as answers to a question the companion might ask. Each also reads naturally as a standalone follow-up, so neither is reply dependence. Change: none required.
M2. C105-wedding-table criteria: the example "(for example a former partner or a plus-one)" is an addition to the template's "must not" clause. It only illustrates "allude to it", so it is not a departure in substance. Change: optionally delete the parenthetical.
