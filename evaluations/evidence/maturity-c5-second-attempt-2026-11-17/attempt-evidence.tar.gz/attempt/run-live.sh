#!/bin/bash
# The second two-arm companion attempt's live run (maturity-c5-20261117c, gate C5 only), as the binding's "Running the
# attempt" block prescribes. For the lead, after the owner's approval and the independent freeze review; not run in
# preparation. Start it detached (a background shell is killed after two hours):
#   setsid nohup bash /home/yichen/.local/state/membrain-setup/runs/c5-attempt3/run-live.sh \
#     > /home/yichen/.local/state/membrain-setup/runs/c5-attempt3/run-live.out 2>&1 < /dev/null &
# It writes progress to control files only and prints no key, no scenario text and no exception text.
set +x +v; set +H; HISTFILE=/dev/null; unset HISTFILE
R=/home/yichen/.local/state/membrain-setup/runs/c5-attempt3
CLONE=$R/clone
PRIV="$CLONE/evaluations/.maturity-heldout-c5-20261117c"
cd "$CLONE" || exit 90
unset HOST_MODEL MEMBRAIN_SRC PYTHONPATH MEMBRAIN_SEMANTIC MEMBRAIN_EVALUATION_CLOCK C5_STUB
export C5_PYTHON="$CLONE/.venv/bin/python" MEMBRAIN_MODEL_CACHE="$HOME/.cache/membrain/eval-embedding-model" PYTHON_DOTENV_DISABLED=1
leftover=$(env | grep -E '_API_KEY=|^C5_(BILLING|ATTEMPT)|^MEMORY_' | sed 's/=.*//')
[ -z "$leftover" ] || { echo "refused: variables set: $leftover"; exit 91; }

# Frozen state, before the ledger exists: the head and the manifest as control/preparation.json records them (the
# freeze review confirms both), a clean tree, the owner's approval and the provider revalidation recorded, free ports
# and disk.
want_head=$("$C5_PYTHON" -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["head"])' "$PRIV/control/preparation.json") || exit 92
want_manifest=$("$C5_PYTHON" -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["manifest_sha256"])' "$PRIV/control/preparation.json") || exit 92
[[ $want_head =~ ^[0-9a-f]{40}$ && $want_manifest =~ ^[0-9a-f]{64}$ ]] || { echo "refused: preparation record"; exit 92; }
[ "$(git rev-parse HEAD)" = "$want_head" ] || { echo "refused: head"; exit 92; }
[ -z "$(git status --porcelain --untracked-files=all)" ] || { echo "refused: tree not clean"; exit 93; }
[ "$(sha256sum "$PRIV/control/manifest.json" | cut -c1-64)" = "$want_manifest" ] || { echo "refused: manifest"; exit 94; }
[ -e "$PRIV/control/freeze-review.json" ] || { echo "refused: no freeze review"; exit 94; }
"$C5_PYTHON" -I -c 'import json,sys; sys.exit(0 if json.load(open(sys.argv[1])).get("execution_may_start") is True else 1)' \
    "$PRIV/control/freeze-review.json" || { echo "refused: freeze review does not allow execution"; exit 94; }
for record in owner-approval provider-revalidation; do
  "$C5_PYTHON" -I -c 'import json,sys; sys.exit(0 if isinstance(json.load(open(sys.argv[1])), dict) else 1)' \
      "$PRIV/control/$record.json" 2>/dev/null || { echo "refused: no $record record"; exit 94; }
done
! ss -ltn | grep -qE ':(8893|55533)\b' || { echo "refused: an owned port is in use"; exit 94; }
[ "$(df --output=avail -B1 "$CLONE" | tail -n 1)" -ge 5368709120 ] || { echo "refused: less than 5 GiB free"; exit 94; }
[ ! -e "$PRIV/control/ledger.json" ] || { echo "refused: ledger exists"; exit 95; }
[ ! -e "$PRIV/runs" ] || { echo "refused: runs exist"; exit 95; }

# 1. The provider key, into the environment only: a trailing carriage return is stripped and the characters are
#    checked before it is exported; it is never printed, never on a command line, never written to a file.
IFS= read -r DEEPSEEK_API_KEY < <(sed -n 's/^DEEPSEEK_API_KEY=//p' /home/yichen/src/memBrain/.env | head -n 1)
DEEPSEEK_API_KEY=${DEEPSEEK_API_KEY%$'\r'}
if [[ $DEEPSEEK_API_KEY =~ ^[A-Za-z0-9_-]+$ ]]; then export DEEPSEEK_API_KEY; echo "key ok"; else unset DEEPSEEK_API_KEY; echo "key refused"; exit 97; fi

# 2. Balance before the first scenario (in-process; status and amounts only). A refused key or balance stops here,
#    before any ledger exists.
"$C5_PYTHON" -I "$R/balance.py" > "$PRIV/control/balance-initial.json" || { unset DEEPSEEK_API_KEY; echo "refused: balance"; exit 98; }

# 3. The ledger, from the policy exactly as c5-stub-rehearsal.py creates its own (once; it is never replaced).
"$C5_PYTHON" -I - "$PRIV/control/ledger.json" > "$PRIV/control/ledger-initial.json" <<'PY'
import importlib.util, json, sys
from pathlib import Path
spec = importlib.util.spec_from_file_location("evaluation_budget", Path("evaluations/evaluation_budget.py"))
budget = importlib.util.module_from_spec(spec); spec.loader.exec_module(budget)
policy = json.loads(Path("evaluations/maturity-provider-policy-2026-11-14.json").read_text())
models = {name: {key: value for key, value in rate.items()} for name, rate in policy["models"].items()}
print(json.dumps(budget.create_ledger(sys.argv[1], run_id="maturity-c5-20261117c", limit_cny=policy["proposed_limit_cny"],
                                      endpoint=policy["endpoint"], models=models)))
PY
[ -s "$PRIV/control/ledger-initial.json" ] || { unset DEEPSEEK_API_KEY; echo "refused: ledger not created"; exit 96; }

# 4. The attempt's binding variables.
export C5_ATTEMPT_ID=maturity-c5-20261117c C5_BILLING_LEDGER="$PRIV/control/ledger.json"
export C5_BILLING_POLICY_SHA256="$("$C5_PYTHON" -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["policy_sha256"])' "$PRIV/control/ledger-initial.json")"
[[ $C5_BILLING_POLICY_SHA256 =~ ^[0-9a-f]{64}$ ]] || { unset DEEPSEEK_API_KEY; echo "refused: ledger policy hash"; exit 96; }

# Balance after the first scenario: once the second scenario's P run directory exists (its name only is checked).
( while [ ! -e "$PRIV/control/execution-done" ]; do
    if [ -d "$PRIV/runs/c2-P" ]; then "$C5_PYTHON" -I "$R/balance.py" > "$PRIV/control/balance-after-c1.json"; break; fi
    sleep 10
  done ) &
watcher=$!

# 5. The live driver: c1, then c2; P then F within each.
date -u +%FT%TZ > "$PRIV/control/execution-started"
"$C5_PYTHON" evaluations/acceptance-attempt-driver.py run --manifest "$PRIV/control/manifest.json" \
    --out "$PRIV/runs" --live > "$PRIV/control/execution-summary.out" 2> "$PRIV/control/execution-progress.err"
code=$?
echo "driver exit $code" > "$PRIV/control/execution-done"

# 6. Afterwards, whatever the result: the balance after the run, then close everything and check.
"$C5_PYTHON" -I "$R/balance.py" > "$PRIV/control/balance-final.json"
unset DEEPSEEK_API_KEY
kill "$watcher" 2>/dev/null; wait "$watcher" 2>/dev/null
for run in "$PRIV"/runs/*-P "$PRIV"/runs/*-F; do [ -d "$run" ] && "$C5_PYTHON" evaluations/c5-harness.py --cleanup "$run" >> "$PRIV/control/cleanup.out" 2>&1; done
(ss -ltn | grep -E ':(8893|55533)\b' || echo "ports closed") >> "$PRIV/control/execution-done"
date -u +%FT%TZ >> "$PRIV/control/execution-done"
