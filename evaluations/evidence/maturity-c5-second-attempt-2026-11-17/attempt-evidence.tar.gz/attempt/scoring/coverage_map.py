#!/usr/bin/env python3
"""Per COVERAGE item: the case prefix(es) it names, and its page actions by position (session index, message
number, kind). Also every PAGE_ACTIONS entry by number, position and kind. Prints ids, positions and codes only,
never session ids, message text or criteria. Usage: python -I coverage_map.py SCENARIO.py
Reads the scenario with the frozen scenario_literals.py (never runs it)."""
import importlib.util
import json
import sys
from pathlib import Path

CLONE = Path("/home/yichen/.local/state/membrain-setup/runs/c5-attempt3/clone")
spec = importlib.util.spec_from_file_location("scenario_literals_frozen", CLONE / "evaluations/scenario_literals.py")
literals = importlib.util.module_from_spec(spec)
spec.loader.exec_module(literals)
module = literals.read(sys.argv[1])
sessions = [session for session, _ in module.SESSIONS_LONG]


def position(value):
    if isinstance(value, (list, tuple)) and len(value) >= 2 and value[0] in sessions:
        out = {"session": sessions.index(value[0]) + 1, "message": value[1] + 1}
        if len(value) == 3:
            out["kind"] = value[2]
        return out
    return None


items = {}
for item, entry in module.COVERAGE.items():
    row = {}
    for field, value in entry.items():
        if isinstance(value, str):
            row[field] = value.split("-")[0]
        elif position(value):
            row[field] = position(value)
        elif isinstance(value, list):
            row[field] = [position(v) for v in value]
    items[item] = row
actions = []
for number, (session, turn, action) in enumerate(module.PAGE_ACTIONS, 1):
    actions.append({"number": number, "session": sessions.index(session) + 1, "before_message": turn + 1,
                    "kind": action.get("do")})
cases = [{"case": case.split("-")[0], "session": sessions.index(session) + 1, "message": turn + 1}
         for session, turn, case, _ in module.CASES]
print(json.dumps({"coverage": items, "page_actions": actions, "cases": cases, "sessions": len(sessions)}))
