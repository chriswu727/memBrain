import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess

root = Path(__file__).parent
previous = Path('/Users/yichen/tmp/membrain-month-precision-delivery-20261107')
retained_models = Path('/Users/yichen/tmp/membrain-semantic-scale-20261107/installation/models')
report = json.loads((previous / 'installed-and-ports.json').read_text())
assert report['completed'] and len(report['profiles']) == 4
assert json.loads((previous / 'install-run-meta.json').read_text())['exit_code'] == 0

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(data)
    return h.hexdigest()

processes = subprocess.check_output(['ps', '-axo', 'pid=,command='], text=True).splitlines()
targets = []
models = []
archives = []
for item in report['profiles']:
    profile = Path(item['directory'])
    assert profile.is_relative_to(previous / 'install-final') and not profile.is_symlink()
    for port in item['ports'].values():
        with socket.socket() as connection:
            connection.settimeout(1)
            assert connection.connect_ex(('127.0.0.1', port['port'])) != 0
    for line in processes:
        pid, command = line.strip().split(None, 1)
        executable = Path(command.split(' ', 1)[0]).name
        if int(pid) not in (os.getpid(), os.getppid()) and executable.startswith(('python', 'postgres')):
            assert str(profile) not in command, 'A retired test profile is still active'
    for p in (profile / 'models').rglob('*'):
        if p.is_file():
            retained = retained_models / p.relative_to(profile / 'models')
            assert retained.is_file() and digest(p) == digest(retained)
            models.append({'removed_copy': str(p), 'retained_copy': str(retained), 'sha256': digest(retained)})
    for p in profile.rglob('cluster.zip'):
        archives.append({'path': str(p), 'sha256': digest(p)})
    for name in ('postgres', 'models', 'native-engines'):
        path = profile / name
        assert path.is_dir() and not path.is_symlink()
        targets.append(path)
assert len(models) == 8 and len(archives) == 4
before = shutil.disk_usage(root).free
allocated = sum(int(subprocess.check_output(['du', '-sk', str(p)], text=True).split()[0]) * 1024 for p in targets)
for path in targets:
    shutil.rmtree(path)
for archive in archives:
    assert digest(Path(archive['path'])) == archive['sha256']
for model in models:
    assert digest(Path(model['retained_copy'])) == model['sha256']
result = {'removed_generated_directories': [str(p) for p in targets],
          'allocated_bytes_removed': allocated, 'available_bytes_before': before,
          'available_bytes_after': shutil.disk_usage(root).free, 'identical_model_copies': models,
          'preserved_archives': archives, 'completed': True,
          'note': 'Retired synthetic profiles must not be restarted; metadata/logs, installed packages, shared model/download caches and private archives remain.'}
(root / 'retired-tests-cleanup.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('allocated_bytes_removed', 'available_bytes_before', 'available_bytes_after', 'completed')}))
