import hashlib,json,os,shutil,socket,subprocess
from pathlib import Path
from membrain.local_profile import load_profile
root=Path(__file__).parent
canonical=Path('/Users/yichen/tmp/membrain-semantic-scale-20261107/installation/models')
repeat=root/'installation-repeat'
assert json.loads((repeat/'install-run-meta.json').read_text())['exit_code']==0
assert json.loads((root/'public-practice-validity.json').read_text())['valid']
profiles=[]
for base in (root,repeat):
 report=json.loads((base/'installed-and-ports.json').read_text());assert report['completed']
 profiles.extend(Path(i['directory']) for i in report['profiles'])
for arm in 'PE':profiles.extend(p.parent for p in (root/'public-practice'/f'practice-{arm}').glob('brain-*/profile.json'))
assert len(profiles)==10
processes=subprocess.check_output(['ps','-axo','pid=,command='],text=True).splitlines()
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
targets=[];copies=[];archives=[];partials=[]
for p in profiles:
 assert p.is_relative_to(root) and not p.is_symlink()
 profile=load_profile(p)
 for port in (profile.api_port,profile.database_port):
  with socket.socket() as s:s.settimeout(1);assert s.connect_ex(('127.0.0.1',port))!=0
 for line in processes:
  pid,command=line.strip().split(None,1)
  if int(pid) not in (os.getpid(),os.getppid()):assert str(p) not in command
 for f in (p/'models').rglob('*'):
  if f.is_file():
   retained=canonical/f.relative_to(p/'models')
   if f.name.endswith('.partial'):
    retained=retained.with_suffix('')
    assert retained.is_file() and f.stat().st_size < retained.stat().st_size
    with retained.open('rb') as stream:assert f.read_bytes()==stream.read(f.stat().st_size)
    partials.append({'removed_partial_download':str(f),'retained_complete_file':str(retained),'bytes':f.stat().st_size})
   else:
    assert retained.is_file() and digest(f)==digest(retained)
    copies.append({'removed_copy':str(f),'retained_copy':str(retained),'sha256':digest(retained)})
 for f in p.rglob('cluster.zip'):archives.append({'path':str(f),'sha256':digest(f)})
 for name in ('postgres','models','native-engines'):
  target=p/name
  if target.exists():assert target.is_dir() and not target.is_symlink();targets.append(target)
assert len(archives)==10 and len(copies)==15 and len(partials)==1
receipt={'completed':False,'removed_generated_directories':[str(p) for p in targets],'preserved_private_archives':archives,'identical_model_copies':copies,'verified_partial_downloads':partials,'available_bytes_before':shutil.disk_usage(root).free,'allocated_bytes_removed':sum(int(subprocess.check_output(['du','-sk',str(p)],text=True).split()[0])*1024 for p in targets),'note':'All ten completed/interrupted synthetic profiles are retired and must not be restarted. Installed packages, metadata, logs and private archives remain; canonical models and download caches remain.'}
path=root/'completed-profiles-cleanup.json';path.write_text(json.dumps(receipt,indent=2)+'\n')
for p in targets:shutil.rmtree(p)
assert all(digest(Path(i['path']))==i['sha256'] for i in archives)
assert all(digest(Path(i['retained_copy']))==i['sha256'] for i in copies)
receipt.update(completed=True,available_bytes_after=shutil.disk_usage(root).free)
path.write_text(json.dumps(receipt,indent=2)+'\n')
print({k:receipt[k] for k in ('completed','allocated_bytes_removed','available_bytes_before','available_bytes_after')})
