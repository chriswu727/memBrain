from pathlib import Path
import hashlib,json,os,shutil,socket,subprocess
from membrain.local_profile import load_profile
root=Path(__file__).parent
base=Path('/Users/yichen/tmp/membrain-xml-integration-20261105/performance')
p=base/'perf-recall-cache-installation'; target=p/'postgres'
m=json.loads((base/'canonical-command.json').read_text())
assert m['exit_code']==0 and m['source_unchanged'] and m['both_ports_closed']
assert '--bulk-to' in m['command'] and str(p) in m['command']
assert target.is_dir() and not target.is_symlink() and not (target/'postmaster.pid').exists()
profile=load_profile(p)
for port in (profile.api_port,profile.database_port):
 with socket.socket() as s:
  s.settimeout(1);assert s.connect_ex(('127.0.0.1',port))!=0
for line in subprocess.check_output(['ps','-axo','pid=,command='],text=True).splitlines():
 pid,cmd=line.strip().split(None,1)
 if int(pid) not in (os.getpid(),os.getppid()):assert str(p) not in cmd
preserved={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*.zip')}
assert len(preserved)==1
before=shutil.disk_usage(root).free
size=int(subprocess.check_output(['du','-sk',str(target)],text=True).split()[0])*1024
receipt={'target':str(target),'allocated_bytes':size,'available_before':before,'preserved_private_archives':preserved,'reason':'Retired generated benchmark database; raw metrics, logs, seed runners, metadata and snapshot are retained. Newer isolated qualifications supersede this database. Do not restart this retired profile.','completed':False}
receipt_path=root/'retired-synthetic-benchmark.json';receipt_path.write_text(json.dumps(receipt,indent=2)+'\n')
shutil.rmtree(target)
assert all(hashlib.sha256(Path(f).read_bytes()).hexdigest()==h for f,h in preserved.items())
receipt.update(completed=True,available_after=shutil.disk_usage(root).free)
receipt_path.write_text(json.dumps(receipt,indent=2)+'\n')
print({k:receipt[k] for k in ('allocated_bytes','available_before','available_after','completed')})
