import gzip,hashlib,json
from pathlib import Path
root=Path(__file__).parent
repo=Path('/Users/yichen/tmp/membrain-ui-code-atomicity-20261107')
target=repo/'evaluations/evidence/maturity-acceptance-preparation-2026-11-07'
files=[p for p in root.iterdir() if p.is_file() and p.suffix in {'.py','.json','.log'} and not p.name.startswith('pr43-')]
files+=[root/'install-final/results.json']
repeat=root/'installation-repeat'
files += [p for p in repeat.iterdir() if p.is_file() and p.suffix in {'.py','.json','.log'}]
files += [repeat/'install-final/results.json']
for arm in 'PEF':
 files += [p for p in (root/'public-practice'/f'practice-{arm}').iterdir() if p.is_file() and p.suffix in {'.json','.jsonl','.log'}]
profiles=[]
for base in (root,repeat):profiles.extend(Path(i['directory'])/'profile.json' for i in json.loads((base/'installed-and-ports.json').read_text())['profiles'])
for arm in 'PE':profiles.extend((root/'public-practice'/f'practice-{arm}').glob('brain-*/profile.json'))
assert len(profiles)==10
secrets=set()
for p in profiles:
 d=json.loads(p.read_text())
 for k in ('api_key','admin_password','app_password'):
  assert isinstance(d[k],str) and len(d[k])>16;secrets.add(d[k].encode())
assert len(secrets)>=18
manifest={'source_head':'25cfbcce0256fc8520c6d6186be119e52517a9de','runtime_pin':'4115e90c24eb1eb09857624a01db8bd3b22bfe50','build_id':'09051895b947ff192b1c277af3ca5fc2f5ac7f3d3021be66cb751201cf8f57b8','scope':'Public synthetic evidence only. Profiles, database contents, private archives and credentials excluded. Interrupted installation retained as incomplete; fresh repeat passes. No paid or subscription-backed evaluation.','files':[],'privacy':{'synthetic_profiles_checked':len(profiles),'known_credential_values_checked':len(secrets),'all_absent':True}}
for path in sorted(set(files)):
 data=path.read_bytes();assert not any(s in data for s in secrets),f'Credential present in {path.name}; do not publish'
 name=path.relative_to(root).as_posix()+'.gz';out=target/name;out.parent.mkdir(parents=True,exist_ok=True)
 packed=gzip.compress(data,mtime=0);out.write_bytes(packed)
 assert gzip.decompress(out.read_bytes())==data
 manifest['files'].append({'path':name,'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'original_sha256':hashlib.sha256(data).hexdigest()})
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print({'payloads':len(manifest['files']),'privacy':manifest['privacy']})
