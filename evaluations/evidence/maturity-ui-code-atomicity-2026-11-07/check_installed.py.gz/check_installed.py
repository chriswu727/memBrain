import hashlib
import json
from pathlib import Path
import membrain
from membrain.build_identity import BUILD_ID, SCHEMA_ID, manifest_digest, package_manifest
root=Path(__file__).parent
repo=Path('/Users/yichen/tmp/membrain-ui-code-atomicity-20261107')
package=Path(membrain.__file__).parent
assert package.is_relative_to(root/'installed-env'), package
source=package_manifest(repo/'src/membrain',repo)
installed=package_manifest(package,package.parents[1])
assert source == installed
assert BUILD_ID == manifest_digest(source)
wheel=next((root/'wheels').glob('*.whl'))
result={'package':str(package),'build_id':BUILD_ID,'schema_id':SCHEMA_ID,
        'runtime_files_equal':len(source),'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),
        'wheel_bytes':wheel.stat().st_size,'completed':True,
        'scope':'Isolated wheel installation with existing unchanged test dependencies; not a fresh dependency installation.'}
(root/'installed-parity.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
