import gzip
import hashlib
import json
from pathlib import Path

root = Path(__file__).parent
repo = Path('/Users/yichen/tmp/membrain-ui-code-atomicity-20261107')
previous = Path('/Users/yichen/tmp/membrain-month-precision-20261107')
target = repo / 'evaluations/evidence/maturity-ui-code-atomicity-2026-11-07'
from membrain.build_identity import package_manifest

before = package_manifest(previous / 'src/membrain', previous)
after = package_manifest(repo / 'src/membrain', repo)
changed = sorted(name for name in before.keys() | after.keys() if before.get(name) != after.get(name))
assert changed == ['host.py'], changed
(root / 'runtime-scope.json').write_text(json.dumps({
    'previous_runtime': 'f5e265c262b66e0c4f3ddb58a079c6fa14e625a4',
    'runtime': '4115e90c24eb1eb09857624a01db8bd3b22bfe50',
    'changed_runtime_inputs': changed, 'unchanged_runtime_inputs': len(after) - len(changed),
    'recall_schema_native_and_visual_inputs_unchanged': True,
}, indent=2) + '\n')
files = [p for p in root.iterdir() if p.is_file() and p.suffix in {'.py', '.json', '.log'}
         and not p.name.startswith('pr43-')]
for directory in ('ci', 'integration-ci'):
    files.extend(p for p in (root / directory).rglob('*') if p.is_file()
                 and p.suffix in {'.py', '.json', '.log'} and not p.name.endswith('-collection.log'))
identity = json.loads((root / 'installed-parity.json').read_text())
manifest = {'build_id': identity['build_id'], 'schema_id': identity['schema_id'],
            'status': 'Local source, installed, five-platform native and full integration Verify passed. Earlier source CI execution-limit cancellation retained. Not R4/C5 acceptance.', 'files': []}
integration = json.loads((root / 'integration-ci/verify-status-final.json').read_text())
assert integration['conclusion'] == 'success' and integration['headSha'] == 'ee564c5d75fcee5db0f8d6eee73e0e41a49e0ff1'
manifest['integration_verify'] = {'run': 42380382170, 'head': integration['headSha'], 'conclusion': 'success',
                                  'python_passed': 7838, 'python_warnings': 3, 'python_skipped': 0,
                                  'typescript_passed': 53, 'typescript_skipped': 0,
                                  'ruff_typecheck_build': 'passed'}
source_ci = json.loads((root / 'ci/verify-status-final.json').read_text())
assert source_ci['conclusion'] == 'cancelled'
assert source_ci['headSha'] == 'fdbc80a6bff27ca1ab57c190466021445021651e'
manifest['source_verify'] = {'run': 42378912858, 'head': source_ci['headSha'], 'conclusion': 'cancelled',
                             'python_passed': 7838, 'python_warnings': 3, 'python_skipped': 0,
                             'typescript_and_build': 'skipped', 'reason': '45-minute job execution limit'}
native = json.loads((root / 'integration-ci/native-status-final.json').read_text())
stages = json.loads((root / 'integration-ci/native-stage-audit.json').read_text())
assert native['conclusion'] == 'success' and native['headSha'] == stages['head']
assert stages['completed'] is True and len(stages['checks']) == 47
manifest['native'] = {'run': stages['run'], 'head': stages['head'], 'platforms': 5,
                      'unique_summaries': 47, 'linux_version': 'Ubuntu 22.04.5', 'conclusion': 'success'}
for path in sorted(files):
    data = path.read_bytes()
    name = path.relative_to(root).as_posix() + '.gz'
    output = target / name
    output.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(data, mtime=0)
    output.write_bytes(packed)
    assert gzip.decompress(output.read_bytes()) == data
    manifest['files'].append({'path': name, 'bytes': len(packed),
                              'sha256': hashlib.sha256(packed).hexdigest(),
                              'original_sha256': hashlib.sha256(data).hexdigest()})
manifest['scope'] = 'Synthetic test output, packaging checks and scripts only; no profiles or live credentials read.'
(target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'payloads': len(files), 'changed_runtime_inputs': changed}))
