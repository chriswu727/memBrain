import gzip
import hashlib
import json
from pathlib import Path

root = Path(__file__).parent
repo = Path('/Users/yichen/tmp/membrain-ui-code-atomicity-20261107')
previous = Path('/Users/yichen/tmp/membrain-month-precision-20261107')
target = repo / 'evaluations/evidence/maturity-ui-code-atomicity-2026-11-07'
from membrain.build_identity import package_manifest

before = package_manifest(previous / 'src/membrain', previous)
after = package_manifest(repo / 'src/membrain', repo)
changed = sorted(name for name in before.keys() | after.keys() if before.get(name) != after.get(name))
assert changed == ['host.py'], changed
(root / 'runtime-scope.json').write_text(json.dumps({
    'previous_runtime': 'f5e265c262b66e0c4f3ddb58a079c6fa14e625a4',
    'runtime': '4115e90c24eb1eb09857624a01db8bd3b22bfe50',
    'changed_runtime_inputs': changed, 'unchanged_runtime_inputs': len(after) - len(changed),
    'recall_schema_native_and_visual_inputs_unchanged': True,
}, indent=2) + '\n')
files = [p for p in root.iterdir() if p.is_file() and p.suffix in {'.py', '.json', '.log'}]
files.extend(p for p in (root / 'ci').rglob('*') if p.is_file()
             and p.suffix in {'.py', '.json', '.log'} and p.name != 'verify-collection.log')
identity = json.loads((root / 'installed-parity.json').read_text())
manifest = {'build_id': identity['build_id'], 'schema_id': identity['schema_id'],
            'status': 'Source and installed sign-in qualification passed; full Verify pending.', 'files': []}
for path in sorted(files):
    data = path.read_bytes()
    name = path.relative_to(root).as_posix() + '.gz'
    output = target / name
    output.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(data, mtime=0)
    output.write_bytes(packed)
    assert gzip.decompress(output.read_bytes()) == data
    manifest['files'].append({'path': name, 'bytes': len(packed),
                              'sha256': hashlib.sha256(packed).hexdigest(),
                              'original_sha256': hashlib.sha256(data).hexdigest()})
manifest['scope'] = 'Synthetic test output, packaging checks and scripts only; no profiles or live credentials read.'
(target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'payloads': len(files), 'changed_runtime_inputs': changed}))
