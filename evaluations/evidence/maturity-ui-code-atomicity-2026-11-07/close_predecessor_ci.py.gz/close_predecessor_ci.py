import gzip
import hashlib
import json
from pathlib import Path

repo = Path('/Users/yichen/tmp/membrain-ui-code-atomicity-20261107')
secrets = set()
for name in ('membrain-semantic-balance-1000-20261107', 'membrain-semantic-scale-20261107'):
    profile = json.loads((Path('/Users/yichen/tmp') / name / 'installation/profile.json').read_text())
    secrets.update(profile[key].encode() for key in ('api_key', 'admin_password', 'app_password') if profile.get(key))

for name, checks, run, head, count in (
    ('maturity-month-precision-2026-11-07', 'membrain-month-precision-checks-20261107',
     '42376625930', '4dc274c995d15223f904277389f2b52975964bee', 7834),
    ('maturity-persona-revision-2026-11-07', 'membrain-persona-revision-checks-20261107',
     '42375927924', '0e9fb042a1206b8307b5eca93f1430244bd52e91', 7820),
):
    source = Path('/Users/yichen/tmp') / checks / 'ci'
    target = repo / 'evaluations/evidence' / name
    status = json.loads((source / 'verify-status-final.json').read_text())
    receipt = json.loads((source / 'verify-log-receipt.json').read_text())
    assert status['status'] == 'completed' and status['conclusion'] == 'success'
    assert status['headSha'] == head and receipt['head'] == head and receipt['run'] == run
    for row in receipt['files']:
        assert hashlib.sha256((source / row['path']).read_bytes()).hexdigest() == row['sha256']
    raw = (source / 'verify-pytest.log').read_text()
    assert f'collected {count} items' in raw and f'{count} passed, 3 warnings' in raw
    manifest = json.loads((target / 'manifest.json').read_text())
    entries = {entry['path']: entry for entry in manifest['files']}
    for filename in ('verify-pytest.log', 'verify-complete.log', 'verify-status-final.json', 'verify-log-receipt.json'):
        data = (source / filename).read_bytes()
        name = 'ci/' + filename + '.gz'
        packed = gzip.compress(data, mtime=0)
        (target / name).write_bytes(packed)
        entries[name] = {'path': name, 'bytes': len(packed), 'sha256': hashlib.sha256(packed).hexdigest(),
                         'original_bytes': len(data), 'original_sha256': hashlib.sha256(data).hexdigest()}
    for entry in entries.values():
        packed = (target / entry['path']).read_bytes()
        data = gzip.decompress(packed)
        assert hashlib.sha256(packed).hexdigest() == entry['sha256']
        assert hashlib.sha256(data).hexdigest() == entry['original_sha256']
        assert not any(value in data for value in secrets), entry['path']
    manifest['files'] = sorted(entries.values(), key=lambda entry: entry['path'])
    manifest['status'] = 'Local source, installed and full Verify checks passed. Not R4/C5 acceptance.'
    manifest['full_verify'] = {'run': run, 'head': head, 'python_passed': count, 'python_warnings': 3,
                               'python_skipped': 0, 'typescript_passed': 53, 'typescript_skipped': 0,
                               'ruff_typecheck_build': 'passed'}
    manifest['privacy_scan'] = {'owned_credential_values': len(secrets), 'matches': 0,
                                'private_profiles_dumps_excluded': True}
    (target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'run': run, 'python_passed': count, 'payloads': len(entries), 'credential_matches': 0}))
