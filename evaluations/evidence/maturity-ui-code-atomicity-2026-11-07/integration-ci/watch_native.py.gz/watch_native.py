import json
import subprocess
import sys
from pathlib import Path
root=Path(__file__).parent
run='42380381989'
subprocess.run(['gh','run','watch',run,'--repo','chriswu727/memBrain','--interval','30','--exit-status'],check=False)
status=json.loads(subprocess.check_output(['gh','run','view',run,'--repo','chriswu727/memBrain','--json','status,conclusion,headSha,jobs']))
assert status['status']=='completed'
assert status['headSha']=='ee564c5d75fcee5db0f8d6eee73e0e41a49e0ff1'
(root/'native-status-final.json').write_text(json.dumps(status,indent=2)+'\n')
subprocess.run([sys.executable,str(root/'collect_artifacts.py')],check=True)
subprocess.run([sys.executable,str(root/'audit_artifacts.py')],check=True)
assert status['conclusion']=='success', status['conclusion']
