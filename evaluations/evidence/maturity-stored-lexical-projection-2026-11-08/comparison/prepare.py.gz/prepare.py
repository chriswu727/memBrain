from pathlib import Path
root=Path(__file__).parent
s=Path('/private/tmp/membrain-lexical-old-comparison.py').read_text()
s='\n'.join(line for line in s.splitlines() if not line.startswith(('acceptance_state =','assert acceptance_state.')))+'\n'
s=s.replace("(repo/'src').rglob('*')","(repo/'membrain').rglob('*')")
s=s.replace('ordinary baseline/candidate source environments','installed-wheel variants; baseline overrides only lexical_candidates.py with integration 268dbb3, both use migration 030 and identical physical storage')
(root/'compare_profile.py').write_text(s)
s=Path('/Users/yichen/tmp/membrain-recall-query-checks-20261107/check_parity.py').read_text()
s=s.replace('from membrain import candidates, desktop, embedded_database','from membrain import candidates, desktop, embedded_database, lexical_candidates')
s=s.replace("baseline = Path('/Users/yichen/tmp/membrain-review-20261029/src/membrain/candidates.py')","baseline = root/'baseline/membrain/lexical_candidates.py'")
s=s.replace("'membrain.candidates_baseline'","'membrain.lexical_baseline'")
s=s.replace("Path(candidates.__file__)","Path(lexical_candidates.__file__)")
s=s.replace("for module in (old, candidates):\n                            outputs.append(module.collect_candidates(conn, service, principal, copy.deepcopy(brain), copy.deepcopy(target), copy.deepcopy(query), query_embedding=embedding, access_at=access_at))","original_lexical = lexical_candidates.lexical_rows\n                        try:\n                            for function in (old.lexical_rows, original_lexical):\n                                lexical_candidates.lexical_rows = function\n                                outputs.append(candidates.collect_candidates(conn, service, principal, copy.deepcopy(brain), copy.deepcopy(target), copy.deepcopy(query), query_embedding=embedding, access_at=access_at))\n                        finally:\n                            lexical_candidates.lexical_rows = original_lexical")
(root/'check_parity.py').write_text(s)
