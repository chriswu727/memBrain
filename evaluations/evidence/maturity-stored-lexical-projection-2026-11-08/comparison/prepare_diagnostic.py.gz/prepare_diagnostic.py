from pathlib import Path
import subprocess,sys
root=Path(__file__).parent
d=root/'diagnostic';d.mkdir(exist_ok=True)
(d/'instrument.py').write_bytes(Path('/Users/yichen/tmp/membrain-recall-query-checks-20261107/instrument.py').read_bytes())
env=d/'env';subprocess.run([sys.executable,'-m','venv','--without-pip',str(env)],check=True)
site=next((env/'lib').glob('python*/site-packages'))
(site/'membrain-qualification.pth').write_text(str(root/'candidate')+'\n'+str(Path(sys.executable).parent.parent/'lib/python3.12/site-packages')+'\n'+str(d)+'\n')
(site/'sitecustomize.py').write_text('import instrument\n')
s=(root/'compare_profile.py').read_text()
s=s.replace("Path(__file__).parent/'counterbalanced'/sys.argv[1]","Path(__file__).parent/'results'/sys.argv[1]")
s=s.replace('for workers in (1,8):','for workers in (1,):')
s=s.replace('Uninstrumented ABBA comparison using','Instrumented serial diagnosis only; function/SQL wrappers add overhead and these are not performance comparison results. Using')
(d/'run.py').write_text(s)
