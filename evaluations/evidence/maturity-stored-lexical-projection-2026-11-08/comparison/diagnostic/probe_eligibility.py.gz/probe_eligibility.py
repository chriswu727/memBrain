import copy,hashlib,json,os,socket,statistics,time
from pathlib import Path
for k in list(os.environ):
    if k.startswith(('MEMORY_','MEMBRAIN_','C5_')) or k.endswith(('_API_KEY','_API_TOKEN')):del os.environ[k]
os.environ.update(PYTHON_DOTENV_DISABLED='1',MEMBRAIN_SEMANTIC='0')
import psycopg
from psycopg.rows import dict_row
from membrain import candidates,embedded_database
from membrain.client import default_budget,default_read_fence
from membrain.config import configured_service
from membrain.helpers import Principal,now
from membrain.local_profile import load_profile
from membrain.service import reading
root=Path(__file__).parent
p=load_profile(Path('/Users/yichen/tmp/membrain-semantic-scale-20261107/installation'))
cases=json.loads(Path('/Users/yichen/tmp/membrain-semantic-scale-20261107/report.json').read_text())['cases']
settings=p.settings();assert settings.cognition_base_url is None and settings.embedding_base_url is None
principal=Principal(p.tenant_id,p.principal_id)
target={'brain_ref':p.brain_id,'conversation_ref':'synthetic-query','branch_ref':'main'}
original=candidates._eligible
prefix=original(include_speech=True);suffix=original(include_speech=False).removeprefix(prefix)
assert suffix.startswith('AND ')
expression=suffix.removeprefix('AND ').replace('a.document','document')
r={'completed':False,'prototype_only':True,'production_source_changed':False,'paid_provider_calls':0,'subscription_calls':0,'protocol':'Rollback-only stored eligibility prototype. Current production runtime is unchanged. Same transaction, original eligibility expression, cached local embedding, fixed access time, twenty public queries. ABBA strict full candidate/state equality. Timings are in-process diagnostics, not HTTP acceptance.','phases':[]}
def save(): (root/'eligibility-prototype.json').write_text(json.dumps(r,indent=2)+'\n')
for port in (p.api_port,p.database_port):
    with socket.socket() as s: assert s.connect_ex(('127.0.0.1',port))!=0
try:
    embedded_database.start(p)
    with configured_service(settings) as service,psycopg.connect(p.migration_database_url,row_factory=dict_row) as conn:
        start=time.perf_counter()
        conn.execute('ALTER TABLE memory_assertions ADD COLUMN probe_non_speech boolean GENERATED ALWAYS AS ('+expression+') STORED')
        r['rewrite_seconds']=time.perf_counter()-start
        conn.execute("SELECT set_config('app.tenant_id',%s,true),set_config('app.principal_id',%s,true)",(p.tenant_id,p.principal_id))
        conn.execute('SET LOCAL ROLE memory_app')
        access_at=now();brain=service._brain(conn,principal,p.brain_id)
        embeddings=[service.embedding_provider.embed([case['query']],purpose='query') for case in cases]
        def projected(alias='a',*,current=True,include_speech=True):
            return original(alias,current=current,include_speech=True)+('' if include_speech else f'AND {alias}.probe_non_speech ')
        expected=[]
        for phase,function in [('baseline1',original),('candidate1',projected),('candidate2',projected),('baseline2',original)]:
            candidates._eligible=function;samples=[]
            for i,case in enumerate(cases):
                query={'query':case['query'],'intent':'explore','budget':default_budget(12000),'read_fence':default_read_fence(),'cue_event_ids':[],'additional_cues':[]}
                start=time.perf_counter()
                with reading():out=candidates.collect_candidates(conn,service,principal,copy.deepcopy(brain),copy.deepcopy(target),copy.deepcopy(query),query_embedding=embeddings[i],access_at=access_at)
                samples.append((time.perf_counter()-start)*1000)
                if phase=='baseline1':expected.append(out)
                else:assert out==expected[i],(phase,i)
            r['phases'].append({'phase':phase,'median_ms':statistics.median(samples),'samples_ms':samples});save()
        conn.rollback()
        assert not conn.execute("SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='memory_assertions' AND column_name='probe_non_speech'").fetchone()
        r['schema_rolled_back']=True;r['completed']=True
finally:
    candidates._eligible=original
    embedded_database.stop(p)
    r['ports_closed']={}
    for name,port in [('api',p.api_port),('database',p.database_port)]:
        with socket.socket() as s:r['ports_closed'][name]=s.connect_ex(('127.0.0.1',port))!=0
    save()
print(json.dumps({k:v if k!='phases' else [{a:b for a,b in x.items() if a!='samples_ms'} for x in v] for k,v in r.items()}))
