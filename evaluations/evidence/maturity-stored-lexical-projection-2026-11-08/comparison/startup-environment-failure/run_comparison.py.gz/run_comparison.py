import json,os,subprocess,sys
from pathlib import Path
root=Path(__file__).parent
builds=json.loads((root/'wheel-parity.json').read_text())
for name in ['baseline1','candidate1','candidate2','baseline2']:
    variant='baseline' if name.startswith('baseline') else 'candidate'
    env=dict(os.environ,PYTHONPATH=str(root/variant))
    with (root/(name+'.log')).open('x') as log:
        result=subprocess.run([sys.executable,str(root/'compare_profile.py'),name,str(root/variant),builds[variant+'_build']],env=env,stdout=log,stderr=log)
    print(json.dumps({'phase':name,'exit':result.returncode}),flush=True)
    if result.returncode:raise SystemExit(result.returncode)
