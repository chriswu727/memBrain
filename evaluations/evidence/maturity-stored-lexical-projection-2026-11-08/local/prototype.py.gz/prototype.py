import json,os,socket,statistics,time
from pathlib import Path
for key in list(os.environ):
    if key.startswith(('MEMORY_','MEMBRAIN_','C5_')) or key.endswith(('_API_KEY','_API_TOKEN')):del os.environ[key]
os.environ.update(PYTHON_DOTENV_DISABLED='1',MEMBRAIN_SEMANTIC='0')
import psycopg
from psycopg.rows import dict_row
from membrain import embedded_database
from membrain.lexical_candidates import lexical_rows
from membrain.local_profile import load_profile
root=Path('/Users/yichen/tmp/membrain-semantic-scale-20261107')
profile=load_profile(root/'installation')
for port in (profile.api_port,profile.database_port):
    with socket.socket() as s:
        assert s.connect_ex(('127.0.0.1',port))!=0,'Public benchmark profile is already in use'
cases=json.loads((root/'report.json').read_text())['cases']
params=(profile.tenant_id,profile.principal_id,profile.brain_id)
report={'completed':False,'prototype_only':True,'source_changes':False,'model_calls':0,'pairs':[]}
class Projected:
    def __init__(self,conn):self.conn=conn
    def execute(self,query,args=()):
        return self.conn.execute(query.replace("to_tsvector('simple',a.search_text)",'a.search_lexemes'),args)
def measure(conn,projected):
    values=[]
    for case in cases:
        start=time.perf_counter()
        value=lexical_rows(Projected(conn) if projected else conn,params,{},case['query'],limit=128)
        values.append((value,(time.perf_counter()-start)*1000))
    return values
try:
    embedded_database.start(profile)
    with psycopg.connect(profile.migration_database_url,row_factory=dict_row) as conn:
        before=conn.execute("SELECT pg_total_relation_size('memory_assertions') AS bytes, count(*) AS rows FROM memory_assertions").fetchone()
        assert before['rows']==10000
        conn.execute("SELECT set_config('app.tenant_id',%s,true),set_config('app.principal_id',%s,true)",params[:2])
        conn.execute('SET LOCAL ROLE memory_app')
        measure(conn,False)
        original=measure(conn,False)
        conn.execute('RESET ROLE')
        start=time.perf_counter()
        conn.execute("ALTER TABLE memory_assertions ADD COLUMN search_lexemes tsvector GENERATED ALWAYS AS (to_tsvector('simple',search_text)) STORED")
        report['projection_rewrite_seconds']=time.perf_counter()-start
        after=conn.execute("SELECT pg_total_relation_size('memory_assertions') AS bytes, sum(pg_column_size(search_lexemes)) AS projection_bytes FROM memory_assertions").fetchone()
        report['size_before']=before;report['size_after']=after
        conn.execute('SET LOCAL ROLE memory_app')
        for phase,projected in [('baseline1',False),('candidate1',True),('candidate2',True),('baseline2',False)]:
            rows=measure(conn,projected)
            assert [x[0] for x in rows]==[x[0] for x in original]
            report['pairs'].append({'phase':phase,'median_ms':statistics.median(x[1] for x in rows),'samples_ms':[x[1] for x in rows]})
        conn.rollback()
        assert not conn.execute("SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='memory_assertions' AND column_name='search_lexemes'").fetchone()
        report['schema_rolled_back']=True
    report['completed']=True
finally:
    embedded_database.stop(profile)
    report['ports_closed']={}
    for name,port in [('api',profile.api_port),('database',profile.database_port)]:
        with socket.socket() as s:report['ports_closed'][name]=s.connect_ex(('127.0.0.1',port))!=0
    Path('/private/tmp/membrain-lexical-prototype.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v if k!='pairs' else [{a:b for a,b in x.items() if a!='samples_ms'} for x in v] for k,v in report.items()}))
