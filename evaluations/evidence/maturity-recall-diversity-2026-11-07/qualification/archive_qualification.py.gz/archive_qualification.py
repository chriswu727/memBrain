import gzip
import hashlib
import json
from pathlib import Path

root = Path(__file__).parent
repo = Path("/Users/yichen/tmp/membrain-source-script-recall-20261107")
target = repo / "evaluations/evidence/maturity-recall-diversity-2026-11-07"
manifest = json.loads((target/"manifest.json").read_text())
files = [p for p in root.iterdir() if p.is_file() and p.suffix in {".py", ".json", ".log"} and p.name != "pr-body.md"]
for folder in ("visual", "ci"):
    files.extend(p for p in (root/folder).rglob("*") if p.is_file() and p.suffix in {".py", ".json", ".log", ".png", ".txt"} and p.name != "verify-collection.log")
files.append(root/"install-final/results.json")
profiles = list((root/"install-final").rglob("profile.json"))
profiles.append(Path("/Users/yichen/tmp/membrain-xml-integration-20261105/performance/perf-recall-cache-installation/profile.json"))
profiles.extend(Path('/Users/yichen/tmp') / folder / 'installation/profile.json'
                for folder in ('membrain-semantic-balance-1000-20261107', 'membrain-semantic-scale-20261107'))
secrets = set()
for profile in profiles:
    data = json.loads(profile.read_text())
    for key in ("api_key", "admin_password", "app_password"):
        if data.get(key): secrets.add(data[key].encode())
entries = {entry["path"]: entry for entry in manifest["files"]}
for path in sorted(files):
    data = path.read_bytes()
    assert not any(secret in data for secret in secrets), path.name
    name = "qualification/" + str(path.relative_to(root)) + ("" if path.suffix == ".png" else ".gz")
    payload = data if path.suffix == ".png" else gzip.compress(data, mtime=0)
    destination = target/name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(payload)
    entries[name] = {"path": name, "bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest(), "original_bytes": len(data), "original_sha256": hashlib.sha256(data).hexdigest()}
for entry in entries.values():
    payload = (target/entry["path"]).read_bytes()
    raw = gzip.decompress(payload) if entry["path"].endswith(".gz") else payload
    assert hashlib.sha256(payload).hexdigest() == entry["sha256"]
    assert hashlib.sha256(raw).hexdigest() == entry["original_sha256"]
    assert not any(secret in raw for secret in secrets), entry["path"]
manifest["files"] = list(entries.values())
manifest["status"] = "Public development, installed package and current visual/performance checks passed; full CI pending. Not R4/C5 acceptance."
manifest["qualification_privacy_scan"] = {"owned_credential_values": len(secrets), "matches": 0, "private_profiles_dumps_excluded": True}
manifest["qualification_scope"] = "Installed runtime e1c6050: 49 installation checks, 197 runtime inputs in each of two homes and 135 installed regressions pass. See reports for visual qualification and CI status; no implicit pass for pending runs. Public diagnostics are development evidence, not frozen R4/C5 acceptance. No paid/subscription evaluation."
(target/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
print({"added_or_updated":len(files), "total":len(entries), "credential_values_checked":len(secrets), "matches":0})
