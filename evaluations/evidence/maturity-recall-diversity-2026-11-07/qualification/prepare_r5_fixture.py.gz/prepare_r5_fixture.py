import hashlib
import json
import os
from pathlib import Path

import psycopg
from psycopg import sql

from membrain import desktop, embedded_database
from membrain.backup_transport import stream_process
from membrain.build_identity import BUILD_ID
from membrain.local_profile import load_profile

root = Path(__file__).parent
profile = load_profile(Path('/Users/yichen/tmp/membrain-xml-integration-20261105/performance/perf-recall-cache-installation'))
private = root / 'private-r5-corpus'
private.mkdir(mode=0o700)
assert private.stat().st_mode & 0o777 == 0o700
report = {'build_id': BUILD_ID, 'completed': False, 'snapshot_private': True,
          'purpose': 'Preserve schema027 benchmark corpus before additive028 upgrade. Hash every core table with bounded streaming, including the existing passage coverage marker; exclude only the new nullable source_han_majority projection from row hashes; retain exact counts for operational request/trace history without copying its multi-GB payloads. Private corpus dump excludes those two operational table contents and is NOT a product recovery bundle. Original operational rows remain in the benchmark database.'}


def snapshot():
    result = {}
    with psycopg.connect(profile.migration_database_url) as conn:
        conn.execute('SET TRANSACTION READ ONLY')
        tables = conn.execute("SELECT tablename FROM pg_tables WHERE schemaname='public' AND tablename LIKE 'memory_%' ORDER BY tablename").fetchall()
        for (name,) in tables:
            if name in ('memory_requests', 'memory_traces'):
                count = conn.execute(sql.SQL('SELECT count(*) FROM {}').format(sql.Identifier(name))).fetchone()[0]
                result[name] = {'rows': count, 'verification': 'count_only_operational_history'}
                print(name, count, flush=True)
                continue
            count, total = 0, 0
            with conn.cursor(name='fixture_rows') as cursor:
                cursor.itersize = 256
                cursor.execute(sql.SQL("SELECT sha256(convert_to((to_jsonb(t)-'source_han_majority')::text,'UTF8')) FROM {} t")
                               .format(sql.Identifier(name)))
                for (value,) in cursor:
                    count += 1
                    total = (total + int.from_bytes(value, 'big')) % 2**256
            result[name] = {'rows': count, 'sum_sha256': f'{total:064x}'}
            print(name, count, flush=True)
        migrations = [row[0] for row in conn.execute('SELECT name FROM memory_migrations ORDER BY name')]
    return result, migrations


assert not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
try:
    embedded_database.start(profile)
    before, migrations = snapshot()
    assert migrations[-1].startswith('027_')
    report['before'] = before
    report['migrations_before'] = migrations
    command, environment = embedded_database.client_command(profile, 'pg_dump', '--username=postgres',
        '--dbname=agent_memory', '--no-owner', '--no-acl', '--format=custom', '--compress=6',
        '--exclude-table-data=public.memory_requests', '--exclude-table-data=public.memory_traces')
    report['dump'] = stream_process(command, environment, private / 'schema027.dump', write=True,
                                    max_bytes=512*1024**2, timeout_seconds=120)
    assert (private / 'schema027.dump').stat().st_mode & 0o777 == 0o600
    (private / 'profile.json').write_bytes((profile.directory / 'profile.json').read_bytes())
    os.chmod(private / 'profile.json', 0o600)
    (root / 'r5-fixture-upgrade.json').write_text(json.dumps(report, indent=2)+'\n')
    desktop._prepare_database(profile)
    after, migrations = snapshot()
    report['after'] = after
    report['migrations_after'] = migrations
    assert migrations[-1] == '028_source_script.sql'
    assert {key: value for key, value in before.items() if key != 'memory_migrations'} == {
        key: after[key] for key in before if key != 'memory_migrations'}
    report['completed'] = True
finally:
    embedded_database.stop(load_profile(profile.directory))
    report['all_ports_closed'] = not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
    (root / 'r5-fixture-upgrade.json').write_text(json.dumps(report, indent=2)+'\n')
    assert report['all_ports_closed']
print(json.dumps({'completed': report['completed'], 'core_tables_hashed': len(before)-3, 'operational_tables_counted': 2,
                  'dump_bytes': report['dump']['size'], 'all_ports_closed': report['all_ports_closed']}))
