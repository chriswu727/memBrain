import hashlib
import json
import tarfile
import zipfile
from email.parser import BytesParser
from pathlib import Path,PurePosixPath
from membrain.build_identity import BUILD_ID,SCHEMA_ID,_RUNTIME_SUFFIXES,package_manifest
root=Path(__file__).parent
repo=Path('/Users/yichen/tmp/membrain-month-precision-20261107')
dist=Path('/Users/yichen/tmp/membrain-month-precision-checks-20261107/wheels')
source=package_manifest(repo/'src/membrain',repo)
sdist=next(dist.glob('*.tar.gz'));wheel=next(dist.glob('*.whl'))
with tarfile.open(sdist) as archive:
 members=archive.getmembers()
 prefixes={PurePosixPath(item.name).parts[0] for item in members};assert len(prefixes)==1
 files={}
 for item in members:
  path=PurePosixPath(item.name)
  assert not path.is_absolute() and '..' not in path.parts
  assert item.isfile() or item.isdir()
  if item.isfile():files[PurePosixPath(*path.parts[1:]).as_posix()]=archive.extractfile(item).read()
 assert not any(name.startswith('evaluations/') or '.maturity-heldout' in name or name.endswith('deepseek.env') or PurePosixPath(name).name=='.env' for name in files)
 runtime={name.removeprefix('src/membrain/'):data for name,data in files.items() if name.startswith('src/membrain/') and PurePosixPath(name).suffix in _RUNTIME_SUFFIXES and '__pycache__' not in name}
 runtime={name:data for name,data in runtime.items() if not name.startswith('resources/migrations/')}
 runtime.update({'resources/'+name:data for name,data in files.items() if name.startswith('migrations/') and name.endswith('.sql')})
 runtime['resources/memory-contract.schema.json']=files['architecture/memory-contract.schema.json']
 assert runtime==source
 assert files['LICENSE']==(repo/'LICENSE').read_bytes()
 assert files['pyproject.toml']==(repo/'pyproject.toml').read_bytes()
 sdist_metadata=BytesParser().parsebytes(files['PKG-INFO'])
 aliases={name.removeprefix('src/'):data for name,data in files.items() if name.startswith('src/agent_memory/') and name.endswith('.py')}
with zipfile.ZipFile(wheel) as archive:
 names=archive.namelist()
 runtime={name.removeprefix('membrain/'):archive.read(name) for name in names if name.startswith('membrain/') and PurePosixPath(name).suffix in _RUNTIME_SUFFIXES}
 assert runtime==source
 assert {name:archive.read(name) for name in names if name.startswith('agent_memory/') and name.endswith('.py')}==aliases
 license_name=next(name for name in names if name.endswith('.dist-info/licenses/LICENSE'))
 assert archive.read(license_name)==(repo/'LICENSE').read_bytes()
 metadata=BytesParser().parsebytes(archive.read(next(name for name in names if name.endswith('.dist-info/METADATA'))))
for field in ('Name','Version','Requires-Python','License-Expression'):
 assert sdist_metadata[field]==metadata[field],field
assert metadata['License-Expression']=='MIT'
assert sdist_metadata.get_all('Requires-Dist')==metadata.get_all('Requires-Dist')
result={'build_id':BUILD_ID,'schema_id':SCHEMA_ID,'completed':True,'runtime_inputs_equal':len(source),'compatibility_alias_files_equal':len(aliases),'license':'MIT','dependency_metadata_equal':True,'sdist_excludes_evaluations_and_secret_paths':True,'artifacts':{p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (sdist,wheel)}}
(root/'distribution-parity.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
