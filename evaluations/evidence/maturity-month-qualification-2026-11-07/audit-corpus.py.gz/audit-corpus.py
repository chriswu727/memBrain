import json
import socket
import sys
from pathlib import Path
import psycopg
from psycopg import sql
import membrain
from membrain import embedded_database
from membrain.build_identity import BUILD_ID
from membrain.local_profile import load_profile
root=Path(__file__).parent
assert Path(membrain.__file__).is_relative_to(root/'install-final/uv-tools')
assert BUILD_ID == 'f000dd0c0b0a431d2ca20a7add9304acfd8f6e0da9f46395f6588496ebabb52f'
profile=load_profile(Path('/Users/yichen/tmp/membrain-xml-integration-20261105/performance/perf-recall-cache-installation'))
for port in (profile.api_port,profile.database_port):
 with socket.socket() as sock: assert sock.connect_ex(('127.0.0.1',port)) != 0
result={'build_id':BUILD_ID,'package':str(Path(membrain.__file__).parent),'tables':{}}
try:
 embedded_database.start(profile)
 with psycopg.connect(profile.migration_database_url) as conn:
  conn.execute('SET TRANSACTION READ ONLY')
  for table in ('memory_events','memory_assertions','memory_embeddings','memory_embedding_passages','memory_working_states'):
   count,total=0,0
   with conn.cursor(name='corpus_hash') as cursor:
    cursor.itersize=256
    cursor.execute(sql.SQL("SELECT sha256(convert_to(to_jsonb(t)::text,'UTF8')) FROM {} t").format(sql.Identifier(table)))
    for (value,) in cursor:
     count+=1; total=(total+int.from_bytes(value,'big'))%2**256
   result['tables'][table]={'rows':count,'sum_sha256':f'{total:064x}'}
finally:
 embedded_database.stop(profile)
 for port in (profile.api_port,profile.database_port):
  with socket.socket() as sock: assert sock.connect_ex(('127.0.0.1',port)) != 0
result['all_ports_closed']=True
(root/f'corpus-{sys.argv[1]}.json').write_text(json.dumps(result,indent=2)+'\n')
if sys.argv[1]=='after':
 before=json.loads((root/'corpus-before.json').read_text())
 assert before['tables']==result['tables']
print(json.dumps({'phase':sys.argv[1],'tables_hashed':len(result['tables']),'all_ports_closed':True}))
