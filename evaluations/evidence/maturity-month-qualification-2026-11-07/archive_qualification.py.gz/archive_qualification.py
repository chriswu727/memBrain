import gzip
import hashlib
import json
from pathlib import Path
root=Path(__file__).parent
repo=Path('/Users/yichen/tmp/membrain-month-precision-20261107')
target=repo/'evaluations/evidence/maturity-month-qualification-2026-11-07'
files=[p for p in root.iterdir() if p.is_file() and p.suffix in {'.py','.json','.log'}]
files.append(root/'install-final/results.json')
for folder in ('visual','ci','predecessor-query-ci'):
 files.extend(p for p in (root/folder).rglob('*') if p.is_file() and p.suffix in {'.py','.json','.log','.png'} and p.name!='collection.log')
profiles=list((root/'install-final').rglob('profile.json'))
profiles.append(Path('/Users/yichen/tmp/membrain-xml-integration-20261105/performance/perf-recall-cache-installation/profile.json'))
secrets=set()
for path in profiles:
 data=json.loads(path.read_text())
 for key in ('api_key','admin_password','app_password'):
  if data.get(key):secrets.add(data[key].encode())
manifest={'build_id':'f000dd0c0b0a431d2ca20a7add9304acfd8f6e0da9f46395f6588496ebabb52f',
          'runtime_pin':'f5e265c262b66e0c4f3ddb58a079c6fa14e625a4',
          'scope':'Fresh launcher installation and hardware-backed visual/performance qualification. CI conclusions are reported separately; no behavioral acceptance implied.', 'files':[]}
for path in sorted(set(files)):
 data=path.read_bytes(); name=path.relative_to(root).as_posix()
 assert not any(secret in data for secret in secrets),name
 packed=gzip.compress(data,mtime=0)
 out=target/(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(packed)
 assert gzip.decompress(out.read_bytes())==data
 manifest['files'].append({'path':name+'.gz','bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'original_bytes':len(data),'original_sha256':hashlib.sha256(data).hexdigest()})
manifest['privacy_scan']={'owned_credential_values':len(secrets),'matches':0,'private_profiles_dumps_excluded':True}
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print({'payloads':len(manifest['files']),'credential_values_scanned':len(secrets),'matches':0})
