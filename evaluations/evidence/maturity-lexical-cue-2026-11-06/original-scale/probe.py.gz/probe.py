import hashlib,json,math,os,platform,socket,statistics,time
from pathlib import Path
for key in list(os.environ):
    if key.startswith(('MEMORY_', 'MEMBRAIN_', 'C5_')) or key.endswith(('_API_KEY','_API_TOKEN')):
        del os.environ[key]
os.environ.update(MEMBRAIN_SEMANTIC='0',PYTHON_DOTENV_DISABLED='1')
from membrain import desktop,host
from membrain.build_identity import BUILD_ID
from membrain.client import MemoryClient
from membrain.helpers import uid
from membrain.local_profile import ensure_profile,load_profile

root=Path(__file__).parent
report={'runtime_pin':'5048e13090202d3dd201227429d4d4cde66bd180','build_id':BUILD_ID,'platform':platform.platform(),'model_calls':0,'completed':False,'ports_closed':False,'phases':[],
 'protocol':'Fresh public-API synthetic ingestion,100 source-linked plan notes, keyword mode. 1000 then10000 distinct labelled messages. Background indexing enabled. Structural HTTP maps at200/400 and500/1000:20 samples each, no discarded sample/retry. After indexing settles,20 evenly spread literal-label recall queries, no discarded sample/retry. Not R5, semantic quality, rendering or capacity certification.',
 'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
assert BUILD_ID=='ecf661c042ee08cade66bec70690d44324d6799ea6c9ffbe133b84d3a9a92959'
def save():
    (root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def port():
    with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
def summary(items):
    values=sorted(item['ms'] for item in items)
    return {'n':len(values),'p95_ms':values[math.ceil(.95*len(values))-1],'median_ms':statistics.median(values),'max_ms':max(values)}
def status(client):
    value=client.dashboard()['status']
    return {k:value.get(k) for k in ('durable_sequence','indexed_sequence','index_lag','pending_jobs')}
profile=None
save()
try:
    profile=ensure_profile(root/'installation',database_engine='embedded',api_port=port(),database_port=port())
    assert profile.cognition is None
    host.start(profile.directory)
    with MemoryClient(profile.base_url,profile.api_key,profile.brain_id,timeout=120) as client:
        have=0;sources=[]
        for count in (1000,10000):
            phase={'messages':count,'maps':[],'recalls':[]};report['phases'].append(phase);save()
            begin=time.perf_counter()
            for start in range(have,count,500):
                events=[{'source_event_key':f'scale-{i}','source_revision':1,'producer_ref':'scale-probe','actor_ref':'user','actor_role':'user','event_kind':'message','content':{'media_type':'text/plain','text':f'Fictional memorykey{i:06d}: Mira and Theo plan a planetarium visit on route {i%17+1}.'},'occurred_time':{'start':None,'end':None,'precision':'unknown','basis':'unknown'},'interpretation_hint':'unknown','delivery_state':'received','parent_source_event_keys':[]} for i in range(start,min(start+500,count))]
                observed=client.action('observe',{'idempotency_key':uid(),'events':events},conversation_id='synthetic-scale',branch_id='main')
                assert observed['outcome']=='completed'
                sources.extend(observed['result']['accepted_event_ids'])
            if have==0:
                for i in range(100):
                    client.write_note(f'Fictional plan {i}: visit the planetarium.',kind='plan',status='intended',source_event_ids=sources[i*5:i*5+5],sensitive=i%10==0)
            phase['ingest_seconds']=round(time.perf_counter()-begin,3);phase['before_map']=status(client);save()
            for nodes,edges in ((200,400),(500,1000)):
                group={'nodes_limit':nodes,'edges_limit':edges,'samples':[]};phase['maps'].append(group)
                for sample in range(20):
                    row={'sample':sample,'ok':False};group['samples'].append(row);began=time.perf_counter()
                    try:
                        graph=client.memory_map(max_nodes=nodes,max_edges=edges,structure=True)
                        ids={n['id'] for n in graph['nodes']}
                        assert len(ids)==len(graph['nodes']) and len(ids)<=nodes and len(graph['edges'])<=edges
                        assert all(e['source'] in ids and e['target'] in ids for e in graph['edges'])
                        row.update(ok=True,nodes=len(ids),edges=len(graph['edges']))
                    except Exception as error:
                        row.update(error_type=type(error).__name__,error=str(error)[:500]);raise
                    finally:
                        row['ms']=round((time.perf_counter()-began)*1000,3);save()
                group['summary']=summary(group['samples'])
            phase['after_map']=status(client)
            deadline=time.monotonic()+300
            while True:
                state=status(client)
                if not state.get('pending_jobs') and not state.get('index_lag'):break
                if time.monotonic()>deadline:raise RuntimeError('Indexing did not settle within300seconds')
                time.sleep(.5)
            phase['settled']=state
            for i in [round(j*(count-1)/19) for j in range(20)]:
                label=f'memorykey{i:06d}';row={'label':label,'ok':False};phase['recalls'].append(row);began=time.perf_counter()
                try:
                    context=host.recall_context(client,f'What is the visit plan associated with {label}?',current_conversation='scale-query')
                    row.update(ok=label in context,context_characters=len(context));assert row['ok'],'Expected literal source label missing'
                except Exception as error:
                    row.update(error_type=type(error).__name__,error=str(error)[:500]);raise
                finally:
                    row['ms']=round((time.perf_counter()-began)*1000,3);save()
            phase['recall_summary']=summary(phase['recalls']);have=count;save()
            print(json.dumps({'messages':count,'map_summaries':[m['summary'] for m in phase['maps']],'recall':phase['recall_summary']}),flush=True)
    report['completed']=True
except Exception as error:
    report['failure']={'type':type(error).__name__,'message':str(error)[:1000]}
finally:
    if profile:
        try:desktop.stop(profile.directory)
        except Exception as error:report['cleanup_failure']={'type':type(error).__name__,'message':str(error)[:500]}
        ports={}
        for value in (profile.api_port,profile.database_port):
            with socket.socket() as s:ports[str(value)]=s.connect_ex(('127.0.0.1',value))!=0
        report['ports']=ports;report['ports_closed']=all(ports.values())
    save()
raise SystemExit(0 if report['completed'] and report['ports_closed'] else 1)
