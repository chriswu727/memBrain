import json,os,socket
from pathlib import Path
import psycopg
from psycopg.rows import dict_row
os.environ.update(MEMBRAIN_SEMANTIC='0',PYTHON_DOTENV_DISABLED='1')
from membrain import cognition,embedded_database
from membrain.helpers import Principal
from membrain.local_profile import load_profile
from membrain.lexical_candidates import lexical_rows,LexicalScorer
from membrain.service import MemoryService,reading
from membrain.storage import Database
root=Path(__file__).parent;p=load_profile(root/'installation');db=None;result={}
try:
 embedded_database.start(p)
 with psycopg.connect(p.migration_database_url or p.database_url,row_factory=dict_row) as conn:
  ident=conn.execute('SELECT tenant_id,owner_id FROM memory_brains WHERE id=%s',(p.brain_id,)).fetchone()
 principal=Principal(ident['tenant_id'],ident['owner_id']);db=Database(p.database_url);service=MemoryService(db)
 label='memorykey000526';query=f'What is the visit plan associated with {label}?'
 with reading(),db.transaction(principal) as conn:
  brain=service._brain(conn,principal,p.brain_id);params=service._params(principal,p.brain_id)
  expected=conn.execute('SELECT id,revision,document,is_current,invalidated,deleted,suppressed FROM memory_assertions WHERE tenant_id=%s AND owner_id=%s AND brain_id=%s AND search_text LIKE %s',(*params,'%'+label+'%')).fetchall()
  rows,truncated=lexical_rows(conn,params,{},query,limit=248,include_speech=False)
  score=LexicalScorer.from_memories(query,[r['document'] for r in rows])
  result={'query':query,'query_word_terms':sorted(cognition._terms(query)[0]),'brain_indexed_sequence':brain['indexed_sequence'],'brain_durable_sequence':brain['durable_sequence'],'expected_assertions':[{k:r[k] for k in ('id','revision','is_current','invalidated','deleted','suppressed')} for r in expected],'lexical_candidates':len(rows),'truncated':truncated,'target_in_candidate_pool':any(label in r['document']['statement'] for r in rows),'expected_scores':[score(query,r['document']['statement']) for r in expected],'max_candidate_score':max((score(query,r['document']['statement']) for r in rows),default=0),'candidate_statements':[r['document']['statement'] for r in rows[:8]]}
finally:
 if db:db.close()
 embedded_database.stop(p)
 with socket.socket() as s:result['database_port_closed']=s.connect_ex(('127.0.0.1',p.database_port))!=0
 (root/'candidate-diagnosis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
