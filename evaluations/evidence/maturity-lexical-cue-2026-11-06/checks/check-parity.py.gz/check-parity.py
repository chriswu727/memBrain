import hashlib,json,subprocess
from pathlib import Path
from membrain.build_identity import BUILD_ID,SCHEMA_ID,package_manifest
repo=Path("/Users/yichen/tmp/membrain-lexical-cue-20261106");root=Path(__file__).parent
expected={k:hashlib.sha256(v).hexdigest() for k,v in package_manifest(repo/"src/membrain",repo).items()}
code="""import hashlib,json,membrain
from pathlib import Path
from membrain.build_identity import BUILD_ID,SCHEMA_ID,package_manifest
p=Path(membrain.__file__).parent
print(json.dumps({'build':BUILD_ID,'schema':SCHEMA_ID,'manifest':{k:hashlib.sha256(v).hexdigest() for k,v in package_manifest(p,p.parents[1]).items()}}))
"""
installed=json.loads(subprocess.check_output([str(root/"installed-env/bin/python"),"-c",code],text=True,cwd=root))
prior=json.loads(subprocess.check_output(["/Users/yichen/tmp/membrain-affect-window-checks-20261106/installed-env/bin/python","-c",code],text=True,cwd=root))
assert installed['manifest']==expected and installed['build']==BUILD_ID and installed['schema']==SCHEMA_ID
changed=[k for k,v in expected.items() if prior['manifest'].get(k)!=v]
assert changed==['lexical_candidates.py'],changed
report={'completed':True,'build_id':BUILD_ID,'schema_id':SCHEMA_ID,'runtime_inputs_equal':len(expected),'changed_runtime_inputs':changed}
(root/'installed-parity.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
