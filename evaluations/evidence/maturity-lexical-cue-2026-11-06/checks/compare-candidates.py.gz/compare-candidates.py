import hashlib,importlib.util,json,math,os,socket,time
from pathlib import Path
import psycopg
from psycopg.rows import dict_row
os.environ.update(MEMBRAIN_SEMANTIC="0",PYTHON_DOTENV_DISABLED="1")
from membrain import embedded_database,lexical_candidates
from membrain.build_identity import BUILD_ID
from membrain.helpers import Principal
from membrain.local_profile import load_profile
from membrain.lexical_candidates import lexical_rows
from membrain.service import MemoryService,reading
from membrain.storage import Database
root=Path(__file__).parent
spec=importlib.util.spec_from_file_location("membrain.baseline_lexical",root/"baseline-lexical.py")
baseline=importlib.util.module_from_spec(spec);spec.loader.exec_module(baseline)
p=load_profile(Path("/Users/yichen/tmp/membrain-scale-probe-20261106/installation"));db=None
result={"kind":"paired_read_only_candidate_admission", "samples":[],"model_calls":0,"build_id":BUILD_ID,"script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"baseline_implementation_sha256":hashlib.sha256((root/"baseline-lexical.py").read_bytes()).hexdigest(),"repaired_implementation_sha256":hashlib.sha256(Path(lexical_candidates.__file__).read_bytes()).hexdigest()}
try:
 embedded_database.start(p)
 with psycopg.connect(p.migration_database_url or p.database_url,row_factory=dict_row) as conn:
  ident=conn.execute("SELECT tenant_id,owner_id FROM memory_brains WHERE id=%s",(p.brain_id,)).fetchone()
 principal=Principal(ident["tenant_id"],ident["owner_id"]);db=Database(p.database_url);service=MemoryService(db)
 with reading(),db.transaction(principal) as conn:
  conn.execute("SET TRANSACTION READ ONLY")
  conn.execute("SET LOCAL statement_timeout='30s'")
  params=service._params(principal,p.brain_id)
  for j in range(20):
   label=f"memorykey{round(j*9999/19):06d}";query=f"What is the visit plan associated with {label}?"
   functions=[("baseline",baseline.lexical_rows),("repaired",lexical_rows)]
   if j%2:functions.reverse()
   for name,fn in functions:
    started=time.perf_counter();rows,truncated=fn(conn,params,{},query,limit=248,include_speech=False);elapsed=(time.perf_counter()-started)*1000
    sample={"query":query,"implementation":name,"ms":round(elapsed,3),"count":len(rows),"truncated":truncated,"target_found":any(label in r["document"]["statement"] for r in rows)}
    result["samples"].append(sample);print(json.dumps(sample),flush=True)
  for count in (16,64,128):
   query=" ".join(f"memorykey{n:06d}" for n in range(count))
   started=time.perf_counter();rows,truncated=lexical_rows(conn,params,{},query,limit=248,include_speech=False)
   result.setdefault("many_term_samples",[]).append({"terms":count,"ms":round((time.perf_counter()-started)*1000,3),"count":len(rows),"truncated":truncated})
 result["summary"]={}
 for name in ("baseline","repaired"):
  samples=[x for x in result["samples"] if x["implementation"]==name];times=sorted(x["ms"] for x in samples)
  result["summary"][name]={"count":len(samples),"found":sum(x["target_found"] for x in samples),"p95_ms":times[math.ceil(.95*len(times))-1],"max_ms":max(times)}
 result["completed"]=True
finally:
 if db:db.close()
 embedded_database.stop(p)
 with socket.socket() as s:result["database_port_closed"]=s.connect_ex(("127.0.0.1",p.database_port))!=0
 (root/"candidate-comparison.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({k:v for k,v in result.items() if k!="samples"},indent=2))
