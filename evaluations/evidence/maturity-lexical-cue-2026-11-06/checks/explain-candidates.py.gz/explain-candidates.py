import importlib.util,json,math,os,socket,time
from pathlib import Path
import psycopg
from psycopg.rows import dict_row
os.environ.update(MEMBRAIN_SEMANTIC="0",PYTHON_DOTENV_DISABLED="1")
from membrain import embedded_database
from membrain.helpers import Principal
from membrain.local_profile import load_profile
from membrain.lexical_candidates import lexical_rows
from membrain.service import MemoryService,reading
from membrain.storage import Database
root=Path(__file__).parent
spec=importlib.util.spec_from_file_location("membrain.baseline_lexical",root/"baseline-lexical.py")
baseline=importlib.util.module_from_spec(spec);spec.loader.exec_module(baseline)
p=load_profile(Path("/Users/yichen/tmp/membrain-scale-probe-20261106/installation"));db=None
result={"kind":"paired_read_only_candidate_admission", "samples":[],"model_calls":0}
try:
 embedded_database.start(p)
 with psycopg.connect(p.migration_database_url or p.database_url,row_factory=dict_row) as conn:
  ident=conn.execute("SELECT tenant_id,owner_id FROM memory_brains WHERE id=%s",(p.brain_id,)).fetchone()
 principal=Principal(ident["tenant_id"],ident["owner_id"]);db=Database(p.database_url);service=MemoryService(db)
 with reading(),db.transaction(principal) as conn:
  conn.execute("SET TRANSACTION READ ONLY")
  conn.execute("SET LOCAL statement_timeout='30s'")
  params=service._params(principal,p.brain_id)
  class Capture:
   def execute(self,sql,values):self.sql=sql;self.values=values;return self
   def fetchall(self):return []
  for name,fn in (("baseline",baseline.lexical_rows),("repaired",lexical_rows)):
   capture=Capture();fn(capture,params,{},"What is the visit plan associated with memorykey000526?",limit=248,include_speech=False)
   plan=conn.execute("EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) "+capture.sql,capture.values).fetchone()
   (root/(name+"-plan.json")).write_text(json.dumps(plan,indent=2)+"\n")
  result["completed"]=True
finally:
 if db:db.close()
 embedded_database.stop(p)
 with socket.socket() as s:result["database_port_closed"]=s.connect_ex(("127.0.0.1",p.database_port))!=0
 (root/"plan-comparison.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({k:v for k,v in result.items() if k!="samples"},indent=2))
