import hashlib,json,math,os,socket,statistics,time
from pathlib import Path
for key in list(os.environ):
 if key.startswith(("MEMORY_","MEMBRAIN_","C5_")) or key.endswith(("_API_KEY","_API_TOKEN")):del os.environ[key]
os.environ.update(MEMBRAIN_SEMANTIC="0",PYTHON_DOTENV_DISABLED="1")
from membrain import desktop,host
from membrain.build_identity import BUILD_ID
from membrain.client import MemoryClient
from membrain.local_profile import load_profile
root=Path(__file__).parent;p=load_profile(Path("/Users/yichen/tmp/membrain-scale-probe-20261106/installation"))
report={"build_id":BUILD_ID,"completed":False,"model_calls":0,"maps":[],"recalls":[],"script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"protocol":"Retained owned synthetic 10k fixture, index settled; installed HTTP recall over the same20 original targets and40 bounded structural maps; no warmup or retries. Not R5, capacity certification or semantic quality."}
assert BUILD_ID=="ae90bf94a08429e223d5522d98480aeeb8bce6082c0b64153c774ba98d7eae91"
def save():(root/"installed-scale.json").write_text(json.dumps(report,indent=2)+"\n")
def summary(items):
 v=sorted(x['ms'] for x in items);return {"n":len(v),"p95_ms":v[math.ceil(.95*len(v))-1],"median_ms":statistics.median(v),"max_ms":max(v)}
try:
 host.start(p.directory)
 with MemoryClient(p.base_url,p.api_key,p.brain_id,timeout=120) as client:
  state=client.dashboard()['status'];assert not state['index_lag'] and not state['pending_jobs']
  for j in range(20):
   label=f"memorykey{round(j*9999/19):06d}";row={"label":label,"ok":False};report['recalls'].append(row);started=time.perf_counter()
   try:
    context=host.recall_context(client,f"What is the visit plan associated with {label}?",current_conversation="scale-query")
    row.update(ok=label in context,context_characters=len(context));assert row['ok'],"Expected literal source label missing"
   finally:row['ms']=round((time.perf_counter()-started)*1000,3);save()
  report['recall_summary']=summary(report['recalls'])
  for nodes,edges in ((200,400),(500,1000)):
   group={"nodes_limit":nodes,"edges_limit":edges,"samples":[]};report['maps'].append(group)
   for j in range(20):
    started=time.perf_counter();graph=client.memory_map(max_nodes=nodes,max_edges=edges,structure=True);ids={n['id'] for n in graph['nodes']}
    assert len(ids)==len(graph['nodes']) and len(ids)<=nodes and len(graph['edges'])<=edges
    assert all(e['source'] in ids and e['target'] in ids for e in graph['edges'])
    group['samples'].append({"sample":j,"ok":True,"nodes":len(ids),"edges":len(graph['edges']),"ms":round((time.perf_counter()-started)*1000,3)});save()
   group['summary']=summary(group['samples'])
 report['completed']=True
except Exception as error:
 report['failure']={"type":type(error).__name__,"message":str(error)[:1000]}
finally:
 desktop.stop(p.directory);report['ports']={}
 for name,port in (("api",p.api_port),("database",p.database_port)):
  with socket.socket() as s:report['ports'][name]=s.connect_ex(('127.0.0.1',port))!=0
 report['ports_closed']=all(report['ports'].values());save()
print(json.dumps({k:v for k,v in report.items() if k not in ('maps','recalls')},indent=2))
raise SystemExit(0 if report['completed'] and report['ports_closed'] else 1)
