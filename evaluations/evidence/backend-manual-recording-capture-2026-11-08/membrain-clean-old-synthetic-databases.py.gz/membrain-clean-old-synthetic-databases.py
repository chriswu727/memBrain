import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

root = Path('/Users/yichen/tmp').resolve()
items = json.loads(Path('/private/tmp/membrain-old-synthetic-db-candidates.json').read_text())
receipt = {'removed': [], 'skipped': [], 'bytes_removed': 0}
destination = Path('/private/tmp/membrain-old-synthetic-db-cleanup-receipt.json')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

for item in items:
    path = Path(item['path'])
    result = Path(item['result'])
    backup = Path(item['backup'])
    assert path.resolve() == path and path.is_relative_to(root)
    assert path.relative_to(root).parts[0].startswith('membrain-')
    assert path.name == 'postgres' and (path / 'PG_VERSION').is_file()
    data = json.loads(result.read_text())
    assert data['completed'] is True and all(check['ok'] for check in data['results'])
    backups = {str(p): digest(p) for p in backup.rglob('*') if p.is_file() and not p.is_symlink()}
    assert backups
    result_hash = digest(result)
    processes = subprocess.check_output(['ps', '-axo', 'pid,command'], text=True)
    opened = subprocess.run(['lsof', '-nP', '-a', '-d', 'cwd,txt', '+D', str(path)], capture_output=True, text=True)
    if (path / 'postmaster.pid').exists() or item['profile'] in processes or opened.stdout.strip() or opened.returncode not in (0, 1):
        receipt['skipped'].append({'path': str(path), 'reason': 'Process or database marker requires further inspection.'})
        continue
    size = sum(p.stat().st_size for p in path.rglob('*') if p.is_file() and not p.is_symlink())
    shutil.rmtree(path)
    assert digest(result) == result_hash
    assert all(digest(Path(name)) == value for name, value in backups.items())
    receipt['removed'].append({**item, 'bytes': size, 'result_sha256': result_hash, 'retained_backups_sha256': backups})
    receipt['bytes_removed'] += size
    destination.write_text(json.dumps(receipt, indent=2) + '\n')
receipt['free_bytes_after'] = shutil.disk_usage(root).free
destination.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: len(value) if isinstance(value, list) else value for key, value in receipt.items()}, indent=2))
