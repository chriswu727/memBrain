def test_first(tmp_path):
    (tmp_path / "disposable.txt").write_text("synthetic")

def test_second(tmp_path):
    assert not list(tmp_path.parent.glob("test_first[0-9]*"))
