import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile

from membrain import desktop, embedded_database
from membrain.local_profile import ensure_profile, load_profile

root = Path(__file__).parent
checkout = Path('/Users/yichen/tmp/membrain-candidate-budget-20261106')
baseline = Path('/Users/yichen/tmp/membrain-mood-source-privacy-20261106')
report = {}
with tempfile.TemporaryDirectory(prefix='disposable-', dir=root) as temporary:
    directory = Path(temporary) / 'installation'
    profile = ensure_profile(directory, database_engine='embedded')
    try:
        desktop._prepare_database(profile)
        profile = load_profile(directory)
        env = {**os.environ, 'MEMORY_DATABASE_URL': profile.database_url, 'MEMBRAIN_SEMANTIC': '0',
               'PYTHON_DOTENV_DISABLED': '1'}
        phases = [
            ('before', baseline, ['tests/test_candidate_speech_budget.py']),
            ('after', checkout, ['tests/test_candidate_speech_budget.py']),
            ('affected', checkout, [
                'tests/test_candidates.py', 'tests/test_lexical_candidates.py', 'tests/test_source_candidates.py',
                'tests/test_source_passages.py', 'tests/test_source_neighborhood.py',
                'tests/test_learning_neighborhood.py', 'tests/test_belief_candidate_ranking.py',
                'tests/test_recall_speech_scope.py', 'tests/test_retrieval.py', 'tests/test_context_views.py']),
        ]
        for label, source, tests in phases:
            env['PYTHONPATH'] = str(source / 'src') + ':' + str(checkout / 'tests')
            with (root / (label + '.log')).open('w') as output:
                result = subprocess.run([sys.executable, '-m', 'pytest', '-q', *tests], cwd=checkout,
                                        env=env, stdout=output, stderr=subprocess.STDOUT)
            report[label] = result.returncode
            print(label, result.returncode, flush=True)
            if label != 'before' and result.returncode:
                break
    finally:
        embedded_database.stop(load_profile(directory))
        with socket.socket() as sock:
            sock.settimeout(1)
            report['database_stopped'] = sock.connect_ex(('127.0.0.1', profile.database_port)) != 0
        assert report['database_stopped']
report['profile_removed'] = not directory.exists()
(root / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report), flush=True)
