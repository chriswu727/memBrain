import json
import os
from pathlib import Path
import socket
import statistics
import subprocess
import sys
import tempfile
import time
import psycopg
from contextlib import contextmanager

os.environ.update(MEMBRAIN_SEMANTIC='0', PYTHON_DOTENV_DISABLED='1')
from membrain import desktop, embedded_database
from membrain.helpers import Principal, uid
from membrain.local_profile import ensure_profile, load_profile
from membrain.affect import affect_records
from membrain.build_identity import BUILD_ID
from membrain.mood import mood_state
from membrain.notes import store_note
from membrain.relationship import relationship
from membrain.service import MemoryService
from membrain.storage import Database

ROOT = Path(__file__).parent

class TimedDatabase(Database):
    @contextmanager
    def transaction(self, principal):
        with super().transaction(principal) as conn:
            conn.execute("SET LOCAL statement_timeout = '3s'")
            yield conn


def measure():
    database = TimedDatabase(os.environ['MEMORY_DATABASE_URL'])
    principal = Principal(sys.argv[2], sys.argv[3])
    brain = MemoryService(database), principal, sys.argv[4]
    results = {'runtime': {'build_id': BUILD_ID}}
    try:
        for name, reader in [('affect', affect_records), ('mood', mood_state), ('relationship', relationship)]:
            samples=[]
            outcome={}
            for index in range(1 if sys.argv[5]=='before' else 21):
                started = time.perf_counter()
                try:
                    result = reader(*brain)
                    outcome = {'completed':True}
                    if name == 'affect':
                        outcome.update(records=len(result['records']), complete=result['complete'])
                        assert outcome['records']==(0 if sys.argv[5]=='before' else 500)
                        assert outcome['complete']
                    if name == 'mood':
                        outcome['private_reason_count'] = sum('private_topic_' in x['reason'] for x in result['triggers'])
                except psycopg.errors.QueryCanceled:
                    outcome = {'completed':False, 'sqlstate':'57014', 'reason':'three_second_statement_timeout'}
                samples.append((time.perf_counter()-started)*1000)
                if not outcome['completed']: break
            outcome['first_ms']=round(samples[0],2)
            if len(samples)>1:
                ordered=sorted(samples[1:])
                outcome['warm_p95_ms']=round(ordered[int(.95*(len(ordered)-1))],2)
                outcome['warm_median_ms']=round(statistics.median(ordered),2)
            outcome['raw_ms']=samples
            results[name]=outcome
    finally:
        database.close()
    print(json.dumps(results))

if len(sys.argv)>1 and sys.argv[1]=='measure':
    measure();raise SystemExit

baseline = '/Users/yichen/tmp/membrain-episode-membership-checks-20261106/installed-env/bin/python'
report = {'scope':'first direct service reads with autovacuum disabled only on the disposable fixture event/dependency tables; 3-second per-statement deadline; not canonical/R5','model_calls':0,'fixture':{'affect':500,'completed_plans':200,'shared_moments':200,'sensitive_source_every':10,'newer_pending_inferences':501}}
with tempfile.TemporaryDirectory(prefix='companion-cold-',dir=ROOT) as tmp:
    directory=Path(tmp)/'installation';profile=ensure_profile(directory,database_engine='embedded');database=None
    try:
        desktop._prepare_database(profile);profile=load_profile(directory)
        with psycopg.connect(profile.migration_database_url or profile.database_url,autocommit=True) as admin:
            admin.execute('ALTER TABLE memory_events SET (autovacuum_enabled=false)')
            admin.execute('ALTER TABLE memory_event_dependencies SET (autovacuum_enabled=false)')
        database=Database(profile.database_url);service=MemoryService(database);principal=Principal(uid(),uid())
        ident=service.create_brain(principal,'Synthetic companion performance')['id']
        started=time.perf_counter()
        for i in range(900):
            topic=('private_topic_' if i%10==0 else 'public_topic_')+str(i)
            response=service.handle(principal,{'message_type':'request','contract_version':'1.0.0-draft','request_id':uid(),'action':'observe','target':{'brain_ref':ident,'conversation_ref':'synthetic','branch_ref':'main'},'payload':{'idempotency_key':uid(),'events':[{'source_event_key':uid(),'source_revision':1,'producer_ref':'companion-perf','actor_ref':'user','actor_role':'user','event_kind':'message','content':{'media_type':'text/plain','text':'I am glad about '+topic},'occurred_time':{'start':None,'end':None,'precision':'unknown','basis':'unknown'},'interpretation_hint':'unknown','delivery_state':'received','parent_source_event_keys':[]}]}})
            assert response['outcome']=='completed'
            source=response['result']['accepted_event_ids'][0]
            fields={'request_id':uid(),'text':topic+' was completed.','source_event_ids':[source]}
            if i<500: fields['affect']={'label':'glad','valence':1,'intensity':1,'basis':'reported','topic':topic}
            elif i<700: fields.update(kind='plan',status='done')
            else: fields.update(kind='milestone',shared=True)
            store_note(service,principal,ident,fields)
            if i%10==0:store_note(service,principal,ident,{'request_id':uid(),'text':topic+' is private.','source_event_ids':[source],'sensitive':True})
        for i in range(501):
            store_note(service,principal,ident,{'request_id':uid(),'text':f'Pending synthetic feeling {i}.',
                'source_messages':[{'producer_ref':'pending-cold-fixture','source_event_key':uid(),'source_revision':1}],
                'affect':{'label':'sad','valence':-1,'intensity':1,'basis':'inferred','topic':'pending'}})
        report['fixture_seconds']=round(time.perf_counter()-started,2)
        database.close();database=None
        env={**os.environ,'MEMORY_DATABASE_URL':profile.database_url}
        for name,python in [('before',baseline),('after',sys.executable)]:
            result=subprocess.run([python,str(Path(__file__)),'measure',principal.tenant_id,principal.principal_id,ident,name],env=env,capture_output=True,text=True)
            (ROOT/f'cold-window-{name}.log').write_text(result.stdout+result.stderr)
            result.check_returncode()
            report[name]=json.loads(result.stdout)
            print(name,'measured',flush=True)
    finally:
        if database: database.close()
        embedded_database.stop(load_profile(directory))
        with socket.socket() as sock:
            sock.settimeout(1);report['database_port_closed']=sock.connect_ex(('127.0.0.1',profile.database_port))!=0
        assert report['database_port_closed']
report['synthetic_profile_removed']=not directory.exists()
(ROOT/'cold-window.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('before','after')},indent=2))
for phase in ('before','after'):
 print(phase,json.dumps({name:{k:v for k,v in values.items() if k!='raw_ms'} for name,values in report[phase].items()}))

assert report['before']['affect']['records']==0
assert report['after']['affect']['records']==500 and report['after']['affect']['complete']
assert all(report['after'][name]['completed'] for name in ('affect','mood','relationship'))
assert report['after']['mood']['private_reason_count']==0
