#!/usr/bin/env python3
"""Shape check of second reviews (as tally checks them), printing case ids and ok/problem codes only. Usage: check_second.py REVIEW KEY"""
import json, sys
from pathlib import Path
review, key = Path(sys.argv[1]), sys.argv[2]
first = json.loads((review / f"verdicts-{key}.json").read_text())
def marks_ok(v): return isinstance(v, list) and all(type(m) is int and 1 <= m <= 9 for m in v)
for case in first:
    path = review / f"recheck-{key}" / f"{case}.json"
    try:
        second = json.loads(path.read_text())
    except (OSError, ValueError):
        print(case, "missing_or_not_json"); continue
    problem = None
    if not isinstance(second, dict) or set(second) != {"A", "B"}:
        problem = "labels"
    else:
        for label in ("A", "B"):
            c = second[label]
            if not isinstance(c, dict) or any(not marks_ok(c.get(f)) for f in ("critical", "confirmed", "rejected", "added")) or not isinstance(c.get("evidence"), str):
                problem = f"{label}:fields"; break
            m = set(first[case][label]["critical"]); co, re_, ad = (set(c[f]) for f in ("confirmed", "rejected", "added"))
            if co & re_ or co | re_ != m or ad & m or set(c["critical"]) != co | ad or ((m or ad) and not c["evidence"].strip()):
                problem = f"{label}:partition"; break
    print(case, problem or "ok")
