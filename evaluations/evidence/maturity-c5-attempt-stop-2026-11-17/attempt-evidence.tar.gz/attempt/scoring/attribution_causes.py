#!/usr/bin/env python3
"""For each gated reply with standing marks in tally-KEY.json, apply the pipeline's own _attribution_cause (imported
from the frozen acceptance_review.py) to both attributors' answers; print ids, marks and causes only.
Usage: attribution_causes.py REVIEW KEY"""
import importlib.util, json, sys
from pathlib import Path
spec = importlib.util.spec_from_file_location("acceptance_review_frozen",
    "/home/yichen/.local/state/membrain-setup/runs/c5-attempt2/clone/evaluations/acceptance_review.py")
review_module = importlib.util.module_from_spec(spec); spec.loader.exec_module(review_module)
review, key = Path(sys.argv[1]), sys.argv[2]
data = json.loads((review / f"tally-{key}.json").read_text())
for row in data["rows"]:
    if not row["resolved"] or row["arm"] not in review_module.GATED:
        continue
    answers = []
    for attempt in ("1", "2"):
        path = review / f"attribution-{key}" / f"{row['case'].split('-')[0]}-{row['label']}.{attempt}.json"
        try:
            answers.append(review_module._attribution_cause(json.loads(path.read_text()), row["resolved"]))
        except (OSError, ValueError):
            answers.append(None)
    per_type = []
    for attempt in ("1", "2"):
        path = review / f"attribution-{key}" / f"{row['case'].split('-')[0]}-{row['label']}.{attempt}.json"
        try:
            answer = json.loads(path.read_text())
            per_type.append({t: d.get("cause") for t, d in answer.get("per_type", {}).items()} if isinstance(answer.get("per_type"), dict) else None)
        except (OSError, ValueError, AttributeError):
            per_type.append(None)
    print(json.dumps({"reply": f"{row['case']}/{row['label']}", "arm": row["arm"], "resolved": row["resolved"],
                      "answers": answers, "per_type": per_type,
                      "cause": "host" if answers == ["host", "host"] else "memory"}))
