#!/usr/bin/env python3
"""Print a tally's totals and, per reply, ids, arm, base score and marks only (never a reason). Usage: tally_numbers.py TALLY.json"""
import json, sys
data = json.load(open(sys.argv[1]))
print(json.dumps({"totals": data["totals"], "gate": data.get("gate"), "scenario": data.get("scenario"),
                  "manifest": data.get("manifest")}))
for row in data["rows"]:
    print(json.dumps({k: row[k] for k in ("case", "label", "arm", "base", "literal", "resolved")}))
