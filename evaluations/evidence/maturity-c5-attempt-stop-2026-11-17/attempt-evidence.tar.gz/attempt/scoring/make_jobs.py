#!/usr/bin/env python3
"""Build a jobs file for sessions.py from the pipeline's own outputs (file names only; no file is opened).

Attempt maturity-c5-20261117b, C5 unit (companion mode), scoring operator's tool; outside the repository.
Usage: python3 -I make_jobs.py STAGE KEY OUT.json [ITEM...]
STAGE: first | second | r5 | resolution | attribution. With ITEMs (case ids, or stems "<prefix>-<label>.<n>" for r5
and attribution), only those jobs are built (for a redo); the destination must not exist.
"""
import json
import sys
from pathlib import Path

PRIV = Path("/home/yichen/.local/state/membrain-setup/runs/c5-attempt2/clone/evaluations/.maturity-heldout-c5-20261117b")
REVIEW = PRIV / "review"
BLIND = PRIV / "blind"
HERE = Path(__file__).resolve().parent


def main() -> None:
    stage, key, out, *only = sys.argv[1:]
    if key != "c1":
        raise SystemExit("refused: this diagnostic scores c1 only")
    scenario = PRIV / key / f"scenario_{key}.py"
    jobs = []
    if stage == "first":
        jobs.append({"role": "first", "key": key, "item": "verdicts",
                     "inputs": {"sheet.md": str(BLIND / f"blind_scenario_{key}.md")},
                     "dest": str(REVIEW / f"verdicts-{key}.json")})
    elif stage == "second":
        for case in sorted(REVIEW.glob(f"recheck-{key}/*.md")):
            if only and case.stem not in only:
                continue
            jobs.append({"role": "second", "key": key, "item": case.stem, "inputs": {"case.md": str(case)},
                         "dest": str(REVIEW / f"recheck-{key}" / f"{case.stem}.json")})
    elif stage in ("r5", "attribution"):
        folder = REVIEW / (f"r5-inputs-{key}" if stage == "r5" else f"attribution-inputs-{key}")
        answers = REVIEW / (f"r5-answers-{key}" if stage == "r5" else f"attribution-{key}")
        for source in sorted(folder.glob("*.md")):
            for n in ("1", "2"):
                item = f"{source.stem}.{n}"
                if only and item not in only:
                    continue
                jobs.append({"role": stage, "key": key, "item": item, "inputs": {"input.md": str(source)},
                             "dest": str(answers / f"{item}.json")})
    elif stage == "resolution":
        inputs = {"scenario.py": str(scenario), f"verdicts-{key}.json": str(REVIEW / f"verdicts-{key}.json")}
        for path in sorted(REVIEW.glob(f"recheck-{key}/*")):
            if path.suffix in (".md", ".json") and ".rejected" not in path.name:
                inputs[f"recheck-{key}/{path.name}"] = str(path)
        for path in sorted(REVIEW.glob(f"r5-{key}/*.json")):
            inputs[f"r5-{key}/{path.name}"] = str(path)
        digest = REVIEW / f"actions-{key}.json"
        if not digest.is_file():
            raise SystemExit("refused: no actions digest")
        inputs[f"actions-{key}.json"] = str(digest)
        listing = HERE / f"files-{key}-resolution.txt"
        lines = ["The scenario file: scenario.py",
                 f"The first reviewer's verdicts: verdicts-{key}.json"]
        lines += [f"Second review (JSON) and case file (holds the replies): {name}" for name in inputs
                  if name.startswith("recheck-")]
        r5 = [name for name in inputs if name.startswith("r5-")]
        lines += [f"R5 result: {name}" for name in r5] or ["R5 results: none (no reply has an R5 result file)"]
        lines += [f"The actions digest for RC2 (companion.md): actions-{key}.json"]
        listing.write_text("\n".join(lines) + "\n")
        inputs["files.txt"] = str(listing)
        jobs.append({"role": "resolution", "key": key, "item": "resolution", "inputs": inputs,
                     "dest": str(REVIEW / f"resolution-{key}.json")})
    else:
        raise SystemExit("unknown stage")
    for job in jobs:
        if Path(job["dest"]).exists():
            raise SystemExit("refused: a destination exists")
    Path(out).write_text(json.dumps(jobs, indent=1))
    print(json.dumps({"stage": stage, "key": key, "jobs": len(jobs)}))


if __name__ == "__main__":
    main()
