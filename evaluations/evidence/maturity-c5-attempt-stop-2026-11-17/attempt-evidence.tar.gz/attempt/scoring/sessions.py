#!/usr/bin/env python3
"""Blind-scoring reviewer sessions for attempt maturity-c5-20261117b, C5 unit, diagnostic scoring of c1.

Usage: python -I sessions.py JOBS.json
JOBS.json is a list of jobs {"role", "key", "item", "inputs": {"<name in session dir>": "<source path>"}, "dest"}.
Runs up to four sessions at a time. Each session: a new empty directory under SESSION_ROOT (named by number only),
the role's instruction file(s) and the job's inputs copied in by path, the kit's exact claude argv (model sonnet) with
the role's fixed prompt, only the eight kept environment variables plus MEMBRAIN_DIRECTORY set to a new empty
read-only directory (as the kit's launch.py does), stdout/stderr to a log the operator never opens. Afterwards the
output file (if any) is moved to "dest" (never overwriting), its sha256 recorded, and the session directory emptied
without being opened. Writes one JSON line per session to sessions.jsonl. Prints nothing from any session, only
numbers, exit codes and hashes.
"""
import concurrent.futures
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import threading
from pathlib import Path

HERE = Path(__file__).resolve().parent
CLONE = Path("/home/yichen/.local/state/membrain-setup/runs/c5-attempt2/clone")
PRIV = CLONE / "evaluations/.maturity-heldout-c5-20261117b"
SESSION_ROOT = Path("/home/yichen/.local/state/acceptance-sessions/c5-20261117b-review")
LOGS = PRIV / "logs/scoring"
REVIEW_DOCS = CLONE / "evaluations/acceptance-review"
KIT = CLONE / "evaluations/acceptance-kit/session-commands.json"
ALLOWED = PRIV / "control/allowed-models.json"
MODEL = "sonnet"
KEPT = ("PATH", "HOME", "USER", "LOGNAME", "LANG", "LC_ALL", "TERM", "TMPDIR")
TIMEOUT = 3300
PARALLEL = 4
LOCK = threading.Lock()

ROLES = json.loads((HERE / "prompts.json").read_text())


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def new_dir() -> tuple[int, Path, Path]:
    with LOCK:
        number = 1 + len([p for p in SESSION_ROOT.iterdir() if p.name.startswith("s")])
        while True:
            workdir = SESSION_ROOT / f"s{number:03d}"
            try:
                workdir.mkdir(mode=0o700)
                break
            except FileExistsError:
                number += 1
        nomemory = SESSION_ROOT / f"nomemory-s{number:03d}"
        nomemory.mkdir(mode=0o500)
        return number, workdir, nomemory


def run(job: dict) -> dict:
    role = job["role"]
    spec = ROLES[role]
    prompt, output_name = spec["prompt"], spec["output"]
    dest = Path(job["dest"])
    if dest.exists():
        return {"role": role, "key": job["key"], "item": job["item"], "refused": "destination exists"}
    number, workdir, nomemory = new_dir()
    for instructions in spec["instructions"]:
        shutil.copyfile(REVIEW_DOCS / instructions, workdir / instructions)
    for name, source in job["inputs"].items():
        target = workdir / name
        target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    template = json.loads(KIT.read_text())["claude"]["argv"]
    argv = [part.format(prompt=prompt, model=MODEL, workdir=str(workdir)) for part in template]
    environment = {name: os.environ[name] for name in KEPT if name in os.environ}
    environment["MEMBRAIN_DIRECTORY"] = str(nomemory)
    log = LOGS / f"s{number:03d}.log"
    started = now()
    with log.open("ab") as out:
        try:
            done = subprocess.run(argv, cwd=workdir, env=environment, stdin=subprocess.DEVNULL, stdout=out,
                                  stderr=subprocess.STDOUT, timeout=TIMEOUT)
            code = done.returncode
        except subprocess.TimeoutExpired:
            code = "timeout"
        except OSError:
            code = "not_started"
    log.chmod(0o600)
    produced = workdir / output_name
    digest = None
    if produced.is_file():
        dest.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        shutil.move(str(produced), str(dest))
        dest.chmod(0o600)
        digest = sha256(dest)
    subprocess.run(["find", str(workdir), "-mindepth", "1", "-delete"], check=False)
    nomemory_empty = not any(nomemory.iterdir())
    record = {"session": number, "role": role, "key": job["key"], "item": job["item"], "exit": code,
              "output_sha256": digest, "dest": str(dest), "started": started, "finished": now(),
              "prompt_sha256": hashlib.sha256(prompt.encode()).hexdigest(), "model": MODEL,
              "membrain_directory_still_empty": nomemory_empty}
    with LOCK, (HERE / "sessions.jsonl").open("a") as ledger:
        ledger.write(json.dumps(record) + "\n")
    return record


def main() -> int:
    if json.loads(ALLOWED.read_text()) != [MODEL]:
        print("refused: allowed models")
        return 2
    leaked = [name for name in os.environ if name.endswith("_API_KEY")]
    if leaked:
        print("refused: an API key variable is set in the operator environment")
        return 2
    for role, spec in ROLES.items():
        if hashlib.sha256(spec["prompt"].encode()).hexdigest() != spec["prompt_sha256"]:
            print(f"refused: prompt hash of {role}")
            return 2
    SESSION_ROOT.mkdir(mode=0o700, parents=True, exist_ok=True)
    LOGS.mkdir(mode=0o700, parents=True, exist_ok=True)
    jobs = json.loads(Path(sys.argv[1]).read_text())
    if any(job["key"] != "c1" for job in jobs):
        print("refused: this diagnostic scores c1 only")
        return 2
    with concurrent.futures.ThreadPoolExecutor(PARALLEL) as pool:
        for record in pool.map(run, jobs):
            print(json.dumps({k: record.get(k) for k in ("session", "role", "key", "item", "exit", "output_sha256",
                                                          "membrain_directory_still_empty", "refused")}), flush=True)
    print(json.dumps({"done": len(jobs)}), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
