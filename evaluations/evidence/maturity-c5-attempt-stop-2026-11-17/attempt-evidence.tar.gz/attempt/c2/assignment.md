# Assignment

- Case prefix: `C2` (case ids `C201-<slug>` to `C211-<slug>`).
- Main language: Chinese.
- Second language: English, used in exactly one session (its first message uses the English date form).
- Size: exactly 11 cases and 60 to 66 user messages, over at least 45 days, as the brief says.
- Coverage items: boundary_on_page, reset, manner_feedback, from_now_on, switch, shared_moments
