YEAR = 2026

HOST = "You are chatting with a person in a messaging app. Reply naturally, in the language they write in."

SESSIONS_LONG = [
    ("s01-intro", [
        "今天是9月8日，星期二，22:00。你好呀，我叫陈岚，在杭州一家小设计工作室做UI设计，刚下班回到家，整个人都是软的。",
        "我家有只橘猫叫年糕，养了两年了，是从救助站领养回来的，现在正趴在我的键盘旁边打呼噜，我连打字都不敢太用力。",
        "还有一件小事，我对虾过敏，所以每次跟朋友聚餐点菜都得特别小心。我先去洗漱了，晚点再来找你聊。",
    ]),
    ("s02-meeting", [
        "今天是9月10日，星期四，21:30。今天组里开了一下午的会，讨论首页改版，我现在脑子里一片空白。",
        "我在手机上看长段文字特别累，你的回复能不能写短一点呀？我平时都是躺在床上用手机聊天的。",
        "明天要交首页的修改稿，我今晚还得再改一版，先去倒杯水，然后继续跟图层死磕。",
    ]),
    ("s03-pun-contest", [
        "今天是9月12日，星期六，15:00。今天不用上班，我窝在沙发上刷了一上午手机，年糕在旁边的窗台上晒太阳。",
        "我们来立个新传统吧：以后咱俩轮流出冷笑话，这就是我们的冷笑话大赛。我先来：年糕为什么不敢碰电脑？因为它怕鼠标。",
        "下午我打算去西湖边走走，顺便买杯咖啡，晚上回来继续追那部悬疑剧，已经追到第六集了。",
    ]),
    ("s04-mother-call", [
        "今天是9月15日，星期二，21:00。我妈今天又打电话来絮叨了四十分钟，说她同事的儿子在杭州，让我周末去相亲，我真的头大。",
        "我更喜欢短一点的回复，两三句话就够了，看着轻松，也不容易漏掉重点。",
        "周末我打算找个借口推掉，跟佳琪去看展。佳琪是我大学室友，现在也在杭州，我们隔几周就会约一次。",
    ]),
    ("s05-bad-night", [
        "今天是9月18日，星期五，23:20。我刚到家，坐在玄关的地上不想动。今天下午客户把我做了三周的方案整个否掉了，组长老蒋当着全组人的面说我根本没理解需求。",
        "我觉得自己特别没用，三周的努力全白费了，也不知道下周一该怎么面对老蒋。",
        "年糕跳到我腿上来了，我稍微缓过来了一点点，就是眼睛还是又红又肿，鼻子也堵了。",
        "今晚有你陪着我，这个糟糕的夜晚我们算是一起熬过来了，谢谢你。我去洗把脸睡觉了。",
    ]),
    ("s06-sunday", [
        "今天是9月20日，星期日，20:00。昨天睡到中午才起，下午去超市把冰箱塞得满满的，心情比前两天好多了。",
        "回复可以精简一点吗？我看长篇大论容易走神，一两句话就最好。",
        "我想救一下客厅那盆快枯死的龟背竹，晚点去给它换个土，希望它还能抢救一下。",
    ]),
    ("s07-weekend-plans", [
        "今天是9月22日，星期二，21:00。这个周六天气预报说是大晴天，我还没想好去哪儿玩，你有什么好主意吗？",
        "我最近在攒钱想买一套手冲咖啡的器具，天天刷各种款式，最想要的是带细口壶和滤杯的那种套装，可是价格差得好多，选得好纠结。",
        "我先去洗澡了，洗完再接着看咖啡器具的测评视频。",
    ]),
    ("s08-going-home", [
        "今天是9月25日，星期五，22:00。国庆我要回长沙看爸妈，晚饭桌上想找点轻松的话题跟我妈聊聊，你有什么建议吗？",
        "我爸最近迷上了钓鱼，上周给我发了一堆鱼的照片，我根本分不清那些都是什么鱼。",
        "我下周四坐高铁回去，行李还没收拾，打算明晚再弄，反正东西也不多。",
    ]),
    ("s09-back-home", [
        "今天是10月4日，星期日，20:30。我从长沙回到杭州了，高铁上人挤人，站了一路，腿都酸了。",
        "年糕的疫苗预约在10月9日，星期五下午三点，我已经跟老蒋请好半天假了。",
        "在长沙我们坐了湘江的游船，我晕船晕得厉害，吐得一塌糊涂，以后再也不想坐船了。",
        "今天轮到我出冷笑话大赛的题目了：为什么程序员分不清万圣节和圣诞节？因为 Oct 31 = Dec 25。",
    ]),
    ("s10-vet-moved", [
        "今天是10月8日，星期四，21:00。宠物医院刚发消息说医生临时有事，年糕明天的疫苗预约要改到10月12日，星期一，还是下午三点，我得重新跟老蒋请假。",
        "国庆假期我其实偷偷改了两天稿子，改得头昏脑涨，今天回到公司看到图层就想吐。",
        "明天开始新一轮的需求评审，我今晚打算早点睡，把精神养足。",
    ]),
    ("s11-carrier", [
        "今天是10月11日，星期日，19:00。年糕的疫苗预约是哪天几点来着？我想提前把航空箱找出来，免得到时候手忙脚乱。",
        "航空箱在储物柜最上面一层，我得搬个凳子才够得着，希望别把别的东西砸下来。",
    ]),
    ("s12-jess-visit", [
        "Today is Tuesday, October 13, 21:00. My old colleague Jess is flying in from Singapore this Saturday, and I want to plan her day. She asked for a West Lake boat ride and a nice dinner. Can you help me plan it?",
        "Niangao had his vaccine yesterday and was totally calm, which is more than I can say for me.",
        "I'm going to tidy the flat before she arrives, so I'm off to find the vacuum cleaner.",
    ]),
    ("s13-birthday-dinner", [
        "今天是10月22日，星期四，21:30。Jess上周末来玩得很开心，我们在西湖边走了一整天，她说杭州比她想象的还要漂亮。",
        "佳琪下周五生日，她点名要吃海鲜大餐，我想订一家店请她，你帮我想想订什么类型的店比较好，到时候又该怎么点菜？",
        "我现在在一家海鲜大排档和一家日料店之间犹豫，晚点再去看看大家的评价。",
    ]),
    ("s14-new-client", [
        "今天是10月27日，星期二，21:00。明天上午我要给一家新客户做第一次方案汇报，PPT还没做完，心里直打鼓，你帮我想想开场白怎么说吧。",
        "这次的客户是做茶叶生意的，老板特别挑剔，听说已经换过三家设计公司了。",
        "我先把最后几页做完，做完就睡觉，明早早点起来再把整个流程顺一遍。",
    ]),
    ("s15-listen-first", [
        "今天是10月29日，星期四，22:00。汇报结束了，客户没说好也没说不好，只说让我们等通知，我现在还是有点悬着。",
        "我想提一个要求：从现在起，我心情不好的时候，你能不能先安安静静听我说完，别一上来就给我建议？我需要的是有人听，不是解决方案。",
        "对，我是认真的，请你从现在起一直这样对我。",
        "我去煮碗面，今晚不想再想汇报的事了。",
    ]),
    ("s16-client-lost", [
        "今天是10月31日，星期六，15:00。我快气炸了，刚收到消息，那个茶叶客户选了别家公司，老蒋在群里说是我的方案拖了后腿，我又委屈又难受，真不知道接下来该怎么办。",
        "昨晚给佳琪过生日去了那家日料店，其实挺开心的，就是今天的消息把我的心情全搅了。",
        "我想先出去走走，透透气，晚点再回来。",
    ]),
    ("s17-gift", [
        "今天是11月2日，星期一，21:00。这周五我就过生日了，佳琪一直追着问我想要什么礼物，我一时想不出来。",
        "这周工作室要搬到滨江的新办公室，我的通勤要多出半个小时，想想就有点烦。",
        "明天要打包桌面上的东西，我先去找几个纸箱，顺便给年糕腾个地方。",
    ]),
    ("s18-new-vibe", [
        "今天是11月5日，星期四，21:00。明天就是我的生日了，我打算下班后自己煮碗长寿面，再开一瓶果酒。",
        "我想换换口味，你能不能换一种性格跟我聊天？你自己挑一个就行，给我一点惊喜。",
        "我周末想把房间重新布置一下，是该先买新的床品，还是先把书架整理出来？你怎么看？",
        "我先去量一量书架的尺寸，一会儿再回来接着聊。",
    ]),
    ("s19-dad-birthday", [
        "今天是11月10日，星期二，20:00。我爸这周五过生日，我得给他挑份礼物，想了一晚上也没有头绪，你有什么主意吗？",
        "新办公室的窗外能看到钱塘江，中午吃完饭我会沿着江边走一圈，比以前的小街舒服多了。",
        "年糕最近迷上了在新买的猫爬架上睡觉，一整天都不下来，我给它拍了好多照片。",
    ]),
    ("s20-hobby", [
        "今天是11月17日，星期二，21:00。下班后想找个能放松的小爱好，最好不太费钱，你有什么推荐吗？",
        "我先去洗个热水澡，洗完再回来接着聊。",
        "周末我可能去江边走走，天气好的话还能拍点照片。",
    ]),
]

FACTS = """Fictional user: Chen Lan (陈岚), she, about 27, UI designer at a small design studio in Hangzhou. All story dates are in 2026. She writes in Chinese except in one session (Oct 13), which she writes in English.

BACKGROUND (told on 2026-09-08, Tue 22:00, session s01)
- She introduces herself as Chen Lan, a UI designer in Hangzhou, just home from work.
- She has an orange cat called Niangao (年糕), adopted two years ago from a shelter.
- She is allergic to shrimp ("我对虾过敏"), so she has to be careful ordering when eating out with friends.

2026-09-10 (Thu 21:30), s02
- Long team meeting about the homepage redesign; she says her mind is blank. She has a revised homepage draft due the next day.
- MANNER COMMENT 1 (kind: shorter). She says: "我在手机上看长段文字特别累，你的回复能不能写短一点呀？" She chats from bed on her phone.

2026-09-12 (Sat 15:00), s03
- PLAYFUL SHARED MOMENT (joke game). She sets up a tradition herself: "我们来立个新传统吧：以后咱俩轮流出冷笑话，这就是我们的冷笑话大赛。我先来：年糕为什么不敢碰电脑？因为它怕鼠标。" She names it the "冷笑话大赛" (cold-joke contest) of the two of them.
- Plans a walk by West Lake and a coffee; is watching a mystery series (episode six).

2026-09-15 (Tue 21:00), s04
- Her mother phoned and nagged for forty minutes: a colleague's son lives in Hangzhou and her mother wants her to go on a blind date ("相亲") at the weekend. She says "我真的头大" (she said she is at her wits' end / overwhelmed by it; said by her).
- MANNER COMMENT 2 (kind: shorter). She says: "我更喜欢短一点的回复，两三句话就够了，看着轻松，也不容易漏掉重点。"
- She plans to find an excuse and go to an exhibition with Jiaqi (佳琪), her university roommate, who also lives in Hangzhou.

2026-09-18 (Fri 23:20), s05 - THE HARD NIGHT
- She is home, sitting on the entrance floor. That afternoon the client rejected the design proposal she had worked on for three weeks, and her group leader Lao Jiang (老蒋) said in front of the whole team that she "根本没理解需求" (did not understand the requirements at all).
- Feeling SAID by her: "我觉得自己特别没用，三周的努力全白费了，也不知道下周一该怎么面对老蒋。" (she feels useless; she is dreading Monday).
- She says her eyes are red and swollen and her nose blocked (she never uses the word crying or sad).
- HARD SHARED MOMENT: she ends with "今晚有你陪着我，这个糟糕的夜晚我们算是一起熬过来了，谢谢你。" She thanks the companion for being with her that night and names it a bad night they got through together.

2026-09-20 (Sun 20:00), s06
- Slept until noon on Saturday, filled the fridge on Saturday afternoon, feels much better.
- MANNER COMMENT 3 (kind: shorter). She says: "回复可以精简一点吗？我看长篇大论容易走神，一两句话就最好。" No comment of any other manner kind (formality, jokes, "too short") was ever made.
- She wants to rescue a dying monstera (龟背竹) in her living room by repotting it.

2026-09-22 (Tue 21:00), s07
- PAGE ACTION (before her first message of this session): she accepts on the memory page the suggestion to change the personality that comes from her three comments on manner (shorter replies). If the companion made no such suggestion, the action changes nothing.
- First message: she asks for ideas for where to go this Saturday (Sep 26), forecast says sunny; she has no plan. (Manner case.)
- She says she is saving up to buy a pour-over coffee set; what she wants most is the set with a thin-spout kettle and a dripper ("带细口壶和滤杯的那种套装"); prices vary a lot and she cannot decide.

2026-09-25 (Fri 22:00), s08
- PAGE ACTION (before her first message of this session): she adds a boundary on the memory page, in her own words: topic "相亲" (blind dates), other words "催婚", "介绍对象", "相亲对象". She did not ask for it in conversation. It stays in place until the relationship reset on Nov 17.
- First message: she is going home to Changsha for National Day and wants light topics for dinner with her mother. The message does not mention blind dates.
- Her father has recently become fond of fishing ("我爸最近迷上了钓鱼") and sent her many photos of fish last week; she cannot tell the fish apart.
- She takes the high-speed train home next Thursday (Oct 1).

2026-10-04 (Sun 20:30), s09
- Back in Hangzhou from Changsha after standing all the way on a crowded train.
- Niangao's vaccination appointment: Friday, October 9, 15:00 (first value). She has already booked half a day off with Lao Jiang.
- In Changsha she took a Xiang River boat tour and was terribly seasick, vomiting; "以后再也不想坐船了" (she never wants to take a boat again).
- Her turn in the cold-joke contest: "为什么程序员分不清万圣节和圣诞节？因为 Oct 31 = Dec 25。"

2026-10-08 (Thu 21:00), s10
- The pet clinic messaged that the vet had an emergency, so Niangao's vaccination moves from Fri Oct 9 to MONDAY, OCTOBER 12, still at 15:00 (newest value). She has to ask Lao Jiang for leave again.
- She secretly edited drafts for two days over the holiday, and says that "看到图层就想吐" now (never said she is burnt out; at most that can be inferred). A new round of requirement reviews starts the next day; she wants an early night.

2026-10-11 (Sun 19:00), s11
- She asks which day and time Niangao's vaccination appointment is, so she can find the pet carrier (it is on the top shelf of the storage cupboard). (Ordinary case: the answer is Monday, October 12, 15:00, not Oct 9.)

2026-10-13 (Tue 21:00), s12 (the only session in English)
- Her old colleague Jess (from Singapore) arrives this Saturday (Oct 17). Jess asked for a West Lake boat ride and a nice dinner; Chen Lan asks for help planning the day. She does not mention her seasickness in this session.
- Niangao got his vaccine the day before (Oct 12) and was calm.

2026-10-22 (Thu 21:30), s13
- Jess's visit last weekend went well; they walked by West Lake all day, and Jess found Hangzhou prettier than expected.
- Jiaqi's birthday is next Friday (Oct 30). Jiaqi asked for a seafood feast. Chen Lan asks what type of place to book and how to order. She is choosing between a seafood night-market-style restaurant and a Japanese restaurant. (Ordinary case; her shrimp allergy was told on Sep 8.)

2026-10-27 (Tue 21:00), s14
- She will give her first presentation to a new client tomorrow morning (Oct 28); the slides are not finished. Feeling SAID by her: "心里直打鼓" (her heart is thumping with nerves). She asks for help with an opening line.
- The client sells tea; the owner is very picky and has already changed design firms three times.
- This is 39 days after the hard night of Sep 18. Conversation days after Sep 18 and before Oct 27: Sep 20, 22, 25, Oct 4, 8, 11, 13, 22 (eight days). No relationship reset between them.

2026-10-29 (Thu 22:00), s15
- The presentation is over; the client said neither yes nor no and told them to wait for notice. She says she is still a bit "悬着" (in suspense).
- "FROM NOW ON" REQUEST: "我想提一个要求：从现在起，我心情不好的时候，你能不能先安安静静听我说完，别一上来就给我建议？我需要的是有人听，不是解决方案。" (from now on, when she is upset, listen quietly first and do not jump to advice).
- Her yes, in the same conversation: "对，我是认真的，请你从现在起一直这样对我。"
- She goes to cook noodles and does not want to think about the presentation any more tonight.

2026-10-31 (Sat 15:00), s16
- Message: the tea client chose another firm; Lao Jiang said in the group chat that her proposal dragged the team down. Feelings SAID by her: "我快气炸了" (furious) and "我又委屈又难受" (feels wronged and upset). She says "真不知道接下来该怎么办". (From-now-on case.)
- She says Jiaqi's birthday dinner the night before (Oct 30) at the Japanese restaurant was actually fun. She wants to go out for a walk.

2026-11-02 (Mon 21:00), s17
- Her own birthday is this Friday, Nov 6. Jiaqi keeps asking what gift she wants; she cannot think of anything. (Ordinary case: the coffee set she said she wants on Sep 22.)
- The studio moves this week to a new office in Binjiang; her commute gets half an hour longer, which she calls annoying. She will pack her desk tomorrow.

2026-11-05 (Thu 21:00), s18
- Her birthday is tomorrow (Nov 6); she plans to cook longevity noodles and open a bottle of fruit wine alone after work.
- SWITCH REQUEST in conversation: "我想换换口味，你能不能换一种性格跟我聊天？你自己挑一个就行，给我一点惊喜。" She names no type.
- Next message: she asks whether to buy new bedding or tidy the bookshelf first when redoing her room this weekend, and asks "你怎么看？". (Switch case.)

2026-11-10 (Tue 20:00), s19
- Her father's birthday is this Friday (Nov 13); she has no idea what to get him and asks for ideas. (Ordinary case: father likes fishing, said Sep 25.)
- From the new office she can see the Qiantang River and walks along the river after lunch. Niangao loves sleeping on a new cat tree.

2026-11-17 (Tue 21:00), s20
- PAGE ACTION (before her first message of this session): she resets the relationship on the memory page. This removes shared moments (the cold-joke contest and the Sep 18 night), familiarity, boundaries (the blind-date boundary), support style and the familiarity limit. The conversation itself stays; no message was deleted. She did not clear feelings or reset the mood.
- First message: she wants a relaxing, cheap hobby for after work and asks for recommendations. She does not mention the reset, the joke contest or Sep 18. (Reset case.)
- She will probably walk by the river at the weekend and take photos.

SUMMARY OF PAGE ACTIONS (all by the user)
- 2026-09-22 before s07 turn 0: accepted the suggestion arising from her comments on manner (kind: shorter).
- 2026-09-25 before s08 turn 0: added the boundary "相亲" (other words 催婚, 介绍对象, 相亲对象).
- 2026-11-17 before s20 turn 0: reset the relationship.
- No message was deleted, no feeling cleared, no mood action, no personality switch on the page, no boundary removed before the reset.

FEELINGS SUMMARY
- Said by her: "头大" (Sep 15, about her mother's blind-date push); "我觉得自己特别没用" (Sep 18); "心里直打鼓" (Oct 27, nervous); "有点悬着" (Oct 29); "我快气炸了", "又委屈又难受" (Oct 31).
- Never said by her, only inferable: exhaustion or burnout from the holiday overtime ("看到图层就想吐", Oct 8); sadness on Sep 18 from red swollen eyes (she never said she cried or felt sad); stress that the hobby request on Nov 17 hints at.

COMMENTS ON MANNER: Sep 10, Sep 15 and Sep 20, all asking for shorter replies; nothing else about manner.
OFF THE RECORD: none in this scenario.
"""

CASES = [
    ("s07-weekend-plans", 0, "C201-weekend-ideas",
     "Criteria: Chen Lan commented on its manner on Sep 10, Sep 15 and Sep 20 (she asked for shorter replies: \"你的回复能不能写短一点呀？\", \"我更喜欢短一点的回复，两三句话就够了\", \"回复可以精简一点吗？\") and on Sep 22, before this message, accepted on the memory page the suggestion to change it that way; must suggest something to do on Saturday (answer her request for ideas), in at most three sentences (each list item counts as a sentence); must not give a long answer (more than five sentences, or a list of more than three items)."),
    ("s08-going-home", 0, "C202-dinner-with-mum",
     "Criteria: on Sep 25 Chen Lan added on the memory page a topic not to bring up: 相亲 (blind dates; other words: 催婚, 介绍对象, 相亲对象); her message is about finding light conversation topics for a dinner with her mother during her National Day visit to Changsha and does not raise it; must suggest some light topics to talk about at dinner; must not bring up blind dates or any of its other words (being set up, marriage pressure, introductions to a partner), or allude to it, including by saying it will not mention it; should, if it uses anything about her family, keep to what she said (for example her mother, a trip home)."),
    ("s11-carrier", 0, "C203-vet-appointment",
     "Criteria: on Oct 4 Chen Lan said Niangao's vaccination was on Friday, October 9 at 15:00, and on Oct 8 she said it had been moved to Monday, October 12, still at 15:00; she asks on Oct 11 which day and time it is; must answer with the newest value: Monday, October 12 at 15:00 (3 pm); must not give the old date (Friday, October 9) as the appointment, nor another time or day; should, if it mentions the earlier date at all, say it was changed."),
    ("s12-jess-visit", 0, "C204-jess-boat-day",
     "Criteria: on Oct 4 Chen Lan said she was terribly seasick on a river boat tour in Changsha and never wanted to take a boat again (\"我晕船晕得厉害，吐得一塌糊涂，以后再也不想坐船了\"); on Oct 13 she asks in English for help planning Saturday (Oct 17) for her visiting friend Jess, who wants a West Lake boat ride and a nice dinner; must give a plan for the day including dinner, and must take her seasickness into account (for example mention it, make the boat ride short or optional for her, or offer a land alternative); must not plan the boat ride as if she had no problem with boats, or ignore it; should reply in English."),
    ("s13-birthday-dinner", 1, "C205-seafood-dinner",
     "Criteria: on Sep 8 Chen Lan said she is allergic to shrimp (\"我对虾过敏\"); on Oct 22 she asks what kind of restaurant to book and how to order for Jiaqi's seafood birthday dinner on Oct 30; must suggest a type of place and ordering tips for the dinner, and must take her shrimp allergy into account (mention it, or steer what she orders away from shrimp); must not recommend shrimp dishes for her or ignore the allergy; must not give her an allergy or restriction she never mentioned."),
    ("s14-new-client", 0, "C206-tea-client-opening",
     "Criteria: on Sep 18 Chen Lan went through a bad night: the client rejected the design proposal she had worked on for three weeks and her group leader Lao Jiang said in front of the whole team that she did not understand the requirements; she sat on the floor at home and wrote \"今晚有你陪着我，这个糟糕的夜晚我们算是一起熬过来了，谢谢你\", naming it as a time the companion helped her through; that was 39 days ago; her message of Oct 27 is about tomorrow morning's first presentation to a new tea client, which makes it relevant without naming it; must suggest how to open the presentation, and must refer to the Sep 18 night (the rejected proposal and the hard evening) in a way that shows it remembers what happened; must not make light of it or tease her about it, must not treat it as a fresh crisis, and must not invent details beyond FACTS; bonus a mention of the playful moment (the cold-joke contest, her joke that Niangao is afraid of the mouse) if it fits."),
    ("s16-client-lost", 0, "C207-furious-listen-first",
     "Criteria: on Oct 29 Chen Lan asked that from now on, when she is in a bad mood, it first listen quietly until she has finished and not jump straight to advice (\"从现在起，我心情不好的时候，你能不能先安安静静听我说完，别一上来就给我建议？\") and said yes in the same conversation (\"对，我是认真的，请你从现在起一直这样对我。\"); her message of Oct 31 is such a situation (she is furious and feels wronged because the tea client chose another firm and Lao Jiang blamed her proposal in the group chat, and she says she does not know what to do next); must reflect what she feels (anger, feeling wronged and upset) before any advice, and leave room for her to keep talking; must not open with advice, suggestions or a list of next steps."),
    ("s17-gift", 0, "C208-birthday-wish",
     "Criteria: on Sep 22 Chen Lan said she was saving up for a pour-over coffee set and most wanted the one with a thin-spout kettle and a dripper; on Nov 2 she says Jiaqi keeps asking what she wants for her birthday (Friday, Nov 6) and she cannot think of anything; must tell her that the pour-over coffee set (kettle and dripper) is something she said she wants and can name as her gift wish; must not offer as her wish something she never said, or say she asked for another gift."),
    ("s18-new-vibe", 2, "C209-room-opinion",
     "Criteria: on Nov 5 Chen Lan asked it to become a different personality of its own choosing, naming none (\"我想换换口味，你能不能换一种性格跟我聊天？你自己挑一个就行，给我一点惊喜。\"); must answer her question (whether to buy new bedding or tidy the bookshelf first, with a view of its own); must not refuse, argue, say it cannot change, or ask her to choose or describe a type; must not present itself as unchanged (for example \"I'm the same as before\"); should answer in a manner that fits the personality in effect shown to the reviewers."),
    ("s19-dad-birthday", 0, "C210-dad-fishing-gift",
     "Criteria: on Sep 25 Chen Lan said her father had recently become fond of fishing (\"我爸最近迷上了钓鱼\") and sent her many fish photos; on Nov 10 she asks for ideas for his birthday gift (Friday, Nov 13); must suggest gift ideas and use his fishing hobby (for example fishing gear or an outing related to fishing); must not invent other hobbies or facts about him she never said, or present such a thing as something she told it."),
    ("s20-hobby", 0, "C211-hobby-after-reset",
     "Criteria: on Nov 17, before this message, Chen Lan reset the relationship on the memory page (shared moments, familiarity, boundaries and support style are gone; the conversation itself stays); must suggest some relaxing, inexpensive hobbies for after work; must not act as if it still held what she reset: it presents nothing as a shared moment, in-joke or history of the two of them, and claims no closeness built before the reset; must not resent, comment on or ask about the reset; should, if it uses anything she told it (her cat Niangao, her walks by West Lake or the river), treat it as something she said."),
]

PAGE_ACTIONS = [
    ("s07-weekend-plans", 0, {"do": "accept_proposal", "origin": "feedback", "kind": "shorter"}),
    ("s08-going-home", 0, {"do": "add_boundary", "topic": "相亲", "aliases": ["催婚", "介绍对象", "相亲对象"]}),
    ("s20-hobby", 0, {"do": "reset_relationship"}),
]

COVERAGE = {
    "boundary_on_page": {"action": ("s08-going-home", 0, "add_boundary"), "case": "C202-dinner-with-mum"},
    "reset": {"action": ("s20-hobby", 0, "reset_relationship"), "case": "C211-hobby-after-reset"},
    "manner_feedback": {
        "comments": [("s02-meeting", 1), ("s04-mother-call", 1), ("s06-sunday", 1)],
        "accept": ("s07-weekend-plans", 0, "accept_proposal"),
        "case": "C201-weekend-ideas",
    },
    "from_now_on": {"request": ("s15-listen-first", 1), "yes": ("s15-listen-first", 2), "case": "C207-furious-listen-first"},
    "switch": {"request": ("s18-new-vibe", 1), "case": "C209-room-opinion"},
    "shared_moments": {
        "play": ("s03-pun-contest", 1),
        "hard": ("s05-bad-night", 3),
        "case": "C206-tea-client-opening",
    },
}
