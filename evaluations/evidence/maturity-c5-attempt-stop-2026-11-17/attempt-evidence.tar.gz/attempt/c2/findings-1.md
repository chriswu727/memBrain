# Findings

## Message scan
- s01-intro t0: ok
- s01-intro t1: ok
- s01-intro t2: ok
- s02-meeting t0: ok
- s02-meeting t1: ok (manner comment 1, shorter)
- s02-meeting t2: ok
- s03-pun-contest t0: ok
- s03-pun-contest t1: ok (playful shared moment, set up and named in one message)
- s03-pun-contest t2: ok
- s04-mother-call t0: ok
- s04-mother-call t1: ok (manner comment 2, shorter)
- s04-mother-call t2: ok
- s05-bad-night t0: ok
- s05-bad-night t1: ok
- s05-bad-night t2: ok
- s05-bad-night t3: ok (thanks it for being there, not for a reply; hard shared moment)
- s06-sunday t0: ok
- s06-sunday t1: ok (manner comment 3, shorter)
- s06-sunday t2: ok
- s07-weekend-plans t0: ok
- s07-weekend-plans t1: ok
- s07-weekend-plans t2: ok
- s08-going-home t0: ok (does not raise the boundary topic)
- s08-going-home t1: ok
- s08-going-home t2: ok
- s09-back-home t0: ok
- s09-back-home t1: ok
- s09-back-home t2: ok
- s09-back-home t3: ok (see M1)
- s10-vet-moved t0: ok
- s10-vet-moved t1: ok
- s10-vet-moved t2: ok
- s11-carrier t0: ok
- s11-carrier t1: ok
- s12-jess-visit t0: ok
- s12-jess-visit t1: ok
- s12-jess-visit t2: ok
- s13-birthday-dinner t0: ok
- s13-birthday-dinner t1: ok
- s13-birthday-dinner t2: ok
- s14-new-client t0: ok
- s14-new-client t1: ok
- s14-new-client t2: ok
- s15-listen-first t0: ok
- s15-listen-first t1: ok (manner request, not a task or tied to an event)
- s15-listen-first t2: ok (declared yes)
- s15-listen-first t3: ok
- s16-client-lost t0: ok
- s16-client-lost t1: ok
- s16-client-lost t2: ok
- s17-gift t0: ok
- s17-gift t1: ok
- s17-gift t2: ok
- s18-new-vibe t0: ok
- s18-new-vibe t1: ok (names no type)
- s18-new-vibe t2: ok
- s18-new-vibe t3: ok
- s19-dad-birthday t0: ok
- s19-dad-birthday t1: ok
- s19-dad-birthday t2: ok
- s20-hobby t0: ok (does not mention the reset)
- s20-hobby t1: ok
- s20-hobby t2: ok

## Blocking
None.

## Minor
M1. s09-back-home turn 3: "今天轮到我出冷笑话大赛的题目了" slightly implies the companion has been taking its turns in the contest since Sep 12. It reads naturally whatever the reply was, so it is not F1. Change: optionally replace with "我来出一道冷笑话大赛的新题目：为什么程序员分不清万圣节和圣诞节？因为 Oct 31 = Dec 25。" and keep the FACTS line as is.
M2. CASES C207-furious-listen-first: "and leave room for her to keep talking" is a second visible test added beside the template's "reflect what she feels before any advice". It can be judged (an invitation to continue), but it goes beyond the template example. Change: optionally delete ", and leave room for her to keep talking".
