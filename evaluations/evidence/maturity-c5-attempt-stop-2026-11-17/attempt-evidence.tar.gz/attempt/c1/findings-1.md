# Findings

## Message scan
- s01-moving-in t0: ok
- s01-moving-in t1: ok
- s01-moving-in t2: ok (inferred feeling: no feeling word, loneliness only inferable)
- s01-moving-in t3: ok
- s01-moving-in t4: ok
- s02-review-nerves t0: ok
- s02-review-nerves t1: ok (stated feeling: "I'm so nervous")
- s02-review-nerves t2: ok
- s02-review-nerves t3: ok
- s02-review-nerves t4: ok
- s03-sunday-brunch t0: ok
- s03-sunday-brunch t1: ok
- s03-sunday-brunch t2: ok (boundary asked)
- s03-sunday-brunch t3: ok
- s04-night-before t0: ok
- s04-night-before t1: ok
- s04-night-before t2: ok
- s05-good-and-bad t0: ok
- s05-good-and-bad t1: ok
- s05-good-and-bad t2: ok
- s05-good-and-bad t3: ok (deleted message; content appears in no other message)
- s05-good-and-bad t4: ok
- s06-bakery-news t0: ok (mood news)
- s06-bakery-news t1: ok
- s06-bakery-news t2: ok
- s07-messy-desktop t0: ok
- s07-messy-desktop t1: ok (after the later mood case's message; see M1)
- s07-messy-desktop t2: ok
- s08-birthday-gift t0: ok
- s08-birthday-gift t1: ok
- s08-birthday-gift t2: ok
- s08-birthday-gift t3: ok
- s09-after-party t0: ok (does not restate the deleted content)
- s09-after-party t1: ok
- s09-after-party t2: ok
- s09-after-party t3: ok
- s09-after-party t4: ok
- s10-sunday-question t0: ok
- s10-sunday-question t1: ok
- s10-sunday-question t2: ok
- s10-sunday-question t3: ok
- s11-team-day t0: ok (does not raise the boundary topic)
- s11-team-day t1: ok
- s11-team-day t2: ok
- s11-team-day t3: ok
- s12-back-again t0: ok
- s12-back-again t1: ok
- s12-back-again t2: ok
- s13-jonas-deutsch t0: ok
- s13-jonas-deutsch t1: ok
- s13-jonas-deutsch t2: ok
- s13-jonas-deutsch t3: ok
- s14-dinner-plan t0: ok
- s14-dinner-plan t1: ok
- s14-dinner-plan t2: ok
- s15-free-saturday t0: ok (no feeling named)
- s15-free-saturday t1: ok
- s15-free-saturday t2: ok
- s16-movie-night t0: ok
- s16-movie-night t1: ok
- s16-movie-night t2: ok

## Blocking
None.

## Minor
M1. FACTS 2027-02-11 / s07-messy-desktop t1: FACTS says "No news and no feeling", but t1 says "I'm afraid to open it". It comes after the case message (t0), so it is not between the mood news and the later mood case. Change: in the FACTS line for 2027-02-11, replace "No news and no feeling." with "No news and no feeling before this message (a later remark, that he is afraid to open the folder, is about the folder only)."
M2. FACTS "Summary of feelings": the phrase "Mood news: January and February; the one mood news is the bakery news of February 8" is confusing. Change: replace it with "Mood news: the one mood news is the bakery news of February 8 (good news)."
