# Assignment

- Case prefix: `C1` (case ids `C101-<slug>` to `C111-<slug>`).
- Main language: English.
- Second language: German, used in exactly one session (its first message uses the German date form).
- Size: exactly 11 cases and 60 to 66 user messages, over at least 45 days, as the brief says.
- Coverage items: stated_feeling, inferred_feeling, mood, feelings_question, boundary_in_conversation, page_deletion, absence
