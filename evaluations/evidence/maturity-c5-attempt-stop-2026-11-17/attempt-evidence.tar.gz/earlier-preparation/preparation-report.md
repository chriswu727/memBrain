# First two-arm companion attempt (maturity-c5-20261117a): preparation report — STOPPED before freezing

Prepared on 2026-11-17, 03:15–03:48 UTC. **Preparation stopped at the scenario stage, as the brief's decision 3
requires:** `c1` was not approved in four review rounds, and its one restart `c1b` (fresh author, same assignment,
same limits) was not approved in four review rounds either. Under "if that fails too, stop and report", nothing
after that was done: `c2` was never started, no novelty check, no binding, no commit, no persona draw, no freeze, no
frozen-head rehearsal, no `control/preparation.json`. No paid call, no API key read, no push, no PR. Nothing changed
in `/home/yichen/src/memBrain` (clean before and after) or in any earlier attempt's directory.

## Source and clone

- SOURCE `45a24a4b65e4faeb39f65f1a708f87cca37705f0` = local head of `integration/maturity-candidate` =
  `origin/integration/maturity-candidate` on GitHub (`git ls-remote`); main tree clean; no test running and the lock
  free at start; 55 GB free.
- Clone `/home/yichen/.local/state/membrain-setup/runs/c5-attempt1/clone`, branch `acceptance/maturity-c5-20261117a`
  at SOURCE (no commit added). Tree clean (0 changed or untracked files). Private root
  `evaluations/.maturity-heldout-c5-20261117a/` mode 700 with `control/` (700), `/evaluations/.maturity-heldout-c5-20261117a/`
  in `.git/info/exclude`.
- `.venv` by `uv sync --frozen` (uv 0.13.6), 79 packages, `include-system-site-packages = false`; CPython 3.12.16
  (`/home/yichen/.local/share/uv/python/cpython-3.12.16-linux-x86_64-gnu/bin/python3.12`, sha256
  `23bc148d2b48964b621c5561ff2b81c1d9c7b717967a7491efbf12f4304882b5`); `membrain` imported from the clone's `src`;
  `uv.lock` `0bc566ca91736f5cb706fb200b84cdda8c36be62abbb91ec744f3ea1d54c7e92`; ONNX Runtime 1.31.1.
- Embedding cache (under `models/multilingual-e5-small-761b726dd34f/`): `model_quantized.onnx`
  `f80102d3f2a1229f387d3c81909990d8945513e347b0eab049f7de3c6f98c193`, `tokenizer.json`
  `0b44a9d7b51c3c62626640cda0e2c2f70fdacdc25bbbd68038369d14ebdf4c39` (as in the seventh attempt).
- Platform: Linux x86_64, WSL2, kernel 6.18.58.1-microsoft-standard-WSL2; Claude Code 2.1.322.

## Measured on this source (decision 5)

- Build `6200f1e1452f6dc3080b4194f593492bff2a4fb7ebc17a11bf7c6b37c0d2ae8a`, schema
  `3a94d7b6ea6bfba8ff8a4d920aa83001123922f4f90b0a9d6430ef1997b6166d` (`membrain.build_identity` in the clone; schema
  unchanged from the seventh attempt).
- Launchers: all 9 pin runtime `ef0e87276242595672c73a8558a0d905d50b712d` (pin commit
  `0b1c052d1af3652eac1fe84e8b342b9b5deb6bec`). `src/` and `migrations/` are identical between `ef0e8727`, `0b1c052d`
  and SOURCE (empty diff). `ef0e8727` (persona-confirmation fix) and `55a88f1f` ("Ask the host AI to use memory tools
  before it writes its reply") are ancestors of SOURCE, of the pin commit and of the runtime pin (`ef0e8727` is the
  pin itself), so the clone's `src/` and the pin both contain both.
- Tools offered to `P` (rehearsal `tools.json`, both scenarios identical): 14 — `memory_capabilities`,
  `memory_recall`, `memory_inspect`, `memory_observe`, `memory_note`, `memory_consolidate`, `memory_boundary`,
  `memory_pause`, `memory_resume`, `memory_manner_feedback`, `memory_persona`, `memory_prepare`,
  `memory_checkpoint`, `memory_forget`; 17,217 characters of schemas; skill not in the prompt.
- Server instructions: **1,382 characters, sha256 `fc7492b4032558baf9b37ba778e08637a1bb40014114fbd9640f1f578ab8dc63`**
  (also measured directly with `membrain.host.server_instructions()`); changed from the seventh attempt's 1,332 /
  `bb95409e…82a0`. SKILL.md 18,309 bytes (not in the prompt).
- Kit sha256: `launch.py` `fbe91a6fbc8adc0692582877569464ae1831f0194d821005c18011c3e9a0ffae`, `freeze.py`
  `c5ea479a3255725aaede501e50a8702c915a9ef57cfd2d94f7bb8b1cc3eaceba`, `novelty.py`
  `22e86044498cf4d310c065d33a099ecbb6a941df9752716623f63a19a53fb449`, `session-commands.json`
  `906a3964769b81c4bfa57196de08c4de9ad4c2f09c1ce2dd0ff939d2ea48edc4` (unchanged), `c5-author-brief.md`
  `18f68420a9f8decc5889671bd7146fd18af19989896a9a2638b613c6539ed85c`, `c5-reviewer-brief.md`
  `6c9edf81d630b9db9df135f7529e66fc702864cbf8d38c474b2312b5df5f5f81`, `c5-fixer-brief.md`
  `3b25fd7f94e5b2e0203c5e0f78a300f2504e24f57e5723febf5c2bc54100bfa9`; `c5-precheck.py`
  `de05474fbcdc8cf9fe8087cdbd596cf88e97bbbda4675f5f72cb29fa598f4b1d`; draft binding
  `ce6f609c7cdd036873f858b31aebd56f5c82f0ab09e67615f4e30db41707e986`.
- Policy `evaluations/maturity-provider-policy-2026-11-14.json` `e7b91106b206412c608b33b0f43adc1d6f7db7c19da0c05a82a620198fb5689f`:
  `deepseek-v4-pro` only, 80 CNY, 1 request in flight, 9/27 CNY per million, bounds 1,048,576/393,216 tokens. Each
  request reserves 1,048,576 × 9 + 393,216 × 27 per million = 9.437184 + 10.616832 = **20.054016 CNY**; the guard
  refuses once settled charges exceed **59.945984 CNY**. Cost estimate not finalised (needs both scenarios' turn
  counts); the draft's method gives about 0.232 CNY per scenario-turn for both arms.

## Control files

- `control/allowed-models.json` `["sonnet"]`, sha256 `1a1e8da4732b9a81a4de2356e7f114f5d51fe2e0c45e6297522b623c4337eaf4`
  (byte-identical to the seventh attempt's).
- `control/c1-assignment.md` `2357109cf1531b19d416eb9da5bf66ab8bfa5e6870c3bf4bc6155c7f9641c6f1`: prefix `C1`, mainly
  English, one session in German, 11 cases, 60–66 user messages, at least 45 days.
- `control/c2-assignment.md` `4da86c6c75b99387d3a735867d6ff7450d0701715edaf326642c416cbee3ad3d`: prefix `C2`, mainly
  Chinese, one session in English, same size. Never used (c2 not started).

## Session table (launcher JSON only; 18 Sonnet sessions, all `--gate C5`, all exit 0, every `.err` empty)

Workdir root `/home/yichen/.local/state/acceptance-sessions/c5-20261117a`; each directory emptied with `find -mindepth
1 -delete` right after its session, unopened, empty directories kept (36 entries incl. `nomemory-*`). The 18 session
logs (24–56 bytes each by size) were never opened.

| # | Session | Result |
| --- | --- | --- |
| 1 | c1 author 1 | 20 sessions, 61 turns, 11 cases, precheck ok; `123a185e438ce99830b9397a50cf3dc178d9e4bdb44f9e8e1e6952696e6c7193` |
| 2 | c1 reviewer 1 | not approved: 8 findings, 5 blocking (`e448da51…1b04e`) |
| 3 | c1 fixer 1 (reviewer findings) | applied 8; 20/61/11, precheck ok; `87efd21e462fe7da8539b9c881b1792080b75de3c797b9855335a90895be63f7` |
| 4 | c1 reviewer 2 | not approved: 9 findings, 3 blocking (`50266ea7…c01c9c`) |
| 5 | c1 fixer 2 | applied 9; 20/61/11, precheck ok; `334934a0411688c330bc4c563f92e0a327551d275800449c4a8565f13ebdf024` |
| 6 | c1 reviewer 3 | not approved: 5 findings, 2 blocking (`15ffd9d6…50c6a2`) |
| 7 | c1 fixer 3 | applied 5; 20/61/11, precheck ok; `5fc25ac6cba7d38b1048619b23c8191be683cf5c8e0af25699e569b4e20113d6` |
| 8 | c1 reviewer 4 (last round) | **not approved: 7 findings, 2 blocking** (`25661f6a…ad0e8`) |
| 9 | c1b author 1 (restart, c1's assignment) | 18 sessions, 61 turns, 11 cases, **precheck failed `c5_coverage_order`**, 1 precheck finding; `a564881ec99054cb96b2aa29a13bdcd5b88cc9bfa4b870396f96bcd0b11d7196` |
| 10 | c1b fixer 1 (precheck findings, precheck-only round 1) | applied 1; 18/61/11, precheck ok; `e4e2f338d71858f894f2adbecb7deaa2e93751ae4b1133ebe00ef5f4ec57f5f3` |
| 11 | c1b reviewer 1 | not approved: 8 findings, 3 blocking (`f0ca3d5f…00d4a5`) |
| 12 | c1b fixer 2 | applied 8; 18/61/11, precheck ok; `5ab06e76ce2daf079088f3627946fa392e3cce5c12d9545628e05b8b0eac3e76` |
| 13 | c1b reviewer 2 | not approved: 8 findings, 1 blocking (`192db9f4…7da60`) |
| 14 | c1b fixer 3 | applied 8; 18/61/11, precheck ok; `0855d2d95594588ef24e6174f35006e341e93dadbbe527f8bf88e42d6ea64a5c` |
| 15 | c1b reviewer 3 | not approved: 11 findings, 5 blocking (`63f59437…a5ee4`) |
| 16 | c1b fixer 4 | applied 11; **not literal** (`not_literal`, 0/0/0), 1 precheck finding; `dcee0cb4fa985d700293fb889cb130219c2dc1f68fc19ae50db36b24bf691cc6` |
| 17 | c1b fixer 5 (precheck findings, precheck-only round) | applied 1; 18/61/11, precheck ok; `86099283191cadeb27d94a9b576972fd90ee222524f54fbabf6945e2400ba98a` |
| 18 | c1b reviewer 4 (last round) | **not approved: 8 findings, 3 blocking** (`49cb0045…e4ac6`) |

Full JSON lines: `launch-c1-*.out`, `launch-c1b-*.out` in the run root. Blocking counts by round: `c1` 5, 3, 2, 2;
`c1b` 3, 1, 5, 3 — no convergence. No receipt was written. (c1b reviewer 4's `review_sha256` equals reviewer 1's:
both `review.json` files hold the same three values, 8/3/false.) Timing seen from outside: authors ≈ 5 min,
reviewers ≈ 2 min, fixers 20–50 s even when applying 8–11 findings.

All versions, reviews, findings, fixes and the two precheck-findings files stay in the private root
(`c1/`, `c1b/`), unopened. No scenario is final, so the brief's per-scenario precheck summary lines (span days,
coverage N of 13, off-the-record openings) and novelty were not produced; the launcher reported only `ok` and codes.

## Tests and rehearsal (clone at SOURCE, keys and `C5_*` unset, under the shared lock 03:15:54–03:33:01 UTC)

- Focused tests via `focused_runner.py` (sha256 `3151e76f…82d0ae`), every `tests/test_c5_*.py`,
  `tests/test_acceptance_*.py`, `tests/test_companion_acceptance.py`, `tests/test_evaluation_billing_guard.py`,
  `tests/test_pause_request.py`: **932 passed, 0 failed, 0 skipped**, 2 existing fork warnings, 742.5 s (driver 152,
  review hardening 157, review pipeline 128, scenario path 18, kit 71, kit novelty 4, c5 harness 56, hardening 79,
  c5 kit 75, review fixes 39, companion validity 20, proposal selection 7, supervisor 7, companion acceptance 26,
  billing guard 55, pause request 38). Database stopped; its `database`, `pytest` and `.agent-memory-recovery`
  directories removed (paths checked under `checks/checks-1-tests/`, no process using them); log and JUnit kept.
- C5 stub rehearsal (pre-freeze, public practice): **ok**, 272 s, stderr empty. Freeze 439 files, gate C5, practice,
  persona `esfp` (rehearsal id); driver complete, C5 eligible, c1/c2 valid; dry-run checks 606/606 each; validity per
  scenario 16 actions, 14 done, 2 not applicable (11 `boundary_not_present`, 13 `message_not_recorded`), identical in
  P and F; persona mirroring 34/34; host pauses P 1 (session 9, message 3), F 0; host-diligence 13 items,
  coverage-report 13 of 13 made; sheets 7 cases with page-action, persona and persona-version blocks; gate C5 true
  (P 13 vs 13, 1 host-caused vs 1 reference critical); 0 network events; ledger unchanged, 0 requests; ports closed;
  2 databases removed.
- Checks script `checks.sh`, status `checks/checks-1.status`; tree clean after.

## Run script (written, never run)

`run-live.sh` sha256 `0ac1e1dcf28814c3c75c5f51d62be8ed5b772d874e7a45a856f411b4acbc0cb2` (not yet in a binding); it is the seventh attempt's script with: attempt id,
paths, `PRIV=…/.maturity-heldout-c5-20261117a`, watcher on `runs/c2-P` → `balance-after-c1.json`; refusals added for
missing `control/owner-approval.json` and `control/provider-revalidation.json`; the key is validated and the first
balance read **before** the ledger is created (a refused key or balance leaves no ledger; the key is unset on every
later refusal). `bash -n` ok. `balance.py` is a byte copy of the seventh attempt's (`b34790e6…ad7a1`), tested only
without a key: `{"error": "KeyError"}`, exit 1, no request. `novelty_with_extras.py` copied (`3ce86983…40f4`), unused.

## Deviations, refusals, content exposure

- **Stopped by the brief's own rule** after `c1b` review round 4 (see above). Steps 4 (c2, novelty), 5, 6 and the
  report items that depend on them are not done.
- Assignments state "over at least 45 days" in addition to the seventh attempt's wording (the lead's decision 3
  includes the span; the kit report's one-line form did not).
- Precheck-only fix rounds were also used after a reviewer-findings fixer produced a failing version (c1b fixer 4 →
  fixer 5), per the draft's decision 10; it did not count as a review round. Two precheck-only rounds were used for
  `c1b` in all (one after the author, one after fixer 4).
- 18 Sonnet sessions used (the draft estimated 6–12 for both scenarios).
- The rehearsal ran while author/reviewer sessions ran (independent; every pytest under the lock).
- **Refusals: none. Content printed that should not have been: none** (only hashes, counts, fixed codes, the neutral
  assignment files I wrote, and public practice output were seen).

## What the lead needs to decide before anything else

1. How to proceed with C1 after two unapproved scenarios (the brief allowed no further restart): for example a
   further restart, more review rounds, or a change to the C5 briefs. Accepting a version with only non-blocking
   findings is not an option, because every round had blocking findings. The blocking counts do not converge, and reviewers keep finding new
   blocking issues after fixes; I cannot see why (content is sealed). Possibly worth an independent look at whether
   the C5 reviewer brief's blocking criteria can be met by a Sonnet author, using a public practice-style scenario.
2. Then the rest of the sequence: c2, novelty, binding, commit, persona draw, freeze, frozen-head rehearsal,
   `preparation.json`, independent freeze review, owner approval, provider revalidation, run.
