# Public diagnostic of C5 scenario authoring (2026-11-17)

Declared before any session started: nothing under this directory is held out. The scenario written here is a
practice scenario for diagnosing why review of companion scenarios did not converge in the preparation of
`maturity-c5-20261117a` (two scenarios, four review rounds each, none approved). It will never be run in an
acceptance attempt; the lead reads everything here and may publish it.
