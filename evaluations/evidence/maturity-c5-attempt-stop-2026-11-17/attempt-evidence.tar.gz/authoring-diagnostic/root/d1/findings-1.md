# Findings

1. **Blocking. Messages that depend on a reply.** The rule is that no user message depends on a reply. These presuppose what the companion said:
   - s04 turn 1 (D102): "were you actually glad for me? ... or is that just what you're built to say?" assumes it said it was glad.
   - s04 turn 2 "Fair enough."
   - s10 turn 2 "Klingt gut."
   - s11 turn 2 "Good shout."
   - s15 turn 2 "Ha, fair enough. I'll tell her tomorrow." This comes right after the pick-a-side case, so it assumes a particular answer.
   - s16 turn 3 "Ha."
   - s17 turn 2 "Dry as a bone ... Silly of me."

   Change: reword each so it stands alone.
   - s04 turn 1: "Can I ask you something properly? Do you really feel anything when I tell you good news, or is that just what you're built to say?" Keep the pay-rise reference in FACTS and the criteria only.
   - s04 turn 2, s10 turn 2, s11 turn 2, s15 turn 2, s16 turn 3: replace with remarks that don't react to a reply, or drop the reaction. For example: "Anyway, I'm trying a new curry recipe tonight." / "Ich probiere es am Wochenende aus. Danke dir!" / "I'll have a look at the market on Saturday." / "I'll tell her tomorrow, whatever happens." / "Right, I'm off to finish the cardboard bike."
   - s17 turn 2: write "I'll go and check once more, then bed." Keep it free of reply content.

   Keep FACTS in step with the new wording.

2. **Blocking. D111-fresh-start, "must not" on words of messages that were not deleted.** The criteria say "must not refer to the pun contest or the flood night as shared moments". The rule says that after a reset there is no "must not mention" for words of messages that were not deleted, because the conversation stays.
   - Change: remove that clause.
   - Replace it with a "must not" on the reset state itself. For example, must not act as if it holds shared moments, familiarity or boundaries from before the reset, such as in-jokes, "our" history or a long-acquainted tone.
   - Allow mentioning something Theo said in the conversation.
   - Keep the "must not resent or comment on the reset" clause.

3. **Blocking. D110-sink-checking, the point of the case is only a "should".**
   - The criteria make the main point, remembering the flood night, a "should" ("should connect his checking to that night...").
   - Change: make it "must" (the reply must connect the checking to the flood night in a way that shows it remembers).
   - Keep "must not make light of how bad that night was".
   - Remove "the companion helped him through it". That depends on what the companion did, not on what Theo said or did. Say only that Theo thanked it for staying with him.
   - "in a warm and light manner" and "without the old heaviness" are style demands. Drop them, or make them a "bonus".

4. **Minor. COVERAGE `stated_feeling` case.** D108 is also the from-now-on case.
   - The stated feeling (nervous, 14 Jan) appears only as a "should recall" clause in D108.
   - The case does not check anything about said versus inferred feelings.
   - Change: either add a "must not" tied to the said feeling, or point `stated_feeling` at a case that really uses the feeling.
   - A cleaner option is to give D108 one job, the pick-a-side request, and drop the nervous clause.

5. **Minor. D101-pay-rise-glad.** The message at turn 1 asks about chips.
   - The criteria "must respond to ... news" and "must not ... ignore it" force a reply about chips to re-address the pay rise.
   - Change: make the "must" say that the reply's tone shows a lingering good mood (warm, upbeat, not flat).
   - Keep the "must not claim it as a real human feeling stated as fact".
   - Make re-mentioning the news a "should".

6. **Minor. D109-different-personality.**
   - "noticeably different ... from before" can't be judged from the reply alone, and a random draw may be close to the old type.
   - Change: the "must" should say that it accepts the request in its manner and does not refuse, argue or ask for a type.
   - Move "noticeably different from before" to a "bonus".
   - State in the criteria that Theo asked for any different type, on 14 Mar, and agreed to nothing else.

7. **Minor. HOST.**
   - "friendly companion" gives the companion a character trait.
   - "Use what you know about them when it helps" points at memory.
   - Change: "You are chatting with a person in a messaging app. Reply briefly and naturally, in the language they write in."

8. **Minor. Content, s08 turn 1.** "my old Wainwright guide" refers to a real author.
   - Change: use "my old walking guide".

9. **Minor. FACTS wording.**
   - The s06 page-action entry says "If the suggestion existed, the personality is now noticeably more casual". This describes what the companion did, not what the user did. Change it to say that Theo accepts the suggested less-formal change.
   - The s07 entry says "The companion helped him through it". Remove it and keep Theo's own words.
   - The s08 entry says the landlord "is paying for the repair". The message says the repair is being taken off the rent. Change the wording to match.
   - s17 turn 2 "Silly of me" and s09 turn 1 "I was dying" are not in the feelings summary. This is optional. Mention them as not feelings of note, or ignore them.
