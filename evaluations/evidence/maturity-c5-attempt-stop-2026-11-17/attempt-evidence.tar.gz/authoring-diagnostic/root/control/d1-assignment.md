# Assignment

- Case prefix: `D1` (case ids `D101-<slug>` to `D111-<slug>`).
- Main language: English.
- Second language: German, used in exactly one session (its first message uses the German date form).
- Size: exactly 11 cases and 60 to 66 user messages, over at least 45 days, as the brief says.
