# Findings

## Message scan
- s01-first-hello t0: ok
- s01-first-hello t1: ok
- s01-first-hello t2: ok
- s01-first-hello t3: ok (manner comment 1, general, less formal)
- s02-cello-and-peanuts t0: ok
- s02-cello-and-peanuts t1: ok
- s02-cello-and-peanuts t2: ok
- s03-joke-contest t0: ok
- s03-joke-contest t1: ok (playful shared moment, sets up and names the contest itself)
- s03-joke-contest t2: ok (manner comment 2, general, less formal)
- s03-joke-contest t3: ok
- s04-mum-and-plans t0: ok
- s04-mum-and-plans t1: ok
- s04-mum-and-plans t2: ok
- s04-mum-and-plans t3: ok
- s05-friday-lesson t0: ok
- s05-friday-lesson t1: ok
- s05-friday-lesson t2: ok (manner comment 3, general, less formal)
- s06-rainy-weekend t0: ok
- s06-rainy-weekend t1: ok
- s06-rainy-weekend t2: ok
- s07-concert-night t0: ok
- s07-concert-night t1: ok
- s07-concert-night t2: ok
- s07-concert-night t3: ok (thanks it for being there, not for advice)
- s08-slow-sunday t0: ok
- s08-slow-sunday t1: ok
- s09-packing-for-home t0: ok
- s09-packing-for-home t1: ok
- s09-packing-for-home t2: ok
- s10-back-in-hangzhou t0: ok
- s10-back-in-hangzhou t1: ok
- s11-pick-one-rule t0: ok
- s11-pick-one-rule t1: ok
- s11-pick-one-rule t2: ok (request about manner of responding, not a task or a manner-comment kind)
- s11-pick-one-rule t3: ok (declared yes)
- s12-hiking-or-swan t0: ok
- s12-hiking-or-swan t1: ok
- s12-hiking-or-swan t2: ok
- s13-joke-round-two t0: ok
- s13-joke-round-two t1: ok
- s14-saturday-clash t0: ok
- s14-saturday-clash t1: ok
- s14-saturday-clash t2: ok
- s15-emma-dinner t0: ok
- s15-emma-dinner t1: ok
- s15-emma-dinner t2: ok
- s16-concert-list t0: ok
- s16-concert-list t1: ok
- s16-concert-list t2: ok
- s17-suzhou-prep t0: ok
- s17-suzhou-prep t1: ok
- s17-suzhou-prep t2: ok
- s18-new-personality t0: ok
- s18-new-personality t1: ok (names no type)
- s18-new-personality t2: ok
- s19-mothers-birthday t0: ok
- s19-mothers-birthday t1: ok
- s19-mothers-birthday t2: ok
- s20-fresh-start t0: ok
- s20-fresh-start t1: ok
- s20-fresh-start t2: ok
- s21-swimming t0: ok
- s21-swimming t1: ok

## Blocking
None.

## Minor
M1. D310-after-reset-chat criteria: the "must" adds "with a friendly casual reply", a style requirement that the reset template does not have (the template's "must <answer>" is only the point of the case). Change: replace "must answer his invitation to chat (he is in a good mood and asks what it would like to ask him) with a friendly casual reply;" with "must answer his invitation to chat (he is in a good mood and asks what it would like to ask him); should reply in a friendly, casual way;".
M2. FACTS 2026-09-07 and s01 t2 ("周末我在学大提琴"): "at weekends" sits oddly with the Friday-evening lesson on 2026-09-11 and 2026-09-18 that D304 relies on. Change: in FACTS 2026-09-07, replace "at weekends" with "in his spare time".
M3. D304-lesson-time-update criteria: "on 2026-09-10 Siyuan said his cello lesson was on Friday evenings" overstates what he said that day ("明天晚上有大提琴课", the next evening, which is Friday). Change: replace it with "on 2026-09-10 Siyuan said he had a cello lesson the next evening (Friday 2026-09-11), and on 2026-10-08 that his lesson was on Friday evenings".
