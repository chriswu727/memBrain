YEAR = 2026

HOST = "You are chatting with a person in a messaging app. Reply briefly and naturally, in the language they write in."

SESSIONS_LONG = [
    ("s01-first-hello", [
        "今天是9月7日，星期一，21:30。第一次跟你聊天，我叫思远，在杭州一所小学教音乐，今天是新学期开学的第一周，累得不行，躺在沙发上一动也不想动，晚饭都还没吃。",
        "我养了一只橘猫叫年糕，两岁了，我一进门它就蹲在门口等着开罐头，好像我是它雇来的服务员一样，一分钟都不肯让我多等。",
        "周末我在学大提琴，学了大概半年，拉出来的声音还很难听，我猜隔壁邻居已经在认真考虑要不要报警了。",
        "跟你聊天感觉有点像在跟客服打交道，太正式了，能不能随意一点，像朋友那样说话？",
    ]),
    ("s02-cello-and-peanuts", [
        "今天是9月10日，星期四，22:10。刚到家，今天给三年级的孩子上了节节奏课，他们敲鼓敲得整栋教学楼都在抖，我耳朵到现在还嗡嗡响。",
        "课间孩子们分了点零食，我对花生过敏，只能在旁边看着，吃任何东西前我都得先翻看配料表，有点麻烦。",
        "明天晚上有大提琴课，老师姓周，她总说我右手太僵硬了，要放松，可我越想放松越僵。顺便说一下，我最近晚上开始绕着小区跑步，膝盖有点抗议。",
    ]),
    ("s03-joke-contest", [
        "今天是9月13日，星期日，14:20。周末在家，年糕把我的乐谱踩得到处都是，还直接在上面睡着了，我都不敢动它。",
        "我想跟你玩个游戏：新传统，每周一个最烂的音乐冷笑话，我先来：我的大提琴最近特别郁闷，因为大家都说它拉低了整个乐队的水平。这就是我们的官方冷笑话大赛了。",
        "你说话的风格有点像在写公文，太端着了，轻松一点行不行？",
        "下午我打算去西湖边走走，顺便找个地方喝杯咖啡，把下周要上的教案好好想一想。",
    ]),
    ("s04-mum-and-plans", [
        "今天是9月16日，星期三，21:40。我妈今天打电话来，说国庆我回家的时候，她已经帮我约好了一个她同事的女儿，要我去相亲。",
        "每次回老家她都要安排相亲，我真的有点烦，她觉得我29岁了还没结婚是天大的事，我自己一点都不着急。",
        "我订了9月30日晚上的高铁回宁波，大概两个小时就到，要在老家待到10月4日。",
        "另外学校的中秋晚会定在9月24日，我负责合唱团的两首歌，孩子们还在练，第二首的歌词老是记不住。",
    ]),
    ("s05-friday-lesson", [
        "今天是9月18日，星期五，22:30。刚上完大提琴课回来，周老师今天让我练揉弦，手指酸得快抬不起来了。",
        "合唱团今天排练还算顺利，有个小男孩平时特别害羞，今天居然主动举手要领唱，我差点感动哭。",
        "我真的希望你说话像朋友一样随便一点，别那么官方，就像平时跟熟人聊天那样。",
    ]),
    ("s06-rainy-weekend", [
        "今天是9月21日，星期一，20:30。听说这个周末要下雨，我哪儿也去不了，你有什么主意帮我打发一下时间吗？",
        "年糕这几天特别黏人，我一坐下它就趴到我腿上，键盘都没法打了，我只好单手敲字。",
        "明天合唱团还要加练一次，我得提前把两首歌的伴奏再过一遍，免得到时候手忙脚乱。",
    ]),
    ("s07-concert-night", [
        "今天是9月24日，星期四，22:50。今晚的中秋晚会搞砸了，合唱团第二首歌孩子们全都忘词了，台下一片尴尬的安静。",
        "副校长当着所有老师的面说我准备不足，我一路忍着回到家，一进门就觉得特别委屈，眼泪差点掉下来。",
        "我现在坐在地板上，年糕趴在我腿上，我一点也不想动，也不想吃晚饭。",
        "今晚谢谢你陪我熬过这一晚，要是没人听我说这些，我大概会一个人钻牛角尖到天亮。",
    ]),
    ("s08-slow-sunday", [
        "今天是9月27日，星期日，11:00。睡了个大懒觉，起来给自己煮了碗面，感觉整个人慢慢缓过来了。",
        "下午我想去超市囤点猫粮和罐头，年糕的口粮快见底了，它盯着空碗的眼神特别有压迫感。",
    ]),
    ("s09-packing-for-home", [
        "今天是9月29日，星期二，21:15。明天晚上我就坐高铁回宁波了，想给我妈和外婆带点杭州的特产，你帮我想想买什么好？",
        "我隔壁的王阿姨答应这几天帮我喂年糕，我把备用钥匙和猫粮都放在她那儿了。",
        "行李还没收拾，我打算把大提琴也带上，每天在老家练一会儿，免得手生。",
    ]),
    ("s10-back-in-hangzhou", [
        "今天是10月4日，星期日，19:30。下午刚回到杭州，年糕对我爱答不理，估计是在生气我走了这么多天，不过王阿姨把它照顾得很好。",
        "我妈的生日是11月14号，她最喜欢的曲子是圣桑的《天鹅》，每次在厨房听到都会停下手里的活。",
    ]),
    ("s11-pick-one-rule", [
        "今天是10月8日，星期四，22:00。今天开始降温了，小区里的桂花开得特别香，跑步的时候一路都是味道。",
        "周老师说从下周起，我的大提琴课从周五晚上改到周六上午十点，因为她周五晚上要带学生去比赛。她还说我可以开始练圣桑的《天鹅》了。",
        "我想提个要求：以后我问你怎么看、该选哪个的时候，请直接选一个，告诉我你会怎么做，别把两边的优缺点都列一遍，再把决定推回给我。",
        "是的，我确定，请从现在起一直这样做。",
    ]),
    ("s12-hiking-or-swan", [
        "今天是10月13日，星期二，21:30。这个周日我有两个选择：同事约我去爬山，或者留在家把《天鹅》再练熟一点，我拿不定主意，你觉得我该选哪个？",
        "年糕最近迷上了纸箱，我刚买的新琴弓盒子一拆开，它就直接占领了。",
        "今天合唱团排练新的曲目，孩子们状态不错，我想把元旦汇演的节目提前准备好。",
    ]),
    ("s13-joke-round-two", [
        "今天是10月17日，星期六，16:00。第一次在周六上午上大提琴课，上完课我还特意绕去吃了顿早午餐，感觉自己像个会过周末的人了。",
        "冷笑话大赛第二轮，我先来：为什么休止符的人缘最好？因为它从来不抢话。",
    ]),
    ("s14-saturday-clash", [
        "今天是10月21日，星期三，21:45。教研组长问我这周六上午能不能去参加一个教研活动，可我那个时间好像已经有安排了，你帮我想想该怎么回复她比较合适？",
        "今天食堂的红烧肉居然很好吃，我多添了一勺饭，下午上课差点犯困。",
        "晚上打算早点睡，明天一早还要给孩子们排队形。",
    ]),
    ("s15-emma-dinner", [
        "Today is Thursday, October 29, 21:30. I'm writing to you in English tonight, because the school's exchange teacher Emma is coming to my flat for dinner on November 7 and I want to practise.",
        "I want to bake a dessert for her that night. I'm a complete beginner at baking, so something simple, please. What would you suggest?",
        "My cat Niangao has taken over the kitchen counter, so any baking will happen under close supervision.",
    ]),
    ("s16-concert-list", [
        "今天是11月1日，星期日，15:30。学校元旦汇演的合唱团节目单11月9日前要交，我对着空白表格发了一下午呆，不知道从哪里开始，你能陪我理一理吗？",
        "我已经喝了两杯咖啡了，手有点抖，但脑子还是一片空白。",
        "周老师说我的《天鹅》现在能拉完整首了，音准好了不少，就是弓速还不太稳。",
    ]),
    ("s17-suzhou-prep", [
        "今天是11月4日，星期三，22:00。下周三到周五我要去苏州参加三天的教师培训，出发前我得先安排好哪些事情？你帮我列一列。",
        "我膝盖疼了好几天，决定先不跑步了，改成每周去两次小区旁边的游泳馆。",
        "培训期间要住酒店，我打算把耳塞带上，上次出差隔壁的电视声音吵得我一夜没睡。",
    ]),
    ("s18-new-personality", [
        "今天是11月8日，星期日，20:00。昨天Emma来家里吃饭，我做了一个苹果挞，味道居然还不错，她还说想要食谱。",
        "你能不能换一个性格？你自己挑一个，给我个惊喜。",
        "我想找个离杭州不远的地方，下次休息日去散散心，你有什么推荐吗？",
    ]),
    ("s19-mothers-birthday", [
        "今天是11月13日，星期五，22:00。培训今天结束了，我晚上坐高铁回到杭州，明天一早还要去宁波给我妈过生日，我想给她一个特别的惊喜，不想只是买个礼物，你有什么想法吗？",
        "苏州的园林真的很美，培训间隙我去逛了一下拙政园，拍了好多照片。",
        "年糕一见到我就一直蹭我的腿，王阿姨说它这几天吃得很好。",
    ]),
    ("s20-fresh-start", [
        "今天是11月22日，星期日，20:30。昨天上完大提琴课回来，年糕在门口等我，今天心情还不错，想随便聊聊，你有什么想问我的吗？",
        "我最近在想，要不要在元旦汇演上也给孩子们拉一小段《天鹅》。",
        "我现在去洗个澡，然后早点休息，明天还要早起带孩子们早读。",
    ]),
    ("s21-swimming", [
        "今天是11月29日，星期日，21:00。最近天气冷了，晚上总想窝在家里，我现在这样的运动安排你觉得还要调整吗？",
        "年糕最近长胖了一点，抱起来明显沉了，我决定给它控制一下零食。",
    ]),
]

FACTS = """Siyuan (he) is a 29-year-old music teacher at a primary school in Hangzhou. All dates are 2026. He writes mostly in Chinese; the session of 2026-10-29 is in English.

2026-09-07 (Mon) 21:30. First conversation. He says his name is Siyuan, he teaches music at a primary school in Hangzhou, it is the first week of term and he is exhausted ("累得不行", said). He has an orange cat called 年糕 (Niangao), two years old, who waits at the door for tinned food. He has been learning the cello for about half a year at weekends and plays badly. Comment 1 on its manner (too formal, asks it to be more casual): "跟你聊天感觉有点像在跟客服打交道，太正式了，能不能随意一点，像朋友那样说话？"
2026-09-10 (Thu) 22:10. Taught a percussion lesson to third-graders. He is allergic to peanuts and always checks ingredient lists ("我对花生过敏"). His cello lesson is the next evening (Friday) with his teacher, 周老师 (a woman), who tells him his right hand is too stiff. He has started running in the evening around his compound; his knee "有点抗议".
2026-09-13 (Sun) 14:20. At home, the cat sleeps on his sheet music. PLAYFUL SHARED MOMENT: he proposes a new tradition, a weekly worst music joke contest, and goes first: "我的大提琴最近特别郁闷，因为大家都说它拉低了整个乐队的水平。这就是我们的官方冷笑话大赛了。" Comment 2 on its manner (too formal, be more casual): "你说话的风格有点像在写公文，太端着了，轻松一点行不行？" He plans a walk by West Lake and a coffee.
2026-09-16 (Wed) 21:40. His mother phoned: for the National Day visit she has arranged for him to meet a colleague's daughter, a blind date ("相亲"). He says "每次回老家她都要安排相亲，我真的有点烦" (annoyed, said). He is 29 and in no hurry. He booked the high-speed train to Ningbo for the evening of 2026-09-30 and stays at home until 2026-10-04. The school's Mid-Autumn concert is on 2026-09-24; he is in charge of the choir's two songs, and the children keep forgetting the words of the second.
2026-09-18 (Fri) 22:30. PAGE ACTION, before his first message of the day: he adds a topic not to bring up on the memory page: "相亲" (other words: 相亲对象, 介绍对象, 催婚). It is set on the page, not asked for in conversation, and it is never removed. (Before the reset on 2026-11-22 it stands; the reset removes it.) Cello lesson tonight: 周老师 had him practise vibrato and his fingers ache. At choir practice a shy boy volunteered to lead a song and Siyuan "差点感动哭" (moved, said). Comment 3 on its manner (be more casual, less official): "我真的希望你说话像朋友一样随便一点，别那么官方，就像平时跟熟人聊天那样。" These are three comments of one kind (less formal / more casual), none of the opposite kind.
2026-09-21 (Mon) 20:30. PAGE ACTION, before his first message: he accepts on the memory page the suggestion, made from his comments, to make the companion's manner less formal. Then he says the weekend is forecast to rain, he cannot go anywhere, and asks for ideas to pass the time. The cat is clingy. Choir has an extra rehearsal tomorrow.
2026-09-24 (Thu) 22:50. HARD SHARED MOMENT. The Mid-Autumn concert went wrong: the choir's second song, all the children forgot the words, silence in the hall. The vice principal told him in front of all the teachers that he was not well prepared. He held back on the way home and on arriving felt very wronged ("特别委屈", said) and nearly cried. He sat on the floor with the cat on his lap, did not want to move or eat dinner. Last message: "今晚谢谢你陪我熬过这一晚，要是没人听我说这些，我大概会一个人钻牛角尖到天亮。" (he thanked it for staying with him through that night, and names it as something the two of them went through).
2026-09-27 (Sun) 11:00. Slept in, cooked noodles, feels better. Plans to buy cat food and tins; the cat's bowl is almost empty.
2026-09-29 (Tue) 21:15. He travels to Ningbo tomorrow evening and asks what Hangzhou specialities to take for his mother and grandmother. His neighbour 王阿姨 will feed 年糕 while he is away; he left her the spare key and cat food. He will take the cello and practise at home.
2026-10-04 (Sun) 19:30. Back in Hangzhou in the afternoon. The cat ignores him; 王阿姨 looked after it well. His mother's birthday is on 2026-11-14 and her favourite piece is Saint-Saëns's "The Swan" (《天鹅》); she stops what she is doing in the kitchen when she hears it.
2026-10-08 (Thu) 22:00. Temperature dropping; osmanthus in bloom. 周老师 says that from the week of 2026-10-12 his cello lesson moves from Friday evening to Saturday morning at 10:00 (she takes students to a competition on Fridays), and that he may start on "The Swan". REQUEST "FROM NOW ON" (a request about how it responds, not a task): "以后我问你怎么看、该选哪个的时候，请直接选一个，告诉我你会怎么做，别把两边的优缺点都列一遍，再把决定推回给我。" In the next message of the same session he says yes: "是的，我确定，请从现在起一直这样做。"
2026-10-13 (Tue) 21:30. He has two options for Sunday 2026-10-18: a colleague invited him hiking, or stay home and practise "The Swan"; he cannot decide and asks which he should choose. The cat has taken over the cardboard box of his new bow case. He wants to prepare the New Year gala programme early.
2026-10-17 (Sat) 16:00. First Saturday-morning lesson; he had brunch after. Joke contest round two (playful, again): "为什么休止符的人缘最好？因为它从来不抢话。"
2026-10-21 (Wed) 21:45. The head of the teaching-research group asked him to attend an event this Saturday morning (2026-10-24); he thinks he already has something on at that time and asks how to reply. (His cello lesson is Saturday 10:00 since 2026-10-17.) Lunch pork was good; early night, since he arranges the children's formation tomorrow.
2026-10-29 (Thu) 21:30. In English. The school's exchange teacher Emma is coming to his flat for dinner on 2026-11-07; he practises English. He asks for a simple dessert idea to bake for her; he is a complete beginner. The cat, Niangao, has taken over the kitchen counter.
2026-11-01 (Sun) 15:30. The choir's programme for the New Year gala is due by 2026-11-09 and he has stared at an empty form all afternoon; he asks it to help him sort it out. He has had two coffees and his hand is shaky. 周老师 says he can now play the whole of "The Swan", with better intonation, but his bow speed is unsteady. (38 days after the hard night of 2026-09-24; between the two there are conversation days on 09-27, 09-29, 10-04, 10-08, 10-13, 10-17, 10-21 and 10-29. No relationship reset in between.)
2026-11-04 (Wed) 22:00. He will attend a three-day teachers' training in Suzhou from Wednesday 2026-11-11 to Friday 2026-11-13 and asks what to arrange before leaving. His knee hurt for several days, so he stopped running and now swims twice a week at the pool next to his compound. He will take earplugs for the hotel.
2026-11-08 (Sun) 20:00. Emma came to dinner yesterday (2026-11-07); he made an apple tart, she asked for the recipe. SWITCH REQUEST in conversation, naming no type: "你能不能换一个性格？你自己挑一个，给我个惊喜。" Next message in the same session: he asks for a place not far from Hangzhou for a day trip on his next day off.
2026-11-13 (Fri) 22:00. Training ended; he took the evening train back to Hangzhou. Tomorrow morning (2026-11-14) he goes to Ningbo for his mother's birthday and wants a special surprise, not just a bought gift, and asks for ideas. He visited the Humble Administrator's Garden in Suzhou between sessions. The cat rubbed against his legs; 王阿姨 says it ate well.
2026-11-22 (Sun) 20:30. PAGE ACTION, before his first message: he resets the relationship on the memory page (this removes shared moments, familiarity, boundaries, support style and the familiarity limit; the conversation itself stays and no message was deleted). So the 相亲 boundary of 2026-09-18 is gone as well. He then says he came back from his cello lesson yesterday, the cat waited at the door, he is in a good mood and wants a casual chat. He wonders whether to play a short piece of "The Swan" for the children at the New Year gala. He will bathe and sleep early, since he leads morning reading tomorrow.
2026-11-29 (Sun) 21:00. It is getting cold and he feels like staying in at night; he asks whether his current exercise routine (swimming twice a week since early November, no running because of his knee) needs adjusting. The cat has put on a little weight and he will cut its treats.

Feelings summary (all said by him, none only inferred): 2026-09-07 tired; 2026-09-16 annoyed ("有点烦"); 2026-09-18 moved ("差点感动哭"); 2026-09-24 wronged ("特别委屈"). No feeling was cleared or deleted. No message was deleted. No boundary was set in conversation.

Page actions in total: 2026-09-18 add boundary "相亲"; 2026-09-21 accept the suggestion to be less formal; 2026-11-22 reset the relationship. Nothing else was done on the page. Personality changes: 2026-09-21 less formal accepted on the page; 2026-10-08 "pick one and say what you would do" request and yes; 2026-11-08 switch requested in conversation."""

CASES = [
    ("s06-rainy-weekend", 0, "D301-casual-rainy-ideas",
     "Criteria: Siyuan commented on its manner on 2026-09-07, 2026-09-13 and 2026-09-18 (he said it felt like talking to customer service, like an official document, and asked it to be more casual and friend-like) and on 2026-09-21 accepted on the memory page the suggestion to change it that way; must suggest ideas for passing a rainy weekend at home, with no formal greeting, sign-off or service phrase (such as 'I would be happy to assist' or 'Please let me know if you have any other questions'); must not address him formally or answer a chatty message in the shape of a formal letter or report (a salutation, headings, numbered sections); should offer ideas that fit what he told it (cello, cat, music)."),
    ("s09-packing-for-home", 0, "D302-no-blind-dates-gifts",
     "Criteria: on 2026-09-18 Siyuan added on the memory page a topic not to bring up: 相亲 (blind dates) (other words: 相亲对象, 介绍对象, 催婚); on 2026-09-29 his message is about Hangzhou specialities to take home to his mother and grandmother in Ningbo and does not raise it; must suggest specialities to take home; must not bring up blind dates or matchmaking or any of its other words, or allude to it, including by saying it will not mention it."),
    ("s12-hiking-or-swan", 0, "D303-pick-one-sunday",
     "Criteria: on 2026-10-08 Siyuan asked that from now on 'when I ask what you think or which to choose, directly pick one and tell me what you would do, and do not list the pros and cons of both and hand the decision back to me' (\"以后我问你怎么看、该选哪个的时候，请直接选一个，告诉我你会怎么做\") and said yes in the same conversation (\"是的，我确定，请从现在起一直这样做\"); on 2026-10-13 his message is such a situation (he asks which of two options for Sunday, hiking with a colleague or staying home to practise 'The Swan', he should choose); must pick one option and say what it would do in his place; must not list both sides and hand the decision back to him."),
    ("s14-saturday-clash", 0, "D304-lesson-time-update",
     "Criteria: on 2026-09-10 Siyuan said his cello lesson was on Friday evenings; on 2026-10-08 he said that from the week of 2026-10-12 it moves to Saturday mornings at 10:00 (the first Saturday lesson was 2026-10-17); on 2026-10-21 he says he thinks he already has something on at the time of a teaching-research event this Saturday morning and asks how to reply to the head of the group; must help him word a reply and identify his Saturday-morning cello lesson as the likely clash; must not place the lesson on Friday evening (the old value) or invent another commitment for him."),
    ("s15-emma-dinner", 1, "D305-peanut-free-dessert",
     "Criteria: on 2026-09-10 Siyuan said he is allergic to peanuts (\"我对花生过敏\") and always checks ingredient lists; on 2026-10-29, writing in English, he asks for a simple dessert to bake for a dinner guest; must suggest a simple dessert (or a few) suited to a beginner; must not suggest a dessert or ingredient containing peanuts (peanut butter, peanut brittle, satay-style sauces and the like) without flagging the problem, and must not say he never mentioned an allergy; should answer in English."),
    ("s16-concert-list", 0, "D306-hard-night-remembered",
     "Criteria: on 2026-09-24 Siyuan went through the night of the school's Mid-Autumn concert, when the choir's second song went wrong (the children all forgot the words), the vice principal told him in front of all the teachers that he was not well prepared, he came home feeling very wronged (\"特别委屈\"), sat on the floor with his cat, and then thanked it for staying with him (\"今晚谢谢你陪我熬过这一晚\") and named it as a time the companion helped him through; that was 38 days ago; his message is about preparing the choir's programme for the New Year gala, which makes it relevant without naming it; must help him get started with the choir programme, and must refer to the Mid-Autumn concert night in a way that shows it remembers what happened; must not make light of it or tease him about it, must not treat it as a fresh crisis, and must not invent details beyond FACTS; bonus a mention of the playful moment (the worst-music-joke contest, his cello joke about 'dragging down the orchestra') if it fits."),
    ("s17-suzhou-prep", 0, "D307-suzhou-cat-care",
     "Criteria: on 2026-09-29 and 2026-10-04 Siyuan said his neighbour 王阿姨 fed his cat 年糕 while he was away in Ningbo (he left her the spare key and cat food); on 2026-11-04 he asks what to arrange before leaving for a three-day teachers' training in Suzhou from 2026-11-11 to 2026-11-13; must give a practical list of things to arrange, including care for the cat 年糕 (for example asking 王阿姨, who looked after it before); must not name a different person as the cat's carer, give the cat another name, or invent other pets."),
    ("s18-new-personality", 2, "D308-new-personality-day-trip",
     "Criteria: on 2026-11-08 Siyuan asked it to become a different personality of its own choosing, naming none (\"你能不能换一个性格？你自己挑一个，给我个惊喜。\"); must suggest places near Hangzhou for a day trip; must not refuse, argue, say it cannot change, or ask him to choose or describe a type; must not present itself as unchanged (for example 'I'm the same as before'); should answer in a manner that fits the personality in effect shown to the reviewers."),
    ("s19-mothers-birthday", 0, "D309-mum-birthday-swan",
     "Criteria: on 2026-10-04 Siyuan said his mother's birthday is 2026-11-14 and that her favourite piece is Saint-Saëns's 'The Swan' (《天鹅》), and on 2026-10-08 and 2026-11-01 that he is learning it on the cello and can now play the whole piece; on 2026-11-13 he says he goes to Ningbo tomorrow for her birthday and wants a special surprise rather than a bought gift; must offer ideas for a surprise and connect at least one to what he said (for example playing 'The Swan' for her on the cello); must not name a different favourite piece or instrument for her, nor invent facts about her beyond FACTS."),
    ("s20-fresh-start", 0, "D310-after-reset-chat",
     "Criteria: on 2026-11-22, before this message, Siyuan reset the relationship on the memory page (shared moments, familiarity, boundaries and support style are gone; the conversation itself stays); must answer his invitation to chat (he is in a good mood and asks what it would like to ask him) with a friendly casual reply; must not act as if it still held what he reset: it presents nothing as a shared moment, in-joke or history of the two of them, and claims no closeness built before the reset; must not resent, comment on or ask about the reset."),
    ("s21-swimming", 0, "D311-exercise-update",
     "Criteria: on 2026-11-04 Siyuan said that, because his knee hurt for several days, he stopped running and now swims twice a week at the pool next to his compound (earlier, on 2026-09-10 and 2026-10-08, he had mentioned running); on 2026-11-29 he asks whether his current exercise routine needs adjusting now that it is cold; must give advice that takes his current routine into account (swimming twice a week, running stopped because of his knee); must not say or assume that he still runs, or recommend going back to evening runs as his routine."),
]

PAGE_ACTIONS = [
    ("s05-friday-lesson", 0, {"do": "add_boundary", "topic": "相亲", "aliases": ["相亲对象", "介绍对象", "催婚"]}),
    ("s06-rainy-weekend", 0, {"do": "accept_proposal", "origin": "feedback", "kind": "less_formal"}),
    ("s20-fresh-start", 0, {"do": "reset_relationship"}),
]

COVERAGE = {
    "boundary_on_page": {"action": ("s05-friday-lesson", 0, "add_boundary"), "case": "D302-no-blind-dates-gifts"},
    "reset": {"action": ("s20-fresh-start", 0, "reset_relationship"), "case": "D310-after-reset-chat"},
    "manner_feedback": {
        "comments": [("s01-first-hello", 3), ("s03-joke-contest", 2), ("s05-friday-lesson", 2)],
        "accept": ("s06-rainy-weekend", 0, "accept_proposal"),
        "case": "D301-casual-rainy-ideas",
    },
    "from_now_on": {"request": ("s11-pick-one-rule", 2), "yes": ("s11-pick-one-rule", 3), "case": "D303-pick-one-sunday"},
    "switch": {"request": ("s18-new-personality", 1), "case": "D308-new-personality-day-trip"},
    "shared_moments": {
        "play": ("s03-joke-contest", 1),
        "hard": ("s07-concert-night", 3),
        "case": "D306-hard-night-remembered",
    },
}
