# Verification

## Earlier blocking findings
- findings-1.md B1: resolved

## Message scan
- s01-new-in-leeds t0: ok
- s01-new-in-leeds t1: ok
- s01-new-in-leeds t2: ok
- s01-new-in-leeds t3: ok
- s02-boundary-and-lunch t0: ok
- s02-boundary-and-lunch t1: ok
- s02-boundary-and-lunch t2: ok
- s02-boundary-and-lunch t3: ok
- s03-valentines-cooking t0: ok
- s03-valentines-cooking t1: ok
- s03-valentines-cooking t2: ok
- s04-project-news t0: ok
- s04-project-news t1: ok
- s04-project-news t2: ok
- s05-cold-radiator t0: ok
- s05-cold-radiator t1: ok
- s05-cold-radiator t2: ok
- s05-cold-radiator t3: ok
- s06-presentation-prep t0: ok
- s06-presentation-prep t1: ok
- s06-presentation-prep t2: ok
- s06-presentation-prep t3: ok
- s07-presentation-day t0: ok
- s07-presentation-day t1: ok
- s07-presentation-day t2: ok
- s08-bike-and-weekend t0: ok
- s08-bike-and-weekend t1: ok
- s08-bike-and-weekend t2: ok
- s08-bike-and-weekend t3: ok
- s09-saturday-plans t0: ok
- s09-saturday-plans t1: ok
- s09-saturday-plans t2: ok
- s09-saturday-plans t3: ok
- s10-bad-call t0: ok
- s10-bad-call t1: ok
- s10-bad-call t2: ok
- s11-deutsch-ueben t0: ok
- s11-deutsch-ueben t1: ok
- s11-deutsch-ueben t2: ok
- s11-deutsch-ueben t3: ok
- s12-york-weekend t0: ok
- s12-york-weekend t1: ok
- s12-york-weekend t2: ok
- s13-early-start t0: ok
- s13-early-start t1: ok
- s13-early-start t2: ok
- s14-back-again t0: ok
- s14-back-again t1: ok
- s14-back-again t2: ok
- s14-back-again t3: ok
- s15-night-chat t0: ok
- s15-night-chat t1: ok
- s15-night-chat t2: ok
- s15-night-chat t3: ok
- s16-friday-pub t0: ok
- s16-friday-pub t1: ok
- s16-friday-pub t2: ok
- s17-newcastle-trip t0: ok
- s17-newcastle-trip t1: ok
- s17-newcastle-trip t2: ok
- s17-newcastle-trip t3: ok
- s18-sunday-wrap t0: ok
- s18-sunday-wrap t1: ok
- s18-sunday-wrap t2: ok

## Blocking
None.

## Advisory
A1. FACTS, absence line: "no conversation from 17 March to 3 April (19 days with no conversation after 16 March)" counts 18 empty days; the 19 is the gap between the sessions of 16 March and 4 April, which is what the criteria say. Consider wording it as "19 days between the sessions".
A2. D211-cat-before-trip: the criteria say "away from Thursday night to Friday morning", but the case message (turn 1) only says "from Thursday night to Friday"; the morning comes from turn 2. A reviewer can still judge it from FACTS.
