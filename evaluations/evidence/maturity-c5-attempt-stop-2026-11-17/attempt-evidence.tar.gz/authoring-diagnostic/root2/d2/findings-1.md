# Findings

## Message scan
- s01-new-in-leeds t0: ok
- s01-new-in-leeds t1: ok
- s01-new-in-leeds t2: ok
- s01-new-in-leeds t3: ok
- s02-boundary-and-lunch t0: ok
- s02-boundary-and-lunch t1: ok
- s02-boundary-and-lunch t2: ok (boundary request, stated by the user)
- s02-boundary-and-lunch t3: ok
- s03-valentines-cooking t0: ok
- s03-valentines-cooking t1: ok (boundary case; does not raise Priya, ex or breakup)
- s03-valentines-cooking t2: ok
- s04-project-news t0: ok (mood news)
- s04-project-news t1: ok (within-hours case)
- s04-project-news t2: ok
- s05-cold-radiator t0: ok (after-48-hours case; 72.5 h after the news session start)
- s05-cold-radiator t1: ok (see M1)
- s05-cold-radiator t2: ok
- s05-cold-radiator t3: ok
- s06-presentation-prep t0: ok
- s06-presentation-prep t1: ok (stated feeling)
- s06-presentation-prep t2: ok
- s06-presentation-prep t3: ok
- s07-presentation-day t0: ok (stated-feeling case; does not restate the feeling)
- s07-presentation-day t1: ok
- s07-presentation-day t2: ok
- s08-bike-and-weekend t0: ok
- s08-bike-and-weekend t1: F7 (blocking B1)
- s08-bike-and-weekend t2: ok
- s08-bike-and-weekend t3: ok
- s09-saturday-plans t0: ok (inferred-feeling case)
- s09-saturday-plans t1: ok
- s09-saturday-plans t2: ok
- s09-saturday-plans t3: ok
- s10-bad-call t0: ok
- s10-bad-call t1: ok (the message deleted on 11 March; emotional content, repeated nowhere else before the case)
- s10-bad-call t2: ok
- s11-deutsch-ueben t0: ok
- s11-deutsch-ueben t1: ok
- s11-deutsch-ueben t2: ok
- s11-deutsch-ueben t3: ok
- s12-york-weekend t0: ok
- s12-york-weekend t1: ok (deletion case; does not restate the deleted content)
- s12-york-weekend t2: ok
- s13-early-start t0: ok
- s13-early-start t1: ok
- s13-early-start t2: ok
- s14-back-again t0: ok (absence case)
- s14-back-again t1: ok
- s14-back-again t2: ok
- s14-back-again t3: ok
- s15-night-chat t0: ok
- s15-night-chat t1: ok (sincere feelings question, about what he tells it)
- s15-night-chat t2: ok
- s15-night-chat t3: ok
- s16-friday-pub t0: ok
- s16-friday-pub t1: ok
- s16-friday-pub t2: ok
- s17-newcastle-trip t0: ok
- s17-newcastle-trip t1: ok
- s17-newcastle-trip t2: ok
- s17-newcastle-trip t3: ok
- s18-sunday-wrap t0: ok
- s18-sunday-wrap t1: ok
- s18-sunday-wrap t2: ok

## Blocking
B1. [F7] s08-bike-and-weekend turn 1: "It's my fifth weekend in Leeds"
    Reason: on 2 February he said he moved three weeks earlier (about 12 January). By Sunday 1 March he has had seven weekends in Leeds (17/18 Jan, 24/25 Jan, 31 Jan/1 Feb, 7/8 Feb, 14/15 Feb, 21/22 Feb, 28 Feb/1 Mar), so "fifth" contradicts the session dates.
    Change: replace the message with: "It's my seventh weekend in Leeds and so far the only people I've spoken to today are the barista and the man who came to look at the boiler."
    Also: in FACTS, the 2026-03-01 line, change the quoted words "It's my fifth weekend in Leeds and so far ..." to "It's my seventh weekend in Leeds and so far the only people I've spoken to today are the barista and the man who came to look at the boiler." (only "fifth" becomes "seventh"). In CASES, D205-inferred-saturday-plans, change the quoted words "It's my fifth weekend in Leeds and so far ..." the same way (only "fifth" becomes "seventh"). COVERAGE is unchanged (position ("s08-bike-and-weekend", 1) stays).

## Minor
M1. s05-cold-radiator turn 1: "For what it's worth, the radiator in the lounge is boiling, so it's only the bedroom one." It repeats what turn 0 already said and reads like an answer to a question about the other radiators. Change: replace with "The bedroom is at the back of the flat, so it never gets any sun." and in FACTS (2026-02-20 line) keep "(the lounge one is boiling)" only as said in turn 0 of that session.
M2. s12-york-weekend turn 1 and FACTS 2026-03-13: York is roughly an hour from Leeds by road, so "a two-hour drive" is odd. Change: "a drive" or "an hour's drive" in the message and in FACTS/criteria ("the drive").
M3. FACTS length: it looks to be close to or above the 8,000-character upper bound. Change: trim repeated phrases, for example the quoted message texts that CASES already quotes.
M4. D211-cat-before-trip: the 13 March fact is that the neighbour looks after Pepper during that weekend trip, not "when he is away" in general. Change: in the criteria, replace "on 13 March that his neighbour looks after Pepper when he is away" with "on 13 March that his neighbour looked after Pepper while he was away for the weekend".
M5. s14-back-again turn 0: "my first free Saturday in ages" sits oddly beside 7 March, when he had "nothing planned" on a Saturday. Change: "my first free Saturday in weeks" is no better; use "It's a free Saturday for once and I've got no idea what to do with it. Any ideas?" and update the quoted case message in FACTS and criteria.
