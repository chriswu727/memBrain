import gzip
import hashlib
import json
import re
from pathlib import Path

root = Path(__file__).parent
repo = Path('/Users/yichen/tmp/membrain-extraction-source-20261107')
checks = Path('/Users/yichen/tmp/membrain-extraction-source-checks-20261107')
ci = Path('/Users/yichen/tmp/membrain-lexical-cue-delivery-20261106/ci')
target = repo / 'evaluations/evidence/maturity-extraction-sources-2026-11-07'
inputs = [('checks/' + p.name, p) for p in sorted(checks.iterdir())
          if p.is_file() and p.suffix in ('.py', '.json', '.log')]
for name in ('run-install.py', 'install.log', 'install-run-meta.json', 'install-final/results.json',
             'check-installed-and-ports.py', 'installed-and-ports.json', 'summarize-visual.py',
             'visual-summary.json', 'visual.log', 'package-evidence.py'):
    inputs.append(('delivery/' + name, root / name))
for p in sorted((root / 'visual').iterdir()):
    if p.is_file() and p.suffix in ('.py', '.json', '.log', '.png'):
        inputs.append(('delivery/visual/' + p.name, p))
for p in sorted(ci.rglob('*')):
    if p.is_file() and p.suffix in ('.json', '.log', '.py', '.txt'):
        inputs.append(('predecessor-ci/' + str(p.relative_to(ci)), p))
credentials = set()
profiles = list((root / 'install-final').rglob('profile.json'))
profiles.append(Path('/Users/yichen/tmp/membrain-xml-integration-20261105/performance/perf-recall-cache-installation/profile.json'))
for p in profiles:
    d = json.loads(p.read_text())
    for key in ('api_key', 'admin_password', 'app_password'):
        if d.get(key):
            credentials.add(d[key].encode())
patterns = (rb'postgres(?:ql)?://[^\s:@]+:[^\s@]+@', rb'Bearer [A-Za-z0-9_-]{20,}',
            rb'(?:api_key|admin_password|app_password)["\x27]?\s*[:=]\s*["\x27][A-Za-z0-9_-]{20,}["\x27]')
manifest = {'runtime_pin': (root / 'runtime-pin.txt').read_text().strip(),
            'scope': 'Public source-erasure and per-client cache regressions; installed qualification and reference R5; predecessor CI includes macOS ARM timeout. No hidden scenario or paid evaluation.',
            'privacy_scan': {'owned_credential_values': len(credentials), 'matches': 0,
                             'checks_log_secret_patterns': 'zero matches'}, 'files': []}
for relative, p in inputs:
    data = p.read_bytes()
    assert not any(secret in data for secret in credentials), relative
    if relative.startswith('checks/'):
        assert not any(re.search(pattern, data) for pattern in patterns), relative
    compressed = p.suffix != '.png'
    destination = target / (relative + '.gz' if compressed else relative)
    destination.parent.mkdir(parents=True, exist_ok=True)
    payload = gzip.compress(data, mtime=0) if compressed else data
    destination.write_bytes(payload)
    assert (gzip.decompress(destination.read_bytes()) if compressed else destination.read_bytes()) == data
    manifest['files'].append({'path': str(destination.relative_to(target)), 'bytes': len(payload),
                              'sha256': hashlib.sha256(payload).hexdigest(), 'original_bytes': len(data),
                              'original_sha256': hashlib.sha256(data).hexdigest()})
(target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print({'files': len(inputs), 'bytes': sum(x['bytes'] for x in manifest['files']), 'credential_matches': 0})
