import json
from pathlib import Path
root=Path(__file__).parent
r=json.loads((root/'visual/visual-permissions-abba.json').read_text())
m=json.loads((root/'visual/visual-command.json').read_text())
names=('serial','one_brain_8_concurrent','eight_brains_8_concurrent')
assert r['completed'] and r['passed'] and len(r['phases'])==4
assert m['completed'] and m['exit_code']==0 and m['source_and_driver_unchanged'] and m['all_ports_closed']
windows=[c[n] for p in r['phases'] for c in p['cycles'] for n in names]
assert len(windows)==36 and sum(w['n'] for w in windows)==4080
assert all(w['n']==w['nonempty'] for w in windows)
summary={'runtime_pin':r['runtime_pin'],'windows':len(windows),'nonempty':sum(w['nonempty'] for w in windows),
 'worst_window_p95_ms':{n:max(c[n]['p95_ms'] for p in r['phases'] for c in p['cycles']) for n in names},
 'open_phases':[{k:p.get(k) for k in ('nodes','edges','renderer','hologram_frames','document_visible','page_errors','external_requests')} for p in r['phases'] if p['mode']=='open'],
 'browser':r['browser'],'source_and_driver_unchanged':True,'all_ports_closed':True}
(root/'visual-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
