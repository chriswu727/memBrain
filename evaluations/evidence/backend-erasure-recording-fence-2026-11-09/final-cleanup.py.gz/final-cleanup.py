import gzip,hashlib,json,os,shutil,subprocess
from pathlib import Path
prefix='membrain-erasure-fence-'
tmp=Path('/private/tmp')
root=Path('evaluations/evidence/backend-erasure-recording-fence-2026-11-09')
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((root/'local-manifest.json').read_text())
indexed={v['path']:v for v in manifest['files']}
for v in indexed.values():
 packed=(root/v['path']).read_bytes()
 assert sha(packed)==v['gzip_sha256'] and sha(gzip.decompress(packed))==v['stored_sha256']
q=json.loads((root/'qualification-receipt.json').read_text())
assert sha(gzip.decompress((root/'verify.log.gz').read_bytes()))==q['redacted_log_sha256']
paths=sorted(tmp.glob(prefix+'*'))
assert all(not p.is_symlink() for p in paths)
assert {p.name for p in paths if p.is_dir()}=={prefix+'qualification',prefix+'native-audit'}
for p in paths:
 if p.is_dir():continue
 raw=p.read_bytes()
 if p.name==prefix+'collect.py':
  (root/'collect.py.gz').write_bytes(gzip.compress(raw,mtime=0))
  assert gzip.decompress((root/'collect.py.gz').read_bytes())==raw
 elif p.name==prefix+'verify-job-full.log':assert sha(raw)==q['raw_log_sha256']
 else:
  name=p.name.removeprefix(prefix)
  if not name.endswith('.gz'):name+='.gz'
  assert sha(raw)==indexed[name]['raw_sha256'],p
qualification=tmp/(prefix+'qualification')
assert [p.name for p in qualification.iterdir()]==['identity.json']
assert sha((qualification/'identity.json').read_bytes())==indexed['identity.json.gz']['raw_sha256']
native=tmp/(prefix+'native-audit')
nmanifest=json.loads((root/'native/manifest.json').read_text())
assert {p.relative_to(native).as_posix() for p in native.rglob('*') if p.is_file()}=={v['path'].removesuffix('.gz') for v in nmanifest['files']}
for v in nmanifest['files']:
 raw=(native/v['path'].removesuffix('.gz')).read_bytes()
 assert sha(raw)==v['sha256'] and gzip.decompress((root/'native'/v['path']).read_bytes())==raw
processes=subprocess.check_output(['ps','-axo','pid=,command='],text=True)
for line in processes.splitlines():
 pid,command=line.strip().split(None,1)
 if int(pid) in {os.getpid(),os.getppid()}:continue
 assert not (prefix in command and any(term in command for term in ('postgres -D','uvicorn','pytest','latency.py','run-tests.py'))),line
removed=[]
for p in paths:
 size=sum(x.stat().st_size for x in p.rglob('*') if x.is_file()) if p.is_dir() else p.stat().st_size
 if p.is_dir():shutil.rmtree(p)
 else:p.unlink()
 removed.append({'name':p.name,'bytes':size})
for p in (tmp/'__pycache__').glob(prefix+'*.pyc'):
 size=p.stat().st_size;p.unlink();removed.append({'name':'__pycache__/'+p.name,'bytes':size})
assert not list(tmp.glob(prefix+'*'))
receipt={'raw_evidence_verified_before_removal':True,'removed':removed,'removed_bytes':sum(x['bytes'] for x in removed),'free_bytes_after':shutil.disk_usage(tmp).free,'retained':'Compressed evidence, real profiles, backups, models, source worktrees and shared development environment.'}
(root/'final-cleanup.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='removed'}))
