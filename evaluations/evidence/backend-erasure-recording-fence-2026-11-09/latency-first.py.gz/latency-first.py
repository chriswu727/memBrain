import json, os, shutil, statistics, subprocess, time
from pathlib import Path
os.environ['PYTHON_DOTENV_DISABLED']='1'
os.environ['MEMBRAIN_SEMANTIC']='0'
from membrain import desktop, host
from membrain.build_identity import BUILD_ID
from membrain.desktop_connection import open_client
from membrain.runtime import BrainRuntime, DeliveryReceipt
root=Path('/private/tmp/membrain-erasure-fence-latency-profile')
assert not root.exists()
assert shutil.disk_usage(root.parent).free>2*1024**3
result={'build_id':BUILD_ID,'warmups':4,'measured_turns':20,'provider_calls':0,'semantic_enabled':False,'milliseconds':[]}
try:
    host.start(root)
    with open_client(root,start_service=False) as client:
        runtime=BrainRuntime(client,lambda _: 'Public fixed response.',deliver=lambda _: DeliveryReceipt('delivered'))
        for index in range(24):
            started=time.perf_counter()
            response=runtime.respond('Public fixture input '+str(index),message_id=str(index),conversation_id='public-latency')
            elapsed=(time.perf_counter()-started)*1000
            assert response.stage=='completed' and response.text=='Public fixed response.'
            if index>=4:result['milliseconds'].append(elapsed)
    result['median_ms']=statistics.median(result['milliseconds'])
    result['p95_ms']=sorted(result['milliseconds'])[18]
finally:
    desktop.stop(root)
    assert not list(root.rglob('postmaster.pid'))
    processes=subprocess.check_output(['ps','-eo','pid,command'],text=True).splitlines()
    assert not any(str(root) in p for p in processes if p.split()[0]!=str(os.getpid()))
    result['temporary_bytes_removed']=sum(p.stat().st_size for p in root.rglob('*') if p.is_file() and not p.is_symlink())
    shutil.rmtree(root)
print(json.dumps(result))
