import gzip,hashlib,json,re,subprocess
from pathlib import Path
from membrain.privacy import scrub
root=Path('evaluations/evidence/backend-erasure-recording-fence-2026-11-09')
source='a78bd088d57651093860a27505b79bf75bc409c1'
rawpath=Path('/private/tmp/membrain-erasure-fence-verify-final-failed-full.log')
raw=rawpath.read_bytes();text=raw.decode()
assert '1 failed, 8213 passed, 3 warnings in 2778.23s' in text
meta=json.loads(Path('/private/tmp/membrain-erasure-fence-verify-final-failed-status.json').read_text())
assert meta['conclusion']=='failure' and meta['headSha']==source
redacted=re.sub(r'(::test[^\[\n]+)\[.*\](?=\s+(?:PASSED|FAILED|SKIPPED|XFAIL|XPASS))',r'\1[parameters redacted]',text)
stored=('\n'.join(line.rstrip() for line in scrub(redacted).splitlines()).rstrip()+'\n').encode()
(root/'verify.log.gz').write_bytes(gzip.compress(stored,mtime=0))
(root/'verify-status.json').write_text(json.dumps(meta,indent=2)+'\n')
rawpath.rename('/private/tmp/membrain-erasure-fence-verify-job-full.log')
receipt={'verify_run_id':42592289236,'verify_job_id':meta['jobs'][0]['databaseId'],'verify_conclusion':'failure','source_commit':source,'source_tree':subprocess.check_output(['git','rev-parse',source+'^{tree}'],text=True).strip(),'python_passed':8213,'python_failed':1,'python_warnings':3,'python_seconds':2778.23,'failed_test':'tests/test_longitudinal_evaluation.py::test_complete_scenario_through_real_loopback_http_has_no_automatic_semantic_pass','failure':'httpx.RemoteProtocolError: Server disconnected without sending a response during GET runtime/cognitive-usage; root cause unconfirmed.','typescript_status':'not_run_after_pytest_failure','ci_build_status':'not_run_after_pytest_failure','targeted_source_passed':502,'targeted_installed_passed':502,'matrix_tests_passed':2,'isolated_http_diagnostic_passed':1,'native_qualification_run_id':42587958963,'native_source_commit':'10b0b5b6a21a15a574a325e511f73675058a9b2b','native_conclusion':'success','native_logical_summaries':47,'native_reused_binary_run_id':42574397718,'raw_log_sha256':hashlib.sha256(raw).hexdigest(),'redacted_log_sha256':hashlib.sha256(stored).hexdigest(),'merged':False,'release_ready':False}
(root/'qualification-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
for name in ('final-docs','pr-bodies','finalize-ci'):
 Path('/private/tmp/membrain-erasure-fence-'+name+'.py').unlink()
print(json.dumps(receipt,indent=2))
