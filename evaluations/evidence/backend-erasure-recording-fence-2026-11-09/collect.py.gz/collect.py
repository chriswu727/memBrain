import gzip,hashlib,json,re
from pathlib import Path
from membrain.privacy import scrub
root=Path('evaluations/evidence/backend-erasure-recording-fence-2026-11-09');root.mkdir(parents=True,exist_ok=True)
prefix='membrain-erasure-fence-';tmp=Path('/private/tmp')
paths=[p for p in tmp.glob(prefix+'*') if p.is_file() and p.name not in (Path(__file__).name,prefix+'verify-job-full.log')]
paths+=list((tmp/(prefix+'qualification')).glob('identity*.json'))
files=[]
for path in sorted(paths):
 raw=path.read_bytes();content=gzip.decompress(raw) if path.suffix=='.gz' else raw
 value=re.sub(r'(::test[^\[\n]+)\[.*\](?=\s+(?:PASSED|FAILED|SKIPPED|XFAIL|XPASS))',r'\1[parameters redacted]',content.decode())
 stored=('\n'.join(line.rstrip() for line in scrub(value).splitlines()).rstrip()+'\n').encode();packed=gzip.compress(stored,mtime=0)
 name=path.name.removeprefix(prefix)
 if not name.endswith('.gz'):name+='.gz'
 (root/name).write_bytes(packed)
 files.append({'path':name,'raw_sha256':hashlib.sha256(raw).hexdigest(),'stored_sha256':hashlib.sha256(stored).hexdigest(),'gzip_sha256':hashlib.sha256(packed).hexdigest()})
identity=json.loads((tmp/(prefix+'qualification')/'identity.json').read_text())
record={'identity':identity,'source_passed':502,'installed_passed':502,'notes':'Targeted replacement source batches (93+409) and installed replacement batch (502) pass for runtime 154ec713. Final CI 42592289236 still fails one HTTP test (8213 passed); isolated local pass does not clear that result. PR58 is unmerged. First-candidate logs and failed Verify 42581404998 retain runtime e14d84f scope. Earlier failing/intermediate outputs retain their original scope. Original/stored hashes may differ after privacy scrubbing. No paid or subscription-backed evaluation. The latency probe excludes providers, semantic models and network transport; it is not recall R5.','files':files}
(root/'local-manifest.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'logs':len(files),'bytes':sum(p.stat().st_size for p in root.rglob('*') if p.is_file())}))
