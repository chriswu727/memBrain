import json, os, shutil, statistics, subprocess, time
from pathlib import Path
os.environ['PYTHON_DOTENV_DISABLED']='1'
os.environ['MEMBRAIN_SEMANTIC']='0'
from membrain import desktop, host
from membrain.build_identity import BUILD_ID
from contextlib import contextmanager
from dataclasses import replace
import httpx
from fastapi.testclient import TestClient
from membrain.api import create_app
from membrain.client import MemoryClient
from membrain.local_profile import ensure_profile
from membrain.recovery_profile import authority_for
from membrain.service import MemoryService
from membrain.storage import Database

@contextmanager
def open_client(root):
    profile=ensure_profile(root,database_engine='embedded')
    desktop._prepare_database(profile)
    database=Database(profile.database_url,profile.migration_database_url)
    database.recovery_authority=authority_for(profile)
    service=MemoryService(database)
    with TestClient(create_app(replace(profile.settings(),allowed_hosts=('testserver',),recall_processes=0),service=service)) as api:
        def forward(request):
            response=api.request(request.method,request.url.path,headers=dict(request.headers),content=request.content)
            return httpx.Response(response.status_code,content=response.content,headers=dict(response.headers))
        with MemoryClient('http://testserver',profile.api_key,profile.brain_id,transport=httpx.MockTransport(forward)) as client:
            yield client
from membrain.runtime import BrainRuntime, DeliveryReceipt
root=Path('/private/tmp/membrain-erasure-fence-latency-profile')
assert not root.exists()
assert shutil.disk_usage(root.parent).free>2*1024**3
result={'build_id':BUILD_ID,'warmups':4,'measured_turns':20,'provider_calls':0,'semantic_enabled':False,'milliseconds':[]}
try:
    with open_client(root) as client:
        runtime=BrainRuntime(client,lambda _: 'Public fixed response.',deliver=lambda _: DeliveryReceipt('delivered'))
        for index in range(24):
            started=time.perf_counter()
            response=runtime.respond('Public fixture input '+str(index),message_id=str(index),conversation_id='public-latency')
            elapsed=(time.perf_counter()-started)*1000
            assert response.stage=='completed' and response.text=='Public fixed response.'
            if index>=4:result['milliseconds'].append(elapsed)
    result['median_ms']=statistics.median(result['milliseconds'])
    result['p95_ms']=sorted(result['milliseconds'])[18]
finally:
    desktop.stop(root)
    assert not list(root.rglob('postmaster.pid'))
    processes=subprocess.check_output(['ps','-eo','pid,command'],text=True).splitlines()
    assert not any(str(root) in p for p in processes if p.split()[0]!=str(os.getpid()))
    result['temporary_bytes_removed']=sum(p.stat().st_size for p in root.rglob('*') if p.is_file() and not p.is_symlink())
    shutil.rmtree(root)
    Path('/private/tmp/membrain-erasure-fence-latency-lifecycle.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
