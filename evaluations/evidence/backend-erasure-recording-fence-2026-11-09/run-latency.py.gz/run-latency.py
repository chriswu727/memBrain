import io,json,os,subprocess,tarfile
from pathlib import Path
root=Path('/private/tmp/membrain-erasure-fence-baseline')
assert (root/'src/membrain/runtime.py').is_file()
variants={'baseline':str(root/'src'),'candidate':'/private/tmp/membrain-erasure-fence-qualification/wheel'}
results=[]
for variant in ('baseline','candidate','candidate','baseline'):
    env={**os.environ,'PYTHONPATH':variants[variant]}
    proc=subprocess.run(['.venv/bin/python','/private/tmp/membrain-erasure-fence-latency.py'],env=env,capture_output=True,text=True)
    log=Path('/private/tmp/membrain-erasure-fence-latency-'+str(len(results))+'.log');log.write_text(proc.stdout+proc.stderr)
    assert proc.returncode==0,log
    result=json.loads(proc.stdout.splitlines()[-1]);result['variant']=variant
    expected={'baseline':'ae0c1662a3663bc52d7300dedc407b08fecdaaf05419ffc3b07a5264244920d8','candidate':'4a0f88f51dcd54346fe6e04cefc25e054cc64a33eb95a52fb6382fab9e1fa181'}
    assert result['build_id']==expected[variant]
    results.append(result)
    print(json.dumps({k:v for k,v in result.items() if k!='milliseconds'}),flush=True)
Path('/private/tmp/membrain-erasure-fence-latency.json').write_text(json.dumps({'protocol':'ABBA fresh profiles; 4 warmups and 20 measured serial turns per run; fixed local generation/delivery callbacks; in-process HTTP dispatch and real PostgreSQL; network excluded; no provider or semantic model; not recall R5','runs':results},indent=2)+'\n')
