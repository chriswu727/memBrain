import hashlib,json,os,shutil,subprocess
from pathlib import Path
from membrain.build_identity import BUILD_ID,package_manifest,manifest_digest
root=Path('/private/tmp/membrain-erasure-fence-qualification')
identity=json.loads((root/'identity.json').read_text())
assert BUILD_ID==identity['build_id']
wheel=root/'wheel'
assert manifest_digest(package_manifest(wheel/'membrain',root))==BUILD_ID
baseline=Path('/private/tmp/membrain-erasure-fence-baseline')
assert manifest_digest(package_manifest(baseline/'src/membrain',baseline))=='ae0c1662a3663bc52d7300dedc407b08fecdaaf05419ffc3b07a5264244920d8'
dist=Path.cwd()/'dist';files=list(dist.iterdir())
assert len(files)==3 and (dist/'.gitignore').read_bytes()==b'*'
whl=next(dist.glob('*.whl'));sdist=next(dist.glob('*.tar.gz'))
assert hashlib.sha256(whl.read_bytes()).hexdigest()==identity['wheel_sha256']
record={'build_id':BUILD_ID,'sdist_sha256':hashlib.sha256(sdist.read_bytes()).hexdigest(),'removed':[]}
processes=subprocess.check_output(['ps','-eo','pid,command'],text=True).splitlines()
for path in (baseline,wheel,dist):
    assert not path.is_symlink() and not list(path.rglob('postmaster.pid'))
    assert not any(str(path) in p for p in processes if p.split()[0]!=str(os.getpid())),path
    size=sum(p.stat().st_size for p in path.rglob('*') if p.is_file() and not p.is_symlink())
    shutil.rmtree(path)
    record['removed'].append({'path':str(path),'bytes':size})
    Path('/private/tmp/membrain-erasure-fence-replacement-build-cleanup.json').write_text(json.dumps(record,indent=2)+'\n')
record['free_bytes_after']=shutil.disk_usage(root).free
Path('/private/tmp/membrain-erasure-fence-replacement-build-cleanup.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
