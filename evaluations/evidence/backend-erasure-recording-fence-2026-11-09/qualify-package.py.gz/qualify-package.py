import hashlib, json, subprocess, zipfile
from pathlib import Path
import membrain
from membrain.build_identity import BUILD_ID, SCHEMA_ID, package_manifest, manifest_digest
root=Path('/private/tmp/membrain-erasure-fence-qualification')
assert not root.exists()
root.mkdir()
wheels=list(Path('dist').glob('*.whl'));assert len(wheels)==1
wheel=wheels[0]
with zipfile.ZipFile(wheel) as archive:
    for member in archive.namelist():
        assert not Path(member).is_absolute() and '..' not in Path(member).parts
    archive.extractall(root/'wheel')
source=package_manifest(Path(membrain.__file__).parent,Path.cwd())
installed=package_manifest(root/'wheel/membrain',root)
assert source==installed and manifest_digest(installed)==BUILD_ID
record={'runtime_commit':'154ec713e85a3bb90a00997fb6be2248ad0d0fc8','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'build_id':BUILD_ID,'schema_id':SCHEMA_ID,'runtime_inputs':len(source),'wheel_parity':True,'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest()}
(root/'identity.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
