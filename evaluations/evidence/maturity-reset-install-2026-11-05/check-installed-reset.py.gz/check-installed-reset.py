import json
import re
from pathlib import Path

from membrain import desktop, host, notes
from membrain.build_identity import BUILD_ID
from membrain.host_context import snapshot

ROOT = Path(__file__).parent
REPORT = ROOT / 'installed-reset.json'


def main():
    frozen = json.loads((ROOT / 'frozen-inputs.json').read_text())
    installed = json.loads((ROOT / 'installed-and-ports.json').read_text())
    directory = next(Path(p['directory']) for p in installed['profiles']
                     if Path(p['directory']) == ROOT / 'install-final/restored')
    report = {'completed': False, 'build': BUILD_ID, 'runtime': frozen['runtime'],
              'paid_model_calls': 0, 'checks': []}

    def check(name, passed):
        report['checks'].append({'name': name, 'passed': bool(passed)})
        REPORT.write_text(json.dumps(report, indent=2) + '\n')
        assert passed, name

    def automatic(text):
        return '\n'.join(re.findall(r'<membrain-(?:notes|coming-up)>.*?</membrain-(?:notes|coming-up)>',
                                    text or '', re.DOTALL))

    check('installed build matches frozen candidate', BUILD_ID == frozen['build'])
    user = 'installed-reset-context'
    try:
        host.start(directory)
        with host.ready_client(directory, user) as client:
            notes.save_note(client, 'Send the old recipe.', kind='agent_commitment', status='intended', due='2025-03-10')
            notes.save_note(client, 'Visit the museum.', kind='plan', status='scheduled')
            before = host.session_context(directory, 'reset-live', user_id=user)
            check('old promise initially reaches automatic context', 'Send the old recipe.' in automatic(before))
            client.reset_relationship()
            refreshed = host.prompt_context(directory, 'reset-live', 'Hello again.', turn_id='reset-turn', user_id=user)
            check('same-session reset refresh is delivered', 'Saved memory has been refreshed' in (refreshed or ''))
            check('same-session automatic context drops old promise', 'Send the old recipe.' not in automatic(refreshed))
            check('same-session ordinary plan remains', 'Visit the museum.' in automatic(refreshed))
            host.finish_turn(directory, 'reset-live', 'Hello.', turn_id='reset-turn', user_id=user)
            notes.save_note(client, 'Send the new map.', kind='agent_commitment', status='intended')
            later = host.session_context(directory, 'reset-new-session', user_id=user)
            check('new-session automatic context drops old promise', 'Send the old recipe.' not in automatic(later))
            check('new promise and ordinary plan remain', all(x in automatic(later) for x in ('Send the new map.', 'Visit the museum.')))
            check('old note is still stored as history', any('Send the old recipe.' in item['text'] for item in notes.list_notes(client)['items']))
            for index in (1, 2):
                archive = client.export()['result']
                target = client.create_brain(f'Installed reset restore {index}')['id']
                restored = client.restore(archive['archive_id'], expected_manifest_sha256=archive['manifest_sha256'],
                                          expected_scope_generation=1, mode='new_brain', brain_id=target)
                check(f'restore {index} completes', restored['outcome'] == 'completed')
                client.brain_id = target
                saved = notes.list_notes(client)
                rendered = snapshot(saved, brain_id=target, tools=None, relationship=client.relationship())['text']
                check(f'restore {index} omits only old automatic promise', 'Send the old recipe.' not in automatic(rendered)
                      and all(x in automatic(rendered) for x in ('Send the new map.', 'Visit the museum.')))
                check(f'restore {index} keeps historical note', any('Send the old recipe.' in item['text'] for item in saved['items']))
        report['completed'] = True
    finally:
        desktop.stop(directory)
        REPORT.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'completed': report['completed'], 'checks': len(report['checks']),
                      'build': BUILD_ID, 'paid_model_calls': 0}))


if __name__ == '__main__':
    main()
