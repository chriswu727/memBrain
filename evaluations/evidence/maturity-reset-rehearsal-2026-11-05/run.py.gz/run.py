import hashlib,json,os,subprocess
from pathlib import Path
root=Path(__file__).parent
repo=Path('/Users/yichen/tmp/membrain-review-20261029')
python=repo/'.venv/bin/python'
files=['evaluations/c5-run-scenario.sh','evaluations/c5-harness.py','evaluations/c5-practice-scenario.py','evaluations/c5-dry-run-check.py','evaluations/acceptance_review.py','src/membrain/host_context.py']
frozen={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in files}
metadata={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'runtime':'cc2a60176499c97bc7423199363dbd9311452dcf','mode':'public practice, fixed host/extractor stubs, keyword recall, external sockets refused','files':frozen,'completed':False}
(root/'inputs.json').write_text(json.dumps(metadata,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith(('MEMORY_','MEMBRAIN_','C5_')) and not k.endswith(('_API_KEY','_API_TOKEN'))}
env.update(C5_STUB='1',C5_PYTHON=str(python),MEMBRAIN_SEMANTIC='0',MEMBRAIN_MODEL_CACHE=str(root/'model-cache'),PYTHON_DOTENV_DISABLED='1')
commands=[('run.log',['bash','evaluations/c5-run-scenario.sh','evaluations/c5-practice-scenario.py',str(root/'practice'),'dry']),('practice-check.txt',[str(python),'evaluations/c5-dry-run-check.py','evaluations/c5-practice-scenario.py',str(root/'practice'),'dry']),('practice-validity.json',[str(python),'evaluations/acceptance_review.py','validity',*[str(root/'practice'/('dry-'+a)) for a in 'PEF']])]
metadata['steps']=[]
for filename,command in commands:
 with (root/filename).open('w') as output:
  done=subprocess.run(command,cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT)
 metadata['steps'].append({'output':filename,'exit_code':done.returncode})
 (root/'completion.json').write_text(json.dumps(metadata,indent=2)+'\n')
 if done.returncode:raise SystemExit(done.returncode)
assert frozen=={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in files}
metadata.update(completed=True,inputs_unchanged=True)
(root/'completion.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps({'completed':True,'inputs_unchanged':True,'steps':metadata['steps']}))
