import importlib.util
import json
import tempfile
from pathlib import Path
import httpx
spec = importlib.util.spec_from_file_location("budget", "evaluations/evaluation_budget.py")
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
p = json.loads(Path("evaluations/maturity-provider-policy-draft.json").read_text())
assert p["status"] == "draft_not_approved"
with tempfile.TemporaryDirectory() as folder:
    path = Path(folder) / "offline-policy.json"
    meta = b.create_ledger(path, run_id="offline-policy-compatibility", limit_cny=p["proposed_limit_cny"], endpoint=p["endpoint"], models=p["models"])
    calls = []
    def handler(request):
        model = json.loads(request.content)["model"]
        calls.append(model)
        return httpx.Response(200, json={"model": model, "usage": {"prompt_tokens": 7, "completion_tokens": 11, "total_tokens": 18, "prompt_tokens_details": {"cached_tokens": 0}, "prompt_cache_hit_tokens": 0, "prompt_cache_miss_tokens": 7}})
    transport = b.GuardedTransport(path, run_id=meta["run_id"], policy_sha256=meta["policy_sha256"], transport=httpx.MockTransport(handler))
    with httpx.Client(transport=transport) as client:
        for model in p["models"]:
            response = client.post(p["endpoint"], json={"model":model,"messages":[{"role":"user","content":"Synthetic protocol check"}],"max_tokens":16384,"stream":False})
            assert response.status_code == 200
    state = json.loads(path.read_text())
    rows = list(state["requests"].values())
    assert [row["reserved_micros"] for row in rows] == [20054016,5242880]
    assert [row["actual_micros"] for row in rows] == [360,102]
    assert state["blocked"] is False and len(calls)==2
    print(json.dumps({"scope":"offline mock compatibility only; no provider request", "reservations_cny":["20.054016","5.242880"], "three_hosts_plus_extractor_cny":"65.404928", "synthetic_settlement_micros":[360,102], "passed":True}))
