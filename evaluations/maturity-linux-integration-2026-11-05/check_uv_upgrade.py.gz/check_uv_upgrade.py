import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path('/Users/yichen/tmp/membrain-xml-integration-20261105/uv-qualification')
REPO = Path('/Users/yichen/tmp/membrain-review-20261029')
OLD = '73ee62ee5796902249ddd20b08ed7e4ad6922b3f'
NEW = subprocess.check_output(['git', 'rev-parse', '603e0a2'], cwd=REPO, text=True).strip()
EXPECTED = '99d5c45e20d1e29882a9151107f85b1740c027d09e32d772164c34f00fd55ecf'
ROOT.mkdir(mode=0o700, exist_ok=False)
tracked = subprocess.check_output(['git', 'ls-files', '-z', 'src', 'scripts', 'tests', 'plugins', 'integrations', '.github', 'migrations', 'architecture', 'pyproject.toml', 'uv.lock'], cwd=REPO).decode().split('\0')
def hashes():
    return {name: hashlib.sha256((REPO / name).read_bytes()).hexdigest() for name in tracked if name}
frozen = hashes()
report = {'completed': False, 'model_calls': 0, 'old_runtime': OLD, 'new_runtime': NEW, 'phases': [],
          'scope': 'isolated uv tool dependencies, fresh current profile, then active old tool replacement and automatic host restart; existing macOS native cache may be reused; semantic model download disabled'}
env = {k: v for k, v in os.environ.items() if not k.startswith(('MEMORY_', 'MEMBRAIN_', 'PG', 'UV_', 'PYTHON', 'LD_', 'DYLD_')) and not any(s in k for s in ('TOKEN', 'SECRET', 'API_KEY', 'PASSWORD'))}
env.update(UV_CACHE_DIR=str(ROOT / 'cache'), UV_LINK_MODE='copy', UV_PYTHON_DOWNLOADS='never', MEMBRAIN_SEMANTIC='0', PYTHON_DOTENV_DISABLED='1')
uv = shutil.which('uv')
base_python = str(REPO / '.venv/bin/python')
profiles = []

def checkpoint(name):
    report['phases'].append(name)
    (ROOT / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
    print(name, flush=True)

def environment(name):
    result = env.copy()
    result.update(UV_TOOL_DIR=str(ROOT / name / 'tools'), UV_TOOL_BIN_DIR=str(ROOT / name / 'bin'))
    return result

def install(name, revision):
    checkpoint('install-' + name + '-' + revision[:7])
    arguments = [uv, 'tool', 'install', '--force', '--python', base_python,
                 'membrain-ai[embedded,semantic] @ https://github.com/chriswu727/membrain/archive/' + revision + '.zip']
    r = subprocess.run(arguments, env=environment(name), cwd=ROOT, capture_output=True, text=True, timeout=600)
    (ROOT / ('install-' + name + '-' + revision[:7] + '.txt')).write_text(r.stdout + r.stderr)
    if r.returncode:
        raise RuntimeError('uv install failed: ' + str(r.returncode))
    return ROOT / name / 'tools/membrain-ai/bin/python'

PROBE = r'''
import hashlib, importlib.metadata, json, sys
from pathlib import Path
from membrain import desktop, host, local_profile
from membrain.build_identity import BUILD_ID
from membrain.desktop_connection import open_client
from membrain.recovery_profile import read_document
p=Path(sys.argv[1]);mode=sys.argv[2];out=Path(sys.argv[3])
result={'build_id':BUILD_ID,'package_root':str(Path(__import__('membrain').__file__).parent),'python_prefix':sys.prefix}
if mode=='stop':
 if (p/'profile.json').exists():
  profile=local_profile.load_profile(p);desktop.stop(p)
  result['ports_closed']=not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
else:
 before=desktop.status(p) if (p/'profile.json').exists() else None
 profile_bytes=(p/'profile.json').read_bytes() if (p/'profile.json').exists() else None
 journal_bytes=(p/'native-transition.json').read_bytes() if (p/'native-transition.json').exists() else None
 result['previous_state']=before and before['state']
 assert host.start(p)['ready']
 profile=local_profile.load_profile(p)
 with open_client(p,start_service=False) as client:
  if mode=='write':
   assert client.observe('My cat is named Biscuit and she dislikes thunder.',conversation_id='uv-install',branch_id='main',source_event_key='biscuit')['outcome']=='completed'
  assert 'Biscuit' in json.dumps(client.recall('what is my cat called'))
 result['ready']=True;result['recall_preserved']=True
 result['instance_id']=desktop._probe(profile)['instance_id']
 if mode=='upgrade':
  assert before['state']=='restart_required'
  assert profile_bytes==(p/'profile.json').read_bytes()
  assert journal_bytes==(p/'native-transition.json').read_bytes()
  result['profile_and_native_journal_unchanged']=True
 for package in ('membrain-ai','postgresql-binaries','onnxruntime','tokenizers','psycopg'):
  distribution=importlib.metadata.distribution(package)
  assert Path(distribution.locate_file('')).is_relative_to(Path(sys.prefix))
 distribution=importlib.metadata.distribution('membrain-ai')
 result['direct_url']=json.loads(distribution.read_text('direct_url.json'))['url']
 result['package_digest']=hashlib.sha256((Path(__import__('membrain').__file__).parent/'native_bundle.py').read_bytes()).hexdigest()
out.write_text(json.dumps(result,indent=2)+'\n')
'''

def probe(name, python, profile, mode):
    checkpoint(name + '-' + mode)
    output = ROOT / (name + '-' + mode + '.json')
    r = subprocess.run([str(python), '-I', '-c', PROBE, str(profile), mode, str(output)], env=environment(name), cwd=ROOT, capture_output=True, text=True, timeout=420)
    (ROOT / (name + '-' + mode + '.txt')).write_text(r.stdout+r.stderr)
    if r.returncode:
        raise RuntimeError('installed probe failed: ' + name + '-' + mode)
    return json.loads(output.read_text())

try:
    current = install('fresh', NEW)
    fresh = ROOT / 'fresh-profile';profiles.append(('fresh',current,fresh))
    a = probe('fresh', current, fresh, 'write')
    assert a['build_id']==EXPECTED and NEW in a['direct_url']
    assert probe('fresh', current, fresh, 'stop')['ports_closed']
    old = install('upgrade', OLD)
    previous = ROOT / 'upgrade-profile';profiles.append(('upgrade',old,previous))
    b = probe('upgrade', old, previous, 'write')
    assert b['build_id']!=EXPECTED and OLD in b['direct_url']
    current = install('upgrade', NEW)
    c = probe('upgrade', current, previous, 'upgrade')
    assert c['build_id']==EXPECTED and NEW in c['direct_url']
    assert c['instance_id']!=b['instance_id']
    assert probe('upgrade', current, previous, 'stop')['ports_closed']
    report.update(completed=True,fresh_current_installed=True,active_old_environment_replaced=True,
                  automatic_restart_after_replacement=True,recall_preserved=True,profile_and_journal_unchanged=True)
finally:
    closed=[]
    for name,python,profile in profiles:
        try: closed.append(probe(name,python,profile,'stop').get('ports_closed',True))
        except Exception: closed.append(False)
    report['owned_ports_closed']=bool(closed) and all(closed)
    report['frozen_inputs_unchanged']=frozen==hashes()
    report['frozen_input_count']=len(frozen)
    checkpoint('terminal')
assert report['completed'] and report['owned_ports_closed'] and report['frozen_inputs_unchanged']
print(json.dumps(report), flush=True)
