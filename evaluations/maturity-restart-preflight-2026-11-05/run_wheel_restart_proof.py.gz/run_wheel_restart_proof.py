import hashlib
import json
import os
import shutil
import sys
from pathlib import Path

import membrain
from membrain import desktop, embedded_database
from membrain.build_identity import BUILD_ID
from membrain.local_profile import load_profile

root = Path("/Volumes/memBrainFixture-20261105/public-delivery")
sys.path.insert(0, str(root / "worktree/scripts"))
from check_native_adoption import check_restart

profile = load_profile(Path("/Users/yichen/tmp/membrain-native-engine-store-20261105/preserved-rollback-v2/profile"))
paths = list(Path(membrain.__file__).parent.rglob("*")) + [root / "worktree/scripts/check_native_adoption.py"]
frozen = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths if path.is_file()}
report = {"completed": False, "model_calls": 0, "build_id": BUILD_ID, "new_database_created": False,
          "new_dependencies_installed": False, "failure_injected": "NativeBundleError in target tool loader", "installed_package": membrain.__file__,
          "dependencies_reused_read_only": True, "clean_complete_installation_claimed": False,
          "free_before_MiB": shutil.disk_usage(profile.directory).free // 1024**2}
os.environ["MEMBRAIN_SEMANTIC"] = "0"
assert report["free_before_MiB"] > 256
assert not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
try:
    assert desktop.start(profile.directory)["ready"]
    with embedded_database._admin_connection(profile, "agent_memory") as connection:
        before = connection.execute("SELECT count(*) FROM transition_fixture").fetchone()[0]
    assert before == 1000
    report.update(check_restart(profile))
    with embedded_database._admin_connection(profile, "agent_memory") as connection:
        assert connection.execute("SELECT count(*) FROM transition_fixture").fetchone()[0] == before
        assert connection.execute("SHOW server_version").fetchone()[0] == "16.15"
    report.update(existing_vector_rows_preserved=before, completed=True)
finally:
    if desktop._port_open(profile.api_port) or desktop._port_open(profile.database_port):
        desktop.stop(profile.directory)
    report["owned_ports_closed"] = not desktop._port_open(profile.api_port) and not desktop._port_open(profile.database_port)
    report["frozen_inputs_unchanged"] = all(hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest
                                           for path, digest in frozen.items())
    (root / "wheel-http-proof.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report), flush=True)
    assert report["owned_ports_closed"] and report["frozen_inputs_unchanged"]
