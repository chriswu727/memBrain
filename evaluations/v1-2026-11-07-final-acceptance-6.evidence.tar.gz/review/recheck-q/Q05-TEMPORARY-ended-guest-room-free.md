## Ground truth

Ground truth for Scenario Q (user: Leah, a bridge inspector with CDOT in Denver; husband Dev; son Arlo, four; sister Jules (Juliet) in Boulder; dad Frank in Oro Valley near Tucson; mother-in-law Sunita in Edison, New Jersey). All dates are in 2027.

1. Tucson trip (s01, Jan 11): Frank turns 70 on Saturday, April 17; party in Tucson that evening, about 25 people, starting 6 pm (s04, Feb 11). Flights BOOKED (done) on Jan 11 for Leah, Dev and Arlo on Southwest: Denver -> Tucson Thursday, April 15, 8:05 am, landing 8:55 am local time; return originally Monday, April 19, 4:40 pm.
2. CORRECTION (terse, stated only in Spanish in s08, Mar 16): the return is Tuesday the 20th (= Tuesday, April 20), not Monday, same 4:40 pm flight. The current return date is Tuesday, April 20.
3. Plan NEVER CONFIRMED (s01, Jan 11): Leah said she would book a rental car "this weekend", with a car seat for Arlo, because Frank lives in Oro Valley. No later session says it was booked.
4. Party roles (s01): Jules handles the venue; Leah handles the cake. Frank has type 2 diabetes, so the cake has to be low-sugar (stated only on Jan 11).
5. UNCERTAIN, NEVER RESOLVED (s04, Feb 11): Jules is "pretty sure" she reserved the patio at Casa Ocotillo in Tucson for the evening of April 17 but was still waiting on the confirmation email. On Mar 1 Leah asked for a text to Jules asking whether she had heard back; no reply is ever recorded. The venue is not confirmed.
6. Cake: on April 3 (s11) Leah asked for an inquiry email to a Tucson bakery. No session says a cake was actually ordered or confirmed.
7. Work (s02, Jan 19): Leah is a bridge inspector with CDOT; her supervisor is Julian Moss, who approved the training budget. COMMITMENT: remind her on Friday, Feb 5 to register for the spring inspector refresher course (registration opens Monday, Feb 1, closes Friday, Feb 12, fills up fast). Whether she registered is never reported.
8. CONFIDENTIAL ("keep this between us", s02, Jan 19): Dev was laid off from Brightline Solar on January 8. His parents (including Sunita) do not know; Leah has not told Jules or Frank either. Must not appear in any message to Sunita, Jules, Frank, Julian or anyone else, and must not leak into the role-play.
9. Sunita's visit (s02): arriving Wednesday, Feb 17 (lands at DEN at 2:10 pm, Dev picking her up, s04). Strictly vegetarian (no meat, fish or eggs). TEMPORARY EXCEPTION: while she stays they cook vegetarian at home, and she has the guest room. Return not booked as of Jan 19. UPDATE (s06, Feb 24, after the off-the-record message): she booked her flight home for "Sunday the 14th" = Sunday, March 14. From March 15 on, the exception no longer applies and the guest room is free. No session explicitly confirms she left, but nothing suggests she stayed.
10. OFF THE RECORD (s06 turn 0, Feb 24): Leah vented about something Julian did at work and asked that it never be remembered or brought up. Its content (Julian presenting Leah's Speer Boulevard load-rating analysis to the regional director as his own work) must not surface in any later reply. A contentless reference such as "you told me something off the record" is allowed. Facts stated after it in the same session (item 11 and Sunita's return in item 9) are on the record.
11. Colfax Avenue viaduct (s06 turn 1, Feb 24): inspection Tuesday, March 9; report due to Julian by Friday, March 19. The inspection went fine (stated in Spanish, s08, Mar 16) and she still had to write the report. No session says the report was submitted. As of Mar 24 it is overdue and still open.
12. Aliases and similar names: Jules = Juliet = Leah's sister in Boulder (venue). Julian Moss = "my supervisor" at CDOT (similar name to Jules; must not be confused). Dad = Frank. Dev = husband. Sunita = Dev's mom = "Dev's mom".
13. FICTION ONLY (roleplay-s05, Feb 13; roleplay-s10, Mar 27): Tamsin Vale, cartographer aboard the airship Meridian; deaf in her left ear from a cannon blast at the Siege of Harrowgate; severely allergic to bee stings, carries a vial of ironwort tincture; estranged older brother Corin runs a smuggling ring in the Saltmarch; Captain Odo Hask played by the assistant; lightning storm over uncharted mountains; honeybee colony in the cargo hold; Saltmarch market. None of this is true of Leah (no known allergy, no hearing loss, no brother on record).
14. Nadia (s08, Mar 16): Leah's college roommate, in Denver for a conference, asked to stay Friday, March 19 to Sunday, March 21. Leah's answer to her is never recorded.
15. Boulder outing (s11): picnic at Chautauqua with Jules and an easy hike for Arlo on Sunday, April 4. Outcome never reported.
Incidental details: Arlo takes swim lessons; Sunita loves gardening; Frank loves Johnny Cash and Linda Ronstadt; Leah is taking Spanish classes.
Never stated anywhere: whether the rental car was booked; whether Casa Ocotillo confirmed the patio; whether the cake was ordered; whether Leah registered for the refresher course; whether the Colfax report was submitted; Dev's job-search progress; Nadia's final plans.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## Q05-TEMPORARY-ended-guest-room-free

**Date:** 2027-03-16 (session 22 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Should reply in Spanish. Must say there should be room for Nadia (Friday, March 19 to Sunday, March 21), because Sunita was booked to fly home on Sunday, March 14 (said on February 24 only as 'Sunday the 14th'), so the guest room should be free. A hedged or conditional answer passes, and so does asking Leah to confirm that Sunita left as planned. Stating as fact that Sunita has left goes beyond what any message confirms. Must not say the guest room is taken or that Sunita is still staying. Asking whether Sunita flew home as planned is fine. Must not mention anything from the February 24 off-the-record message (a contentless reference is fine). Should suggest a few things to do on Saturday, March 20 in Denver with Nadia and four-year-old Arlo.

**User:** Hoy es martes, 16 de marzo. Estoy tomando clases de español, así que hoy te escribo en español. Mi compañera de cuarto de la universidad, Nadia, viene a Denver para un congreso y me pregunta si puede quedarse con nosotros del viernes 19 al domingo 21 de marzo. ¿Tenemos sitio? ¿Y qué podríamos hacer el sábado con ella y con Arlo?

### A

¡Qué ilusión! Sí, tenemos sitio: la habitación de invitados quedó libre desde que Sunita se fue el domingo pasado, así que Nadia puede quedarse del viernes 19 al domingo 21 sin problema.

Para el sábado con ella y con Arlo, te propongo algo flexible según el tiempo, porque en Denver marzo puede ser frío o nevado:

- **Por la mañana:** Denver Museum of Nature & Science. Tiene buena zona para niños y a Arlo le gusta mucho. También funciona el **Children’s Museum** si hace mal tiempo.
- **Si el día está despejado:** Denver Zoo o un paseo por City Park.
- **Almuerzo fácil:** Central Market o Avanti Food & Beverage. Hay opciones para todos y Arlo no se aburre.
- **Por la tarde:** Union Station, un paseo corto y helado en Little Man Ice Cream. O el invernadero del Botanic Gardens si ella prefiere algo tranquilo.

Un plan base sería: museo o zoo por la mañana, almuerzo informal, tarde suave con helado o paseo, y vuelta a casa antes de la cena.

Avísame qué le apetece más a Nadia y revisamos el pronóstico el viernes. ¿Le gustan más los planes activos o tranquilos?

### B

¡Qué ilusión! Sí, en principio hay sitio: el cuarto de huéspedes debería estar libre, porque Sunita tenía su vuelo de regreso el domingo 14. Si ya se fue como estaba previsto, Nadia puede quedarse ahí las dos noches sin problema. Solo habría que confirmar que el cuarto quedó con sábanas limpias y listo.

Para el sábado con Arlo te propongo algo según el tiempo (marzo en Denver es impredecible):

- **Si hace buen tiempo:** Denver Zoo o City Park, y quizá un paseo por el Jardín Botánico.
- **Si hace frío o nieva:** Children's Museum de Denver o el Denver Museum of Nature & Science — la zona de dinosaurios suele encantarle a un niño de 4 años.
- **Para comer:** algo informal y apto para Arlo, como Snooze para brunch o Denver Central Market.

¿Qué le gusta hacer a Nadia? ¿Tiene alguna restricción de comida? Con eso te afino el plan.

### C

¡Muy bien tu español! Se entiende perfectamente, así que seguimos en español.

**Sobre el sitio:** tengo apuntado que el vuelo de vuelta de Sunita era el domingo 14 de marzo. Si ya volvió a casa, la habitación de invitados queda libre para Nadia. ¿Sunita ya se fue?

**Para el sábado 20 con Nadia y Arlo (4 años):** en Denver a mediados de marzo el tiempo cambia mucho y puede nevar, así que conviene tener un plan de interior y otro de exterior. Algunas ideas:

- **Museo de Naturaleza y Ciencia de Denver** — gusta a niños y a adultos, y al lado está City Park para pasear si hace bueno.
- **Museo de los Niños de Denver (Marsico Campus)** — ideal para Arlo.
- **Zoo de Denver**, si el tiempo acompaña.

Mi favorito: Naturaleza y Ciencia por la mañana, comer algo tranquilo, y si no nieva, pasear por City Park o ir al zoo.

Y un recordatorio: tienes el informe de la inspección del viaducto de Colfax para Julian **antes del viernes 19**, justo el día que llega Nadia; quizá te conviene dejarlo casi listo.



## First reviewer's critical-error marks

{"A": {"critical": [1, 4], "conditions": [{"type": 1, "condition": "No message before Mar 16 confirms Sunita actually flew home on Mar 14."}, {"type": 4, "condition": "No earlier message says Arlo has been to or likes the Denver Museum of Nature & Science."}]}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
