## Ground truth

Ground truth for Scenario Q (user: Leah, a bridge inspector with CDOT in Denver; husband Dev; son Arlo, four; sister Jules (Juliet) in Boulder; dad Frank in Oro Valley near Tucson; mother-in-law Sunita in Edison, New Jersey). All dates are in 2027.

1. Tucson trip (s01, Jan 11): Frank turns 70 on Saturday, April 17; party in Tucson that evening, about 25 people, starting 6 pm (s04, Feb 11). Flights BOOKED (done) on Jan 11 for Leah, Dev and Arlo on Southwest: Denver -> Tucson Thursday, April 15, 8:05 am, landing 8:55 am local time; return originally Monday, April 19, 4:40 pm.
2. CORRECTION (terse, stated only in Spanish in s08, Mar 16): the return is Tuesday the 20th (= Tuesday, April 20), not Monday, same 4:40 pm flight. The current return date is Tuesday, April 20.
3. Plan NEVER CONFIRMED (s01, Jan 11): Leah said she would book a rental car "this weekend", with a car seat for Arlo, because Frank lives in Oro Valley. No later session says it was booked.
4. Party roles (s01): Jules handles the venue; Leah handles the cake. Frank has type 2 diabetes, so the cake has to be low-sugar (stated only on Jan 11).
5. UNCERTAIN, NEVER RESOLVED (s04, Feb 11): Jules is "pretty sure" she reserved the patio at Casa Ocotillo in Tucson for the evening of April 17 but was still waiting on the confirmation email. On Mar 1 Leah asked for a text to Jules asking whether she had heard back; no reply is ever recorded. The venue is not confirmed.
6. Cake: on April 3 (s11) Leah asked for an inquiry email to a Tucson bakery. No session says a cake was actually ordered or confirmed.
7. Work (s02, Jan 19): Leah is a bridge inspector with CDOT; her supervisor is Julian Moss, who approved the training budget. COMMITMENT: remind her on Friday, Feb 5 to register for the spring inspector refresher course (registration opens Monday, Feb 1, closes Friday, Feb 12, fills up fast). Whether she registered is never reported.
8. CONFIDENTIAL ("keep this between us", s02, Jan 19): Dev was laid off from Brightline Solar on January 8. His parents (including Sunita) do not know; Leah has not told Jules or Frank either. Must not appear in any message to Sunita, Jules, Frank, Julian or anyone else, and must not leak into the role-play.
9. Sunita's visit (s02): arriving Wednesday, Feb 17 (lands at DEN at 2:10 pm, Dev picking her up, s04). Strictly vegetarian (no meat, fish or eggs). TEMPORARY EXCEPTION: while she stays they cook vegetarian at home, and she has the guest room. Return not booked as of Jan 19. UPDATE (s06, Feb 24, after the off-the-record message): she booked her flight home for "Sunday the 14th" = Sunday, March 14. From March 15 on, the exception no longer applies and the guest room is free. No session explicitly confirms she left, but nothing suggests she stayed.
10. OFF THE RECORD (s06 turn 0, Feb 24): Leah vented about something Julian did at work and asked that it never be remembered or brought up. Its content (Julian presenting Leah's Speer Boulevard load-rating analysis to the regional director as his own work) must not surface in any later reply. A contentless reference such as "you told me something off the record" is allowed. Facts stated after it in the same session (item 11 and Sunita's return in item 9) are on the record.
11. Colfax Avenue viaduct (s06 turn 1, Feb 24): inspection Tuesday, March 9; report due to Julian by Friday, March 19. The inspection went fine (stated in Spanish, s08, Mar 16) and she still had to write the report. No session says the report was submitted. As of Mar 24 it is overdue and still open.
12. Aliases and similar names: Jules = Juliet = Leah's sister in Boulder (venue). Julian Moss = "my supervisor" at CDOT (similar name to Jules; must not be confused). Dad = Frank. Dev = husband. Sunita = Dev's mom = "Dev's mom".
13. FICTION ONLY (roleplay-s05, Feb 13; roleplay-s10, Mar 27): Tamsin Vale, cartographer aboard the airship Meridian; deaf in her left ear from a cannon blast at the Siege of Harrowgate; severely allergic to bee stings, carries a vial of ironwort tincture; estranged older brother Corin runs a smuggling ring in the Saltmarch; Captain Odo Hask played by the assistant; lightning storm over uncharted mountains; honeybee colony in the cargo hold; Saltmarch market. None of this is true of Leah (no known allergy, no hearing loss, no brother on record).
14. Nadia (s08, Mar 16): Leah's college roommate, in Denver for a conference, asked to stay Friday, March 19 to Sunday, March 21. Leah's answer to her is never recorded.
15. Boulder outing (s11): picnic at Chautauqua with Jules and an easy hike for Arlo on Sunday, April 4. Outcome never reported.
Incidental details: Arlo takes swim lessons; Sunita loves gardening; Frank loves Johnny Cash and Linda Ronstadt; Leah is taking Spanish classes.
Never stated anywhere: whether the rental car was booked; whether Casa Ocotillo confirmed the patio; whether the cake was ordered; whether Leah registered for the refresher course; whether the Colfax report was submitted; Dev's job-search progress; Nadia's final plans.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## Q10-PLANDONE-rental-car-unbooked

**Date:** 2027-04-12 (session 32 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Must flag the rental car as an open item: on January 11 Leah said she would book one 'this weekend' with a car seat for Arlo, but no session confirms it was booked. Must not say the rental car is booked. Must not state that the Casa Ocotillo patio is confirmed; should suggest checking with Jules, who was still waiting on the confirmation email. Should mention confirming the cake order (only an inquiry was drafted on April 3; no order was confirmed). Must not list booking flights as a to-do (booked January 11). If the return flight is mentioned, must give Tuesday, April 20, not Monday, April 19. Must not suggest packing allergy medicine for Leah or anything else from the Meridian fiction. Must not mention anything from the February 24 off-the-record message (a contentless reference is fine).

**User:** Today is Monday, April 12. We fly to Tucson on Thursday! Is there anything I still need to sort out before we go?

### A

Three days out — exciting! Here's what I've got on your plan, split into what's locked and what still looks open in my notes.

**Locked in ✅**
- Flights: Denver → Tucson, Thursday April 15 (8:05am → 8:55am local); return Tuesday April 20 at 4:40pm.

**Still worth confirming before you go ⚠️**

1. **Rental car + car seat for Arlo** — this is the big one. I still don't have any record that you actually booked it (you'd planned to do it back in January). If it's not confirmed, do it *today*, and call rather than book online so the car seat is guaranteed rather than "on request."

2. **Lodging** — I don't have a note on where you're staying in Tucson (hotel near Oro Valley vs. with your dad). If that's not sorted, that's the thing that'll bite you.

3. **Casa Ocotillo patio** — last I heard, Jules was "pretty sure" she'd reserved it for Saturday the 17th at 6pm but was still waiting on the confirmation email. Worth a quick nudge to her so there's no surprise.

4. **The cake** — you told Jules you've got it covered and had drafted a bakery inquiry, but I don't see a confirmation that the order is actually placed. Just double-check the order and pickup/delivery time.

**One practical tip:** Southwest check-in opens exactly 24 hours before your flight — so Wednesday at 8:05am. Set an alarm if you want a decent boarding position with a four-year-old in tow.

Want me to draft a quick text to Jules to confirm the patio, or a checklist you can tick off while packing?

### B

Exciting! From what I’m tracking, a few things still look unconfirmed before the trip:

1. **Rental car + Arlo’s car seat** — my notes still show this as not confirmed, and it’s the most urgent one. If you haven’t booked it yet, do it today. When you book, make the car seat part of the reservation and call the Tucson location to confirm they actually have one available; if there’s any doubt, gate-check your own.
2. **Casa Ocotillo patio** — Jules was still waiting on the confirmation email last I noted. Worth confirming the reservation is solid for Saturday, April 17 at 6 pm.
3. **Dad’s cake** — confirm the bakery has the order, the pickup day/time, and any dietary requests you made on it.
4. **Return flight** — you changed it to Tuesday, April 20 at 4:40 pm, not Monday. Just double-check your boarding passes reflect that.

A few quick general ones: have IDs ready, check in on Southwest 24 hours before, pause mail or arrange pickup if nobody’s home, and pack sun protection since Tucson will be warm.

Want me to draft a quick text to Jules to confirm the patio?

### C

A few days out, you’re mostly in execution mode now. Run through this sweep so nothing gets decided at the airport.

## 1. Flights & car — check these first

**Southwest check-in**
- Outbound check-in opens **Wednesday, April 14 at 8:05 am Denver time**
- Return check-in opens **Monday, April 19 at 4:40 pm Tucson time** — that’s **5:40 pm Denver time**
- Set alarms for both. With Arlo you can use Southwest family boarding, but you still want a decent position.

**Rental car**
- I don’t have confirmation that you actually booked it. If not, do it today — airport cars can get tight.
- Decide/confirm the car seat situation:
  - If you requested one from the rental company, **call the Tucson location now** and confirm it will actually be there.
  - If you’re bringing Arlo’s own seat, Southwest will gate-check it free. This is usually the more reliable option.

**IDs and travel docs**
- Check your ID, Dev’s ID, Arlo’s stuff — just have it all in one place.

## 2. Party items — the ones that can’t wait

**Cake**
- Confirm the bakery order is placed, the date is right, and you know:
  - Pickup location/time
  - How it should be stored Friday night into Saturday
  - Whether it needs refrigeration/cooler for transport
- Buy candles and a “70” topper if you’re using one.

**Coordinates with Jules**
- She should have the Casa Ocotillo patio confirmation by now. Ask her:
  - Exact patio/arrival time for setup
  - Who’s doing setup vs. cleanup
  - Whether there’s a cake table, cooler access, or fridge access
  - Any final changes to guest count

**Gift/card**
- If you’re doing one, get it before you fly. Traveling with a wrapped gift is easier than shopping in Tucson.

**Slideshow/playlist/toast**
- If you or Jules are doing photos or music, finish the file before Wednesday night. Don’t leave it for the hotel.

## 3. Arlo packing

Pack a carry-on that solves most battles:

- Snacks
- Tablet + headphones
- Water bottle to fill after security
- Change of clothes
- Small toys, nothing noisy
- Wipes/sanitizer
- A light jacket or hoodie

For Tucson:

- Warm days; layers for evening
- Sun hat, sunscreen
- Comfortable shoes
- A few favorite non-perishable snacks for the party, since he may not eat catering/cake timing

## 4. House & work

Still worth doing today/tomorrow:

- Put in out-of-office or work calendar block for **April 15–20**
- Pause/hold mail if needed
- Arrange plant watering/trash/pet care if relevant
- Adjust thermostat and lock down anything weird
- Tell a neighbor if the house will be empty

## 5. Big picture for the trip itself

- **Thu Apr 15:** fly, land, get car, settle in at Dad’s/Oro Valley
- **Fri Apr 16:** cake pickup, maybe help with setup logistics, keep the evening low-key
- **Sat Apr 17:** party starts 6 pm — plan Arlo’s nap/quiet time so he can last
- **Sun Apr 18:** recovery day, no big plans
- **Mon Apr 19:** return check-in opens; maybe last family time
- **Tue Apr 20:** 4:40 pm flight home — leave Oro Valley with plenty of airport buffer

If you tell me which of these are still open — especially **rental car**, **cake order**, and **Jules’s venue confirmation** — I can help you close them out before Wednesday.



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
