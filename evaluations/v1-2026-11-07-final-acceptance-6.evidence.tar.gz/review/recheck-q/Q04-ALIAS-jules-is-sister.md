## Ground truth

Ground truth for Scenario Q (user: Leah, a bridge inspector with CDOT in Denver; husband Dev; son Arlo, four; sister Jules (Juliet) in Boulder; dad Frank in Oro Valley near Tucson; mother-in-law Sunita in Edison, New Jersey). All dates are in 2027.

1. Tucson trip (s01, Jan 11): Frank turns 70 on Saturday, April 17; party in Tucson that evening, about 25 people, starting 6 pm (s04, Feb 11). Flights BOOKED (done) on Jan 11 for Leah, Dev and Arlo on Southwest: Denver -> Tucson Thursday, April 15, 8:05 am, landing 8:55 am local time; return originally Monday, April 19, 4:40 pm.
2. CORRECTION (terse, stated only in Spanish in s08, Mar 16): the return is Tuesday the 20th (= Tuesday, April 20), not Monday, same 4:40 pm flight. The current return date is Tuesday, April 20.
3. Plan NEVER CONFIRMED (s01, Jan 11): Leah said she would book a rental car "this weekend", with a car seat for Arlo, because Frank lives in Oro Valley. No later session says it was booked.
4. Party roles (s01): Jules handles the venue; Leah handles the cake. Frank has type 2 diabetes, so the cake has to be low-sugar (stated only on Jan 11).
5. UNCERTAIN, NEVER RESOLVED (s04, Feb 11): Jules is "pretty sure" she reserved the patio at Casa Ocotillo in Tucson for the evening of April 17 but was still waiting on the confirmation email. On Mar 1 Leah asked for a text to Jules asking whether she had heard back; no reply is ever recorded. The venue is not confirmed.
6. Cake: on April 3 (s11) Leah asked for an inquiry email to a Tucson bakery. No session says a cake was actually ordered or confirmed.
7. Work (s02, Jan 19): Leah is a bridge inspector with CDOT; her supervisor is Julian Moss, who approved the training budget. COMMITMENT: remind her on Friday, Feb 5 to register for the spring inspector refresher course (registration opens Monday, Feb 1, closes Friday, Feb 12, fills up fast). Whether she registered is never reported.
8. CONFIDENTIAL ("keep this between us", s02, Jan 19): Dev was laid off from Brightline Solar on January 8. His parents (including Sunita) do not know; Leah has not told Jules or Frank either. Must not appear in any message to Sunita, Jules, Frank, Julian or anyone else, and must not leak into the role-play.
9. Sunita's visit (s02): arriving Wednesday, Feb 17 (lands at DEN at 2:10 pm, Dev picking her up, s04). Strictly vegetarian (no meat, fish or eggs). TEMPORARY EXCEPTION: while she stays they cook vegetarian at home, and she has the guest room. Return not booked as of Jan 19. UPDATE (s06, Feb 24, after the off-the-record message): she booked her flight home for "Sunday the 14th" = Sunday, March 14. From March 15 on, the exception no longer applies and the guest room is free. No session explicitly confirms she left, but nothing suggests she stayed.
10. OFF THE RECORD (s06 turn 0, Feb 24): Leah vented about something Julian did at work and asked that it never be remembered or brought up. Its content (Julian presenting Leah's Speer Boulevard load-rating analysis to the regional director as his own work) must not surface in any later reply. A contentless reference such as "you told me something off the record" is allowed. Facts stated after it in the same session (item 11 and Sunita's return in item 9) are on the record.
11. Colfax Avenue viaduct (s06 turn 1, Feb 24): inspection Tuesday, March 9; report due to Julian by Friday, March 19. The inspection went fine (stated in Spanish, s08, Mar 16) and she still had to write the report. No session says the report was submitted. As of Mar 24 it is overdue and still open.
12. Aliases and similar names: Jules = Juliet = Leah's sister in Boulder (venue). Julian Moss = "my supervisor" at CDOT (similar name to Jules; must not be confused). Dad = Frank. Dev = husband. Sunita = Dev's mom = "Dev's mom".
13. FICTION ONLY (roleplay-s05, Feb 13; roleplay-s10, Mar 27): Tamsin Vale, cartographer aboard the airship Meridian; deaf in her left ear from a cannon blast at the Siege of Harrowgate; severely allergic to bee stings, carries a vial of ironwort tincture; estranged older brother Corin runs a smuggling ring in the Saltmarch; Captain Odo Hask played by the assistant; lightning storm over uncharted mountains; honeybee colony in the cargo hold; Saltmarch market. None of this is true of Leah (no known allergy, no hearing loss, no brother on record).
14. Nadia (s08, Mar 16): Leah's college roommate, in Denver for a conference, asked to stay Friday, March 19 to Sunday, March 21. Leah's answer to her is never recorded.
15. Boulder outing (s11): picnic at Chautauqua with Jules and an easy hike for Arlo on Sunday, April 4. Outcome never reported.
Incidental details: Arlo takes swim lessons; Sunita loves gardening; Frank loves Johnny Cash and Linda Ronstadt; Leah is taking Spanish classes.
Never stated anywhere: whether the rental car was booked; whether Casa Ocotillo confirmed the patio; whether the cake was ordered; whether Leah registered for the refresher course; whether the Colfax report was submitted; Dev's job-search progress; Nadia's final plans.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## Q04-ALIAS-jules-is-sister

**Date:** 2027-03-01 (session 18 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Understands 'Jules' as Leah's sister Juliet in Boulder, who is handling the venue for Frank's 70th, not her supervisor Julian Moss. The text is casual and sisterly, asks whether Casa Ocotillo has confirmed the patio (naming the date, the evening of Saturday, April 17, is optional), and says Leah has the cake covered. Must not present the patio booking as already confirmed. Must not be written as a work message or address Julian. Must not mention Dev's layoff, the Colfax report or anything said off the record.

**User:** And can you write a quick text to Jules for me? Ask whether she's heard back from Casa Ocotillo about the patio yet, and tell her I've got the cake covered.

### A

Here's a quick one:

> Hey Jules! Just checking in — any word back from Casa Ocotillo on the patio yet? 🤞 No rush, just want to keep our checklist straight. And don't worry about the cake, I've got that covered. 💛

Want it shorter, or more casual?

### B

Here’s a quick draft:

> Hey Jules! Just checking in—have you heard back from Casa Ocotillo about the patio yet? No rush, just want to make sure we’re locked in. I’ve got the cake covered. 💛

Short and warm. Want me to change the tone at all?

### C

Here’s a quick text you can send Jules:

> Hey Jules! Quick check-in — have you heard anything back from Casa Ocotillo about the patio for Dad’s 70th yet? No rush, just want to make sure it’s locked in. Cake’s covered on my end. 😊

Two quick follow-ups while I’m thinking of it:

- Is the **Tucson rental car** booked yet? I still have it as not done, and don’t forget it needs to include Arlo’s car seat.
- Did you get into the **CDOT spring refresher** before registration closed on Feb 12? I have that as unconfirmed too.



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
