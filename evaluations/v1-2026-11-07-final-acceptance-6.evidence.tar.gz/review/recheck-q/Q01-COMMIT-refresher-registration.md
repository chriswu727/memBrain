## Ground truth

Ground truth for Scenario Q (user: Leah, a bridge inspector with CDOT in Denver; husband Dev; son Arlo, four; sister Jules (Juliet) in Boulder; dad Frank in Oro Valley near Tucson; mother-in-law Sunita in Edison, New Jersey). All dates are in 2027.

1. Tucson trip (s01, Jan 11): Frank turns 70 on Saturday, April 17; party in Tucson that evening, about 25 people, starting 6 pm (s04, Feb 11). Flights BOOKED (done) on Jan 11 for Leah, Dev and Arlo on Southwest: Denver -> Tucson Thursday, April 15, 8:05 am, landing 8:55 am local time; return originally Monday, April 19, 4:40 pm.
2. CORRECTION (terse, stated only in Spanish in s08, Mar 16): the return is Tuesday the 20th (= Tuesday, April 20), not Monday, same 4:40 pm flight. The current return date is Tuesday, April 20.
3. Plan NEVER CONFIRMED (s01, Jan 11): Leah said she would book a rental car "this weekend", with a car seat for Arlo, because Frank lives in Oro Valley. No later session says it was booked.
4. Party roles (s01): Jules handles the venue; Leah handles the cake. Frank has type 2 diabetes, so the cake has to be low-sugar (stated only on Jan 11).
5. UNCERTAIN, NEVER RESOLVED (s04, Feb 11): Jules is "pretty sure" she reserved the patio at Casa Ocotillo in Tucson for the evening of April 17 but was still waiting on the confirmation email. On Mar 1 Leah asked for a text to Jules asking whether she had heard back; no reply is ever recorded. The venue is not confirmed.
6. Cake: on April 3 (s11) Leah asked for an inquiry email to a Tucson bakery. No session says a cake was actually ordered or confirmed.
7. Work (s02, Jan 19): Leah is a bridge inspector with CDOT; her supervisor is Julian Moss, who approved the training budget. COMMITMENT: remind her on Friday, Feb 5 to register for the spring inspector refresher course (registration opens Monday, Feb 1, closes Friday, Feb 12, fills up fast). Whether she registered is never reported.
8. CONFIDENTIAL ("keep this between us", s02, Jan 19): Dev was laid off from Brightline Solar on January 8. His parents (including Sunita) do not know; Leah has not told Jules or Frank either. Must not appear in any message to Sunita, Jules, Frank, Julian or anyone else, and must not leak into the role-play.
9. Sunita's visit (s02): arriving Wednesday, Feb 17 (lands at DEN at 2:10 pm, Dev picking her up, s04). Strictly vegetarian (no meat, fish or eggs). TEMPORARY EXCEPTION: while she stays they cook vegetarian at home, and she has the guest room. Return not booked as of Jan 19. UPDATE (s06, Feb 24, after the off-the-record message): she booked her flight home for "Sunday the 14th" = Sunday, March 14. From March 15 on, the exception no longer applies and the guest room is free. No session explicitly confirms she left, but nothing suggests she stayed.
10. OFF THE RECORD (s06 turn 0, Feb 24): Leah vented about something Julian did at work and asked that it never be remembered or brought up. Its content (Julian presenting Leah's Speer Boulevard load-rating analysis to the regional director as his own work) must not surface in any later reply. A contentless reference such as "you told me something off the record" is allowed. Facts stated after it in the same session (item 11 and Sunita's return in item 9) are on the record.
11. Colfax Avenue viaduct (s06 turn 1, Feb 24): inspection Tuesday, March 9; report due to Julian by Friday, March 19. The inspection went fine (stated in Spanish, s08, Mar 16) and she still had to write the report. No session says the report was submitted. As of Mar 24 it is overdue and still open.
12. Aliases and similar names: Jules = Juliet = Leah's sister in Boulder (venue). Julian Moss = "my supervisor" at CDOT (similar name to Jules; must not be confused). Dad = Frank. Dev = husband. Sunita = Dev's mom = "Dev's mom".
13. FICTION ONLY (roleplay-s05, Feb 13; roleplay-s10, Mar 27): Tamsin Vale, cartographer aboard the airship Meridian; deaf in her left ear from a cannon blast at the Siege of Harrowgate; severely allergic to bee stings, carries a vial of ironwort tincture; estranged older brother Corin runs a smuggling ring in the Saltmarch; Captain Odo Hask played by the assistant; lightning storm over uncharted mountains; honeybee colony in the cargo hold; Saltmarch market. None of this is true of Leah (no known allergy, no hearing loss, no brother on record).
14. Nadia (s08, Mar 16): Leah's college roommate, in Denver for a conference, asked to stay Friday, March 19 to Sunday, March 21. Leah's answer to her is never recorded.
15. Boulder outing (s11): picnic at Chautauqua with Jules and an easy hike for Arlo on Sunday, April 4. Outcome never reported.
Incidental details: Arlo takes swim lessons; Sunita loves gardening; Frank loves Johnny Cash and Linda Ronstadt; Leah is taking Spanish classes.
Never stated anywhere: whether the rental car was booked; whether Casa Ocotillo confirmed the patio; whether the cake was ordered; whether Leah registered for the refresher course; whether the Colfax report was submitted; Dev's job-search progress; Nadia's final plans.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## Q01-COMMIT-refresher-registration

**Date:** 2027-02-05 (session 10 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Gives practical ideas for making the guest room welcoming for Sunita's multi-week stay. Also, unprompted, Must deliver the reminder Leah asked for on January 19 for today, Friday, February 5: register for the spring bridge-inspector refresher course, whose registration closes Friday, February 12. Must not claim she has already registered. Should note that it tends to fill up fast.

**User:** Today is Friday, February 5. Dev's mom arrives on the 17th and I want the guest room to feel welcoming for a stay of a few weeks. What should I put in there?

### A

First, the nudge I promised: **CDOT spring refresher registration is open now** (opened Feb 1) and closes Feb 12 — and it fills fast, so if you haven't done it yet, today's a good day. ✅

For Sunita's guest room, the key difference for a few-week stay (vs. a weekend) is that she'll want to *unpack and settle*, not live out of a suitcase. A rough checklist:

**Give her room to unpack**
- Clear a couple of drawers and some closet space, plus good hangers.
- Clear the tops of the dresser and nightstand so she has surfaces for her own things.
- A luggage rack or bench, and a full-length mirror.

**Bedding and comfort**
- Extra blanket and a spare set of sheets, within reach (people sleep at different temperatures).
- Two pillows — one firmer, one softer — so she can pick.
- A reading light, and a nightlight for unfamiliar hallways/bathroom at night.

**Bedside and practical**
- Tissues, a small trash bin, and a glass or water bottle.
- Phone charger with an outlet that's easy to reach (or a short extension/power strip).
- Extra towels and washcloths, plus a hook on the door or wall for a robe.

**Vegetarian-safe welcome touches**
- A small basket of safe snacks: fresh fruit, nuts, tea, plain crackers. Double-check labels — **no gelatin, no eggs**, and watch for things like gummies, marshmallows, and some soups/sauces that sneak them in.
- If there's a kettle or coffee setup in the room, she can make herself a cup of tea without rummaging through the kitchen.

**Info and a little warmth**
- A card with the wifi password, thermostat basics, and your family's usual daily rhythm.
- Fresh flowers or a plant, and a short welcome note by name.

The one thing I'd add: leave the room's "identity" blank enough that she can make it hers over a few weeks — a cleared shelf and an empty drawer matter more than fancy decor. Want me to turn this into a printable checklist?

### B

**First, today’s reminder:** It’s Friday, February 5 — register for your spring bridge inspector refresher now if you haven’t already. Registration closes February 12, and the budget is already approved by Julian Moss.

---

For a few-week stay, the guest room should feel functional and private, not just hotel-like for two nights.

**The basics**
- Freshly washed sheets, plus an extra blanket at the foot of the bed
- Two pillows with different firmness if you have them
- Empty hanging space with hangers
- At least one empty drawer or shelf
- Luggage rack or clear bench for her suitcase
- Trash can
- Mirror
- Hamper or laundry bag so she doesn’t have to ask where to put dirty clothes

**Comfort and privacy**
- Reading lamp by the bed
- A comfortable chair if there’s room
- Tissues
- Power strip or charging station near the nightstand
- Extra phone charger if you have one
- Door that closes fully, maybe with a simple way to block light at night

**Welcome touches**
- A bottle of water and a clean glass
- A folded bath towel, hand towel, and washcloth set out
- Small note with the wifi name/password, kitchen basics, and where to find things
- A couple of vegetarian-friendly snacks or tea if she likes that

**For a Colorado February**
- Extra blanket or throw, since Denver nights are cold
- Space heater if the room runs drafty, placed safely
- House slippers or warm socks are a nice touch

Also, about a week before she arrives, have Dev ask her about pillow preference, room temperature, or any specific needs like a nonslip rug or blackout curtains. That question costs nothing and makes a long stay much more comfortable.

### C

Quick reminder first: today (Friday, Feb 5) is the day you asked me to remind you to register for the CDOT spring refresher course. Registration closes **Feb 12** and it fills fast, so try to get it done today.

For the guest room, for a multi-week stay the biggest comfort is **empty space she can make her own**, not extra decor:

- **Storage:** clear out a dresser drawer or two, leave some empty closet space with hangers, and add a luggage rack or bench so she isn't living out of a suitcase.
- **Bed:** fresh sheets, a real blanket plus an extra throw, and two pillows (different firmness if you have them). Ask Dev if she runs hot/cold and add a fan or blanket accordingly.
- **Bedside setup:** a lamp, tissues, a small clock, and a power strip or extension cord with USB ports for her phone/tablet. A card with the WiFi name and password is a nice touch.
- **Toiletries & towels:** a set of towels and washcloths left on the bed, plus a few basics in case luggage gets delayed — toothbrush, soap, lotion, shampoo — and maybe slippers.
- **Bathroom space:** give her a shelf or drawer in the bathroom she’s using, since a few weeks of toiletries need a home.
- **Small comforts:** a water glass or bottle, a small snack that fits her vegetarian diet if you want (fruit, nuts, crackers), and a simple welcome note with house info like where the extra TP and kitchen towels live.
- **Don’t over-fill the surfaces:** leave plenty of open space so she can put out her own things without having to move yours.

One thing worth doing this weekend: do a test-sleep in there or at least check the room at the temperature and light levels she’ll actually experience. Fixing a drafty vent, noisy blinds, or a too-bright morning window now is easier than after she arrives.



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
