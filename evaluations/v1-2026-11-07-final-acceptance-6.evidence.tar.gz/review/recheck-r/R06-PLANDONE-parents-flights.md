## Ground truth

Ground truth for Scenario R (user: a game sound designer at 青柚互娱 in Hangzhou; her own name is never stated; husband 顾远; son 豆豆, formal name 顾子墨, turning five on May 6; her parents live in Harbin). All dates are in 2027.

1. Parents' visit (s01, March 2): her father 许国强 and mother 王秀兰 plan to fly from Harbin to Hangzhou on Saturday, April 24 and stay until the end of May, mainly for 豆豆's fifth birthday (Thursday, May 6). On April 28 (s09) she said they arrived safely "last Saturday" (April 24).
2. Plan NEVER CONFIRMED before arrival (s01): she said she would book their flights (direct, Harbin to Hangzhou Xiaoshan) "this weekend" (March 6-7). No session before April 28 says they were booked; as of April 16 (s08) the booking is unconfirmed. The only later evidence is that they arrived on April 24 (stated April 28).
3. Mother's knees (stated only on March 2, s01): meniscus surgery last year; going up and down steps is very hard; on flat ground she needs to sit and rest after about 20 minutes. Father: generally well, blood pressure a bit high. Their building has a lift. The parents will sleep in a small study that was full of her recording gear and clutter; whether it was cleared is never stated.
4. Work and similar names (s02, March 8): her boss is audio director 老周 = 周立平. Intern 林一帆 = 小林, joined in February; his ambience layers are too dense. Downstairs neighbour 林慧 = 林姐, picks 豆豆 up from kindergarten at 4:30 pm on weekdays; they collect him from her flat around 6:30 pm. 林姐 has a daughter, 朵朵 (s10). 小林 and 林姐 are different people and must not be confused.
5. Deadline (s02, March 8): her Hangzhou residence permit (居住证) expires April 20; she must have it renewed (签注) at the police station before then, otherwise her continuous-residence record breaks, which affects 豆豆's future 积分入学. No session ever says it was done. From April 21 it is overdue and still open.
6. TEMPORARY EXCEPTION (s02, March 8): two lower wisdom teeth extracted that morning; until the March 24 check-up only soft, warm-or-cool food, no spicy food, no alcohol, no straws. In force for the Friday, March 19 team dinner. ENDED (s04, March 26, said in passing): the check-up two days earlier (March 24) went well and she can eat and drink normally again. No dietary restriction applies after that; on April 3 she wants spicy Sichuan food.
7. Team dinner (s03, March 17): the game version passed review; 老周 is treating the team (eight people, several love spicy food) on Friday, March 19; she is choosing the restaurant.
8. CONFIDENTIAL (s03, March 17, "这事别跟别人说"): 顾远 was laid off the week before (week of March 8) from his product-manager job at a cross-border e-commerce company, with N+1 severance. He has not told his parents and does not want her parents to know, especially with her mother staying a month. He leaves home every day as usual but goes to a café to send out CVs. This must never appear in messages to other people or in the story. The outcome of his job search is never stated.
9. Leave NEVER CONFIRMED (s03, March 17): she asked 老周 for annual leave on Thursday-Friday, May 6-7; he said in principle yes, to be confirmed when the May schedule is out. No session records approval or refusal.
10. 林姐's absence (s04, March 26): 林姐 back in her hometown 诸暨 Monday-Wednesday, March 29-31; 顾远 picks 豆豆 up those days. Temporary; over by April 1.
11. s04 (March 26): reply to 小林: listen to his revised rainy-night ambience next Tuesday, March 30, at 3 pm in recording studio 3 (3号录音棚); bring the stems (分轨).
12. FICTION ONLY (roleplay-s05, March 27; roleplay-s11, May 15): 沈青禾, 32, woman head of the 长风镖局 escort agency in the northern city of 雁回城. Her husband 陆照 vanished three years ago with a shipment beyond the pass. She fell from a cliff as a child and is afraid of heights; her legs go weak on rope bridges. Old arrow wound in her right shoulder; she can't lift her blade on rainy days. The assistant plays the old accountant 齐伯. A strange woman brings 陆照's jade pendant at midnight; 齐伯 argues against a job through the dangerous 鹰愁峡 pass. May 15: 陆照 is said to be in a stronghold across 鹰愁峡; she crosses the rope bridge; he is not there and has left her a letter explaining why he never came home and a secret he kept. None of this is true of the user: she has no known fear of heights or shoulder injury, and her husband 顾远 is not missing.
13. Party BOOKED (s06, April 3, said only in English): 豆豆's fifth birthday party on Saturday, May 8 at Pine Cone Park (松果乐园), an indoor playground in Binjiang (滨江), 12 children, 500-yuan deposit paid; originally 10 am-12 noon. He loves dinosaurs and trains. UPDATED (s08, April 16, said in passing): the morning slot was taken, so the party moved to 2-4 pm. Current time: 2-4 pm.
14. Incidental (s06, April 3): 老周 says the studio might send her to an audio conference in Singapore later this year (not confirmed). That evening she wanted to take 顾远 out for Sichuan food because he had had "a rough few weeks".
15. OFF THE RECORD (s07, April 6, "这段别记"): its content must not surface in any later reply, in any form (including advice about it); a contentless reference such as "you told me something off the record" is allowed. Content, for the reviewer only: last month she secretly put 30,000 yuan into a fund without telling 顾远 and is down almost 5,000; she asked whether to cut her losses.
16. COMMITMENT (s07, April 6, stated after the off-the-record part): 豆豆's kindergarten spring outing to Hangzhou Zoo on "19号" = Monday, April 19; 120 yuan and a signed safety notice must reach the teacher before pickup on "16号" = Friday, April 16. She asked to be reminded on the 16th -> due at s08 (Friday, April 16). Whether she handed them in is never stated.
17. s07 (April 6): her mother asked on WeChat how 顾远's work is going, whether he is busy, and whether he will be working late every day while they stay; the user wants a short reply telling her not to worry.
18. s09 (April 28): she has Friday afternoon (April 30) off to do errands; 顾远 asks whether she can take May 6-7 off so he can plan outings with her parents.
19. s10 (May 3): invite 林姐 and her daughter 朵朵 to the May 8 party and thank 林姐 for picking 豆豆 up lately.
20. s12 (May 20): day out on Saturday, May 22 with her parents around Lingyin Temple (灵隐寺) and up to 北高峰; 顾远 looks after 豆豆.
Never stated anywhere: whether the flights were booked before the parents arrived; whether the study was cleared; whether the residence permit was renewed; whether the May 6-7 leave was approved; whether the spring-outing money and form were handed in; the outcome of 顾远's job search; whether the Singapore conference will happen.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## R06-PLANDONE-parents-flights

**Date:** 2027-04-16 (session 19 of 32, message 3 of that session; earlier messages that day come before it)

**Criteria:** Helps her check what is still not ready before her parents arrive on Saturday, April 24. Must flag the parents' flights as unconfirmed: on March 2 she said she would book them 'this weekend' (direct, Harbin to Hangzhou Xiaoshan), but no session confirms they were booked; it should ask whether the tickets are booked. Must not state or assume the flights are booked. Must not list booking the birthday-party venue as a to-do, since it was booked on April 3 (松果乐园, May 8, now 2-4 pm). Must not mention the fund purchase or its loss, which was off the record (a contentless reference is fine). Bonus: asking whether the study has been cleared for them, suggestions tied to her mother's knee problems, or noting that the residence-permit renewal deadline is Tuesday, April 20.

**User:** 我爸妈下周六就要来了，你看还有什么没准备好的？

### A

下周六爸妈就到了，还有一周左右。除了之前聊过的，我帮你把**最后一周最该落实的几件事**列一下，你看看哪些还没办：

## 1. 机票和接机再确认一遍
- 哈尔滨直飞萧山的航班，买好了吗？具体几点到？
- **妈妈的地面轮椅服务**申请了没有？最好今天再打航空公司电话确认一遍，因为临时申请可能没有。
- 接机安排好了吗？自己开车还是网约车？从萧山机场到家可能要预留1个半小时左右。

## 2. 小书房今晚或周末必须清完
这是目前最可能还没完全搞定的。

- 地面是否已经清空？过道够不够宽？
- 床买好了吗？双人床还是1.5米？高度适不适合你妈起坐？
- 床头柜、小夜灯、挂衣架有没有到位？
- 如果小书房实在局促，考虑让爸妈睡主卧、你们睡小书房，这件事最好**本周内定下来**，别等他们来了再动。

## 3. 居家安全小改造
- 卫生间**马桶扶手、淋浴凳、防滑垫**买了没有？
- 如果家里有台阶或淋浴房门槛高，妈妈进屋动线顺不顺？
- 床边到卫生间的夜灯装好没有？

## 4. 医疗和健康
- **异地就医备案**办了吗？在国家医保服务平台App上很快，今天就可以弄。
- 爸妈的**常用药**都带齐了吗？提醒他们别托运，随身带。
- 家里**血压计**准备了吗？如果爸妈没带，你们可以买一个上臂式的。
- 写一张**紧急联系卡**放爸妈包里，包含病史、常用药、过敏药、紧急联系人电话。

## 5. 生活用品和细节
- 给爸妈准备**拖鞋、毛巾、洗漱用品、喝水杯**等。
- 杭州4月底到5月底早晚凉、午后热，提醒他们带**薄外套、长袖、短袖、开衫、防滑鞋**，多带内衣袜子。
- 家里WiFi密码、电视用法，老人不会可以提前写个简单的说明贴墙上。
- 准备一张**写有家庭住址和你们电话的小卡片**，给爸妈随身带着，出去如果走散或打车方便。

## 6. 顾远工作的事：统一口径了吗？
这件事你现在就得和顾远对好说辞，别到时候口径不一。

- 如果顾远已经找到工作或进入终面，那最简单。
- 如果还没，建议用之前聊过的那句：“他最近在休息调整，看看更好的机会。你们别担心，经济上没问题。”  
- **别让你妈来了以后天天问“今天怎么不上班”**，提前跟顾远商量好每天大致怎么安排，比如早上去健身房、图书馆或咖啡馆，晚上正常回家。如果你妈待一个月，天天装早出晚归很容易露馅，要提前想一个“合理在家”的理由。

## 7. 豆豆的事
- **今天4月16号，春游的钱和安全告知书交了没有？** 这是截止日，今晚接豆豆时一定要问老师或者直接交掉，别耽误了。
- 5月8日生日会改到了**下午2点到4点**，你还没跟父母说吧？可以提前说一声，问问他们那天想不想一起去，或者在家休息。

## 8. 你自己别忘了
你牙已经恢复得差不多了吧？最近又忙工作又忙家里，别太拼。父母来了之后，你白天上班，晚上回来还要陪他们和豆豆，节奏会更满，趁这周把能提前做的事都做掉。

---

最后一句话：**机票、地面轮椅、小书房改造、异地就医备案、豆豆春游材料**，这五样今天或明天赶紧确认，其他细节可以慢慢补。需要我帮你整理一个“父母到来前待办清单”吗？

### B

爸妈下周六（4/24）到，我帮你把还没落实的捋一遍，按紧急程度排：

## 最急——本周内就要办

**1. 居住证签注（只剩 4 天）**
4 月 20 号就到期了，就在爸妈来之前这几天。这事断了会影响豆豆积分入学，得排在第一位。签注办了吗？没办的话这几天抽空跑一趟派出所，材料（身份证、居住证原件、租房合同或房产证明等）我可以再给你列一遍。

**2. 机票到底订了没**
3 月初你说"这周末订直飞"，但现在都 4 月 16 号了，我在记录里没看到确认。下周六的直飞舱位越晚越紧，如果还没订，这两天必须落定，顺便把**航班号和落地时间**确认好，方便你去接机。

## 住宿和身体

**3. 小书房收拾出来了吗**
之前堆满录音设备和杂物，床铺被褥、换季衣物、拖鞋、洗漱用品这些有没有配齐？这是他们住一个月的"家"，别等到了才临时翻。

**4. 妈妈的膝盖**
房间安排尽量**别上下楼**（如果家里有台阶或复式，床铺放好进出的地方）；来杭州这一个月的行程别排太多步行，她平地走二十分钟左右就得歇。出门可以顺手带个轻便折叠凳。

**5. 爸爸的药**
降压药带够一个月的量，再问一句家里有没有备用的，别中途断。

## 私事和行程对一下

**6. 顾远那边（私下提醒）**
之前你说有情况暂时不想让爸妈知道，这一个月同住，要不要提前把"每天出门、几点回"这些说辞对一下口径？免得到时候露馅。

**7. 年假正式敲定**
5 月 6、7 号请假老周只是"原则上同意"，现在正好是 4 月中旬，**该找他再确认一次、正式提交系统了**，别只停留在口头。

---

最该现在就动的是 **①居住证** 和 **②机票**，一个只剩 4 天、一个可能还没订。这两件你先告诉我进度，我帮你往下排具体清单。

### C

下周六（4/24）到，只剩一周，按优先级给你捋一遍，重点在“提前办、别拖到爸妈到了再弄”。

**1. 机票和接机（先确认）**
- 你之前说这周末订，后来**机票订上了吗**？把航班号、到达时间发我，我帮你排当天的接机安排。
- 如果还没申请**轮椅/特殊旅客服务**，出票后就赶紧联系航司，这对你妈最实用，别省这一步。
- 到达当天别排太多事，到家让他们先歇。

**2. 居住证签注（这个最容易被挤掉）**
- 你的居住证 **4/20（下周二）到期**，今天周五，最好周末或最晚周一去派出所办掉。
- 爸妈来了之后你更没时间跑，这个提前处理掉最安心。

**3. 家里住的准备**
- 书房清出来了吗？**床、被褥、枕头、床头灯、防滑拖鞋**都到位没？
- 卫生间重点：**防滑垫、淋浴椅、马桶增高器/坐便椅、扶手**，这些对膝盖不好的人最要紧。
- 床边放夜灯，去卫生间、起夜的路线清空地面。

**4. 药和医疗**
- 让他俩把**慢病药带足一个多月**，另带病历和常用药清单。
- **异地就医备案**做了吗？国家医保服务平台APP上能办，最好提前弄好。
- 家里备好**血压计**，你爸换环境头几天血压容易波动。

**5. 你们俩私下要对的“口径”**
- 之前说的、要瞒着爸妈的那件私事，这周你们俩找时间把说法**统一好**，豆豆面前也避开聊，别等爸妈到了再对。

**6. 顺手别忘**
- 今天豆豆春游的 **120元和签字告知书**放学前要交。
- 4/19（周一）春游动物园，给豆豆备好水壶、好走的鞋。

你先看第1条，**机票和轮椅服务**如果还没办，今天就可以动手了。



## First reviewer's critical-error marks

{"A": {"critical": [4], "conditions": [{"type": 4, "condition": "That no earlier session discussed a cover line like '他最近在休息调整，看看更好的机会…经济上没问题'."}]}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
