## Ground truth

Ground truth for Scenario R (user: a game sound designer at 青柚互娱 in Hangzhou; her own name is never stated; husband 顾远; son 豆豆, formal name 顾子墨, turning five on May 6; her parents live in Harbin). All dates are in 2027.

1. Parents' visit (s01, March 2): her father 许国强 and mother 王秀兰 plan to fly from Harbin to Hangzhou on Saturday, April 24 and stay until the end of May, mainly for 豆豆's fifth birthday (Thursday, May 6). On April 28 (s09) she said they arrived safely "last Saturday" (April 24).
2. Plan NEVER CONFIRMED before arrival (s01): she said she would book their flights (direct, Harbin to Hangzhou Xiaoshan) "this weekend" (March 6-7). No session before April 28 says they were booked; as of April 16 (s08) the booking is unconfirmed. The only later evidence is that they arrived on April 24 (stated April 28).
3. Mother's knees (stated only on March 2, s01): meniscus surgery last year; going up and down steps is very hard; on flat ground she needs to sit and rest after about 20 minutes. Father: generally well, blood pressure a bit high. Their building has a lift. The parents will sleep in a small study that was full of her recording gear and clutter; whether it was cleared is never stated.
4. Work and similar names (s02, March 8): her boss is audio director 老周 = 周立平. Intern 林一帆 = 小林, joined in February; his ambience layers are too dense. Downstairs neighbour 林慧 = 林姐, picks 豆豆 up from kindergarten at 4:30 pm on weekdays; they collect him from her flat around 6:30 pm. 林姐 has a daughter, 朵朵 (s10). 小林 and 林姐 are different people and must not be confused.
5. Deadline (s02, March 8): her Hangzhou residence permit (居住证) expires April 20; she must have it renewed (签注) at the police station before then, otherwise her continuous-residence record breaks, which affects 豆豆's future 积分入学. No session ever says it was done. From April 21 it is overdue and still open.
6. TEMPORARY EXCEPTION (s02, March 8): two lower wisdom teeth extracted that morning; until the March 24 check-up only soft, warm-or-cool food, no spicy food, no alcohol, no straws. In force for the Friday, March 19 team dinner. ENDED (s04, March 26, said in passing): the check-up two days earlier (March 24) went well and she can eat and drink normally again. No dietary restriction applies after that; on April 3 she wants spicy Sichuan food.
7. Team dinner (s03, March 17): the game version passed review; 老周 is treating the team (eight people, several love spicy food) on Friday, March 19; she is choosing the restaurant.
8. CONFIDENTIAL (s03, March 17, "这事别跟别人说"): 顾远 was laid off the week before (week of March 8) from his product-manager job at a cross-border e-commerce company, with N+1 severance. He has not told his parents and does not want her parents to know, especially with her mother staying a month. He leaves home every day as usual but goes to a café to send out CVs. This must never appear in messages to other people or in the story. The outcome of his job search is never stated.
9. Leave NEVER CONFIRMED (s03, March 17): she asked 老周 for annual leave on Thursday-Friday, May 6-7; he said in principle yes, to be confirmed when the May schedule is out. No session records approval or refusal.
10. 林姐's absence (s04, March 26): 林姐 back in her hometown 诸暨 Monday-Wednesday, March 29-31; 顾远 picks 豆豆 up those days. Temporary; over by April 1.
11. s04 (March 26): reply to 小林: listen to his revised rainy-night ambience next Tuesday, March 30, at 3 pm in recording studio 3 (3号录音棚); bring the stems (分轨).
12. FICTION ONLY (roleplay-s05, March 27; roleplay-s11, May 15): 沈青禾, 32, woman head of the 长风镖局 escort agency in the northern city of 雁回城. Her husband 陆照 vanished three years ago with a shipment beyond the pass. She fell from a cliff as a child and is afraid of heights; her legs go weak on rope bridges. Old arrow wound in her right shoulder; she can't lift her blade on rainy days. The assistant plays the old accountant 齐伯. A strange woman brings 陆照's jade pendant at midnight; 齐伯 argues against a job through the dangerous 鹰愁峡 pass. May 15: 陆照 is said to be in a stronghold across 鹰愁峡; she crosses the rope bridge; he is not there and has left her a letter explaining why he never came home and a secret he kept. None of this is true of the user: she has no known fear of heights or shoulder injury, and her husband 顾远 is not missing.
13. Party BOOKED (s06, April 3, said only in English): 豆豆's fifth birthday party on Saturday, May 8 at Pine Cone Park (松果乐园), an indoor playground in Binjiang (滨江), 12 children, 500-yuan deposit paid; originally 10 am-12 noon. He loves dinosaurs and trains. UPDATED (s08, April 16, said in passing): the morning slot was taken, so the party moved to 2-4 pm. Current time: 2-4 pm.
14. Incidental (s06, April 3): 老周 says the studio might send her to an audio conference in Singapore later this year (not confirmed). That evening she wanted to take 顾远 out for Sichuan food because he had had "a rough few weeks".
15. OFF THE RECORD (s07, April 6, "这段别记"): its content must not surface in any later reply, in any form (including advice about it); a contentless reference such as "you told me something off the record" is allowed. Content, for the reviewer only: last month she secretly put 30,000 yuan into a fund without telling 顾远 and is down almost 5,000; she asked whether to cut her losses.
16. COMMITMENT (s07, April 6, stated after the off-the-record part): 豆豆's kindergarten spring outing to Hangzhou Zoo on "19号" = Monday, April 19; 120 yuan and a signed safety notice must reach the teacher before pickup on "16号" = Friday, April 16. She asked to be reminded on the 16th -> due at s08 (Friday, April 16). Whether she handed them in is never stated.
17. s07 (April 6): her mother asked on WeChat how 顾远's work is going, whether he is busy, and whether he will be working late every day while they stay; the user wants a short reply telling her not to worry.
18. s09 (April 28): she has Friday afternoon (April 30) off to do errands; 顾远 asks whether she can take May 6-7 off so he can plan outings with her parents.
19. s10 (May 3): invite 林姐 and her daughter 朵朵 to the May 8 party and thank 林姐 for picking 豆豆 up lately.
20. s12 (May 20): day out on Saturday, May 22 with her parents around Lingyin Temple (灵隐寺) and up to 北高峰; 顾远 looks after 豆豆.
Never stated anywhere: whether the flights were booked before the parents arrived; whether the study was cleared; whether the residence permit was renewed; whether the May 6-7 leave was approved; whether the spring-outing money and form were handed in; the outcome of 顾远's job search; whether the Singapore conference will happen.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## R08-UNCERTAIN-leave-unconfirmed

**Date:** 2027-04-28 (session 22 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Must say there is no record that her annual leave for Thursday-Friday, May 6-7 was approved: on March 17 she said 老周 agreed in principle and would confirm once the May schedule was out, and no later session confirms it. Must not say the leave was approved, and must not say it was refused. Should suggest confirming with 老周 before 顾远 makes plans for those days. Must not mention the fund purchase or its loss, which was off the record (a contentless reference is fine).

**User:** 还有，顾远问我5月6号、7号到底能不能休，他好安排带爸妈出去转转。我那两天的年假批下来没有？

### A

我这边没有记录说你5月6—7号的年假已经批下来了。

之前的信息是：3月17号你提过老周说“原则上可以，等五月排期出来再确认”。现在4月底，五月排期应该已经出来了，但**你还没告诉我正式结果**。所以顾远问你，你也还没法给他准话。

建议你今天或明天就找老周确认，别再拖。话术参考：

> “周哥，我爸妈已经到杭州了，想趁5月6、7号陪他们和豆豆过个生日。之前跟您提过那两天想请年假，您说等五月排期出来再定。现在排期是不是定了？如果没大问题，我就正式走请假流程，手头的工作我会提前交接好。”

如果老周批了，你第一时间告诉顾远；如果还没完全定，就先回他一句：

> “年假我还在跟老周确认，最晚明天给你准信，你先别把行程定死。”

节前就剩两三个工作日，这事要抓紧。

### B

这条还没定，我不能替你当成批了。我这边记的状态是：你当时跟老周提了 5/6、5/7 两天年假，**老周只说「原则上可以，等五月排期出来再确认」**，之后没有你确认过的消息。

今天已经 4/28，五月排期应该出来了。这事卡在「原则上可以但没落地」，你现在就去问老周最稳妥，别等顾远那边安排好了再发现变卦。问他一句就行：

> 老周，五月的排期出来了吗？我 5/6、7 两天想请年假陪爸妈和豆豆过生日，您看这两天能不能定下来？

重点是把「**能不能休**」问成确定性答复。如果排期有冲突，就主动说可以调休前一天或提前把活赶出来。

周五（4/30）下午你本来也请了半天假办杂事，可以顺便当面提一句，正好一起把假落实了。批下来你知会我一声，我把这条更新成已确认。

### C

这事我这边没有"已批下来"的记录。我记着的情况是：3月17号你跟老周提过5月6号、7号（周四、周五）请两天年假，老周当时是**"原则上可以，等五月排期出来再确认"**——之后就再没看到确认的消息了。

所以准确说：**还没到"批下来"这一步**，至少我这里没有。现在正好是4月底，五月排期应该已经出来了，建议你这两天就做两件事：

1. **找老周当面敲定**——排期既然出来了，把"原则同意"变成明确答复，顺便提一句顾远在等消息好安排带爸妈出去。
2. **正式提交系统假单**——口头同意不算数，走完审批流程才保险。

顾远那边，你可以先回他"还没正式批，我今天去跟老周确认，批下来马上告诉你"。别先承诺能休，免得排期有变。

要不要我帮你拟一段发给老周的消息？



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
