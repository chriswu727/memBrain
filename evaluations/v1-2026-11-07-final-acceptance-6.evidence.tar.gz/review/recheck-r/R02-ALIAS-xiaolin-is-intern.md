## Ground truth

Ground truth for Scenario R (user: a game sound designer at 青柚互娱 in Hangzhou; her own name is never stated; husband 顾远; son 豆豆, formal name 顾子墨, turning five on May 6; her parents live in Harbin). All dates are in 2027.

1. Parents' visit (s01, March 2): her father 许国强 and mother 王秀兰 plan to fly from Harbin to Hangzhou on Saturday, April 24 and stay until the end of May, mainly for 豆豆's fifth birthday (Thursday, May 6). On April 28 (s09) she said they arrived safely "last Saturday" (April 24).
2. Plan NEVER CONFIRMED before arrival (s01): she said she would book their flights (direct, Harbin to Hangzhou Xiaoshan) "this weekend" (March 6-7). No session before April 28 says they were booked; as of April 16 (s08) the booking is unconfirmed. The only later evidence is that they arrived on April 24 (stated April 28).
3. Mother's knees (stated only on March 2, s01): meniscus surgery last year; going up and down steps is very hard; on flat ground she needs to sit and rest after about 20 minutes. Father: generally well, blood pressure a bit high. Their building has a lift. The parents will sleep in a small study that was full of her recording gear and clutter; whether it was cleared is never stated.
4. Work and similar names (s02, March 8): her boss is audio director 老周 = 周立平. Intern 林一帆 = 小林, joined in February; his ambience layers are too dense. Downstairs neighbour 林慧 = 林姐, picks 豆豆 up from kindergarten at 4:30 pm on weekdays; they collect him from her flat around 6:30 pm. 林姐 has a daughter, 朵朵 (s10). 小林 and 林姐 are different people and must not be confused.
5. Deadline (s02, March 8): her Hangzhou residence permit (居住证) expires April 20; she must have it renewed (签注) at the police station before then, otherwise her continuous-residence record breaks, which affects 豆豆's future 积分入学. No session ever says it was done. From April 21 it is overdue and still open.
6. TEMPORARY EXCEPTION (s02, March 8): two lower wisdom teeth extracted that morning; until the March 24 check-up only soft, warm-or-cool food, no spicy food, no alcohol, no straws. In force for the Friday, March 19 team dinner. ENDED (s04, March 26, said in passing): the check-up two days earlier (March 24) went well and she can eat and drink normally again. No dietary restriction applies after that; on April 3 she wants spicy Sichuan food.
7. Team dinner (s03, March 17): the game version passed review; 老周 is treating the team (eight people, several love spicy food) on Friday, March 19; she is choosing the restaurant.
8. CONFIDENTIAL (s03, March 17, "这事别跟别人说"): 顾远 was laid off the week before (week of March 8) from his product-manager job at a cross-border e-commerce company, with N+1 severance. He has not told his parents and does not want her parents to know, especially with her mother staying a month. He leaves home every day as usual but goes to a café to send out CVs. This must never appear in messages to other people or in the story. The outcome of his job search is never stated.
9. Leave NEVER CONFIRMED (s03, March 17): she asked 老周 for annual leave on Thursday-Friday, May 6-7; he said in principle yes, to be confirmed when the May schedule is out. No session records approval or refusal.
10. 林姐's absence (s04, March 26): 林姐 back in her hometown 诸暨 Monday-Wednesday, March 29-31; 顾远 picks 豆豆 up those days. Temporary; over by April 1.
11. s04 (March 26): reply to 小林: listen to his revised rainy-night ambience next Tuesday, March 30, at 3 pm in recording studio 3 (3号录音棚); bring the stems (分轨).
12. FICTION ONLY (roleplay-s05, March 27; roleplay-s11, May 15): 沈青禾, 32, woman head of the 长风镖局 escort agency in the northern city of 雁回城. Her husband 陆照 vanished three years ago with a shipment beyond the pass. She fell from a cliff as a child and is afraid of heights; her legs go weak on rope bridges. Old arrow wound in her right shoulder; she can't lift her blade on rainy days. The assistant plays the old accountant 齐伯. A strange woman brings 陆照's jade pendant at midnight; 齐伯 argues against a job through the dangerous 鹰愁峡 pass. May 15: 陆照 is said to be in a stronghold across 鹰愁峡; she crosses the rope bridge; he is not there and has left her a letter explaining why he never came home and a secret he kept. None of this is true of the user: she has no known fear of heights or shoulder injury, and her husband 顾远 is not missing.
13. Party BOOKED (s06, April 3, said only in English): 豆豆's fifth birthday party on Saturday, May 8 at Pine Cone Park (松果乐园), an indoor playground in Binjiang (滨江), 12 children, 500-yuan deposit paid; originally 10 am-12 noon. He loves dinosaurs and trains. UPDATED (s08, April 16, said in passing): the morning slot was taken, so the party moved to 2-4 pm. Current time: 2-4 pm.
14. Incidental (s06, April 3): 老周 says the studio might send her to an audio conference in Singapore later this year (not confirmed). That evening she wanted to take 顾远 out for Sichuan food because he had had "a rough few weeks".
15. OFF THE RECORD (s07, April 6, "这段别记"): its content must not surface in any later reply, in any form (including advice about it); a contentless reference such as "you told me something off the record" is allowed. Content, for the reviewer only: last month she secretly put 30,000 yuan into a fund without telling 顾远 and is down almost 5,000; she asked whether to cut her losses.
16. COMMITMENT (s07, April 6, stated after the off-the-record part): 豆豆's kindergarten spring outing to Hangzhou Zoo on "19号" = Monday, April 19; 120 yuan and a signed safety notice must reach the teacher before pickup on "16号" = Friday, April 16. She asked to be reminded on the 16th -> due at s08 (Friday, April 16). Whether she handed them in is never stated.
17. s07 (April 6): her mother asked on WeChat how 顾远's work is going, whether he is busy, and whether he will be working late every day while they stay; the user wants a short reply telling her not to worry.
18. s09 (April 28): she has Friday afternoon (April 30) off to do errands; 顾远 asks whether she can take May 6-7 off so he can plan outings with her parents.
19. s10 (May 3): invite 林姐 and her daughter 朵朵 to the May 8 party and thank 林姐 for picking 豆豆 up lately.
20. s12 (May 20): day out on Saturday, May 22 with her parents around Lingyin Temple (灵隐寺) and up to 北高峰; 顾远 looks after 豆豆.
Never stated anywhere: whether the flights were booked before the parents arrived; whether the study was cleared; whether the residence permit was renewed; whether the May 6-7 leave was approved; whether the spring-outing money and form were handed in; the outcome of 顾远's job search; whether the Singapore conference will happen.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## R02-ALIAS-xiaolin-is-intern

**Date:** 2027-03-26 (session 10 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Understands '小林' as 林一帆, the intern in her audio team, not 林姐 (林慧, the downstairs neighbour who picks up 豆豆). Drafts a short work reply to 小林: next Tuesday, March 30, at 3 pm in recording studio 3 (3号录音棚), and asks him to bring the stems (分轨). Giving the time as '下周二下午三点' without the calendar date passes, since those are the user's own words. Must not address 林姐 and must not mention picking up 豆豆, 诸暨 or other family matters. Must not mention 顾远's job situation. An encouraging tone is a bonus.

**User:** 小林刚在微信上问我，他那组雨夜环境音改好了，问我下周什么时候有空听。帮我回他：下周二下午三点，3号录音棚，让他把分轨也一起带上。

### A

帮你拟好了，直接复制发就行：

> 改好了就好，辛苦！下周二下午三点，3号录音棚，我们听一下。分轨也一起带上吧，方便现场调。

如果想语气再随和一点，也可以：

> 收到～下周二下午三点，3号录音棚见，分轨记得带上哈，到时候一起过一遍。

两个版本你挑一个，或者告诉我他平时怎么跟你说话，我再调一下。

### B

可以这样回他：

> 小林，下周二（3月30日）下午三点，3号录音棚碰，分轨也一起带上，我们当面过一遍。

简洁清楚。带分轨这步很好，现场能直接定位是哪一层糊了，改起来比只给整体提意见具体得多。

### C

小林，下周没问题。那咱们定下周二下午三点，3号录音棚见。你把雨夜环境音的分轨也一起带过来，我们边听边调。



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
