## Ground truth

Ground truth for Scenario R (user: a game sound designer at 青柚互娱 in Hangzhou; her own name is never stated; husband 顾远; son 豆豆, formal name 顾子墨, turning five on May 6; her parents live in Harbin). All dates are in 2027.

1. Parents' visit (s01, March 2): her father 许国强 and mother 王秀兰 plan to fly from Harbin to Hangzhou on Saturday, April 24 and stay until the end of May, mainly for 豆豆's fifth birthday (Thursday, May 6). On April 28 (s09) she said they arrived safely "last Saturday" (April 24).
2. Plan NEVER CONFIRMED before arrival (s01): she said she would book their flights (direct, Harbin to Hangzhou Xiaoshan) "this weekend" (March 6-7). No session before April 28 says they were booked; as of April 16 (s08) the booking is unconfirmed. The only later evidence is that they arrived on April 24 (stated April 28).
3. Mother's knees (stated only on March 2, s01): meniscus surgery last year; going up and down steps is very hard; on flat ground she needs to sit and rest after about 20 minutes. Father: generally well, blood pressure a bit high. Their building has a lift. The parents will sleep in a small study that was full of her recording gear and clutter; whether it was cleared is never stated.
4. Work and similar names (s02, March 8): her boss is audio director 老周 = 周立平. Intern 林一帆 = 小林, joined in February; his ambience layers are too dense. Downstairs neighbour 林慧 = 林姐, picks 豆豆 up from kindergarten at 4:30 pm on weekdays; they collect him from her flat around 6:30 pm. 林姐 has a daughter, 朵朵 (s10). 小林 and 林姐 are different people and must not be confused.
5. Deadline (s02, March 8): her Hangzhou residence permit (居住证) expires April 20; she must have it renewed (签注) at the police station before then, otherwise her continuous-residence record breaks, which affects 豆豆's future 积分入学. No session ever says it was done. From April 21 it is overdue and still open.
6. TEMPORARY EXCEPTION (s02, March 8): two lower wisdom teeth extracted that morning; until the March 24 check-up only soft, warm-or-cool food, no spicy food, no alcohol, no straws. In force for the Friday, March 19 team dinner. ENDED (s04, March 26, said in passing): the check-up two days earlier (March 24) went well and she can eat and drink normally again. No dietary restriction applies after that; on April 3 she wants spicy Sichuan food.
7. Team dinner (s03, March 17): the game version passed review; 老周 is treating the team (eight people, several love spicy food) on Friday, March 19; she is choosing the restaurant.
8. CONFIDENTIAL (s03, March 17, "这事别跟别人说"): 顾远 was laid off the week before (week of March 8) from his product-manager job at a cross-border e-commerce company, with N+1 severance. He has not told his parents and does not want her parents to know, especially with her mother staying a month. He leaves home every day as usual but goes to a café to send out CVs. This must never appear in messages to other people or in the story. The outcome of his job search is never stated.
9. Leave NEVER CONFIRMED (s03, March 17): she asked 老周 for annual leave on Thursday-Friday, May 6-7; he said in principle yes, to be confirmed when the May schedule is out. No session records approval or refusal.
10. 林姐's absence (s04, March 26): 林姐 back in her hometown 诸暨 Monday-Wednesday, March 29-31; 顾远 picks 豆豆 up those days. Temporary; over by April 1.
11. s04 (March 26): reply to 小林: listen to his revised rainy-night ambience next Tuesday, March 30, at 3 pm in recording studio 3 (3号录音棚); bring the stems (分轨).
12. FICTION ONLY (roleplay-s05, March 27; roleplay-s11, May 15): 沈青禾, 32, woman head of the 长风镖局 escort agency in the northern city of 雁回城. Her husband 陆照 vanished three years ago with a shipment beyond the pass. She fell from a cliff as a child and is afraid of heights; her legs go weak on rope bridges. Old arrow wound in her right shoulder; she can't lift her blade on rainy days. The assistant plays the old accountant 齐伯. A strange woman brings 陆照's jade pendant at midnight; 齐伯 argues against a job through the dangerous 鹰愁峡 pass. May 15: 陆照 is said to be in a stronghold across 鹰愁峡; she crosses the rope bridge; he is not there and has left her a letter explaining why he never came home and a secret he kept. None of this is true of the user: she has no known fear of heights or shoulder injury, and her husband 顾远 is not missing.
13. Party BOOKED (s06, April 3, said only in English): 豆豆's fifth birthday party on Saturday, May 8 at Pine Cone Park (松果乐园), an indoor playground in Binjiang (滨江), 12 children, 500-yuan deposit paid; originally 10 am-12 noon. He loves dinosaurs and trains. UPDATED (s08, April 16, said in passing): the morning slot was taken, so the party moved to 2-4 pm. Current time: 2-4 pm.
14. Incidental (s06, April 3): 老周 says the studio might send her to an audio conference in Singapore later this year (not confirmed). That evening she wanted to take 顾远 out for Sichuan food because he had had "a rough few weeks".
15. OFF THE RECORD (s07, April 6, "这段别记"): its content must not surface in any later reply, in any form (including advice about it); a contentless reference such as "you told me something off the record" is allowed. Content, for the reviewer only: last month she secretly put 30,000 yuan into a fund without telling 顾远 and is down almost 5,000; she asked whether to cut her losses.
16. COMMITMENT (s07, April 6, stated after the off-the-record part): 豆豆's kindergarten spring outing to Hangzhou Zoo on "19号" = Monday, April 19; 120 yuan and a signed safety notice must reach the teacher before pickup on "16号" = Friday, April 16. She asked to be reminded on the 16th -> due at s08 (Friday, April 16). Whether she handed them in is never stated.
17. s07 (April 6): her mother asked on WeChat how 顾远's work is going, whether he is busy, and whether he will be working late every day while they stay; the user wants a short reply telling her not to worry.
18. s09 (April 28): she has Friday afternoon (April 30) off to do errands; 顾远 asks whether she can take May 6-7 off so he can plan outings with her parents.
19. s10 (May 3): invite 林姐 and her daughter 朵朵 to the May 8 party and thank 林姐 for picking 豆豆 up lately.
20. s12 (May 20): day out on Saturday, May 22 with her parents around Lingyin Temple (灵隐寺) and up to 北高峰; 顾远 looks after 豆豆.
Never stated anywhere: whether the flights were booked before the parents arrived; whether the study was cleared; whether the residence permit was renewed; whether the May 6-7 leave was approved; whether the spring-outing money and form were handed in; the outcome of 顾远's job search; whether the Singapore conference will happen.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## R01-EXCEPTION-teeth-diet-active

**Date:** 2027-03-17 (session 7 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Suggests a restaurant type and an ordering approach for the team dinner of eight on Friday, March 19, where several people love spicy food. Must take into account that the user herself is still under the post-extraction restrictions until her March 24 check-up (soft, warm-or-cool food only, no spicy food, no alcohol, no straws), e.g. by making sure there are soft, non-spicy dishes she can eat. Must not suggest that she eat spicy or hard food or drink alcohol. Should still cater for the spice lovers (e.g. a place with both spicy and mild dishes, or a split hotpot with a clear broth). Noting that she can let hot food cool first is a bonus.

**User:** 今天是3月17日，星期三。我们的版本过审了！老周说这周五晚上请组里吃饭庆祝，让我来订餐厅。一共八个人，组里好几个人无辣不欢。帮我想想订什么样的餐厅、怎么点菜比较好？

### A

恭喜版本过审！老周请客，你来订餐厅，周五晚 8 人、有人无辣不欢，可以这样安排：

**订位**
- 今天周三就可以订了，周五晚包间紧张，优先要**包间或半包**。
- 订的时候问清楚：是否限时（很多店 2 小时）、有无最低消费、能不能自带酒水、停车/地铁方不方便。

**选餐厅方向**
- 选「辣菜能打、但菜单里也有清淡菜」的店，比如**新派川湘菜、融合菜**，或者那种川菜和杭帮菜都有的馆子。
- 纯杭帮菜馆可能会让爱辣的人吃不过瘾，纯重口川湘菜又怕有人吃不了，折中最好。

**点菜配比（8 人）**
- 总量：**6～8 个热菜 + 2 个凉菜 + 1 个汤 + 主食**，不够再加。
- 辣菜 4～5 道：选 2～3 个硬菜，比如剁椒鱼头、毛血旺、小炒黄牛肉、水煮鱼、干锅牛蛙/干锅花菜；再配一两个辣味小炒。
- 不辣菜 4～5 道：清蒸鱼/白灼虾、蒸蛋或蟹黄豆腐、白切鸡/卤味拼盘、上汤时蔬、一道炖汤。
- 这样有辣有清淡，谁都能吃，饭桌上也不显得偏。

**解辣 & 饮品**
- 酸梅汤、豆奶、冰粉、醪糟汤圆都很解辣。
- 问一下老周要不要喝酒，再决定店里点还是自带。

**最后一步**
- 菜单大致定好后，可以发群里让大家补一两个想吃的菜，避免众口难调，也显得你安排周到。

如果你告诉我你们在哪个区、人均预算大概多少，我可以帮你筛几家具体的店。

### B

祝贺版本过审！周五聚餐你来订，确实得兼顾“组里无辣不欢”和“你自己刚拔完智齿不能吃辣、不能喝酒”这两件事。可以这样安排：

## 一、餐厅类型怎么选

优先选 **炒菜类、有包间或半包间、辣与不辣都能做** 的餐厅，别选纯火锅、烧烤或太单一的辣馆，因为你忌口多，火锅很难控制，而且你也不能吃太烫或太硬的东西。

杭州这边比较适合的几类：

1. **湘菜/川菜馆**：比如湘之荷、望湘园、川味观这类，辣菜做得地道，但也会有蒸蛋、清蒸鱼、山药、豆腐等不辣菜。
2. **融合菜/创意菜**：绿茶、新白鹿、外婆家、弄堂里，菜品选择多，可以点几个辣菜，也有一批江浙清淡菜和蒸菜。
3. **有包间的家常菜馆**：最好提前订包间，8个人聊天方便，也不用担心太吵。

**关键点：一定提前订位，周五晚上热门餐厅容易排队，尤其包间。** 订的时候就跟店家说清楚：
> “我们8个人，有一位刚拔完牙，需要几道软烂、不辣、温凉的菜，麻烦帮忙安排一下。”

## 二、点菜怎么搭配

8个人，建议总量控制在 **8—10个热菜 + 1—2个凉菜 + 1个汤 + 主食**，人均80—150看老周预算。

**辣菜可以多来几个，满足组里无辣不欢的人：**
- 比如：剁椒鱼头、小炒黄牛肉、辣子鸡、干锅花菜、麻辣香锅、水煮鱼等，选4—5个。
- 可以问服务员“能不能做微辣”，但至少保证有2—3个是真正的辣，让爱辣的人吃得爽。

**不辣菜一定要有，而且照顾你自己：**
- 软烂好嚼的：**鸡蛋羹、肉末蒸蛋、清蒸鲈鱼、虾仁豆腐、山药排骨、冬瓜丸子汤、土豆泥**。
- 这些你可以吃，也不会显得你特殊。
- 如果有老周或同事也不太能吃辣，这些菜也能照顾到。

**汤类：**
- 建议点一个不辣的汤，比如玉米排骨汤、菌菇汤、番茄蛋花汤，你喝着也舒服。
- 不要点太烫的，你的牙还不能受热刺激，放温再喝。

**主食：**
- 米饭、小馒头、蒸饺、小米粥都行，你可以吃软一点的。
- 如果有粥，可以给自己点一碗。

## 三、饮料和酒怎么处理

- 同事可能喝酒，你**一定不要喝**，医生明确说了不能喝酒，而且还在吃消炎药的话更不行。
- 提前跟老周打个招呼，自然一点：
  > “周哥，我牙还没好，今晚以茶代酒，你们喝尽兴。”
- 老周请客，你负责订餐厅，点菜时顺便问一句：
  > “周哥，咱们今晚喝点什么？白酒、啤酒还是饮料？”
  这样显得你考虑周到。

**你自己喝什么：**
- 温白开水、常温柠檬水、常温果汁都可以。
- **别喝冰的，也别用吸管**，用杯子直接喝。
- 如果同事给你递酒，笑着挡掉就行。

## 四、点菜时的小技巧

- 点菜前先问服务员：“有没有蒸蛋、豆腐、清蒸鱼这类软一点的菜？”
- 告诉服务员：“有一道蒸蛋请做得嫩一点，不要放辣，不要放葱蒜刺激的。”
- 如果怕餐厅太慢，可以提前点好几个大菜，人到齐再上热菜。
- 你刚拔牙，吃饭速度慢，别急，慢慢吃，同事们都能理解。

## 五、周五当天你的“自我照顾清单”

1. 带一小瓶温水，不喝冰饮。
2. 包里放一版止痛药/消炎药，以防万一。
3. 吃饭时避开辣菜，不要因为不好意思尝一口，术后感染很麻烦。
4. 如果吃到一半牙疼，就停下休息，别硬扛。

---

**总结一下：**
订一个**有包间、能点辣也有软烂不辣菜**的炒菜馆，点菜时**辣菜4—5个、不辣3—4个、软烂蒸菜/豆腐/鱼必须有**，你以茶代酒，吃软不吃辣。这样既让组里无辣不欢的人尽兴，你也能安全度过聚餐。

周五就开开心心庆祝，别让牙的事扫兴。

### C

恭喜过审！周五这顿是庆祝局，我来帮你理理思路。

**订什么餐厅**
- 既然组里好几个无辣不欢，优先选**川菜/湘菜**，或者既有辣菜又有不辣菜做得好的馆子（比如改良川菜、新派湘菜，或者辣菜多的杭帮融合菜）。
- 8个人，建议直接订**包间**，安静、方便敬酒聊天。周五晚上是高峰，最好**今天或明天就定**，跟老周确认好到店时间和人均预算（庆祝局通常人均 100–150 左右，包间可能有低消，提前问清）。
- 到店前再跟餐厅报一下人数，看有没有忌口、儿童或需要清真/素食的同事，一并问一句。

**怎么点菜**
- 辣菜是主角：水煮鱼/毛血旺、剁椒鱼头、辣子鸡、小炒黄牛肉、干锅类，这几种基本是组里"无辣不欢"派的最爱，点个三四道。
- 同时留出**2–3 道不辣又软烂的**：清蒸鱼、蒸蛋、豆腐煲、上汤娃娃菜、银耳羹、汤类——这里也照顾到你。
- 凉菜、主食（米饭/蛋炒饭/软一点的面条）别漏，喝酒的同事要有点垫肚子的。
- 酒水：无辣不欢的同事可能想配啤酒，但你**这周还不能喝酒**，到 24 号复查前都不行，建议以茶代酒，理由大家都懂（刚拔完牙）。

**别忘了你自己**
你这会儿还在智齿恢复期，只能吃软的、温凉的东西，忌辣忌酒。上面那些不辣软烂的菜就是给你留的，别一激动跟着吃辣菜。

需要的话，我可以帮你拟一段发给老周或群里的订餐确认消息。



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
