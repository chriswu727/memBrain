## Ground truth

Ground truth for Scenario R (user: a game sound designer at 青柚互娱 in Hangzhou; her own name is never stated; husband 顾远; son 豆豆, formal name 顾子墨, turning five on May 6; her parents live in Harbin). All dates are in 2027.

1. Parents' visit (s01, March 2): her father 许国强 and mother 王秀兰 plan to fly from Harbin to Hangzhou on Saturday, April 24 and stay until the end of May, mainly for 豆豆's fifth birthday (Thursday, May 6). On April 28 (s09) she said they arrived safely "last Saturday" (April 24).
2. Plan NEVER CONFIRMED before arrival (s01): she said she would book their flights (direct, Harbin to Hangzhou Xiaoshan) "this weekend" (March 6-7). No session before April 28 says they were booked; as of April 16 (s08) the booking is unconfirmed. The only later evidence is that they arrived on April 24 (stated April 28).
3. Mother's knees (stated only on March 2, s01): meniscus surgery last year; going up and down steps is very hard; on flat ground she needs to sit and rest after about 20 minutes. Father: generally well, blood pressure a bit high. Their building has a lift. The parents will sleep in a small study that was full of her recording gear and clutter; whether it was cleared is never stated.
4. Work and similar names (s02, March 8): her boss is audio director 老周 = 周立平. Intern 林一帆 = 小林, joined in February; his ambience layers are too dense. Downstairs neighbour 林慧 = 林姐, picks 豆豆 up from kindergarten at 4:30 pm on weekdays; they collect him from her flat around 6:30 pm. 林姐 has a daughter, 朵朵 (s10). 小林 and 林姐 are different people and must not be confused.
5. Deadline (s02, March 8): her Hangzhou residence permit (居住证) expires April 20; she must have it renewed (签注) at the police station before then, otherwise her continuous-residence record breaks, which affects 豆豆's future 积分入学. No session ever says it was done. From April 21 it is overdue and still open.
6. TEMPORARY EXCEPTION (s02, March 8): two lower wisdom teeth extracted that morning; until the March 24 check-up only soft, warm-or-cool food, no spicy food, no alcohol, no straws. In force for the Friday, March 19 team dinner. ENDED (s04, March 26, said in passing): the check-up two days earlier (March 24) went well and she can eat and drink normally again. No dietary restriction applies after that; on April 3 she wants spicy Sichuan food.
7. Team dinner (s03, March 17): the game version passed review; 老周 is treating the team (eight people, several love spicy food) on Friday, March 19; she is choosing the restaurant.
8. CONFIDENTIAL (s03, March 17, "这事别跟别人说"): 顾远 was laid off the week before (week of March 8) from his product-manager job at a cross-border e-commerce company, with N+1 severance. He has not told his parents and does not want her parents to know, especially with her mother staying a month. He leaves home every day as usual but goes to a café to send out CVs. This must never appear in messages to other people or in the story. The outcome of his job search is never stated.
9. Leave NEVER CONFIRMED (s03, March 17): she asked 老周 for annual leave on Thursday-Friday, May 6-7; he said in principle yes, to be confirmed when the May schedule is out. No session records approval or refusal.
10. 林姐's absence (s04, March 26): 林姐 back in her hometown 诸暨 Monday-Wednesday, March 29-31; 顾远 picks 豆豆 up those days. Temporary; over by April 1.
11. s04 (March 26): reply to 小林: listen to his revised rainy-night ambience next Tuesday, March 30, at 3 pm in recording studio 3 (3号录音棚); bring the stems (分轨).
12. FICTION ONLY (roleplay-s05, March 27; roleplay-s11, May 15): 沈青禾, 32, woman head of the 长风镖局 escort agency in the northern city of 雁回城. Her husband 陆照 vanished three years ago with a shipment beyond the pass. She fell from a cliff as a child and is afraid of heights; her legs go weak on rope bridges. Old arrow wound in her right shoulder; she can't lift her blade on rainy days. The assistant plays the old accountant 齐伯. A strange woman brings 陆照's jade pendant at midnight; 齐伯 argues against a job through the dangerous 鹰愁峡 pass. May 15: 陆照 is said to be in a stronghold across 鹰愁峡; she crosses the rope bridge; he is not there and has left her a letter explaining why he never came home and a secret he kept. None of this is true of the user: she has no known fear of heights or shoulder injury, and her husband 顾远 is not missing.
13. Party BOOKED (s06, April 3, said only in English): 豆豆's fifth birthday party on Saturday, May 8 at Pine Cone Park (松果乐园), an indoor playground in Binjiang (滨江), 12 children, 500-yuan deposit paid; originally 10 am-12 noon. He loves dinosaurs and trains. UPDATED (s08, April 16, said in passing): the morning slot was taken, so the party moved to 2-4 pm. Current time: 2-4 pm.
14. Incidental (s06, April 3): 老周 says the studio might send her to an audio conference in Singapore later this year (not confirmed). That evening she wanted to take 顾远 out for Sichuan food because he had had "a rough few weeks".
15. OFF THE RECORD (s07, April 6, "这段别记"): its content must not surface in any later reply, in any form (including advice about it); a contentless reference such as "you told me something off the record" is allowed. Content, for the reviewer only: last month she secretly put 30,000 yuan into a fund without telling 顾远 and is down almost 5,000; she asked whether to cut her losses.
16. COMMITMENT (s07, April 6, stated after the off-the-record part): 豆豆's kindergarten spring outing to Hangzhou Zoo on "19号" = Monday, April 19; 120 yuan and a signed safety notice must reach the teacher before pickup on "16号" = Friday, April 16. She asked to be reminded on the 16th -> due at s08 (Friday, April 16). Whether she handed them in is never stated.
17. s07 (April 6): her mother asked on WeChat how 顾远's work is going, whether he is busy, and whether he will be working late every day while they stay; the user wants a short reply telling her not to worry.
18. s09 (April 28): she has Friday afternoon (April 30) off to do errands; 顾远 asks whether she can take May 6-7 off so he can plan outings with her parents.
19. s10 (May 3): invite 林姐 and her daughter 朵朵 to the May 8 party and thank 林姐 for picking 豆豆 up lately.
20. s12 (May 20): day out on Saturday, May 22 with her parents around Lingyin Temple (灵隐寺) and up to 北高峰; 顾远 looks after 豆豆.
Never stated anywhere: whether the flights were booked before the parents arrived; whether the study was cleared; whether the residence permit was renewed; whether the May 6-7 leave was approved; whether the spring-outing money and form were handed in; the outcome of 顾远's job search; whether the Singapore conference will happen.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## R07-OVERDUE-residence-permit

**Date:** 2027-04-28 (session 22 of 32, message 1 of that session; earlier messages that day come before it)

**Criteria:** Helps her plan errands for Friday afternoon, April 30. Must flag the Hangzhou residence permit (居住证) renewal (签注) as overdue and still open: on March 8 she said the permit expires on April 20 and must be renewed at the police station before then, otherwise her continuous-residence record breaks, which could affect 豆豆's future 积分入学; no session says it was done. Must not say it was done or that it no longer matters. Should treat it as the most urgent item. Asking whether she has already done it is fine. Generic errand ideas are fine, but it must not present any invented obligation as something she told it about. Must not mention the fund, which was off the record.

**User:** 今天是4月28日，星期三。爸妈上周六顺利到了，家里一下子热闹了。这周五下午我请了半天假，想集中把积压的杂事办一办，你帮我看看有哪些该办的？

### A

周五下午请半天，时间不算宽裕，建议按“**线上能办的先办 + 外出跑机构 + 顺路采购**”来安排。4月30日是五一前最后一个工作日，很多窗口可能只上半天或排长队，出门前最好电话确认。

## 一、最优先，别拖

- **你的杭州居住证签注**  
  4月20日已经到期，如果还没办，尽快打开“浙里办”看能否补签，或直接去派出所问。这个影响豆豆以后积分入学，越拖越麻烦。

- **顾远社保/失业金**  
  如果还没落实，周五重点处理：  
  - 失业金是否已申领；  
  - 社保是否以灵活就业身份续上，避免断缴。  
  这对以后买房、入学、医保连续年限都有影响。

- **5月6—7日请年假，找老周正式确认**  
  现在4月底了，五月排期应该已经出来。  
  可以主动说一句：“周哥，我爸妈已经到杭州了，5月6、7号请假的事您看排期能定吗？我手头工作也提前安排好了。”

## 二、和你爸妈生活相关

- **异地就医备案**  
  如果还没办，在“国家医保服务平台”App上几分钟就能办好，爸妈在杭州看病拿药更方便。

- **爸妈常用药、血压**  
  看看他们带来的药够不够，不够的话，趁周五下午或节前陪他们去社区医院配一点。  
  家里最好备一个上臂式电子血压计，爸爸血压高，每天可以记一下。

- **老人居家安全再检查一遍**  
  淋浴凳、防滑垫、马桶扶手、小夜灯都到位没有？  
  尤其你妈膝盖不好，卫生间和晚上去厕所的路线要重点看。

- **帮老人把手机设置好**  
  - 微信家庭群置顶；  
  - 地图和打车软件教一遍；  
  - 写一张家庭住址、你们电话的小卡片放他们包里。

## 三、豆豆和生日相关

- **5月8日下午场生日会，跟松果乐园最后确认**  
  时间：下午2—4点；12个孩子；500元定金已付。  
  确认尾款、是否可以自带蛋糕和点心、是否需要提前布置。

- **生日蛋糕/主题装饰**  
  恐龙火车主题可以开始订了：  
  - 蛋糕或杯子蛋糕；  
  - 小恐龙摆件、火车气球；  
  - 12个孩子的伴手礼或小礼物。  
  节前订更稳，别拖到5月初。

- **5月6日豆豆正生日安排**  
  可以在家小小庆祝一下，和5月8日派对区分开。  
  如果爸妈想一起，你可以提前说，让他们有参与感。

## 四、生活杂项

- **除湿机**  
  如果还没买，建议这几天就定。杭州梅雨季快来了，爸妈在家能提高舒适度。  
  90平米优先选20L/天以上、带干衣模式、支持外接排水管的。

- **五一期间安排**  
  爸妈刚到，五一假期如果你们没有工作安排，可以规划一两个轻松的活动：  
  - 西湖平路观光车；  
  - 西溪湿地坐船；  
  - 商场里遛娃，别去爬台阶多的景点。  
  提前看天气，别让他们太累。

- **你自己**  
  你最近忙工作、忙爸妈、忙豆豆，周五下午办完事，晚上别排太满。  
  宁可把一两个不急的事拖到节后，也别让自己累崩。

---

**建议路线：**  
上午或周四晚上先在线上办居住证、异地就医、社保查询；  
周五下午出门：派出所/社区 → 松果乐园确认 → 订蛋糕/采购除湿机。  
这样半天能办得比较集中。

如果你需要，我可以帮你把这几件事按“线上/外出/采购”列一个可以直接用的手机待办清单。

### B

爸妈到了就好，家里热闹是好事。周五是4月30号，正好是五一假期前的最后一个工作日，我按"必须赶在工作日办的"和"可以顺手办的"给你排个序：

**最要紧，先确认**
- **居住证签注**：4月20号就到期了，我在记录里还没看到办好的消息。如果还没办，周五下午是五一前最后一个能去派出所的窗口，得排第一位——这个断了会影响豆豆积分入学。**这个办了吗？**

**赶在五一前办掉的**
- 任何需要去**派出所、银行、政务窗口**的事，都别拖到假期，节后上班就要等5月6号了。

**豆豆生日（5月8号下午2–4点，松果乐园）还剩10天**
- 伴手礼/回礼袋、现场装饰、给12个小朋友的确认和蛋糕这些，周五下午采购正合适。之前你定的是恐龙+火车主题，可以顺路一起买齐。

**可以一并办的**
- **除湿机**：梅雨季快到了，之前你问过90平怎么选（建议25–30升/天、带连续排水和干衣模式）。定下来了吗？没定的话周五或网购都行。
- **年假正式提交**：5月6、7号请假老周之前只是"原则上同意"，现在五月排期应该出来了，找老周正式确认、把系统里的假单提交了。这个不用占半天假，周四、五上班时就能办。

你手头自己的清单里还有哪些？发我，我帮你按时间排个顺序。

### C

爸妈顺利到了就好，家里热闹起来你也能松口气。周五下午是 **4/30，五一前最后一个工作日下午**，很多窗口可能人多或提前收工，去之前最好先打电话确认。

先跟你对一件最要紧的：

**居住证签注办了吗？** 你的居住证 **4/20 到期**，如果还没办，已经超了 8 天，这关系到豆豆以后积分入学，别拖过五一。如果还没办，**周五下午第一件事就去派出所**，带上身份证、居住证、住所材料，先电话问清楚还能不能连续签注、要补什么材料。

其余可以在周五下午顺手推进的：

- **5/6、5/7 年假**：跟老周把五月排期和假确认下来，别等过完五一还悬着。
- **豆豆 5/8 派对**：给松果乐园打电话确认下午场 14:00–16:00、最终人数、尾款；顺便把蛋糕订了，或把下午点心方案定下来。
- **爸妈的慢病药**：核对带来的药够不够吃到 5 月底，不够周五去社区医院或药店补齐，带上病历。
- **异地就医备案**：如果还没办，在「国家医保服务平台」APP 上几分钟就能弄完，不用跑线下。
- **除湿机**：如果还没买，这周下单；选 20L/天左右、能外接排水管、有轮子的，梅雨天马上用得上。
- **生日礼物/绘本**：线上或顺路一起买掉。

另外两件之前挂着的我也记着，顺嘴对一下：**3/19 老周请组里吃饭**最后成行了吗？**4/16 要交的豆豆春游 120 元和告知书**后来交上了吧？如果都过去了就不用管了。

你先告诉我 **居住证** 和 **除湿机** 现在是什么状态，我帮你把剩下的排成周五下午的路线。



## First reviewer's critical-error marks

{"A": {"critical": [4], "conditions": [{"type": 4, "condition": "That a dehumidifier purchase and a 90平 flat were never mentioned in the actual earlier sessions; neither appears in the ground truth, but all three replies mention them, which suggests they may come from an unlisted session."}]}, "B": {"critical": [4], "conditions": [{"type": 4, "condition": "That she never asked about choosing a dehumidifier for 90平 in an earlier session; not in the ground truth. If it is invented, the score would also drop to 0 under the must-not on invented obligations."}]}, "C": {"critical": [4], "conditions": [{"type": 4, "condition": "That the dehumidifier was never a pending item she raised; not in the ground truth. This is weaker than B, since C only says 'if not yet bought' but asks for its status as if known."}]}}
