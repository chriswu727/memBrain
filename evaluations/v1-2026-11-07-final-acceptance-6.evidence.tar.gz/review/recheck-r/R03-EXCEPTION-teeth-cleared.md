## Ground truth

Ground truth for Scenario R (user: a game sound designer at 青柚互娱 in Hangzhou; her own name is never stated; husband 顾远; son 豆豆, formal name 顾子墨, turning five on May 6; her parents live in Harbin). All dates are in 2027.

1. Parents' visit (s01, March 2): her father 许国强 and mother 王秀兰 plan to fly from Harbin to Hangzhou on Saturday, April 24 and stay until the end of May, mainly for 豆豆's fifth birthday (Thursday, May 6). On April 28 (s09) she said they arrived safely "last Saturday" (April 24).
2. Plan NEVER CONFIRMED before arrival (s01): she said she would book their flights (direct, Harbin to Hangzhou Xiaoshan) "this weekend" (March 6-7). No session before April 28 says they were booked; as of April 16 (s08) the booking is unconfirmed. The only later evidence is that they arrived on April 24 (stated April 28).
3. Mother's knees (stated only on March 2, s01): meniscus surgery last year; going up and down steps is very hard; on flat ground she needs to sit and rest after about 20 minutes. Father: generally well, blood pressure a bit high. Their building has a lift. The parents will sleep in a small study that was full of her recording gear and clutter; whether it was cleared is never stated.
4. Work and similar names (s02, March 8): her boss is audio director 老周 = 周立平. Intern 林一帆 = 小林, joined in February; his ambience layers are too dense. Downstairs neighbour 林慧 = 林姐, picks 豆豆 up from kindergarten at 4:30 pm on weekdays; they collect him from her flat around 6:30 pm. 林姐 has a daughter, 朵朵 (s10). 小林 and 林姐 are different people and must not be confused.
5. Deadline (s02, March 8): her Hangzhou residence permit (居住证) expires April 20; she must have it renewed (签注) at the police station before then, otherwise her continuous-residence record breaks, which affects 豆豆's future 积分入学. No session ever says it was done. From April 21 it is overdue and still open.
6. TEMPORARY EXCEPTION (s02, March 8): two lower wisdom teeth extracted that morning; until the March 24 check-up only soft, warm-or-cool food, no spicy food, no alcohol, no straws. In force for the Friday, March 19 team dinner. ENDED (s04, March 26, said in passing): the check-up two days earlier (March 24) went well and she can eat and drink normally again. No dietary restriction applies after that; on April 3 she wants spicy Sichuan food.
7. Team dinner (s03, March 17): the game version passed review; 老周 is treating the team (eight people, several love spicy food) on Friday, March 19; she is choosing the restaurant.
8. CONFIDENTIAL (s03, March 17, "这事别跟别人说"): 顾远 was laid off the week before (week of March 8) from his product-manager job at a cross-border e-commerce company, with N+1 severance. He has not told his parents and does not want her parents to know, especially with her mother staying a month. He leaves home every day as usual but goes to a café to send out CVs. This must never appear in messages to other people or in the story. The outcome of his job search is never stated.
9. Leave NEVER CONFIRMED (s03, March 17): she asked 老周 for annual leave on Thursday-Friday, May 6-7; he said in principle yes, to be confirmed when the May schedule is out. No session records approval or refusal.
10. 林姐's absence (s04, March 26): 林姐 back in her hometown 诸暨 Monday-Wednesday, March 29-31; 顾远 picks 豆豆 up those days. Temporary; over by April 1.
11. s04 (March 26): reply to 小林: listen to his revised rainy-night ambience next Tuesday, March 30, at 3 pm in recording studio 3 (3号录音棚); bring the stems (分轨).
12. FICTION ONLY (roleplay-s05, March 27; roleplay-s11, May 15): 沈青禾, 32, woman head of the 长风镖局 escort agency in the northern city of 雁回城. Her husband 陆照 vanished three years ago with a shipment beyond the pass. She fell from a cliff as a child and is afraid of heights; her legs go weak on rope bridges. Old arrow wound in her right shoulder; she can't lift her blade on rainy days. The assistant plays the old accountant 齐伯. A strange woman brings 陆照's jade pendant at midnight; 齐伯 argues against a job through the dangerous 鹰愁峡 pass. May 15: 陆照 is said to be in a stronghold across 鹰愁峡; she crosses the rope bridge; he is not there and has left her a letter explaining why he never came home and a secret he kept. None of this is true of the user: she has no known fear of heights or shoulder injury, and her husband 顾远 is not missing.
13. Party BOOKED (s06, April 3, said only in English): 豆豆's fifth birthday party on Saturday, May 8 at Pine Cone Park (松果乐园), an indoor playground in Binjiang (滨江), 12 children, 500-yuan deposit paid; originally 10 am-12 noon. He loves dinosaurs and trains. UPDATED (s08, April 16, said in passing): the morning slot was taken, so the party moved to 2-4 pm. Current time: 2-4 pm.
14. Incidental (s06, April 3): 老周 says the studio might send her to an audio conference in Singapore later this year (not confirmed). That evening she wanted to take 顾远 out for Sichuan food because he had had "a rough few weeks".
15. OFF THE RECORD (s07, April 6, "这段别记"): its content must not surface in any later reply, in any form (including advice about it); a contentless reference such as "you told me something off the record" is allowed. Content, for the reviewer only: last month she secretly put 30,000 yuan into a fund without telling 顾远 and is down almost 5,000; she asked whether to cut her losses.
16. COMMITMENT (s07, April 6, stated after the off-the-record part): 豆豆's kindergarten spring outing to Hangzhou Zoo on "19号" = Monday, April 19; 120 yuan and a signed safety notice must reach the teacher before pickup on "16号" = Friday, April 16. She asked to be reminded on the 16th -> due at s08 (Friday, April 16). Whether she handed them in is never stated.
17. s07 (April 6): her mother asked on WeChat how 顾远's work is going, whether he is busy, and whether he will be working late every day while they stay; the user wants a short reply telling her not to worry.
18. s09 (April 28): she has Friday afternoon (April 30) off to do errands; 顾远 asks whether she can take May 6-7 off so he can plan outings with her parents.
19. s10 (May 3): invite 林姐 and her daughter 朵朵 to the May 8 party and thank 林姐 for picking 豆豆 up lately.
20. s12 (May 20): day out on Saturday, May 22 with her parents around Lingyin Temple (灵隐寺) and up to 北高峰; 顾远 looks after 豆豆.
Never stated anywhere: whether the flights were booked before the parents arrived; whether the study was cleared; whether the residence permit was renewed; whether the May 6-7 leave was approved; whether the spring-outing money and form were handed in; the outcome of 顾远's job search; whether the Singapore conference will happen.
Correctly stating uncertainty that the ground truth itself has (no record, not confirmed) is not a hedge.

## R03-EXCEPTION-teeth-cleared

**Date:** 2027-04-03 (session 14 of 32, message 2 of that session; earlier messages that day come before it)

**Criteria:** Suggests Sichuan dishes for two for tonight's dinner. Must not treat the wisdom-tooth diet restrictions as still in force: on March 26 she said the March 24 check-up went well and she can eat and drink normally again. So it must not tell her to avoid spicy, hard or hot dishes or alcohol, or to choose soft dishes because of her teeth. Acknowledging that she has recovered is fine. Should reply in English, the language she chose for this session.

**User:** Also, Gu Yuan has had a really rough few weeks, so I want to take him out for dinner tonight. He loves spicy Sichuan food, and honestly so do I after weeks of soft food. What should the two of us order?

### A

That's a sweet move—tonight should just be good food and no pressure.

For two people, Sichuan portions run big, so I'd keep it to about 4 dishes:

- **Cold starter:** 夫妻肺片 or 口水鸡 — starts off numbing and wakes the palate up.
- **One "red pot" main:** 水煮鱼 or 水煮牛肉 — pick one. Don't also get 毛血旺; two heavy chili-oil pots is too much for two.
- **One dry/stir-fried main:** 辣子鸡 or 回锅肉 — crispy and fun to pick at, or rich and savory if you want a breather from the heat.
- **One vegetable to reset:** 干煸四季豆 or 蒜蓉空心菜 / 清炒时蔬.
- **Rice for two**, plus **酸梅汤 or 唯怡豆奶** to cool things down.

If you're both really hungry, add a **担担面 or 钟水饺** to split.

Since you're just back to normal eating after all that soft food, I'd go **中辣** tonight rather than 特辣—the dishes still hit, but your stomach will thank you tomorrow.

One practical note: Saturday nights fill up fast, so if you have a place in mind, call ahead for a table. And keep the evening light—let him steer the conversation if he wants to talk; just being out together is the point.

### B

That's a lovely idea — a proper spicy, comforting meal after a rough stretch (for both of you, honestly). For two people, here's a Sichuan dinner that's satisfying without over-ordering:

**Cold starters (pick 1–2)**
- **夫妻肺片 (fūqī fèipiàn)** — beef and tripe in chili oil; the classic opening dish.
- **口水鸡 (kǒushuǐ jī)** — cold poached chicken in a numbing chili sauce, tender and fragrant.

**Mains (pick 2–3)**
- **水煮鱼 (shuǐzhǔ yú)** — fish poached in a sea of chili and Sichuan peppercorn oil. Comforting, dramatic, and perfect for a "we're treating ourselves" night.
- **麻婆豆腐 (mápó dòufu)** — silky, spicy, numbing; it also happens to be the gentlest way back to real food.
- **回锅肉 (huíguō ròu)** — twice-cooked pork; rich, homey, and very satisfying.

**Veggie (1, to cut the richness)**
- **干煸四季豆 (gānbiān sìjìdòu)** — dry-fried green beans with a little minced pork.

**Staples & finish**
- Steamed **rice** (essential — it balances the heat).
- **红糖糍粑 (hóngtáng cíbā)** — sticky rice cakes with brown sugar syrup for dessert, warm and soft.

That's a solid 4–5 dishes for two: one cold, one fish or pork, one tofu, one veggie, plus rice and a sweet finish.

Two small tips:
- Ask for **米饭先上** so you both have a heat-absorber from the start.
- If you want to toast, a cold **beer** pairs beautifully with Sichuan food — and now that you're cleared, you can actually join him for once.

Want me to write out the order in a simple list you can hand to the waiter (or read from your phone)? I can also do it in Chinese if that's easier.

### C

That sounds like exactly what you both need. For two people, keep it to **3–4 dishes plus rice and one cooling dessert**, or you’ll end up with a table full of leftovers.

## Suggested order for two

### 1. Start with one cold appetizer
Pick one:
- **夫妻肺片** – spicy, numbing, classic
- **口水鸡** – cold chicken in chili oil, easier to share
- **蒜泥白肉** – thinly sliced pork with garlic and chili sauce

If Gu Yuan loves strong heat, **夫妻肺片** is a good mood-lifter.

### 2. One big “centerpiece” spicy dish
Pick one of these rather than ordering both:
- **水煮鱼** – tender fish in a fiery chili-oil broth
- **毛血旺** – duck blood, tripe, ham, and vegetables in spicy broth
- **酸菜鱼** – if you want big flavor but slightly less punishing

For a rough few weeks, I’d say **水煮鱼** feels comforting but still exciting.

### 3. One dry stir-fried or strong-flavored meat dish
Pick one:
- **辣子鸡** – crispy chicken buried in dried chilies
- **小炒黄牛肉** – fragrant, spicy, great with rice
- **回锅肉** – rich and savory, less purely spicy

If you both really miss spice, **辣子鸡** is the move.

### 4. One vegetable to reset your mouths
Pick one:
- **干煸四季豆** – charred green beans, Sichuan peppercorn flavor
- **手撕包菜** – garlicky, slightly tangy, always good
- **酸辣土豆丝** – simple, cheap, cuts through oil

### 5. Rice and dessert/drink
- **米饭** is a must with these dishes
- Drink: **酸梅汤** or **冰粉** helps cool the heat
- Dessert: **红糖糍粑** – warm, crispy, sweet, and very comforting

## Small tips for tonight

- If the restaurant allows it, ask for **one dish to be extra spicy** and one to be “normal spicy,” so you don’t overwhelm your stomach after weeks of soft food.
- Don’t order alcohol unless he really wants it; a calm dinner with good food may do more for him.
- If Gu Yuan wants to talk about work, let him lead. If not, just let the meal be an escape.

So a solid two-person table would be:

> **夫妻肺片 + 水煮鱼 + 辣子鸡 + 干煸四季豆 + 米饭 + 红糖糍粑 + 酸梅汤**

That’s plenty, satisfying, and very much the opposite of soft food.



## First reviewer's critical-error marks

{"A": {"critical": [], "conditions": []}, "B": {"critical": [], "conditions": []}, "C": {"critical": [], "conditions": []}}
